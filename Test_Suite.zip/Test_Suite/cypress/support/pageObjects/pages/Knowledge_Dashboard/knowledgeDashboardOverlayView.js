
const knowledgeDashboard = '[class="p-treenode p-treenode-leaf ng-star-inserted"]'
const knowledge = '[class="p-element p-datatable-tbody"]'
const crossIcon = '[id="knowledge-sidebar-close"]'
const editButton = '[id="knowledge-sidebar-edit"]'
const viewButton = '[id="knowledge-sidebar-view"]'
const knowledgeDetails = '[id="knowledge-overlay-container"]'
const knowledgeDetailsPage = '[class="h-100"]'
const myKnowlwdgeDashboard = '[id="Dashboard"]' 

import AssertionConstants from "../../../../support/pageObjects/pages/AssertionConstants"
const assertionContants = new AssertionConstants()

class KnowledgeDashboardOverlayView {
    knowledgeDashboardSelected(){
        cy.get(knowledgeDashboard).eq(1).find('div').first().should(assertionContants.haveAttributeAssertion,'class',"p-treenode-content p-treenode-selectable p-highlight")
    }

    firstKnowledgeSelect(){
        cy.get(knowledge).last().find('tr').eq(0).find('td').eq(1).click()
    }

    crossIconVisible(){
        cy.get(crossIcon).should(assertionContants.beVisibleAssertion)
    }

    editButtonVisible(){
        cy.get(editButton).should(assertionContants.beVisibleAssertion)
    }

    viewButtonVisible(){
        cy.get(viewButton).should(assertionContants.beVisibleAssertion)
    }

    viewButtonClick(){ 
        cy.get(viewButton).click() 
    }

    secondKnowledgeSelect(){
        cy.get(knowledge).last().find('tr').eq(1).find('td').eq(1).click()
    }

    knowledgeDetailsVisible(){
        cy.get(knowledgeDetails).should(assertionContants.beVisibleAssertion)
    }

    knowledgeDetailsPageVisibel(){
        cy.get(knowledgeDetailsPage).should(assertionContants.beVisibleAssertion)
    }

    myKnowlwdgeDashboard(){
        cy.get(myKnowlwdgeDashboard).last().click()
    }

}

export default KnowledgeDashboardOverlayView;