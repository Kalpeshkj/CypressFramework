

/// <reference types="Cypress" />
/// <reference types = 'cypress-tags' />

import "../../../support/index"
import { Then } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../support/commands';

import NavigationPanel from "../../../support/pageObjects/pages/Dashboard/NavigationPanel";
const navigationPanel = new NavigationPanel();

Then("Application Name: {string} should be displayed", (pagetitle) => {
    navigationPanel.displayAppName(pagetitle)
    console.log(printTimestamp(), 'Application Name displayed')
});

Then("Pattern Should be in Expanded State", () => {
    navigationPanel.patternExpanded()
    console.log(printTimestamp(), ' Verified Pattern is in Expanded State')
});

Then("Dashboard should be in selected state", () => {
    navigationPanel.selectedDashboard()
    console.log(printTimestamp(), 'Verified Dashboard in selected state')
});

Then("Close Application", () => {
    cy.log('Test case executed successfully')
    console.log(printTimestamp(), 'Test case executed successfully')
});
