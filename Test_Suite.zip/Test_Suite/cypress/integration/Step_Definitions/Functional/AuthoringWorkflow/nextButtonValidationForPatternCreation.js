/// <reference types="Cypress" />
/// <reference types='cypress-tags' />

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();
var arr = [];

And("verifies next button should be disabled", () => {
    createPattern.nextButtonDisabledVerification()
    console.log(printTimestamp(), ' Next button verified as disabled')

});

And("User hover mouse on Next Button and verify tooltip message", () => {

    console.log(printTimestamp(), ' Tooltip message verified')
});

And("User should be able to enter Pattern Name and Pattern description", () => {
    cy.PatternCreation()
    cy.readFile('cypress/fixtures/patternNameCreation.json').then(function (result) {
        var PatternName = result.name;
        createPattern.patternName().type(PatternName);
    });
    createPattern.description().type(Cypress.env("PatternDescription"));
    console.log(printTimestamp(), ' PatternName and Description Added')
});

And("User should be able to Import Data Model by selecting from drop down option", () => {
    createPattern.importDataModelAction()
    console.log(printTimestamp(), ' Import Data Model Added')
});

And("User selects action from drop down", () => {
    createPattern.addAction()
    console.log(printTimestamp(), ' Action selected from drop down')
});

When("User Clicks on Add Condition and select option from dropdown options", () => {
    createPattern.addConditionInPattern()
    console.log(printTimestamp(), ' Add Condition Added')
});

Then("Verifies Next button should be enabled When all following fields are filled", () => {
    createPattern.nextButtonEnabledVerification()
    console.log(printTimestamp(), ' Next Button verified as enabled')
});

And("User should be able to click on next button if all mandatory data are filled", () => {
    createPattern.nextButtonClick()
    console.log(printTimestamp(), ' Verified next button is clickable')
});

When("Clicks on Previous button and remove any one of mandatory filed data", () => {
    createPattern.previousButtonClick()
    createPattern.removeAction()
    console.log(printTimestamp(), ' Previous button clicked and removed one fields data')
});

Then("verifies next button should be disabled", () => {
    createPattern.nextButtonDisabledVerification()
    console.log(printTimestamp(), '  Verified next button as disabled')
});

When("User re enters data for all mandatory fields", () => {
    createPattern.addAction()
    console.log(printTimestamp(), ' Mandatory details re entered in pattern')
});

Then("Next button is enabled", () => {
    createPattern.nextButtonEnabledVerification()
    console.log(printTimestamp(), ' Next button verified as enabled')
});

And("User should navigate to Apply Metadata", () => {
    createPattern.nextButtonClick()
    createPattern.applyMetadataActiveVerification()
    console.log(printTimestamp(), ' Navigated to apply metedata section')
});

And("Navigate to Create Pattern Workflow and Click on Save as draft", () => {
    createPattern.previousButtonClick()
    createPattern.saveAsDraftButtonClick()
    cy.DeleteWorkflow()
    console.log(printTimestamp(), ' Save as draft clicked')
});

And("Repeat above steps by filling data in any order for each field", () => {
    createPattern.myPatternThreeDotsClick()
    createPattern.createPatternClick()
    cy.PatternCreation()
    cy.readFile('cypress/fixtures/patternNameCreation.json').then(function (result) {
        var PatternName = result.name;
        createPattern.patternName().type(PatternName);
    });
    createPattern.description().type(Cypress.env("PatternDescription"));
    createPattern.addAction()
    createPattern.importDataModelAction();
    createPattern.addConditionInPattern()
    console.log(printTimestamp(), ' Above steps repeated')
});

And("Next button should be enabled", () => {
    createPattern.nextButtonEnabledVerification()
    console.log(printTimestamp(), ' Verified next button as enabled')
});

And("Close DAW application", () => {
    cy.DeleteWorkflow()
    cy.log("Test Case Executed Successfully")
    console.log(printTimestamp(), ' Test Case Executed Successfully')
});
