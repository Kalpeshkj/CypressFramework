/// <reference types="Cypress" />
/// <reference types='cypress-tags' />

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();
import IncludeKnowlegePage from "../../../../support/pageObjects/pages/PatternAuthoring/includeKnowledgepageObj";
const includeKnowlegePage = new IncludeKnowlegePage();

When("User Navigate to my pattern dashbard", () => {
    createPattern.myPatternsSectionCollapseIconClick();
    createPattern.myPatternDashboardClick();
    console.log(printTimestamp(), ' Navigated to my pattern dashbard')
});

Then('Verifies the 3 vertical dots in the dashboard', () => {
    createPattern.myPatternThreeDotsVisible();
    console.log(printTimestamp(), ' Verified 3 vertical dots in the dashboard')
});

When("Launch DAW application with User2", () => {
    cy.reload()
    console.log(printTimestamp(), ' DAW application launched with User2')
});

Then("Clicks on create pattern option and verify created wf", () => {
    cy.wait(3000)
    createPattern.myPatternThreeDotsClick();
    createPattern.createPatternClick();
    createPattern.createPatternHeadingActiveVerification();
    console.log(printTimestamp(), ' Clicked on create pattern option')
});

Then("Rename and delete same workflow", () => {
    createPattern.breadcumbLastValueCapture()
    createPattern.NewPatternThreeDotsClick();
    createPattern.renameOptionClick();
    createPattern.renameTextBoxType();
    createPattern.renamedPopUptextVisible();
    cy.wait(2000)
    cy.DeleteWorkflow()
    console.log(printTimestamp(), ' Renamed and deleted same workflow')
});

When("User Navigate to Include knowledge page and verify Add Knowledge hyper link", () => {
    cy.createPattern()
    createPattern.nextButtonClick()
    cy.ApplyMetaDetaPageCompletion()
    createPattern.nextButtonClick()
    includeKnowlegePage.addKnowledgeHyperlinkVisible()
    console.log(printTimestamp(), ' Navigate to Include knowledge page and verified Add Knowledge hyper linkd')
});

Then("Navigate to step 4 validate and verify message displayed in page", () => {
    createPattern.ShowCheckboxClick();
    createPattern.recordSelectionInIncludeKnowledge();
    createPattern.nextButtonClick();
    createPattern.validateHeadingActiveVerification();
    createPattern.SaveAsDraftClick();
    console.log(printTimestamp(), ' Navigated to step 4 validate and verify message displayed in page')
});

Then('Navigate to my pattern dashbard', () => {
    createPattern.myPatternDashboardClick();
    console.log(printTimestamp(), ' Navigated to my pattern dashbard')
});

Then("Navigate to workflow and navigate to Include Knowledge page", () => {
    cy.createPattern()
    createPattern.nextButtonClick()
    cy.ApplyMetaDetaPageCompletion()
    createPattern.nextButtonClick()
    console.log(printTimestamp(), ' Navigated to workflow and navigated to Include Knowledge page')
});

And('Verifies Add Knowledge hyper link in include knowledge page', () => {
    includeKnowlegePage.addKnowledgeHyperlinkVisible()
    console.log(printTimestamp(), ' Verified Add Knowledge hyper link in include knowledge page')
});