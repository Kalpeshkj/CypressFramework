import AssertionConstants from "../../../../support/pageObjects/pages/AssertionConstants"
const assertionConstants = new AssertionConstants();

const knowledgenames = []
//constants
const knowledgeDetail1 = "Description ";
const knowledgeDetail2 = "Symptoms";
const knowledgeDetail3 = "Causes and Solutions";
const raiseAlertAction = ' Raise Alert '
const ModalityDXR = 'DXR'
const ServiceContextFSE = 'FSE'
const SeverityCriticalNeed = '1-Critical Need'
const dignosticsText = 'Diagnostics'
const [arrOne, newArr, textArr] = [[], [], []]
const filePath = 'cypress/fixtures/patternNameCreation.json'
//locators
const includeKnowledgePage = " Include Knowledge ";
const patternName = "dls-layout-container>ul>li>a>span";
const dropdownFilter = 'dls-dropdown[role="listbox"]';
const filterForKeyword = 'input[placeholder="Search by Keyword"]';
const firstKnowledge = " Check the motor voltage ";
const secondKnowledge = 'div>span[class="p-checkbox-icon"]';
const nameFilter = 'input[placeholder="Search"]';
const tagsfilter = 'p-multiselect[defaultlabel="All"]';
const clearAllFiltersButton = "#clear-all-filter";
const previousButton = 'button[id="pat-step-prev"]';
const closeButton = "#pat-close";
const saveAsDraftButon = "#pat-draft";
const nextButton = "#pat-step-next";
const recordsCount = 'span[id="record-count"]';
const entriesPerPageText = " Entries per page: ";
const entriesPerPageCount = ".pt-quiet.pt-dropdown.ng-untouched.ng-pristine.ng-valid";
const pageSelectionInformation = 'section[class="showing"]';
const arrowSymbol = 'button[tabindex="-1"]';
const KnowledgeSelectionFromDropDown = 'li[aria-label="AWS"]';
const applyButton = "#tags_applyBtn";
const filteredKnowledge = ' td[class="p-element p-resizable-column ng-star-inserted"]';
const filteredKnowledgeRow2 = '  td[class="p-element auto-column-width p-resizable-column ng-star-inserted"]';
const clearFilterOption = "#clear-all-filter";
const firstKnowledgeRow = 'td[id="f4a03b65-912d-4267-b6bc-0addd40ac4b1"]';
const fullScreenButton = ".pt-image.pt-image-left.ng-star-inserted";
const collapsedNavigationPanel = 'a[id="Patterns"]';
const fullScreenKnowledgeButton = ".pt-image.pt-image-left.ng-star-inserted";
const expandedDetailOrReviewSection = 'div[id="authoring-patterns-body"]';
const selectMoreThanOneKnowlwdge = ".p-checkbox-box.p-component";
const reviewTab = 'span[class="p-tabview-title ng-star-inserted"]';
const crossMark = ".item-icon.pt-close-icon.icon-dls-cross.font-18.pt-icon";
const knowledgeDetailDecriptionInReviewTab = ".accordian-header.multiline-content.ng-star-inserted";
const knowledgeDetailSymptomsInReviewTab = ".custom-header.ng-star-inserted";
const knowledgeDetailCausesAndSolutionsInReviewTab = ".custom-header.ng-star-inserted";
const knowledgeNameInDetailsSection = 'p[id="knowledge-name"]';
const saveKnowledgeButton = 'button[id="pat-draft"]';
const message = "TESTDATAPATTERN: Workflow Saved Successfully";
const includeTab = 'span[class="p-tabview-title ng-star-inserted"]';
const addKnowledgeHyperlink = 'span[class="btn-link"]';
const knowledgeOption = " Create ";
const workFlowMessage = "Workflow Created Successfully";
const dropdownValuesVerification = "dls-option-list>dls-option"
const causeNameColumnType = "#causeName_searchIcon"
const addactionPlusIcon = "#add-action-btn > .pt-layout-container";
const addActionTab = "//span[contains(text(),'Add Action')]";
const adConditionTab = "//span[contains(text(),'Add Condition')]";
const attributeForCause = "section>dls-dropdown";
const mandatoryClass = '.mandatory';
const knowledgeResults = 'span[class="p-checkbox-icon"]';
const createPatternTab = '#step-0';
const addAction = "//span[contains(text(),'Raise Alert')]";
const applyMetadataTab = '#step-1'
const applyMetadataFields = 'dls-layout-container[class="pt-layout-container"]>span'
const includeKnowledgeTab = '#step-2'
const selectedKnowledge0 = '#selected_knowledge_0'
const selectedKnowledge1 = '#selected_knowledge_1'
const actionList = '#action-list'
const serviceContextList = "//p[contains(text(),'FSE')]"
const severityList = "//p[contains(text(),'1-Critical Need')]"
const knowledgeTitle = "//span[contains(text(),'Knowledge')]"
const fullscreenViewIcon = 'button img[alt="logo"]'
const collapseButton = 'img[alt="Expand"]'
const descriptionSection = "//span[contains(text(),'Description')]"
const symptomsSection = "//div[contains(text(),'Symptoms')]"
const causesAndSolutionSection = "//div[contains(text(),'Causes and Solutions')]"
const tagsSection = "//div[contains(text(),'Tags')]"
const saveButton = "#knowledge-save"
const savebutton = "#pat-draft"
const knowledgeNameType = '#labelName'
const fullscreenExpandIconInKnowledgeView = 'button img[alt="Expand"]'
const fullscreenCollapseIconInKnowledgeView = 'button img[alt="Collapse"]'
const causeDropdown = 'dls-dropdown[role="listbox"]'
const causeDropdownOptions = 'dls-option[role="option"]'
const knowledgeInfo = "//span[contains(text(),'Knowledge Information')]"
const selectSymptomsButtonInAddSymptomSection = "#select-symptom"
const NextButtonInPattern = '#pat-step-next'
const descriptionType = "#description"
const patternNameField = "#labelName";
const description = "#description";
const infoIcon = "span[class='pt-icon icon-dls-info info-icon-color info-icon ng-star-inserted']"
const versionIcon = "dls-label[class='version-info pt-label']"
const draftInfo = "span[class='version-info']"
const draftIcon = "dls-layout-container img[alt='Version']"
const expandIcon = "dls-layout-container img[alt='Expand']"
const includeTabInKnowledge = "#p-tabpanel-0-label"
const reviewTabInKnowledge = "#p-tabpanel-1-label"
const addKnowledgeText = "#include-tab p"
const addKnowledgeTextVerification = ' Search for a Knowlegde or click on "Show All" to view all available Knowledge. '
const causeDropdownText = 'dls-dropdown[role="listbox"] span'
const sortingIcon = 'p-sorticon i'
const totalResults = 'tr>td span[class="p-checkbox-icon"]'
const nextPageNavigationIcon = 'dls-icon[class="pt-icon icon-dls-navigation-right custom-right-icon"]'
const previousPageNavigationIcon = 'dls-icon[class="pt-icon icon-dls-navigation-left custom-left-icon"]'
const knowledgeColumn = '#Name'
const tagsColumninKnowledge = '#Tags'
const showAllCheckbox = '#es-show-all-checkbox input[class="pt-input"]'
const knowledgeColumnRecords1 = '//tbody/tr[1]/td[2]/span[1]'
const knowledgeColumnRecords2 = '//tbody/tr[2]/td[2]/span[1]'
const recordsCheckboxCount = 'tr>td[id="-checkbox"]'
const selectButton = 'span[class="dialog-button"]'
const selectedSymptomsPreviewSection = 'div[class="preview-section"]'
const richTextEditorSection = "//div[@id='']"
const tickButton = '#tick-1';
const deleteCauseFromList = 'button[dlstooltip="Delete"]';
let textArrey = [""]
let sortedDataArrey = [""]
const saveAsDraft = '[id="pat-draft"]'
const dataInGrid = ' [class="p-element p-datatable-tbody"]'
const KnowledgwSelectcheckBox = 'span[class="p-checkbox-icon"]'
const TitleWithRightMark = '[id="steps-list"]'
const Tab = '[class="p-tabview-title ng-star-inserted"]'
const next = 'button[id="pat-step-next"]'
const saveAsAfterClick = '[class="opacity-05 pt-button ng-star-inserted"]'
const confirmationPopUpHeader = '[id="dialog-title"]'
const confirmationPopUpDialog = '[id="dialog-body"]'
const popUpcancelButton = '[id="cancel-btn"]'
const okButtonOnPopUp = '[id="ok-btn"]'
const breadCrumbForMyPatternDashboard = '[class="pt-breadcrumb"]'
const myPatternDashboard = '[class="p-treenode-content p-treenode-selectable p-highlight"]'
const removeKnowledgeIcon = '[id="remove-icon"]'
const existingWF = '[class="p-treenode-children ng-star-inserted"]'
const addedAdditionalKnowledge = ' Ask the customer to complete '
const searchedResults = '[class="p-element p-selectable-row ng-star-inserted"]'
const firstSelectedKnowledgeText = "  Check the motor voltage";
const KnowledgeTextInRightSection = '[id="knowledge-name"]';
const iconToCollaspeRightSideSection = '[id="knowledge-view-toggle-icon"]';
const KnowledgeDetailsTextWhenRightSideCollapse = '[class="collapse-label ng-star-inserted"]';
const iconToExpandRightSideSection = 'button[id="knowledge-view-toggle-icon"]';
const knowledgeDetailslable = '"Knowledge Details"';
const showAllNameCheckBoxClick = '[class="p-checkbox p-component"]';
const detaInReviewTabGrid = '[id="knowledge-list"]';
const firstKnowledgwSelectInReviewTab = '[id="selected_knowledge_0"]';
const secondKnowledgeInReviewTab = '[id="selected_knowledge_1"]';
const KnowledgeDetailsTextWhenRightSideCollapseInReviewTab = '[class="knowledge-details col-md-9 h-100 width-3"]';
const knowledgeDetailsReviewTab = '[class="accordion-view ng-star-inserted"]';
const knowledgeDetailsInIncludeTab = '[class="col-md-6 rightView ng-star-inserted"]';
const lastSelectedKnowledge = '[class="p-element p-selectable-row ng-star-inserted p-highlight"]>td>span'

// constants
const knowledgeDescription = 'Description '
const knowledgeSymptom = 'Symptoms'
const knowledgeCauseAndSolution = 'Causes and Solutions'
const knowledgeTags = 'Tags'
const accordionsInIncludeKnoeledgePage = '[class="mar-left-1 knowledge-accordion pt-accordion"]'
const collapsableAndExpandableIcon = '[class*="pt-expander-chevron"]'
const descriptionDetails = '[id="auditInfo"]'
const reviewTabWithKnowledgeCount = '[class="p-tabview-title ng-star-inserted"]'
const knowledgeNameHeader = '[class="font-sans-book font-14 pt-list-header"]'
const firstKnowledgeInLeftSection = '[id="selected_knowledge_0"]'
const secondKnowledgeInLeftSection = '[id="selected_knowledge_1"]'
const descriptionAccordions = '[id="auditInfo"]'
const selectedKnowledgeDetails = '[class="mar-left-1 knowledge-accordion pt-accordion"]'
const crossMarkOfFirstKnowaledge = '[class="item-icon pt-close-icon icon-dls-cross font-18 pt-icon"]'
const knowledgeDescriptionInrewviewTab = '[class="accordian-header multiline-content ng-star-inserted"]'
const removedKnowledge = '[class="p-checkbox-box p-component"]'
const fullScreenButtonInIncludeTab = '[id="knowledge-details-fullview-icon"]'
const rightSectionInFullScreenView = '[class="row h-100 mar-0 include-tab"]'
const leftPane = '[class="dashboard_box"]'
const fullScreenViewButtonAtPatternLevel = '[class="pt-quiet-default icon-fullscreen pl-0 pt-button"]'
const leftPaneCollapsed = '[class="dashboard_container"]'
const allButtons = '[id="authoring-patterns-btns"]'
const searchButton = '[placeholder="Search"]'
const detailsOfDescriptionInReviewTab = '[class="pt-expander-content ng-tns-c82-32 ng-trigger ng-trigger-isExpanderContentExpanded"]'
const causeAndSolution = '[class="custom-header ng-star-inserted"]'
const detailsOfCauseAndSolutionInIncludeTab = '[class="preview-section"]'
const causeNameAndRemoveIcon = 'ul>li>span'
const disabledClass = 'opacity-05 pt-button ng-star-inserted'
const enabledClass = 'pt-primary pt-button ng-star-inserted'
const dlsExpanderClass = 'dls-expander'
const sectionExpandedClass = "pt-expander ng-star-inserted pt-expanded"
const ExpandedClass = "pt-expander pt-expanded ng-star-inserted"
const tagsColumnDropDown = 'p-multiselect[defaultlabel="All"]'
const tagsColumnMultiDropDown = 'div[class="p-checkbox-box"]'
const tagsColumnMultiDropDownClearButton = '#tags_clearBtn'
const tagsFirstRecord = '//tbody/tr[2]/td[3]/span'
const tagsSecondRecord = '//tbody/tr[1]/td[3]/span'
const tagsColumnFilterByType = "input[role='textbox']"
const crossIconInSelectSymptoms = "button[class='pt-clear-button']>.icon-dls-cross-circle.pt-icon"
const searchIconInSelectSymptom = "dls-icon[class='icon-dls-search pt-icon']"
const recordsFound = "#record-count"
const entriesPerPage = 'section[class="pt-entries-per-page"]'
const spanTextCapture = 'p-multiselectitem>li>span'
const dropDownNextToCommonSearch = '[role="listbox"]'
const searchIconInCommonSearch = '[class="pt-search-button"]'
const commonSearchBoxWithText = '[id="search-field"]'
const dropDownOptionsUnderDropdownNextToCommonSearch = '[role="option"]'
const xmarkInSearchTextBox = '[class="icon-dls-cross-circle pt-icon"]'
const selectAllCheckBox = '[id="selectall_checkbox"]'
const columnLevelTagsFilter = '[filterplaceholder="Filter Options"]'
const diaomAndInteroperabilityTag = '[aria-label="FV==DICOM and Interoperability"]'
const searchIconInNameFilter = '[class="icon-dls-search pt-icon"]'
const awsTag = '[aria-label="AWS"]'
const dicomTag = '[aria-label="DICOM/RIS/PACS"]'
const showAllOption = 'input[class="pt-input"]';
const recordsFoundTextVerification = "#record-count.font-14"
const recordsFoundText = 'records found'
const navigationPanel = 'div[class="dashboard_left active"]'
const symptomNameColumnField = "#symptomName_searchIcon";
const popUpOkButton = "#ok-btn";
const NextButtonInKnowledge = '#knowledge-step-next'
const patternDashboardBreadCrum = '[class="pt-breadcrumb"]'
const ptLayoutContainerClass = '[class="pt-layout-container"]'
const searchButtonOfSearchByKeyWord = 'button[class="pt-search-button"]'
const knowledgeList = '.p-element.p-datatable-tbody td '
const tagColumnInIncludeKnowledge = '#column_tags'
const tagColumnFirstRecord = '#multiselect-filter div>div[class]'
const tagColumnValues = 'ul[role="listbox"] span[class="ng-star-inserted"]'
const checkboxesAtColumn = '.p-multiselect-header > .p-checkbox > .p-checkbox-box'
const tagsRecords1 = ':nth-child(1) > .auto-column-width > .ng-star-inserted'
const knowledgeNameColumn = '#knowledgeName_searchIcon'
const multiselectFilter = '#multiselect-filter span'
const knowledgePatternRecordsCheckbox = '.p-checkbox-icon'
const firstRecord = "p-tablecheckbox"
const loadingSymbol = '[class="pt-progress-indicator-rotate"]'
const validateHeading = "#step-3"
const popUpMessage = ' Press Cancel to wait until the workflow is saved to avoid losing changes in case of failure or OK to continue. '
const firstRecordcheckedcheckBox = '[aria-checked="true"]'

let arr1 = []

class IncludeKnowledge {
    // Constants
    enabledButtons = 'Previous - enabled,Close - enabled,Save as Draft - enabled,Next - enabled'
    
    savedKnowledgeDetailsVisible() {
        return cy.get(reviewTabInKnowledge).find('span').invoke('text').should('include','Review (3)')
    }
    multipleKnowledgeSelectionFromRecords() {
        cy.get(knowledgePatternRecordsCheckbox).eq(1).click()
        cy.get(knowledgePatternRecordsCheckbox).eq(2).click()
        cy.get(knowledgePatternRecordsCheckbox).eq(3).click()
      }
    commonFilterType() {
        cy.get(filterForKeyword).scrollIntoView().click({force:true}).type('Test{enter}')
    }
    commonSearchNameClear() {
        cy.get(filterForKeyword).clear()
    }
    knowledgeNameColumnClear() {
        return cy.get(knowledgeNameColumn).clear()
    }
    knowledgeNameColumnType() {
        return cy.get(knowledgeNameColumn).scrollIntoView().type('- Perform SAM_CleaIDS Not {enter}')
    }
    selectedTagsVisible() {
        return cy.get(tagsRecords1).scrollIntoView().should(assertionConstants.beExistAssertion);
    }
    tagColumnAllValueSelectionClick() {
        cy.get(checkboxesAtColumn).first().scrollIntoView().click()
        cy.get(applyButton).click()
    }
    multipleTagsSelectionFromDropdown() {
        cy.get(tagColumnValues).eq(1).click();
        cy.get(tagColumnValues).eq(2).click()
        cy.get(applyButton).click()
      }
    tagColumnBesideTheBoxClick() {
        cy.get(applyButton).click()
    }
    tagColumnFirstValueClick() {
        cy.get(tagColumnValues).first().click();
        cy.get(applyButton).click()
    }
    tagsClearButtonVisible() {
        cy.get(tagsColumnMultiDropDownClearButton).should(assertionConstants.beVisibleAssertion)
    }
    tagsColumnFirstValueSelectedNotVisible() {
        cy.get(tagColumnFirstRecord).eq(2).invoke('text').should('not.include','Collimeter')
    }
    tagsColumnFirstValueSelectedVerification() {
        cy.get(tagColumnFirstRecord).eq(2).invoke('text').should('include','AWS')
    }
    tagsColumnMultipleValueSelectedVerification() {
        cy.get(tagColumnFirstRecord).eq(2).invoke('text').should('include','AWS, DAP/Collimator, Detector')
    }
    tagColumnInIncludeKnowledgeClick() {
        return cy.get(tagColumnInIncludeKnowledge).click()
    }
    tagColumnInIncludeKnowledgeForceClick() {
        cy.get(tagColumnInIncludeKnowledge).scrollIntoView()
        return cy.get(multiselectFilter).scrollIntoView().click({force:true})
    }
    knowledgeOptionVisible() {
        return cy.contains(knowledgeOption).should(assertionConstants.beVisibleAssertion)
    }
    crossMarkVisible() {
        return cy.get(crossMark).should(assertionConstants.beVisibleAssertion)
    }
    knowledgeDetail1Visible() {
        return cy.contains(knowledgeDetail1).should(assertionConstants.beVisibleAssertion)
    }
    knowledgeDetail2Visible() {
        return cy.contains(knowledgeDetail2).should(assertionConstants.beVisibleAssertion)
    }
    knowledgeDetail3Visible() {
        return cy.contains(knowledgeDetail3).should(assertionConstants.beVisibleAssertion)
    }
    clearFilterOptionClick() {
        return cy.get(clearFilterOption).click()
    }
    saveAsDraftButtonVisible() {
        return cy.get(saveAsDraftButon).should(assertionConstants.beVisibleAssertion)
    }
    closeButtonVisible() {
        return cy.get(closeButton).should(assertionConstants.beVisibleAssertion)
    }
    firstKnowledgeVisible() {
        return cy.contains(firstKnowledge).should(assertionConstants.beVisibleAssertion)
    }
    nameFilterVisible() {
        return cy.get(nameFilter).should(assertionConstants.beVisibleAssertion)
    }
    tagsFilterVisible() {
        return cy.get(tagsfilter).should(assertionConstants.beVisibleAssertion)
    }
    dropdownFilterVisible() {
        return cy.get(dropdownFilter).should(assertionConstants.beVisibleAssertion)
    }
    applyFilterOnMultipleColumnsLevelForSelectCause() {
        cy.get(causeNameColumnType).type('Testing{enter}')
        cy.get(tagsColumnDropDown).click()
        cy.get(tagsColumnMultiDropDown).eq(1).click()
        cy.get(applyButton).click()
    }
    applyFilterOnMultipleColumnsLevel() {
        cy.get(symptomNameColumnField).type('Test{enter}')
        cy.get(tagsColumnDropDown).click()
        cy.get(tagsColumnMultiDropDown).eq(1).click()
        cy.get(applyButton).click()
    }
    searchIconInSelectSymptomClick() {
        cy.get(searchIconInSelectSymptom).eq(0).click()
    }
    commonDropdownClick() {
        cy.get(causeDropdown).eq(0).click()
        cy.get(causeDropdownOptions).eq(1).click()
    }
    entriesPerPageVisible() {
        cy.get(entriesPerPage).should(assertionConstants.beVisibleAssertion)
    }
    recordsFoundVisible() {
        cy.get(recordsFound).should(assertionConstants.beVisibleAssertion)
    }
    searchedDataVisible() {
        cy.get('td>span').eq(0).should(assertionConstants.beVisibleAssertion)
    }
    searchIconInSelectSymptomVisible() {
        cy.get(searchIconInSelectSymptom).eq(1).should(assertionConstants.beVisibleAssertion)
    }
    crossIconInSelectSymptomsVisible() {
        cy.get(crossIconInSelectSymptoms).should(assertionConstants.beVisibleAssertion)
    }
    crossIconInSelectSymptomsClick() {
        cy.get(crossIconInSelectSymptoms).click()
    }
    crossIconInSelectSymptomClick() {
        cy.get(crossIconInSelectSymptoms).eq(1).click()
    }
    tagsColumnFilterByTypeVerification() {
        cy.get(tagsColumnFilterByType).type('Detector')
        cy.get(tagsColumnMultiDropDown).eq(1).click()
        cy.get(applyButton).click()
    }
    tagsColumnFilterForSelectAllValuesVerification() {
        cy.get(tagsColumnMultiDropDown).eq(1).click()
        cy.get(applyButton).click()
    }
    dropdownPopUpNotExistVerification() {
        cy.get(applyButton).should(assertionConstants.notExistsAssertion)
    }
    symptomTagsMultiValuesDropdownVerification() {
        cy.get(tagsColumnMultiDropDown).each(($el) => {
            cy.wrap($el).scrollIntoView().should(assertionConstants.beVisibleAssertion)
        })
        cy.get(tagsColumnMultiDropDownClearButton).should(assertionConstants.beVisibleAssertion)
        cy.get(applyButton).should(assertionConstants.beVisibleAssertion)
    }
    symptomTagsSingleValueClickFromDropdown() {
        cy.get(tagsColumnMultiDropDown).eq(1).click()
        cy.get(spanTextCapture).eq(0).invoke('text').then((value) => {
            arr1.length = 0;
            arr1.push(value)
            cy.wait(2000)
            cy.log(arr1)
        })
        cy.get(applyButton).click()
    }
    symptomTagsSingleMultipleClickFromDropdown() {
        cy.get(tagsColumnDropDown).click()
        cy.get(tagsColumnMultiDropDown).eq(1).click()
        cy.get(spanTextCapture).eq(0).invoke('text').then((value) => {
            arr1.length = 0;
            arr1.push(value)
            cy.wait(2000)
        })
        cy.get(tagsColumnMultiDropDown).eq(2).click()
        cy.get(spanTextCapture).eq(1).invoke('text').then((value) => {
            arr1.push(value)
            cy.wait(2000)
        })
        cy.get(applyButton).click()
    }
    filteredDataVerification() {
        cy.wait(2000)
        cy.log(arr1)
        cy.xpath(tagsFirstRecord).invoke('text').should('include', arr1[0])
    }
    filteredataVerification() {
        cy.wait(2000)
        cy.log(arr1)
        cy.xpath(tagsSecondRecord).invoke('text').should('include', arr1[0])
    }
    filteredDataVerificationForMultplefilters() {
        cy.xpath(tagsFirstRecord).should(assertionConstants.beVisibleAssertion)
    }
    symptomTagsColumnDropdownClearButtonClick() {
        cy.get(tagsColumnMultiDropDownClearButton).click()
    }
    symptomTagsColumnDropdownClick() {
        cy.get(tagsColumnDropDown).click()
    }
    symptomNameAndTagsColumnFiltersTypeVerification() {
        cy.get(symptomNameColumnField).should(assertionConstants.beVisibleAssertion)
        cy.get(tagsColumnDropDown).should(assertionConstants.beVisibleAssertion)
    }
    causeNameAndTagsColumnFiltersTypeVerification() {
        cy.get(causeNameColumnType).should(assertionConstants.beVisibleAssertion)
        cy.get(tagsColumnDropDown).should(assertionConstants.beVisibleAssertion)
    }
    commonFilterClickAndType() {
        cy.get(filterForKeyword).type('Test{enter}')
    }
    causeNameAndRemoveIconNotVisible() {
        cy.get(causeNameAndRemoveIcon).should(assertionConstants.notExistsAssertion)
    }

    viewDetailsTabActiveVerification() {
        return cy.get(applyMetadataTab).should(assertionConstants.haveAttributeAssertion, 'class', 'ng-star-inserted active')
    }
    knowledgeNameTypeInKnowledgeDetails() {
        cy.readFile(filePath).then(function (result) {
            let PatternName = result.name;
            cy.get(knowledgeNameType).type(PatternName);
        });
    }
    knowledgeInfoTabClick() {
        cy.xpath(knowledgeInfo).click()
    }
    nextButtonClick() {
        cy.get(NextButtonInKnowledge).click()
    }
    deleteCauseFromListClick() {
        cy.get(deleteCauseFromList).eq(3).click()
        cy.get(popUpOkButton).click()
    }
    tickButtonClick() {
        cy.get(tickButton).click()
    }
    richTextEditorSectionVerification() {
        cy.xpath(richTextEditorSection).should(assertionConstants.beVisibleAssertion)
    }

    selectedSymptomsPreviewSectionVerification() {
        // cy.xpath(symptoms).click()
        cy.get(selectedSymptomsPreviewSection).should(assertionConstants.beVisibleAssertion)
    }
    addedSymptomsPreviewSectionVerification() {
        cy.get(selectedSymptomsPreviewSection).eq(1).should(assertionConstants.beVisibleAssertion)
    }
    firstRecordsCheckboxClick() {
        cy.get(recordsCheckboxCount).eq(1).click()
        cy.get(selectButton).click()
    }
    recordsCheckboxCountVerification() {
        cy.wait(2000)
        cy.get(recordsCheckboxCount).should(assertionConstants.havelengthAssertion, 10)
    }
    clearAllFilterButtonClick() {
        return cy.get(clearAllFiltersButton).click()
    }
    nameColumnSortingOfDataVerification() {
        cy.get(knowledgeColumn).click();
        cy.xpath(knowledgeColumnRecords1).invoke('text').then((value) => {
            cy.wait(2000)
            textArrey.length = 0
            textArrey.push(value.slice(0, 1))
        });
        cy.xpath(knowledgeColumnRecords1).invoke('text').then((value) => {
            sortedDataArrey.length = 0
            cy.wait(2000)
            sortedDataArrey.push(value.slice(0, 1))
        });
        cy.log(textArrey)
        cy.log(sortedDataArrey)
        if (textArrey >= sortedDataArrey) {
            cy.log("Data is sorted as descending");
        }
        else {
            cy.log("Data is sorted as ascending");
        }
        cy.get(knowledgeColumn).click();
        cy.xpath(knowledgeColumnRecords1).invoke('text').then((valueTwo) => {
            cy.wait(2000)
            textArrey.length = 0
            textArrey.push(valueTwo.slice(0, 1))
        });
        cy.xpath(knowledgeColumnRecords2).invoke('text').then((valueOne) => {
            sortedDataArrey.length = 0
            cy.wait(2000)
            sortedDataArrey.push(valueOne.slice(0, 1))
        });
        cy.log(textArrey)
        cy.log(sortedDataArrey)
        if (textArrey >= sortedDataArrey) {
            cy.log("Data is sorted as ascending");
        }
        else {
            cy.log("Data is sorted as descending");
        }
    }
    nameColumnClick() {
        cy.get(knowledgeColumn).click()
    }

    knowledgeDetailsVerification() {
        cy.get(knowledgeColumn).should(assertionConstants.beVisibleAssertion)
        return cy.get(tagsColumninKnowledge).should(assertionConstants.beVisibleAssertion)
    }
    showingResultsVerificationAfterPreviousPageClick() {
        return cy.get(pageSelectionInformation).invoke('text').should('include', ' Showing 1 of')
    }
    previousPageNavigationIconVisibleandClick() {
        cy.get(previousPageNavigationIcon).should(assertionConstants.beVisibleAssertion)
        return cy.get(previousPageNavigationIcon).click()
    }
    showingResultsVerificationAfterNextPageClick() {
        return cy.get(pageSelectionInformation).invoke('text').should('include', ' Showing 2 of')
    }
    nextPageNavigationIconVisibleandClick() {
        cy.get(nextPageNavigationIcon).should(assertionConstants.beVisibleAssertion)
        return cy.get(nextPageNavigationIcon).click()
    }
    totalResultsCountVerification() {
        cy.get(totalResults).should(assertionConstants.havelengthAssertion, 'eq', '20')
    }
    EntriesPerPageCountChange() {
        cy.get(causeDropdownText).eq(1).click({ force: true })
        cy.get(causeDropdownOptions).eq(2).click({ force: true })
    }
    sortingIconInAscendingOrderVisible() {
        return cy.get(sortingIcon).eq(0).should(assertionConstants.haveAttributeAssertion, 'class', 'p-sortable-column-icon pi pi-fw pi-sort-amount-up-alt')
    }
    entriesPerPageTextVisible() {
        return cy.contains(entriesPerPageText).should(assertionConstants.beVisibleAssertion)
    }
    clearAllFilterButtonVisible() {
        return cy.get(clearAllFiltersButton).should(assertionConstants.beVisibleAssertion)
    }
    totalNumberOfRecordsVisible() {
        return cy.get(pageSelectionInformation).should(assertionConstants.beVisibleAssertion)
    }
    dropdownWithByDefaultAllSelectedVisible() {
        cy.get(causeDropdown).should(assertionConstants.beVisibleAssertion)
        cy.get(causeDropdownText).eq(0).invoke('text').should('eq', 'All')
    }
    showAllCheckBoxVisible() {
        return cy.get(showAllCheckbox).should(assertionConstants.beVisibleAssertion)
    }
    addKnowledgeHyperlinkVisible() {
        return cy.get(addKnowledgeHyperlink).should(assertionConstants.beVisibleAssertion)
    }
    addKnowledgeTextVisible() {
        return cy.get(addKnowledgeText).invoke('text').should('include', addKnowledgeTextVerification)
    }
    includeTabInKnowledgeByDefaultSelectedVisible() {
        return cy.get(includeTabInKnowledge).should(assertionConstants.haveAttributeAssertion, 'aria-selected', 'true')
    }
    includeTabInKnowledgeVisible() {
        return cy.get(includeTabInKnowledge).should(assertionConstants.beVisibleAssertion)
    }
    reviewTabInKnowledgeVisible() {
        return cy.get(reviewTabInKnowledge).should(assertionConstants.beVisibleAssertion)
    }
    previousButtonEnabledVerification() {
        return cy.get(previousButton).should(assertionConstants.haveAttributeAssertion, 'class', 'ng-star-inserted pt-button')
    }
    closeButtonEnabledVerification() {
        return cy.get(closeButton).should(assertionConstants.haveAttributeAssertion, 'class', 'pt-button')
    }
    saveAsDraftButonEnabledVerification() {
        return cy.get(saveAsDraftButon).should(assertionConstants.haveAttributeAssertion, 'class', 'opacity-05 ng-star-inserted pt-button')
    }
    nextButtonDisabledVerification() {
        return cy.get(nextButton).should(assertionConstants.haveAttributeAssertion, 'class', disabledClass)
    }
    expandIconVisible() {
        cy.get(expandIcon).should(assertionConstants.beVisibleAssertion)
    }
    draftIconVisible() {
        cy.get(draftIcon).should(assertionConstants.beVisibleAssertion)
    }
    draftInfoVisible() {
        cy.get(draftInfo).should(assertionConstants.beVisibleAssertion)
    }
    versionIconVisible() {
        return cy.get(versionIcon).should(assertionConstants.beVisibleAssertion)
    }
    infoIconVisible() {
        return cy.get(infoIcon).should(assertionConstants.beVisibleAssertion)
    }
    patternNameMandatoryVisible() {
        return cy.get(patternNameField).should(assertionConstants.beVisibleAssertion)
            .parentsUntil(mandatoryClass).should(assertionConstants.beVisibleAssertion)
    }
    descriptionMandatoryVisible() {
        return cy.get(description).should(assertionConstants.beVisibleAssertion)
            .parentsUntil(mandatoryClass).should(assertionConstants.beVisibleAssertion)
    }

    nextButtonEnabled() {
        cy.get(NextButtonInPattern).should(assertionConstants.beVisibleAssertion)
        return cy.get(NextButtonInPattern).should(assertionConstants.haveAttributeAssertion, 'class', enabledClass)
    }
    nextButtonEnabledInKnowledge() {
        cy.get(NextButtonInKnowledge).should(assertionConstants.beVisibleAssertion)
        return cy.get(NextButtonInKnowledge).should(assertionConstants.haveAttributeAssertion, 'class', enabledClass)
    }

    saveasDraftClick() {
        return cy.get(savebutton).click()
    }
    saveAsDraftClick() {
        return cy.get(saveButton).click()
    }
    nameAndDescriptionExpandedVerification() {
        cy.xpath(knowledgeInfo).should(assertionConstants.beVisibleAssertion)
        cy.get(descriptionType).should(assertionConstants.beVisibleAssertion)
    }

    selectedKnowledgeNotVisible() {
        cy.get(selectedKnowledge0).scrollIntoView().should(assertionConstants.beVisibleAssertion)
        cy.get(selectedKnowledge1).scrollIntoView().should(assertionConstants.beVisibleAssertion)
    }
    fullscreenCollapseIconInKnowledgeViewClick() {
        return cy.get(fullscreenCollapseIconInKnowledgeView).scrollIntoView().click({ force: true })
    }
    fullscreenViewIconInKnowledgeViewClick() {
        return cy.get(fullscreenExpandIconInKnowledgeView).scrollIntoView().click({ force: true })
    }

    rightSideSectionVerification() {
        cy.xpath(descriptionSection).scrollIntoView().should(assertionConstants.beVisibleAssertion)
        cy.xpath(symptomsSection).scrollIntoView().should(assertionConstants.beVisibleAssertion)
        cy.xpath(causesAndSolutionSection).scrollIntoView().should(assertionConstants.beVisibleAssertion)
        cy.xpath(tagsSection).scrollIntoView().should(assertionConstants.beVisibleAssertion)
    }
    collapseButtonVisible() {
        return cy.get(collapseButton).scrollIntoView().should(assertionConstants.beVisibleAssertion)
    }
    fullscreenViewIconVisible() {
        return cy.get(fullscreenViewIcon).eq(2).should(assertionConstants.beVisibleAssertion)
    }
    fullscreenViewIconClick() {
        return cy.get(fullscreenViewIcon).eq(2).click()
    }
    selectedKnowledgeVisible() {
        cy.get(selectedKnowledge0).should(assertionConstants.beVisibleAssertion)
        cy.get(selectedKnowledge1).should(assertionConstants.beVisibleAssertion)
    }
    knowledgeTitleVisible() {
        return cy.xpath(knowledgeTitle).should(assertionConstants.beVisibleAssertion)
    }
    selectedKnowledge1Click() {
        return cy.get(selectedKnowledge1).click()
    }
    savedDetailsVerificationFromDashboardNavigation() {
        cy.get(actionList).invoke('text').should('contains', raiseAlertAction)
        cy.xpath(serviceContextList).invoke('text').should('contains', ServiceContextFSE)
        cy.xpath(severityList).invoke('text').should('contains', SeverityCriticalNeed)
    }
    savedDetailsVerification() {
        cy.get(createPatternTab).click()
        cy.xpath(addAction).should(assertionConstants.beVisibleAssertion)
        cy.get(applyMetadataTab).click()
        cy.wait(3000)
        cy.get(applyMetadataFields).eq(1).invoke('text').should('include', 'CT')
        cy.get(applyMetadataFields).eq(2).invoke('text').should('include', dignosticsText)
        cy.get(applyMetadataFields).eq(3).invoke('text').should('include', ServiceContextFSE)
        cy.get(applyMetadataFields).eq(4).invoke('text').should('include', SeverityCriticalNeed)
        cy.get(includeKnowledgeTab).click()

    }
    saveAsDraftButtonClick() {
        return cy.get(saveAsDraftButon).click()
    }

    knowledgeResultsSelection() {
        const knowledges = (value) => cy.get(knowledgeResults).eq(value).click()
        knowledges(1)
        knowledges(2)
    }

    showAllCheckboxClick() {
        return cy.get(showAllOption).click()
    }
    addActionTabNotInExpandedVerification() {
        cy.get(addactionPlusIcon).should('not.exist')
    }
    addActionTabClickAndExpandedVerification() {
        cy.xpath(addActionTab).click();
        cy.get(addactionPlusIcon).should(assertionConstants.beVisibleAssertion)
    }
    adConditionTabMandatoryVisible() {
        return cy.xpath(adConditionTab).should(assertionConstants.beVisibleAssertion)
            .siblings(mandatoryClass).should(assertionConstants.beVisibleAssertion)
    }
    addActionTabMandatoryVisible() {
        return cy.xpath(addActionTab).should(assertionConstants.beVisibleAssertion)
            .siblings(mandatoryClass).should(assertionConstants.beVisibleAssertion)
    }
    importDataModelMandatoryVisible() {
        return cy.xpath(importdatamodelTab).should(assertionConstants.beVisibleAssertion)
            .siblings(mandatoryClass).should(assertionConstants.beVisibleAssertion)
    }

    selectSymptomsHeadingVisible() {
        return cy.xpath(selectSymptomsHeading).should(assertionConstants.beVisibleAssertion)
    }
    selectSymptomsButtonClick() {
        return cy.get(selectSymptomsButtonInAddSymptomSection).click({ force: true })
    }
    causeNameColumnType() {
        return cy.get(causeNameColumnType).type('Testing{enter}')
    }
    attributeClickForClaus() {
        cy.get(attributeForCause).eq(0).click()
        cy.get(dropdownValuesVerification).eq(2).click()
    }

    causesAndSolutionsClick() {
        return cy.contains(knowledgeDetail3).click()
    }
    causesAndSolutionsVisible() {
        return cy.contains(knowledgeDetail3).should(assertionConstants.beVisibleAssertion)
    }

    includeKnowledgePage() {
        return cy.contains(includeKnowledgePage).should(assertionConstants.beVisibleAssertion).and('not.be.disabled')
    }

    patternName() {
        return cy.get(patternName)
    }

    dropdownFilter() {
        return cy.get(dropdownFilter)
    }

    filterForKeyword() {
        return cy.get(filterForKeyword)
    }

    showAllOption() {
        return cy.get(showAllOption)
    }

    checkBox() {
        return cy.get(showAllOption)
    }

    firstKnowledge() {
        return cy.contains(firstKnowledge)
    }

    secondKnowledge() {
        return cy.contains(secondKnowledge)
    }
    nameFilter() {
        return cy.get(nameFilter)
    }

    tagsFilter() {
        return cy.get(tagsfilter)
    }

    clearAllFilterButton() {
        return cy.get(clearAllFiltersButton)
    }

    previousButton() {
        return cy.get(previousButton)
    }

    closeButton() {
        return cy.get(closeButton)
    }

    saveAsDraftButton() {
        return cy.get(saveAsDraftButon)
    }

    nextButton() {
        return cy.get(nextButton)
    }

    recordsCount() {
        return cy.get(recordsCount)
    }

    entriesPerPageText() {
        return cy.contains(entriesPerPageText)
    }

    entriesPerPageCount() {
        return cy.get(entriesPerPageCount)
    }

    pageSelectionInformation() {
        return cy.get(pageSelectionInformation)
    }

    arrowSymbol() {
        return cy.get(arrowSymbol)
    }

    tagsfilter() {
        return cy.get(tagsfilter)
    }

    knowledgeFromDropDown() {
        return cy.get(KnowledgeSelectionFromDropDown)
    }

    applyButton() {
        return cy.get(applyButton)
    }

    filteredKnowledges() {
        return cy.get(filteredKnowledge)
    }
    filteredKnowledgesRow2() {
        return cy.get(filteredKnowledgeRow2)
    }

    clearFilterOption() {
        return cy.get(clearFilterOption)
    }

    firstKnowledgeRow() {
        return cy.get(firstKnowledgeRow)
    }

    firstKnowledgeRowClick() {
        return cy.get(firstKnowledgeRow).eq(0).click()
    }

    secondKnowledgwSelect() {
        return cy.get(secondKnowledge).eq(2).click()
    }

    knowledgeDetail1() {
        return cy.contains(knowledgeDetail1)
    }

    knowledgeDetail2() {
        return cy.contains(knowledgeDetail2)
    }

    knowledgeDetail3() {
        return cy.contains(knowledgeDetail3)
    }

    fullScreenButton() {
        return cy.get(fullScreenButton)
    }

    collapsedNavigationPanel() {
        return cy.get(collapsedNavigationPanel)
    }

    expandedDetailOrReviewSection() {
        return cy.get(expandedDetailOrReviewSection)
    }

    fullScreenKnowledgeButton() {
        return cy.get(fullScreenKnowledgeButton)
    }

    selectMoreThanOneKnowlwdge() {
        return cy.get(selectMoreThanOneKnowlwdge)
    }

    reviewTab() {
        return cy.get(reviewTab)
    }

    knowledgeNameInDetailsSection() {
        return cy.get(knowledgeNameInDetailsSection)
    }

    crossMark() {
        return cy.get(crossMark)
    }


    knowledgeDetailDecriptionInReviewTab() {
        return cy.get(
            knowledgeDetailDecriptionInReviewTab)
    }


    knowledgeDetailSymptomsInReviewTab() {
        return cy.get(knowledgeDetailSymptomsInReviewTab)
    }

    knowledgeDetailCausesAndSolutionsInReviewTab() {
        return cy.get(knowledgeDetailCausesAndSolutionsInReviewTab)
    }


    saveKnowledgeButton() {
        return cy.get(saveKnowledgeButton)
    }

    workFlowMessage() {
        return cy.contains(workFlowMessage)
    }

    includeTab() {
        return cy.get(includeTab)
    }

    addKnowledgeHyperlink() {
        return cy.get(addKnowledgeHyperlink)
    }

    popUpOkButton() {
        return cy.get(popUpOkButton)
    }

    knowledgeOption() {
        return cy.contains(knowledgeOption)
    }


    previousButtonEnabled() {
        cy.get(previousButton).should(assertionConstants.notBeDisabledAssertion)
    }

    closeButtonEnabled() {
        cy.get(closeButton).should(assertionConstants.notBeDisabledAssertion)
    }

    saveAsDraftEnabled() {
        cy.get(saveAsDraft).should(assertionConstants.notBeDisabledAssertion)
    }

    nextButtonDisabled() {
        cy.get(nextButton).should(assertionConstants.notHaveClassAssertion, "pt-primary pt-button ng-star-inserted")
    }

    dataInGridVisible() {
        cy.get(dataInGrid).find('td').should(assertionConstants.beVisibleAssertion)
    }

    firstKnowledgwSelect() {
        cy.get(KnowledgwSelectcheckBox).eq(1).click()
    }
    previousButtonClick() {
        cy.get(previousButton).click()
    }

    nextClick() {
        cy.get(next).click()
    }

    reviewTabClick() {
        cy.get(Tab).last().click()
    }

    createPatternWithRightMarkVisible() {
        cy.get(TitleWithRightMark).find('li').first().should(assertionConstants.haveAttributeAssertion, 'class').and(assertionConstants.containAssertion, 'completed')
    }

    applyMetadataWithRightMarkVisible() {
        cy.get(TitleWithRightMark).find('li').eq(1).should(assertionConstants.haveAttributeAssertion, 'class').and(assertionConstants.containAssertion, 'completed')
    }

    includeKnowledgeWithRightMarkVisible() {
        cy.get(TitleWithRightMark).find('li').eq(2).should(assertionConstants.haveAttributeAssertion, 'class').and(assertionConstants.containAssertion, 'completed')
    }

    includeTabClick() {
        cy.get(Tab).first().click()
    }

    saveAsDraftDisabled() {
        cy.get(saveAsAfterClick).should(assertionConstants.haveClassAssertion, disabledClass)
    }

    closeButtonClick() {
        cy.get(closeButton).click()
    }

    confirmationPopUpHeaderVisible() {
        cy.get(confirmationPopUpHeader).should(assertionConstants.containAssertion, 'WARNING: You have unsaved changes.').and(assertionConstants.beVisibleAssertion)
    }

    confirmationPopUpDialogVisible() {
        cy.get(confirmationPopUpDialog).should(assertionConstants.containAssertion, ' Press OK to continue or Cancel to stay on this page. ').and(assertionConstants.beVisibleAssertion)
    }

    cancelButtonVisible() {
        cy.get(popUpcancelButton).should(assertionConstants.beVisibleAssertion)
    }

    okButtonOnPopUpVisible() {
        cy.get(okButtonOnPopUp).should(assertionConstants.beVisibleAssertion)
    }

    okButtonOnPopUpClick() {
        cy.get(okButtonOnPopUp).click()
    }

    breadCrumbForMyPatternDashboard() {
        cy.get(breadCrumbForMyPatternDashboard).find('li').should(assertionConstants.havelengthAssertion, '7')
    }

    myPatternDashboardSelected() {
        cy.get(myPatternDashboard).should(assertionConstants.haveAttributeAssertion, 'aria-selected', "true")
    }

    firstKnowledgwClick() {
        cy.get(KnowledgwSelectcheckBox).eq(1).click()
    }

    removeKnowledgeIconClick() {
        cy.get(removeKnowledgeIcon).first().click()
    }

    removeKnowledgesIconsClick() {
        cy.get(removeKnowledgeIcon).click({ multiple: true })
    }

    multipleknowledgeSelection() {
        const selectKnowledge = (value) => cy.get(KnowledgwSelectcheckBox).eq(value).click()
        selectKnowledge(3)
        selectKnowledge(5)
    }

    existingWFClick() {
        cy.get(existingWF).eq(1).find('p').find('.p-treenode.p-treenode-leaf.ng-star-inserted').last().click()
    }

    additionalKnowledgeNotVisible() {
        cy.contains(addedAdditionalKnowledge).should(assertionConstants.notExistsAssertion)
    }

    lastSelectedKnowledgeText() {
        cy.get(searchedResults).eq(1).find('td').eq(1).find('span').first().invoke('text').should(assertionConstants.beVisibleAssertion)

    }


    showAllCheckBoxClick() {
        cy.get(showAllCheckbox).click();
    }

    selectedKnowledgeTextInRightSection() {
        cy.get(KnowledgeTextInRightSection).first().should(assertionConstants.haveTextAssertion, firstSelectedKnowledgeText);

    }

    iconToCollaspeRightSideSectionVisible() {
        cy.get(iconToCollaspeRightSideSection).first().should(assertionConstants.beVisibleAssertion);
    }

    iconToCollaspeRightSideSectionClick() {
        cy.get(iconToCollaspeRightSideSection).first().click();
    }

    KnowledgeDetailsTextWhenRightSideCollapse() {
        cy.get(KnowledgeDetailsTextWhenRightSideCollapse).last().should(assertionConstants.beVisibleAssertion);

    }

    iconToExpandRightSideSectionVisible() {
        cy.get(iconToExpandRightSideSection).first().should(assertionConstants.beVisibleAssertion);
    }

    KnowledgeDetailsLableVisible() {
        return cy.get(KnowledgeDetailsTextWhenRightSideCollapse).then((el) => {
            const before = window.getComputedStyle(el[1], "before");
            const contentValue = before.getPropertyValue("content");
            expect(contentValue).to.equal(knowledgeDetailslable);
        });
    }

    iconToExpandRightSideSectionClick() {
        cy.get(iconToExpandRightSideSection).first().click();
    }

    knowledgeDetailsInIncludeTabVisible() {
        cy.get(knowledgeDetailsInIncludeTab).should(assertionConstants.beVisibleAssertion);
    }

    showAllNameCheckBoxClick() {
        cy.get(showAllNameCheckBoxClick).first().click();
    }

    detaInReviewTabGridVisible() {
        cy.get(detaInReviewTabGrid).first().find("li").should(assertionConstants.beVisibleAssertion);
    }

    firstKnowledgwSelectInReviewTab() {
        cy.get(firstKnowledgwSelectInReviewTab).click();
    }

    iconToCollaspeRightSideSectionInReviewTabVisible() {
        cy.get(iconToCollaspeRightSideSection).last().should(assertionConstants.beVisibleAssertion);
    }

    iconToCollaspeRightSideSectionInReviewTabClick() {
        cy.get(iconToCollaspeRightSideSection).last().click();
    }

    iconToExpandRightSideSectionInReviewTabVisible() {
        cy.get(iconToExpandRightSideSection).last().should(assertionConstants.beVisibleAssertion);
    }

    iconToExpandRightSideSectionInReviewTabClick() {
        cy.get(iconToExpandRightSideSection).last().click();
    }

    secondKnowledgeInReviewTabClick() {
        cy.get(secondKnowledgeInReviewTab).click();
    }

    KnowledgeDetailsTextWhenRightSideCollapseInReviewTabVisible() {
        cy.get(KnowledgeDetailsTextWhenRightSideCollapseInReviewTab).should(assertionConstants.beVisibleAssertion);

    }

    knowledgeDetailsInReviewTabVisible() {
        cy.get(knowledgeDetailsReviewTab).should(assertionConstants.beVisibleAssertion);
    }

    knowledgeInRightSection() {
        cy.get(lastSelectedKnowledge).last().invoke("text").then((value) => {
            arrOne.push(value.trim());
            cy.log(arrOne);
        });
    }

    compareText() {
        cy.get(KnowledgeTextInRightSection).first().invoke("text").then((el) => {
            newArr.length = 0
            newArr.push(el.trim());
            cy.wait(2000)
            cy.log(newArr);
            expect(arrOne[0]).to.eq(newArr[0])
        });
    }


    knowledgeDescriptionVisible() {
        cy.contains(knowledgeDescription).should(assertionConstants.beVisibleAssertion)
    }

    knowledgeSymptomVisible() {
        cy.contains(knowledgeSymptom).should(assertionConstants.beVisibleAssertion)
    }

    knowledgeCauseAndSolutionVisible() {
        cy.contains(knowledgeCauseAndSolution).should(assertionConstants.beVisibleAssertion)
    }

    knowledgeTagsVisible() {
        cy.contains(knowledgeTags).should(assertionConstants.beVisibleAssertion)
    }

    knowledgeNameInIncludeTabRightSectionVisible() {
        cy.get(KnowledgeTextInRightSection).first().should(assertionConstants.beVisibleAssertion)
    }

    collapsableAndExpandableIconOfDescriptionInIncludeTabClick() {
        cy.get(collapsableAndExpandableIcon).first().click()
    }

    descriptionAccordionsExpanded() {
        cy.get(descriptionAccordions).first().should(assertionConstants.haveClassAssertion, ExpandedClass)
    }

    symptomsAccordionsExpanded() {
        cy.get(accordionsInIncludeKnoeledgePage).first().children(dlsExpanderClass).eq(1).should(assertionConstants.haveClassAssertion, sectionExpandedClass)
    }

    causeAndSoultionAccordionsExpanded() {
        cy.get(accordionsInIncludeKnoeledgePage).first().children(dlsExpanderClass).eq(2).should(assertionConstants.haveClassAssertion, sectionExpandedClass)
    }

    tagsAccordionsExpanded() {
        cy.get(accordionsInIncludeKnoeledgePage).first().children(dlsExpanderClass).eq(3).should(assertionConstants.haveClassAssertion, sectionExpandedClass)
    }

    descriptionAccordionsCollapsed() {
        cy.get(descriptionAccordions).first().should(assertionConstants.notHaveClassAssertion, ExpandedClass)

    }

    descriptionDetailsVisible() {
        cy.get(descriptionDetails).should(assertionConstants.containAssertion, firstKnowledge).and(assertionConstants.beVisibleAssertion)

    }

    collapsableAndExpandableIconOfCauseAndSolutionInIncludeTabClick() {
        cy.get(collapsableAndExpandableIcon).eq(2).click()
    }

    reviewTabWithKnowledgeCountVisible() {
        cy.get(reviewTabWithKnowledgeCount).last().should(assertionConstants.beVisibleAssertion)
    }

    knowledgeNameHeaderVisible() {
        cy.get(knowledgeNameHeader).should(assertionConstants.haveTextAssertion, 'Knowledge Name').and(assertionConstants.beVisibleAssertion)
    }

    selectedFirstKnowledge() {
        cy.get(detaInReviewTabGrid).find('li').first().should(assertionConstants.haveAttributeAssertion, 'class', "pt-separator pt-selected ng-star-inserted")
    }

    selectedKnowledgeDetailsVisible() {
        cy.get(selectedKnowledgeDetails).last().children(dlsExpanderClass).should(assertionConstants.beVisibleAssertion)
    }

    KnowledgeText() {
        cy.get(firstKnowledgeInLeftSection).children().invoke('text').then((textone) => {
            textArr.push(textone)
        })

        cy.get(secondKnowledgeInLeftSection).children().invoke('text').then((texttwo) => {
            textArr.push(texttwo)
        })

        cy.log(textArr)

    }

    orderOfKnowledges() {
        cy.get(detaInReviewTabGrid).find('li').first().invoke('text').then((textone) => {
            expect(textone).to.equal(textArr[0])
        })
        cy.get(detaInReviewTabGrid).find('li').eq(1).invoke('text').then((texttwo) => {
            expect(texttwo).to.equal(textArr[1])
        })

    }

    knowledgeNameInReviewTabRightSectionVisible() {
        cy.get(KnowledgeTextInRightSection).last().should(assertionConstants.beVisibleAssertion)
    }

    descriptionAccordionsInReviewtabExpanded() {
        cy.get(descriptionAccordions).last().should(assertionConstants.haveClassAssertion, ExpandedClass)

    }

    symptomsAccordionsInReviewtabExpanded() {
        cy.get(accordionsInIncludeKnoeledgePage).last().children(dlsExpanderClass).eq(1).should(assertionConstants.haveClassAssertion, sectionExpandedClass)
    }

    causeAndSoultionAccordionsInReviewtabExpanded() {
        cy.get(accordionsInIncludeKnoeledgePage).last().children(dlsExpanderClass).eq(2).should(assertionConstants.haveClassAssertion, sectionExpandedClass)
    }

    tagsAccordionsInReviewtabExpanded() {
        cy.get(accordionsInIncludeKnoeledgePage).last().children(dlsExpanderClass).eq(3).should(assertionConstants.haveClassAssertion, sectionExpandedClass)
    }

    collapsableAndExpandableIconInReviewTabClick() {
        cy.get(collapsableAndExpandableIcon).eq(4).click()
    }

    crossMarkOfFirstKnowaledgeClick() {
        cy.get(crossMarkOfFirstKnowaledge).first().click()
    }

    knowledgeDescriptionInrewviewTabVisible() {
        cy.get(knowledgeDescriptionInrewviewTab).last().find('span').should(assertionConstants.haveTextAssertion, 'Description ').and(assertionConstants.beVisibleAssertion)
    }

    reviewTabWithUpdatedKnowledgeCountVisible() {
        cy.get(reviewTabWithKnowledgeCount).last().should(assertionConstants.haveTextAssertion, 'Review (1)')
    }

    removedKnowledgeUnselected() {
        cy.get(removedKnowledge).first().should(assertionConstants.notBeCheckedAssertion)
    }

    fullScreenButtonInIncludeTabClick() {
        cy.get(fullScreenButtonInIncludeTab).first().click()
    }

    rightSectionInFullScreenView() {
        cy.get(rightSectionInFullScreenView).children('div').eq(1).should(assertionConstants.haveAttributeAssertion, 'class', "col-md-6 rightView ng-star-inserted col-md-12 details-full-view")
    }

    leftPaneVisible() {
        cy.get(leftPane).should(assertionConstants.beVisibleAssertion)
    }

    includeTabVisible() {
        cy.get(Tab).first().should(assertionConstants.beVisibleAssertion)
    }
    fullScreenViewButtonAtPatternLevelClick() {
        cy.get(fullScreenViewButtonAtPatternLevel).click()
    }

    leftPaneCollapsed() {
        cy.get(leftPaneCollapsed).find('div').first().should(assertionConstants.haveAttributeAssertion, 'class', "dashboard_left active")
    }

    includeTabNotExist() {
        cy.get(includeTab).find('li').first().should(assertionConstants.notExistsAssertion)
    }

    reviewTabWithKnowledgeCountNotExist() {
        cy.get(reviewTabWithKnowledgeCount).last().should(assertionConstants.notExistsAssertion)
    }

    previousButtonVisible() {
        return cy.get(previousButton).should(assertionConstants.beVisibleAssertion)
    }

    allButtonsVisible() {
        cy.get(allButtons).find('button').should(assertionConstants.beVisibleAssertion)
    }

    searchButtonVisible() {
        cy.get(searchButton).should(assertionConstants.beVisibleAssertion)
    }

    // previousButtonNotVisible(){
    //     cy.get(previousButton).should('not.be.visible')
    // }

    // allButtonsNotVisible(){
    //     cy.get(allButtons).find('button').should('not.be.visible')
    // }

    detailsOfDescriptionInReviewTabVisible() {
        cy.get(detailsOfDescriptionInReviewTab).should(assertionConstants.beVisibleAssertion)
    }

    knowledgeCauseAndSolutionDetailsvisible() {
        cy.get(causeAndSolution).eq(1).should(assertionConstants.beVisibleAssertion)
    }

    detailsOfCauseAndSolutionInIncludeTabVisible() {
        cy.get(detailsOfCauseAndSolutionInIncludeTab).first().should(assertionConstants.beVisibleAssertion)
    }


    dropDownNextToCommonSearchVisible() {
        cy.get(dropDownNextToCommonSearch).should(assertionConstants.beVisibleAssertion)
    }

    dropDownNextToCommonSearchWithAllTextVisible() {
        cy.get(dropDownNextToCommonSearch).children().find('span').should(assertionConstants.haveTextAssertion, 'All').and(assertionConstants.beVisibleAssertion)
    }

    filterForKeywordWithSearchIcon() {
        cy.get(filterForKeyword).should(assertionConstants.beVisibleAssertion)
    }

    searchIconInCommonSearchVisible() {
        cy.get(searchIconInCommonSearch).should(assertionConstants.beVisibleAssertion)
    }

    commonSearchBoxWithTextVisible() {
        cy.get(commonSearchBoxWithText).find('input').first().should(assertionConstants.haveAttributeAssertion, 'placeholder', 'Search by Keyword').and(assertionConstants.beVisibleAssertion)
    }

    dropDownOptionsUnderDropdownNextToCommonSearchVisible() {
        cy.get(dropDownOptionsUnderDropdownNextToCommonSearch).eq(1).should(assertionConstants.containAssertion, ' Cause ').and(assertionConstants.beVisibleAssertion)
        cy.get(dropDownOptionsUnderDropdownNextToCommonSearch).eq(2).should(assertionConstants.containAssertion, ' Description ').and(assertionConstants.beVisibleAssertion)
        cy.get(dropDownOptionsUnderDropdownNextToCommonSearch).eq(3).should(assertionConstants.containAssertion, ' Name ').and(assertionConstants.beVisibleAssertion)
        cy.get(dropDownOptionsUnderDropdownNextToCommonSearch).eq(4).should(assertionConstants.containAssertion, ' Parts ').and(assertionConstants.beVisibleAssertion)
        cy.get(dropDownOptionsUnderDropdownNextToCommonSearch).eq(5).should(assertionConstants.containAssertion, ' Solutions ').and(assertionConstants.beVisibleAssertion)
        cy.get(dropDownOptionsUnderDropdownNextToCommonSearch).eq(6).should(assertionConstants.containAssertion, ' Symptoms ').and(assertionConstants.beVisibleAssertion)
        cy.get(dropDownOptionsUnderDropdownNextToCommonSearch).eq(7).should(assertionConstants.containAssertion, ' Tags ').and(assertionConstants.beVisibleAssertion)

    }

    filterForKeywordTypeMotor() {
        cy.get(filterForKeyword).type('motor')
    }

    searchIconInCommonSearchClick() {
        cy.get(searchIconInCommonSearch).first().click()
    }

    searchedResultsIngridVisible() {
        cy.get(searchedResults).first().should(assertionConstants.beVisibleAssertion)
    }

    searchedResultsAsPerContentIngridVisible() {
        cy.get(searchedResults).first().should(assertionConstants.containAssertion, 'motor ')
    }

    xmarkInSearchTextBoxClick() {
        cy.get(xmarkInSearchTextBox).first().click()
    }

    filterForKeywordWithOutSearchedWord() {
        cy.get(filterForKeyword).should(assertionConstants.notContainAssertion, 'motor')
    }

    dropDownNextToCommonSearchClick() {
        cy.get(dropDownNextToCommonSearch).first().click()
    }

    nameOptionClick() {
        cy.get(dropDownOptionsUnderDropdownNextToCommonSearch).eq(3).click()

    }

    filterForKeywordWithSearchIconType() {
        cy.get(filterForKeyword).type('knowledge')
    }

    selectAllCheckBoxClick() {
        cy.get(selectAllCheckBox).click()
    }

    filterForKeywordTypeError() {
        cy.get(filterForKeyword).clear().type('error')
    }

    columnLevelTagsFiltercolumnLevelTagsFilterClick() {
        cy.get(columnLevelTagsFilter).click()
    }

    diaomAndInteroperabilityTagClick() {
        cy.get(diaomAndInteroperabilityTag).click()
    }

    applyButtonClick() {
        cy.get(applyButton).click()
    }

    nameFilterType() {
        cy.get(nameFilter).type('error')
    }

    searchIconInNameFilterClick() {
        cy.get(searchIconInNameFilter).last().click()
    }

    descriptionDropDownOptionsUnderDropdownNextToCommonSearchClick() {
        cy.get(dropDownOptionsUnderDropdownNextToCommonSearch).eq(2).click()
    }

    filterForKeywordTypeSupply() {
        cy.get(filterForKeyword).clear().type('supply')
    }

    nameFilterWithoutText() {
        cy.get(nameFilter).should(assertionConstants.notHaveTextAssertion, 'name')
    }

    causeDropDownOptionsUnderDropdownNextToCommonSearchClick() {
        cy.get(dropDownOptionsUnderDropdownNextToCommonSearch).eq(1).click()
    }

    awsTagClick() {
        cy.get(awsTag).click()
    }

    allTagClick() {
        cy.get('div[role="checkbox"]').last(0).click()
    }

    partsDropDownOptionsUnderDropdownNextToCommonSearchClick() {
        cy.get(dropDownOptionsUnderDropdownNextToCommonSearch).eq(4).click()
    }

    filterForKeywordTypeScrews() {
        cy.get(filterForKeyword).clear().type('screws')
    }

    solutionDropDownOptionsUnderDropdownNextToCommonSearchClick() {
        cy.get(dropDownOptionsUnderDropdownNextToCommonSearch).eq(5).click()
    }

    filterForKeywordTypeVoltage() {
        cy.get(filterForKeyword).clear().type('voltage')
    }

    nameFilterKnowledgeType() {
        cy.get(nameFilter).type('Check')
    }

    symptomsDropDownOptionsUnderDropdownNextToCommonSearchClick() {
        cy.get(dropDownOptionsUnderDropdownNextToCommonSearch).eq(6).click()
    }

    filterForKeywordTypeSympton1() {
        cy.get(filterForKeyword).clear().type('symptom1')
    }

    tagsDropDownOptionsUnderDropdownNextToCommonSearchClick() {
        cy.get(dropDownOptionsUnderDropdownNextToCommonSearch).eq(7).click()
    }

    filterForKeywordTypeDicom() {
        cy.get(filterForKeyword).clear().type('dicom')
    }

    dicomTagClick() {
        cy.get(dicomTag).click()
    }

    recordsFoundTextVerification() {
        cy.get(recordsFoundTextVerification).should(assertionConstants.beVisibleAssertion)
        return cy.get(recordsFoundTextVerification).invoke('text').should('include', recordsFoundText)
    }

    expandIconClickandVerification() {
        cy.get(expandIcon).click()
        cy.get(navigationPanel).should(assertionConstants.beVisibleAssertion)
    }

    getKnowledgeName() {
        cy.get(patternDashboardBreadCrum).find(ptLayoutContainerClass).find('ul').children('li').last().find('a').find('span').invoke('text').then((Name) => {
            knowledgenames.push(Name.trim())
          cy.wait(3000)
          cy.log(knowledgenames)
        })
      }

   
    commonFilterClickAndTypePublishedKnowledge() {
        cy.get(filterForKeyword).type(knowledgenames[0])
    }

    searchButtonClick() {
        cy.get(searchButton).click()
    }

    searchButtonOfSearchByKeyWordClick() {
        return cy.get(searchButtonOfSearchByKeyWord).first().click({force:true})
    }

    searchedKnowledgeVisible(){
        cy.get(knowledgeList).eq(1).find('span').first().should(assertionConstants.beVisibleAssertion)
    
    }

    firstRecordClick() {
        return cy.get(firstRecord).eq(0).click()
    }

    loadingSymbolVisible(){
        cy.get(loadingSymbol).should(assertionConstants.beVisibleAssertion)
    }
 
    cancelButtonClick() {
        cy.get(popUpcancelButton).click()
    }

    validateHeadingActiveVerification() {
        return cy.get(validateHeading).should(assertionConstants.haveAttributeAssertion, 'class', 'ng-star-inserted active')
    }

    popUpMessageVisible(){
        cy.contains(popUpMessage).should(assertionConstants.beVisibleAssertion)
    }

    firstRecordcheckedcheckBoxUnchecked(){
        cy.get(firstRecordcheckedcheckBox).last().click({force:true})
    }

  
}
export default IncludeKnowledge;



