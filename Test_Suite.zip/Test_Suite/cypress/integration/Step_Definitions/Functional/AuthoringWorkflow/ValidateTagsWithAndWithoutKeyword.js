/// <reference types="Cypress" />
/// <reference types = 'cypress-tags' /> 
import "../../../../support/index"
import {When, Then, And } from "cypress-cucumber-preprocessor/steps"
import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();
import ApplyMetadata from "../../../../support/pageObjects/pages/PatternAuthoring/applyMetadata";
const applyMetadata = new ApplyMetadata();
import {printTimestamp} from '../../../../support/commands';

When("User Create Wf and fill details", () => {
	cy.createPattern()
    console.log(printTimestamp(), 'User Created Wf and filled details')
});

When("Click on Next button navigate to Apply Metadata page", () => {
	createPattern.nextButtonClick()
    cy.wait(2000)
    console.log(printTimestamp(), 'Clicked on Next button navigated to Apply Metadata page')
});

When("Click on Add Tag link", () => {
	applyMetadata.addTagOptionClick()
    console.log(printTimestamp(), 'Clicked on Add Tag link')
});

Then("Add tag pop up should be displayed and Without Keyword menu should be displayed by default", () => {
	applyMetadata.addTagPopUpVisible()
    applyMetadata.withKeywordOptionVisible()
    applyMetadata.withOutKeywordOptionVisible()
    console.log(printTimestamp(), 'Add tag pop up  displayed and Without Keyword menu  displayed by default')
});

When("Click on the dropdown menu from Without Keyword menu", () => {
	applyMetadata.withOutKeywordOptionClick()
    applyMetadata.withOutKeywordSerchOptionClick()
    console.log(printTimestamp(), 'Clicked on the dropdown menu from Without Keyword menu')
});

Then("Tag values should be displayed in the drop down", () => {
	applyMetadata.tagValuesUnderDropdownVisible()
    console.log(printTimestamp(), 'Tag values displayed in the drop down')
});

And("List of tags associated with module  1 patterns should be matched with db", () => {
	
    console.log(printTimestamp(), 'List of tags associated with module  1 patterns matched with db')
});

When("Select the tag values from the drop down", () => {
	applyMetadata.tagValuesUnderDropdownClick()
    console.log(printTimestamp(), 'Selects the tag values from the drop down')
});

Then("Selected tag values from the drop down should be displayed in the dropdown text box", () => {
	applyMetadata.withOutKeywordSerchOptionWithSelectedTagText()
    console.log(printTimestamp(), 'Selected tag values from the drop down displayed in the dropdown text box')
});

When("Click on the add button + besides the drop down", () => {
	applyMetadata.addTagPlusIconClick()
    console.log(printTimestamp(), 'Clicked on the add button + besides the drop down')
});

Then("Selected tag values should be displayed in the Added Tags section.", () => {
	applyMetadata.addedTagsSectionWithAddedTags()
    console.log(printTimestamp(), 'Selected tag values displayed in the Added Tags section.')
});

When("Click on With Keyword tab from the Add Tag pop up", () => {
	applyMetadata.withKeywordOptionClick()
    console.log(printTimestamp(), 'Clicked on With Keyword tab from the Add Tag pop up')
});

Then("With Keyword tab should be selected and corresponding fields should be displayed", () => {
	applyMetadata.withKeywordOptionSelected()
    applyMetadata.fieldsUnderWithkeywordOptionVisible()
    console.log(printTimestamp(), 'With Keyword tab selected and corresponding fields displayed')
});

When("Click on Operator drop down and verify data", () => {
	applyMetadata.operatorDropdownClick()
    console.log(printTimestamp(), 'Clicked on Operator drop down and verified data')
});

Then("Operator value should be selected Following operators should be displayed == , >=,<=", () => {
	applyMetadata.operatorOptionsVisible()
    console.log(printTimestamp(), 'Operator value selected Following operators displayed == , >=,<=')
});

When("Click on Keyword drop down", () => {
	applyMetadata.keywordDropdownOptionClick()
    console.log(printTimestamp(), 'Clicked on Keyword drop down')
});

Then("All keyword tags associated with module 1 patterns should be matched with db", () => {
	
    console.log(printTimestamp(), 'All keyword tags associated with module 1 patterns matched with db')
});

When("Click on Value drop down", () => {
    applyMetadata.valueDropdownOptionClick()
    console.log(printTimestamp(), 'Clicked on Value drop down')
});

Then("All Value tags associated with keyword should be matched with db", () => {
	
    console.log(printTimestamp(), 'All Value tags associated with keyword  matched with db')
});

When("select Keyword values from the dropdown", () => {
    applyMetadata.keywordDropdownOptionClick()
    applyMetadata.dropdownOptionUnderDiffFiledsClick()
    console.log(printTimestamp(), 'selects Keyword values from the dropdown')
});

Then("Keyword value should be selected and selected keyword value should be displayed in the drop down.", () => {
	applyMetadata.keywordfieldWithSelectedValue()
    console.log(printTimestamp(), 'Keyword value selected and selected keyword value displayed in the drop down.')
});

When("Click on Operator drop down and select Operator values from the dropdown", () => {
	applyMetadata.operatorDropdownClick()
    applyMetadata.dropdownOptionUnderDiffFiledsClick()
    console.log(printTimestamp(), 'Clicked on Operator drop down and selects Operator values from the dropdown')
});

Then("Operator value should be selected and selected operator value should be displayed in the drop down", () => {
	applyMetadata.operatorfieldWithSelectedValue()
    console.log(printTimestamp(), 'Operator value selected and selected operator value displayed in the drop down')
});

When("Click on Value drop down and select values from the dropdown", () => {
    applyMetadata.valueDropdownOptionClick()
    console.log(printTimestamp(), 'Clicked on Value drop down and selects values from the dropdown')
});

Then("Value should be selected and selected value should be displayed in the drop down.", () => {
	applyMetadata.dropdownOptionUnderDiffFiledsClick()
    applyMetadata.valuefieldWithSelectedValue()
    console.log(printTimestamp(), 'Value selected and selected value displayed in the drop down.')
});

When("Click on the add button + besides the Value drop down", () => {
	applyMetadata.addTagPlusIconClick()
    console.log(printTimestamp(), 'Clicked on the add button + besides the Value drop down')
});

Then("Selected Keyword, Operator and Value should be displayed in the Added Tags text area.", () => {
	applyMetadata.addedKeywordValueOperatorAddedTagTextArea()
    console.log(printTimestamp(), 'Selected Keyword, Operator and Value displayed in the Added Tags text area.')
});

When("Click on the Done button displayed down below the Added Tags section", () => {
	applyMetadata.doneButtonClick()
    console.log(printTimestamp(), 'Clicked on the Done button displayed down below the Added Tags section')
});

And("Selected Tag values should be displayed in the Added Tags section as removable token", () => {
	applyMetadata.selectedTagValueUnderAddtagSectionWithRemoveableTokonVisible()
    console.log(printTimestamp(), 'Selected Tag values displayed in the Added Tags section as removable token')
});

And("All added tags should be displayed as removable token Tags section", () => {
	applyMetadata.addedTagValueUnderAddtagSectionWithRemoveableTokonVisible()
    console.log(printTimestamp(), 'All added tags displayed as removable token Tags section')
});

