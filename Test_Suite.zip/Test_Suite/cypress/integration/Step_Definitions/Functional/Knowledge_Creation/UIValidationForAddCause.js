/// <reference types="Cypress" />
/// <reference types = 'cypress-tags' /> 

import "../../../../support/index"
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import CreateKnowledge from "../../../../support/pageObjects/pages/KnowledgeAuthoring/CreateKnowledge";
const createKnowledge = new CreateKnowledge();
import { printTimestamp } from '../../../../support/commands';

When("User Navigate to newly created knowledge workflow", () => {
    createKnowledge.knowledgeOptionArrowClick()
    createKnowledge.addKnowledgeWorkflowButtonClick()
    cy.wait(3000)
    console.log(printTimestamp(), 'Navigated to existing knowledge workflow')
});

Then("Causes and Solutions section should be available with asterisk *", () => {
    createKnowledge.causeAndSolutionVisible()
    createKnowledge.asteriskVisible()
    console.log(printTimestamp(), 'Causes and Solutions section available with asterisk *')
});

When("User Click on Causes and Solution section", () => {
    createKnowledge.causeAndSolutionClick()
    console.log(printTimestamp(), 'Clicked on Causes and Solution section')
});

Then("Causes and Solutions section should get expanded", () => {
    createKnowledge.selectCauseVisible()
    createKnowledge.addCauseVisible()
    console.log(printTimestamp(), 'Causes and Solutions section get expanded')

});

And("Full screen icon and expand icon should be available at right side inline with Causes and Solutions section name", () => {
    createKnowledge.fullScreenIconVisible()
    createKnowledge.expandIconVisible()
    console.log(printTimestamp(), 'Full screen icon and expand icon  available at right side inline with Causes and Solutions section name')
});

And("Select Cause,Add Cause buttons should be available under Causes and Solutions section", () => {
    createKnowledge.selectCauseVisible()
    createKnowledge.addCauseVisible()
    console.log(printTimestamp(), 'Select Cause,Add Cause buttons available under Causes and Solutions section')
});

When("User Click on Add Cause", () => {
    createKnowledge.addCauseClick()
    console.log(printTimestamp(), 'Clicked on Add Cause')
});

Then("Cause 1 sequencially generated should get added under Causes and Solutions section", () => {
    createKnowledge.generatedCause1Visible()
    console.log(printTimestamp(), 'Cause 1 sequencially generated  get added under Causes and Solutions section')
});

And("Tick disabled and Close enabled icons should be available at right corner inline with Cause name", () => {
    createKnowledge.tickdisabled()
    createKnowledge.closeEnabled()
    console.log(printTimestamp(), 'Tick disabled and Close enabled icons available at right corner inline with Cause name')

});

And("Rich text editor should be available for cause Note : Cause name should get gerenated sequencially based on highest number"
    + " of cause available in Causes and Solutions section excluding imported causes", () => {
        createKnowledge.richTextEditorVisible()
        createKnowledge.cause1TextBoxType()
        createKnowledge.addSolutionClick()
        createKnowledge.solution1TextBoxType()
        createKnowledge.selectCauseClick()
        createKnowledge.showAllCheckboxClick()
        createKnowledge.firstCauseClick()
        createKnowledge.selectButtonClick()
        cy.wait(2000)
        createKnowledge.addCauseClick()
        createKnowledge.sequentialCauseNameVisible()
        console.log(printTimestamp(), 'Rich text editor available for cause')
    });

And("Tick mark disabled,Remove mark enabled,Under Causes and Solutions section,Add Solution disabled,Select Casuse disabled,Add Cause disabled", () => {
    createKnowledge.tickdisabled()
    createKnowledge.closeEnabled()
    createKnowledge.addSolutionDisabled()
    createKnowledge.selectCauseDisabled()
    createKnowledge.addCauseDisabled()
    console.log(printTimestamp(), 'Tick mark disabled,Remove mark enabled,Under Causes and Solutions section,Add Solution disabled,Select Casuse disabled,Add Cause disabled')

});

When("add content in cause rich text editor", () => {
    createKnowledge.richTextEditorType()
    console.log(printTimestamp(), 'added content in cause rich text editor')
});

Then("Add Solution button should get enabled", () => {
    createKnowledge.addSolutionEnabled()
    console.log(printTimestamp(), 'Add Solution button get enabled')
});

When("User Click on Add Solution", () => {
    createKnowledge.addSolutionClick()
    console.log(printTimestamp(), 'User Clicked on Add Solution')
});

Then("Solution 1 sequencially generated should get added under generated cause section", () => {
    createKnowledge.solution1Visible()
    console.log(printTimestamp(), 'Solution 1 sequencially generated get added under generated cause section')
});

And("Close icons should be available  beside full screen icon in Rich text editor", () => {
    createKnowledge.closeIconForSolution1()
    console.log(printTimestamp(), 'Close icons available  beside full screen icon in Rich text editor')
});

And("Rich text editor should be available for solution ,Solution name should get gerenated sequencially"
    + " based on highest number of cause available in Causes and Solutions section", () => {
        createKnowledge.richTextEditorForSolution1Visible()
        createKnowledge.solution1UnderCause2TextBoxType()
        createKnowledge.addSolutionClick()
        createKnowledge.sequencialSolutionNameUnderCause2Visible()
        console.log(printTimestamp(), 'Rich text editor available for solution ,Solution name get gerenated sequencially based on highest number of cause available in Causes and Solutions section')
    });

And("When solutions are added priority drop down should get populated with same solution number", () => {
    createKnowledge.priorityDropdownForSolutionOneVisible()
    createKnowledge.priorityDropdownForSolutionTwoVisible()
    console.log(printTimestamp(), 'After The solutions are added priority drop down  get populated with same solution number')

});

And("In drop down addition option should be displayed as Select--", () => {
    createKnowledge.priorityDropdownForSolutionOneClick()
    createKnowledge.selectOptionUderSolution1PriorityDropdownVisible()
    createKnowledge.priorityDropdownForSolutionTwoClick()
    createKnowledge.selectOptionUderSolution2PriorityDropdownVisible()
    console.log(printTimestamp(), 'In drop down addition option displayed as Select--')

});

And("Tick mark enabled,Remove mark enabled", () => {
    createKnowledge.solutionOneTextBoxType()
    createKnowledge.tickEnabled()
    createKnowledge.closeEnabled()
    console.log(printTimestamp(), 'Tick mark enabled,Remove mark enabled')
});

And("Under Causes and Solutions section Add Solution enabled,Select Casuse enabled,Add Cause enabled"
    + " Note : At lest one cause and for cause atlest one solution with priority is mandatory", () => {
        createKnowledge.addSolutionEnabled()
        createKnowledge.selectCauseEnabled()
        createKnowledge.addCauseEnabled()
        console.log(printTimestamp(), 'Under Causes and Solutions section Add Solution enabled,Select Casuse enabled,Add Cause enabled')
});
