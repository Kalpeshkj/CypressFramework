/// <reference types="Cypress" />
/// <reference types='cypress-tags' />
 
import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';

import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();

And("Add condition section is visible with asterisk and indicate as mandatory", () => {
    createPattern.addConditionTabVisible()
    createPattern.addCondtionAsteriskVisible()
    console.log(printTimestamp(), ' Add condition section displayed')
}); 

When("User clicks on Add Condition section", () => {
    createPattern.addConditionTabClick()
    console.log(printTimestamp(), ' clicked on Add Condition section')
});

Then("Add Condition should be visible as expanded", () => {
    createPattern.expandedAddConditionSectionVerification()
    console.log(printTimestamp(), ' Add Condition verified as expanded')
});

And("'+' icon is visible", () => {
    createPattern.addConditionPlusIconVisible()
    console.log(printTimestamp(), ' + icon displayed')
});

When("User clicks on '+' dropdown button", () => {
    createPattern.addConditionPlusIconClick()
    console.log(printTimestamp(), ' clicked on + dropdown button')
});

Then("From Data Model ,From Rule Pattern and From Variable gets visible", () => {
    createPattern.fromdataModelVisible()
    createPattern.fromrulePatternVisible()
    createPattern.fromVariableVisible()
    console.log(printTimestamp(), ' From Data Model ,From Rule/Pattern and From Variable are displayed')
});

And("No Data Model imported should be displayed on hover of From Data Model Option", () => {
    createPattern.fromdataModelHoverValidationBeforeSelection()
    console.log(printTimestamp(), ' No Data Model imported displayed on hover of From Data Model')
});

When("User clicks import data model and selects any option from its dropdown", () => {
    createPattern.importdatamodelTabClick()
    createPattern.importdatamodelDrpdownClick()
    createPattern.importdatamodelDrpdownCommonSelection()
    createPattern.importdatamodelTabClick()
    console.log(printTimestamp(), ' clicked on import data model and selected one option from its dropdown')
});

Then("List of imported data model should be displayed after hovering on From Data Model", () => {
    createPattern.addConditionTabClick()
    createPattern.addConditionPlusIconClick()
    createPattern.fromdataModelHoverValidationAfterSelection()
    console.log(printTimestamp(), ' List of imported data model displayed after hovering on From Data Model')
});

When("User Clicks on From Variable option", () => {
    createPattern.fromVariableClick()
    console.log(printTimestamp(), ' clicked on From Variable option')
});

Then("No Variables added should be displayed", () => {
    createPattern.noVariablesTextVerification()
    console.log(printTimestamp(), ' No Variables added text displayed')
});

When("User clicks From Data Model and selects any option from its dropdown", () => {
    createPattern.fromdataModelClick()
    createPattern.fromdataModelOptionSelection()
    console.log(printTimestamp(), ' clicked on From Data Model and selected one option from its dropdown')
});

Then("Selected option should be visible which user selected in above step", () => {
    createPattern.fromVariableClick()
    console.log(printTimestamp(), ' Selected option was visible')
});

And("User able to click on collapse option from Add Condition", () => {
    cy.wait(1000)
    createPattern.addConditionTabClick()
    createPattern.addConditionCollapsedVisible()
    console.log(printTimestamp(), ' clicked on collapse option from Add Condition')
});

And("User able to click on expand option from Add Condition", () => {
    createPattern.addConditionTabClick()
    createPattern.addConditionExpandedVisible()
    console.log(printTimestamp(), ' clicked on expand option from Add Condition')
});

And("Verify at a time only one section should be in expanded state", () => {
    createPattern.atATimeOneExpandedVerification()
    console.log(printTimestamp(), ' Verified at a time only one section is in expanded state')
});