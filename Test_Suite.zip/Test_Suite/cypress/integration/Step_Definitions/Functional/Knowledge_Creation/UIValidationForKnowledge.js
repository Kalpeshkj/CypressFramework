/// <reference types="Cypress" />
/// <reference types = 'cypress-tags' />
import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import KnowledgeDashboard from "../../../../support/pageObjects/pages/Knowledge_Dashboard/KnowledgeDashboard";
const knowledgeDashboard = new KnowledgeDashboard();

When("User clicks on the expand arrow on knowledge section", () => {
    knowledgeDashboard.knowledgeClick()
    console.log(printTimestamp(), ' clicked on the expand arrow on knowledge section')
})

Then("Verifies '+' icon is available next to My Knowledge", () => { 
    knowledgeDashboard.addKnowledgePlusIconVisible()
    knowledgeDashboard.addKnowledgeClick()
    console.log(printTimestamp(), ' Verified ' + ' icon is available')
})

And("Verify the 3 dots available for each knowledge workflow in the dashboard", () => {
    knowledgeDashboard.threeDotsOfKnowledgeRecordsVisible()
    console.log(printTimestamp(), ' Verified the 3 dots available for each knowledge workflow')
})

When("User Click on the 3 dots available for workflow", () => {
    knowledgeDashboard.myKnowledgeClick()
    cy.wait(2000)
    knowledgeDashboard.scrollElement()
    cy.wait(1000)
    knowledgeDashboard.threeDotsOfKnowledgeLastRecordClick()
    console.log(printTimestamp(), ' Clicked on the 3 dots')
})

Then("It should contain Rename and delete option", () => {
    knowledgeDashboard.buttonsInRecordsThreeDotsVisible()
    console.log(printTimestamp(), ' Rename and delete option verified')
})

When("User Clicks on rename option", () => {
    knowledgeDashboard.renameButtonClick()
    console.log(printTimestamp(), ' Rename option clicked')
})

And("Enters the new value to workflow", () => {
    cy.PatternCreation()
    knowledgeDashboard.crossButtonClickAndNameEnter()
    cy.wait(2000)
    console.log(printTimestamp(), ' Entered new name')
})

When("User Clicks on the delete option available", () => {
    knowledgeDashboard.threeDotsOfKnowledgeLastRecordClick()
    knowledgeDashboard.deleteButtonClick()
    console.log(printTimestamp(), ' Delete option clicked')
})

Then("The workflow should be deleted and User should be navigated to My knowledge dashboard", () => {
    cy.wait(3000)
    knowledgeDashboard.dashboardNavigationVerification()
    console.log(printTimestamp(), ' WF deleted')
})

And("Verify the deleted value in DB but is_deleted column should be true", () => {
    console.log(printTimestamp(), ' Verified the deleted value in DB')
})

When("User Navigates to Include knowledge page and click on Add Knowledge hyper link", () => {
    cy.createIncludeKnowledge()
    console.log(printTimestamp(), ' Navigated to Include knowledge page')
})

Then("Add Knowledge hyper link should navigate to the new authoring workflow of the knowledge", () => {
    knowledgeDashboard.newWFNavigationInKnowledgeVerification()
    console.log(printTimestamp(), ' Add Knowledge hyper link navigated to the new authoring workflow')
});

And("Verify the name of the Authoring workflow that should be next number of workflow", () => {
    knowledgeDashboard.workflowSequencialNumberVerification()
    cy.DeleteWorkflow()
    knowledgeDashboard.deletePatternWF()
    console.log(printTimestamp(), ' Verified the name of the Authoring workflow')
});