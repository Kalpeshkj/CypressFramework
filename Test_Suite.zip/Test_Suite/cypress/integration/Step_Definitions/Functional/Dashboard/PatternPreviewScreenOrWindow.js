/// <reference types="Cypress" />
/// <reference types='cypress-tags' />

import "../../../../support/index";
import { When, Then } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();
import PatternDashboard from "../../../../support/pageObjects/pages/Dashboard/PatternDashboard";
const patternDashboard = new PatternDashboard();

Then("User Select any Pattern name from list", () => {
    cy.createPattern()
    createPattern.nextButtonClick()
    cy.wait(2000)
    cy.ApplyMetaDetaPageCompletionForPatternCreation()
    createPattern.nextButtonClick()
    cy.wait(2000)
    createPattern.showAllCheckboxClick()
    createPattern.recordSelectionInIncludeKnowledge()
    createPattern.saveAsDraftButtonClick()
    cy.wait(3000)
    createPattern.getPatternName()
    cy.wait(1000)
    createPattern.patternDashboardClick()
    cy.wait(2000)
    patternDashboard.modalityDropdownColumnClick()
    patternDashboard.selectAllCheckBoxClick()
    patternDashboard.modalityApplyButtonClick()
    createPattern.PatternNameSearchInSearchOption()
    createPattern.searchIconClicked()
    cy.wait(2000)
    patternDashboard.patternDashboardColumnFirstRecordClick();
  
    console.log(printTimestamp(), ' Selected Pattern name from list') 
});

Then("Pattern Details should be displayed in right side screen", () => {
    patternDashboard.rightSideOverlaySectionVisible()
    console.log(printTimestamp(), ' Pattern Details displayed in right side screen')
});

And("Verifies UI for available for right side overlay section", () => {
    patternDashboard.knowledgeSectionExpandedVisible()
    patternDashboard.editButtonInPatternOverlayVisible()
    patternDashboard.viewButtonInPatternOverlayScreenVisible()
    console.log(printTimestamp(), ' Verified UI for available for right side overlay section')
});

Then("Verifies System Relevance section in UI", () => {
    patternDashboard.relevanceExpandedIconVisible()
    patternDashboard.relevanceCollapsedModalitiesVisible()
    cy.DeleteDynamicPattern()
    console.log(printTimestamp(), ' Verified System Relevance section in UI')
});

When("User Selects any other Pattern name", () => {
    cy.createPattern()
    createPattern.nextButtonClick()
    cy.wait(2000)
    cy.ApplyMetaDetaPageCompletionForPatternCreation()
    createPattern.nextButtonClick()
    cy.wait(2000)
    createPattern.showAllCheckboxClick()
    createPattern.recordSelectionInIncludeKnowledge()
    createPattern.saveAsDraftButtonClick()
    cy.wait(3000)
    createPattern.getPatternName()
    cy.wait(1000)
    createPattern.patternDashboardClick()
    cy.wait(2000)
    patternDashboard.modalityDropdownColumnClick()
    patternDashboard.selectAllCheckBoxClick()
    patternDashboard.modalityApplyButtonClick()
    createPattern.secondPatternNameSearchInSearchOption()
    createPattern.searchIconClicked()
    cy.wait(2000)
    patternDashboard.patternDashboardColumnFirstRecordClick();
    console.log(printTimestamp(), ' Selected other Pattern name')
});

When("User navigates to Knowledge section", () => {
    patternDashboard.knowledgeSectionInOverlayScreenVisible()
    console.log(printTimestamp(), ' Navigated to Knowledge section')
});

Then("Verifies knowledge details in right side", () => {
    patternDashboard.knowledgeNameInOverlayScreenVisible()
    patternDashboard.knowledgeSectionExpandCollapseIconVisible()
    patternDashboard.symptomsSectionInOverlayVisible()
    patternDashboard.causeAndSolutionSectionInOverlayVisible()
    patternDashboard.tagsSectionInOverlayVisible()
    console.log(printTimestamp(), ' Verified knowledge details in right side')
}); 

And("Verifies each section available for knowledge", () => {
    patternDashboard.scrollUp()
    patternDashboard.knowledgeDetailsVisible()
    // patternDashboard.causeAndSolutionDetailsVisible()
    console.log(printTimestamp(), ' Verified each section available for knowledge')
});

When("User Clicks on View button", () => {
    patternDashboard.viewButtonInPatternOverlayScreenClick()
    console.log(printTimestamp(), ' Clicked on View button')
});

Then("Verifies enable,disable edit button and its functionality", () => {
    patternDashboard.editButtonInPatternOverlayScreenVisible()
    patternDashboard.editButtonInPatternOverlayScreenVisibleAsDisabled()
    console.log(printTimestamp(), ' Verified enable,disable edit button and its functionality')
});

Then("Navigates to my pattern dashboard and Repeat above steps and verifies in my pattern dashboard", () => {
    patternDashboard.myPatternDashboardButtonClick()
    createPattern.secondPatternNameSearchInSearchOption()
    createPattern.searchIconClicked()
    cy.wait(2000)
    patternDashboard.patternDashboardColumnFirstRecordClick();
    patternDashboard.rightSideOverlaySectionVisible()
    patternDashboard.viewButtonInPatternOverlayScreenVisible()
    patternDashboard.viewButtonInPatternOverlayScreenClick()
    patternDashboard.editButtonInPatternOverlayScreenVisible()
    cy.DeleteDynamicPattern()
    console.log(printTimestamp(), ' Navigated to my pattern dashboard and Repeated above steps')
});