
class CreatePatternPageLocators {
     eventFiveUnderFromVariable = '#mItem_1'
     eventSixUnderFromVariable = '#mItem_2'
     eventSevenUnderFromVariable = "#mItem_3"
     eventEightUnderFromVariable = '#mItem_4'
     operatorsUnderAttributeDropdown = '[class="dropdown-option-ellipses pt-option ng-star-inserted"]'
     myPatternThreeDots = "#nav-dropdown-btn #Layer_1"
     createPattern = '[id="Create Pattern"]'
     createPatternHeading = "#step-0"
     applyMetadataHeading = "#step-1"
     includeKnowledgeHeading = "#step-2"
     validateHeading = "#step-3"
     requestReviewHeading = "#step-4"
     patternInformationTab = "Pattern Information "
     importdatamodelTab = "#importDataModel"
     patternName = "#labelName"
     description = "#description"
     orderOfExecution = '#order-of-execetion'
     daySpan = 'input[type="text"]'
     importdatamodelDropdownArrow = "#selected-labels"
     importDataModelDropdown = ".p-checkbox-icon"
     clickoutsidetoGetResult = "#authoring-patterns-body"
     addConditionPlusIcon = "#add-condition-btn > .pt-layout-container"
     addActionPlusIcon = "#add-action-btn > .pt-layout-container"
     saveAsDraft = 'button[id="pat-draft"]'
     threeDotsOfAuthoringWorkFlow = 'svg[id="Layer_1"]'
     renameOption = "#Rename"
     deleteOption = "#Delete"
     popUpDeleteOption = 'button[id="ok-btn"]'
     modalityDropdownfield = ".ng-star-inserted >.pt-layout-container > .ng-star-inserted"
     modalityDropdown = ".pt-option-label"
     patternTypeDropdown = 'dls-option[role="option"]'
     relevanceField = "Relevance "
     relevanceText = ".p-checkbox-icon"
     serviceContextFields = ".pt-option-list > :nth-child(1)"
     severityFields = ".pt-option-list >.pt-option"
     commentBox = "#comment"
     addTagButton = 'button[id="add-tag-btn"]'
     selectTag = "dls-multiselect[name='withoutKeyword']"
     addTagFromList = 'dls-multiselect-option[role="option"]'
     popUpOkButton = '#pat-draft'
     tagId = "ul#pattern-tags-list>li"
     addCondtionAsterisk = "#add-conditions span.mandatory"
     expandedAddConditionSectionVerification = "#add-cond-menu-section"
     dashboardButtonVisible = '#Dashboard'
     attributesVisible = "dls-tooltip-container > dls-tooltip > ul > li > p"
     checkboxVisible = ".p-checkbox >.p-checkbox-box"
     checkboxInImportDataModel = 'div[class="p-checkbox-box"]'
     importConditionsHeadingVisible = "dls-dialog-header>.pt-title"
     ruleDisabled = "#p-tabpanel-0-label"
     patternSelected = "#p-tabpanel-1-label"
     noDataVisibleInTable = "div>table>.p-datatable-tbody"
     searchByShowAllText = "app-elastic-search>div>p"
     showAllCheckboxVisible = "#es-show-all-checkbox"
     keywordDropDownWithAllSelected = "dls-dropdown>.pt-layout-container>span"
     searchBoxTestVisible = "#search-field>dls-layout-container>input"
     recordsFoundTextVerification = "#record-count.font-14"
     ButtonVisible = "dls-dialog-footer>button"
     entriesPerPage = " Entries per page: "
     totalCountOfPage = ".pt-navigation>.showing"
     patternNameSorted = "p-sorticon>i"
     changeEntriesPerPageCount = "dls-dropdown[role='listbox']"
     nextPageNavigation = ".pt-navigation dls-icon"
     navigationIcons = "#import-condition-view-toggle-icon"
     horizontalPanelVerification = "div.collapse-label"
     nameColumn = "#Name"
     discriptionColumn = "#Description"
     dataModelColumn = '[id="Data Models"]'
     tagsColumn = "#Tags"
     dropdownatSearchVisible = "section>dls-dropdown span"
     dropdownValuesVerification = "dls-option-list>dls-option"
     noDataFoundVerification = "#no-record-message"
     crossMark = "dls-searchbox .pt-clear-button"
     nextButton = "#pat-step-next"
     causeButton = "#select-cause"
     selectClauseHeading = ".pt-dialog .pt-title"
     selectSymptomsButton = "#select-symptom"
     knowledgeClick = "div[aria-label='Knowledge']>button"
     nextButtonDisabledVerification = "button[id='pat-step-next']"
     previousButtonClick = 'button[id="pat-step-prev"]'
     removeAction = 'app-token-tooltip>ul>li>span.pt-close-icon'
     applyMetadataActiveVerification = "#step-1"
     okButtonClick = "#ok-btn"
     gridVerification = "app-authoring ul>li"
     createPatternGridAsSelected = "#step-0"
     patternDescription = "#description"
     closeButton = "div>button#pat-close>dls-layout-container"
     nextButtonVisible = "button[id='pat-step-next']"
     addTagHeading = 'span[class="pt-title"]'
     doneButtonDisabledVerification = "button[class='pt-primary pt-button']"
     cancelButtonPopUp = "button[class='pt-button']"
     searchTextBox = "dls-multiselect[name='withoutKeyword']"
     addTagOkButton = "#add-select-tag"
     removeMarkVerification = "#remove-tag"
     removeMarkVerificationInKnowledge = "ul>li>span[class='pt-close-icon icon-dls-cross-circle close-icon ng-star-inserted']"
     keywordDropdownVisibleInTagSection = "#select-keyword"
     operatorDropdownVisibleInTagSection = "#select-operator"
     valueDropdownVisibleInTagSection = "#select-value"
     expandedDetails = "tbody>tr>td>span"
     symtomNameTextField = "#symptomName_searchIcon"
     attributeForCause = "section>dls-dropdown"
     option1 = "#mItem_0"
     operatorsDropdown = "#cond-operators > .pt-layout-container"
     valueInputField = ".value-input-field"
     relevanceCheckbox = '[aria-expanded="true"] > .p-checkbox > .p-checkbox-box'
     breadcumbLastValue = ".pt-layout-container > ul > li > a > span"
     dropdownValue = "dls-dropdown"
     withoutKeywordDropdown = 'div>ul>li>.pt-token-label'
     addTagsList = 'div[class="card-text w-100"] ul li'
     addKnowledgePlusIcon = '#nav-add-btn'
     symptomDescription = 'app-symptom-viewmode div span'
     symptomTag = 'dls-token ul'
     tableDataValue = 'tr>td>span'
     previewedSection = '.preview-section>h2>div'
     relevanceFild = 'p-checkbox-icon'
     tableData = 'tr>td'
     importDataModelDropDownList = 'li>div>span>span>div'
     tagsFilterValue = 'p-multiselect div .p-multiselect-label'
     tagsMultiselectFilterValue = 'div[class="p-checkbox-box"]'
     descriptionFilterTextField = "#description_searchIcon"
     patternNameFilterTextField = "#patternName_searchIcon"
     showAllResult = 'div .p-datatable-tbody>tr'
     searchIcon = 'dls-searchbox .icon-dls-search'
     sizeAndPatternDetails = 'div>p'
     importCondLogicalExpression = '#import-cond-logical-exp'
     totalRecordFoundCount = '//tbody/tr'
     importDataModelCapturedValue = "#importDataModel ul > li "
     importDataModelCapturedValueRemove = 'li span[class="pt-close-icon icon-dls-cross-circle close-icon ng-star-inserted"]'
     importDataModlCommonSelection = ".p-checkbox-box"
     patternInformation = "app-token-tooltip>ul>li>span.pt-token-label"
     patternInfo = "span.pt-token-label"
     plusIconInAddCondition = '[id="add-condition-btn"]'
     orderOfExecutionTextBox = 'input[formcontrolname="orderOfExecution"]'
     nextButtton = 'button#pat-step-next';
     disabledClass = 'opacity-05 pt-button ng-star-inserted';
     modalityDropdownInApplyMetadata = 'dls-multiselect[role="listbox"]';
     patternNameInAddCondition = 'th[id="Name"]'
     nameInAddConditionRecord1 = '//tbody/tr[2]/td[1]/span[1]';
     nameInAddConditionRecord2 = '//tbody/tr[3]/td[1]/span[1]';
     descriptionInAddConditionRecord1 = '//tbody/tr[2]/td[2]/span[1]';
     descriptionInAddConditionRecord2 = '//tbody/tr[3]/td[2]/span[1]';
     mandatoryFields = "header>section>span>span";
     mandatoryFieldsWithAsterisk = 'header>section>span>span[class="mandatory"]';
     patternTypeDropdownInApplyMetadataPage = 'dls-dropdown[role="listbox"]';
     myPatternDropArrow = 'span[class="p-tree-toggler-icon pi pi-fw pi-chevron-right"]'
     impoprtDataModel = '#importDataModel'
     dataModelDropdownArrow = '#selected-labels'
     dataModelCommonOptionDropArrow = 'div[aria-label="Common"]'
     formDataModel = '#undefined dls-menu-item'
     dataModel = '[id="mItem_0"]'
     operatorForEventOne = '[id="cond-operators"]'
     Operator = '[class="pt-option ng-star-inserted"]'
     addConditionButton = '[id="cond-add-btn"]'
     addedCondtionAttributeDropdown = '[formcontrolname="attribute"]'
     addCondtionOptionForTestOne = '[class="complex-exp-option pt-option"]'
     addConditionPopUp = 'dls-popup[id="undefined"]'
     operatorOneDropdownFortetsOne = '[formcontrolname="aggregateOperator"]'
     attributeOneDropDownArrowForTestOne = '[class="pi pi-fw pi-chevron-down drop-down-icon dropdown-arrow-icon"]'
     attribute = '[class="pt-menu-item ng-star-inserted"]'
     operatorTwoFortetsOne = '[formcontrolname="operator"]'
     attributetwoArrowForTestOne = '[class="pi pi-fw pi-chevron-down drop-down-icon dropdown-arrow-icon icon-seperator"]'
     addedExpressionForEventOne = 'abs(EventLog1.Event_TimeStamp * EventLog1.EventLog_TimeStamp)'
     mainOperatorDropdownArrowUnderTesttwo = '[id="logical-operators"]'
     operatorOneOfAddExpressionFortetsTwo = '[formcontrolname="aggregateOperator"]'
     operatorTwoOptionFortestTwo = '[formcontrolname="operator"]'
     attributeTwoDropdownArrowUnderTestTwo = '[class="pi pi-fw pi-chevron-down drop-down-icon dropdown-arrow-icon icon-seperator"]'
     testTwoOptionUnderAttributeTwoDropdownOfTestTwo = '[id="mItem_1"]'
     eventOneRemoveOption = '[id="cond-delete-btn"]'
     crossMarkOfImportedDataModel = 'span[class="pt-close-icon icon-dls-cross-circle close-icon ng-star-inserted"]'
     seletedTestDataModel = 'ul[class="token-container ng-star-inserted"]'
     dependentEvent = 'ul[class="token-container ng-star-inserted"]'
     crosssMarkOfdataModel = '[class="pt-close-icon icon-dls-cross-circle close-icon ng-star-inserted"]'
     addedExpressionForEvent = '[id="attribute-name"]'
     ValueForTestOne = 'input[formcontrolname="value"]'
     autoGeneratedFirstEvent = '[id="evt-container"]'
     AutoGeneratedFirstCondition = '[id="condition-group"]'
     autoGeneratedEventName = '[id="evt-name"]'
     checkBox = '[class="pt-input"]'
     attributeDropDown = '[id="attribute-name"]'
     valueTextBox = '#value-field'
     crossMarkAtConditionLevel = '[id="cond-remove-btn"]'
     expandCollapseIconAtgroupLevel = '[viewBox="0 0 140 140"]'
     valueWaterMark = '[formcontrolname="value"]'
     attributeForSecondCondition = '[id="attribute-name"]'
     valueForSecondConditionInSecondEvent = '[role="option"]'
     logicalExpressionAtEventLevel = '#rule-event-group>span'
     logicalExpressionAtAddConditionLevel = '[class="pt-token-only ng-star-inserted"]'
     DataModel = '[class="p-checkbox-box"]'
     systemConfigurationDataModelInList = '#mItem_2'
     eventLogDataModelInList = '#mItem_3'
     importConditionPopUp = '[class="pt-dialog"]'
     availablePatternsList = '[class="p-element p-datatable-tbody"]'
     importButton = '[class="pt-primary pt-button pt-auto-focus"]'
     patternUnderAddCondition = '#add-conditions'
     addExpressionPopUpCloseButton = '[class="pt-quiet pt-button"]'
     selectedDataModel = '[class="p-checkbox-icon pi pi-check"]'
     operator = '[id="cond-operators"]'
     operators = '[class="pt-option ng-star-inserted"]'
     addExpressionsTitle = '[class="pt-title"]'
     attributeOneInAddExpressinPopUp = '#attribute-name1'
     attributeTwoInAddExpressionPopUp = '#attribute-name2'
     doneButtonInPopUp = '[class="pt-primary pt-button pt-auto-focus"]'
     closeButtonInPopUp = '[class="pt-quiet pt-button"]'
     msUnit = '#dls-popup-timespan-unit'
     addAction = '[class="accordian-header ng-star-inserted"]'
     firstKnowledge = '[class="p-element p-selectable-row ng-star-inserted"]'
     UnitDropDown = '[id="timespan-unit"]'
     fromVariableOption = ' From Variable '
     groupButton = '[id="group-cond-btn"]'
     ungroupOptionForEvent = '[id="ungroup-cond-btn"]'
     groupButtonforEventOne = '[class="cond-btn disable-click"]'
     confirmationPopUp = '[id="undefined"]'
     groupButonAtEvent = '[id="group-evt-btn"]'
     eventAddedFromAsIsOption = '[id="cond-evt_3"]'
     ungroupOption = '[class="cond-btn"]'
     crossIconAtGroupedEventLevel = '#ungroup-cond-delete-btn'
     groupedEvents = '[class="event-group-container ng-star-inserted"]'
     groupEvent = '#rule-event-group'
     savedEvent = '[class="token-container ng-star-inserted"]'
     valueOptionForEventTwoConditionFour = '[class="value-input-field ng-untouched ng-pristine ng-invalid pt-input"]'
     eventAddedFromAsIsOptionInRulepattern = '[id="cond-evt_1"]'
     rulePatternOption = '[class="pt-menu-item"]'
     commonSearchBox = '[placeholder="Search by Keyword"]'
     searchButton = '[class="icon-dls-search pt-icon"]'
     coloumLevelNameFilter = '#patternName_searchIcon'
     coloumLevelDecriptionFilter = '#description_searchIcon'
     colcounLevelDataModelFilter = 'th[id="column_dataModels"]'
     colcounLevelDataModelfilter = 'p-multiselect[id="multiselect-filter"]'
     coloumLevelTagsFilter = '#column_tagValue'
     selectAllCheckBox = '[role="checkbox"]'
     filterOption = '[placeholder="Filter Options"]'
     checkBoxAtEachValueLevel = '[class="p-checkbox p-component"]'
     clearButton = '[id="dataModels_clearBtn"]'
     applyButton = '[id="dataModels_applyBtn"]'
     dataModelDropDown = '.ng-trigger.ng-trigger-overlayAnimation'
     valueOnDropDown = '[filterplaceholder="Filter Options"]'
     filterOptionInDropDown = '[placeholder="Filter Options"]'
     commonSearchTextBox = 'dls-dropdown[role="listbox"]'
     commonSearchTextBoxNameSelected = 'dls-dropdown[role="listbox"]'
     allOptionUnderCommonSearch = 'dls-dropdown[role="listbox"]'
     pageCount = '[class="showing"]'
     recordCount = '#record-count'
     crosssIcon = '[class="icon-dls-cross-circle pt-icon"]'
     eventLogDataModelInColumnLevelFilter = '[aria-label="EventLog"]'
     patternTabThreeDots = '#Layer_1'
     addConditionOption = 'span[class="accordian-header ng-star-inserted"]'
     dropDownOptionUnderAddCondition = 'span[class="pi pi-chevron-down"]'
     searchByKeyWordOption = 'input[placeholder="Search by Keyword"]'
     searchButtonOfSearchByKeyWord = 'button[class="pt-search-button"]'
     searchedPatternDetails = '[class="p-element p-selectable-row ng-star-inserted"]'
     dataModeldropDownEventLogOption = '[aria-checked="false"]'
     applyButtonOfDataModelFilter = 'button[id="dataModels_applyBtn"]'
     tagsFilterDICOMandInteroperabilityOption = 'li[aria-label="FV==DICOM and Interoperability"]'
     applyButtonOfTagslFilter = 'button[id="tagValue_applyBtn"]'
     dropDownOptions = 'dls-option[tabindex="0"]'
     allText = 'dls-dropdown[role="listbox"] span'
     addTagPlusButton = '#cond-add-btn'
     firstPatternClick = '[class="p-element context-menu-area p-selectable-row ng-star-inserted"]'
     importDataModelDetailInCreatePatternPage = '[class="pt-token-label"]'
     patternNameTextBox = '#labelName'
     plusIcon = '#add-action-btn'
     detailsInApplyMetadataPage = '[id="field.tagId"]'
     fseOption = '[class="pt-multiselect-option pt-selected ng-star-inserted"]'
     Dashboard = '[id="Dashboard"]'
     searchBar = 'input[placeholder="Search"]'
     commentArea = '#comment'
     patterndescriptionDetails = '[id="readonly-description"]'
     patternDataModelDetails = '[id="data-model-list"]'
     patternExpression = '#logical-expression'
     modelityType = '[id="metadata.modality"]'
     patternTypee = '[id="metadata.pattern_type"]'
     knowledgeName = '[class="font-sans-book font-16 li-label"]'
     newlyCreatedPatternText = '#pat-name'
     myPatternDashboardPage = '[class="p-treenode ng-star-inserted"]'
     daySpanDetails = '#dayspan'
     daySapnInApplyMedadataPage = '[formcontrolname="dayspan"]'
     publishedOption = '[aria-label="Published"]'
     patternStatusApplyButton = '#patternStatus_applyBtn'
     addTagPlusIcon = '#add-select-tag'
     breadcrumbValues = "dls-breadcrumb[class='pt-breadcrumb'] span"
     workflow = 'a[class="node-label-font"]'
     dashboard = 'a[id="Dashboard"]'
     descriptionTextBox = '#description'
     entriesPerPageDropDown = '[class="pt-quiet pt-dropdown ng-untouched ng-pristine ng-valid"]'
     searchByKeywordOption = '#search-field'
     arrowToNevigateToNextpage = '[class="pt-quiet-default custom-button-right pt-button"]'
     recordsInPatternDashBoard = '[class="p-element context-menu-area p-selectable-row ng-star-inserted"]'
     addExpressionPopUpFirstOperatorDropDown = '[name="condLogical"]'
     attributeOneEventOneOperators = '[role="menuitem"]'
     importedDataModelSection = '#importDataModel'
     addConditionSection = '#add-conditions'
     groupUngroupConditionOption = '[id="group-cond-btn"]'
     operatorDropdownAtEventAndCondition = '[id="logical-operators"]'
     groupedConditions = '[class="exp-group-container"]'
     conditionsWithCheckBox = '#cond-check-box'
     patternInformationOption = 'Pattern Information '
     groupOptionAtEvent = '[id="group-evt-btn"]'
     saveAsRuleOption = '#rule-save-btn'
     logicalExpressionAtEventLevelForEvents = '#rule-event-group'
     ungroupOptionForGroupedEvents = '[id="ungroup-cond-btn"]'
     crossMarkAtGroupedEvents = '#ungroup-cond-delete-btn'
     popUpTitle = '[id="dialog-title"]'
     popUpDialogue = '#dialog-body'
     conditionsName = '[id="cond-name"]'
     copiedEventFromEvents = '[class="copy-event-container mar-top-10 ng-star-inserted"]'
     copiedEventFormEVentFour = '#cond-evt_1'
     patternDashboardBreadCrum = '[class="pt-breadcrumb"]'
     includeKnowledgePage = '#steps-list'
     KnowledgwSelectcheckBox = 'span[class="p-checkbox-icon"]'
     TitleWithRightMark = '#steps-list'
     Tab = '[class="p-tabview-title ng-star-inserted"]'
     next = 'button[id="pat-step-next"]'
     saveAsAfterClick = '[class="opacity-05 pt-button ng-star-inserted"]'
     okButtonOnPopUp = '#ok-btn'
     breadCrumbForMyPatternDashboard = '[class="pt-breadcrumb"]'
     myPatternDashboard = '[class="p-treenode-content p-treenode-selectable p-highlight"]'
     removeKnowledgeIcon = '#remove-icon'
     existingWF = '[class="p-treenode-children ng-star-inserted"]'
     KnowledgeTextInRightSection = '#knowledge-name';
     iconToCollaspeRightSideSection = '#knowledge-view-toggle-icon';
     KnowledgeDetailsTextWhenRightSideCollapse = '[class="collapse-label ng-star-inserted"]';
     iconToExpandRightSideSection = 'button[id="knowledge-view-toggle-icon"]';
     firstKnowledgwSelectInReviewTab = '#selected_knowledge_0';
     secondKnowledgeInReviewTab = '#selected_knowledge_1';
     knowledgeDetailsReviewTab = '[class="accordion-view ng-star-inserted"]';
     lastSelectedKnowledgeTextInRightSection = '#knowledge-name'
     Accordions = '[class="mar-left-1 knowledge-accordion pt-accordion"]'
     descriptionDetails = '#auditInfo'
     reviewTabWithKnowledgeCount = '[class="p-tabview-title ng-star-inserted"]'
     knowledgeNameHeader = '[class="font-sans-book font-14 pt-list-header"]'
     seconndKnowledge = '#selected_knowledge_1'
     thirdKnowledge = '#selected_knowledge_2'
     descriptionAccordions = '#auditInfo'
     selectedKnowledgeDetails = '[class="mar-left-1 knowledge-accordion pt-accordion"]'
     crossMarkOfFirstKnowaledge = 'button[id="remove-icon"]'
     knowledgeDescriptionInrewviewTab = '[class="accordian-header multiline-content ng-star-inserted"]'
     includeTab = '[class="p-tabview-nav"]'
     removedKnowledge = '[class="p-checkbox-box p-component"]'
     fullScreenButtonInIncludeTab = '#knowledge-details-fullview-icon'
     rightSectionInFullScreenView = 'div[id="p-tabpanel-0"]'
     leftPane = '[class="dashboard_box"]'
     allButtons = '#authoring-patterns-btns'
     knowlwdgeCauseAndSolution = '[class="custom-header ng-star-inserted"]'
     detailsOfCauseAndSolutionInIncludeTab = '[class="preview-section"]'
     knowledges = '#knowledge-list'
     plusIconUnderAddAction = '#add-action-btn'
     entriesPerpageDropdown = '[role="listbox"]'
     AddAuthoringWokFlowButton = "#nav-add-btn";
     activeClass = 'active ng-star-inserted'
     ngStarInsertedClass = 'ng-star-inserted'
     ngStarInsertedclass = '[class="ng-star-inserted"]'
     ngStarInsertedActiveClass = 'ng-star-inserted active'
     ngStarInProgresStateClass = 'ng-star-inserted in-progress'
     ariaSelectedAttribute = 'aria-selected'
     ptLayoutContainerClass = '[class="pt-layout-container"]'
     dlsExpanderChildrenClass = 'dls-expander'
     ptExpanderClass = "pt-expander ng-star-inserted pt-expanded"
     noResultsFoundInRelevanceMessage = " No records found "
     savedPatternName = '[class="p-treenode-children ng-star-inserted"]'
     threeDotsBesideWfname = '#nav-dropdown-btn'
     renameInputBox = '[class="pt-input ng-untouched ng-pristine ng-valid"]'
     threeDotsOfExistingWf = 'section[id="RenamedWorkFlow"]'
     existingWfName = '[class="p-treenode-content p-treenode-selectable p-highlight"]'
     descriptionSection = '#description'
     orderOfExecutionTextbox = '#order-of-execetion'
     nextButtonInPattern = '#pat-step-next'
     deleteWFText = '#dialog-title'
     deleteWFBodyText = '#dialog-body'
     cancelButtonInDeleteWFPopup = '#cancel-btn'
     attributeList = '#dls-popup-attribute-name'
     addedExpressionsInConditions = '#attribute-name>dls-layout-container[class="pt-layout-container"]>span'
     descriptionAccordiansClass = 'pt-expander pt-expanded ng-star-inserted'
     workFlowNameClass = '[class="node-label-font"]'
     supressAlertOption = 'dls-menu-item[id="mItem_2"]'
     createdPattern = 'ul[class="p-treenode-children ng-star-inserted"]'
     patternFilterOption = '#filter-option'
     patternNameOnDetailsPage = 'span[id="pat-name"]'
     existingPatternNameCapture = 'ul[role="group"] section>a'
     invalidPatternNameEnteredValidationMessage = 'dls-validation-message span'
     workflowStepsList = 'ul>li[id]'
     threeDotsGridButton = '#grid-dropdown-btn > #Layer_1'
     cloneButtonFromGrid = '#Clone'
     createdEvent = '[id="evt-container"]'
     valueOptionForSecondCondition = '[id="value-field"]'
     logicalExpressionUnderEvent = '[id="condition-group"]'
     multiselectFiltersInImportConditionSection = '#multiselect-filter'
     firstValueInDataModelsDropdownInImportCondition = 'li[aria-label="EventLog"]'
     datamodelsApplyButton = '#dataModels_applyBtn'
     datamodelsColumnSelectedValue = '#multiselect-filter div>div>div'
     tagColumnFirstRecord = '#multiselect-filter div>div[class]'
     tagsColumnRecord = '//tbody/tr[1]/td[4]/span[1]'
     knowledgeNameSearch = '#knowledgeName_searchIcon'
     myPatternsSectionCollapseIcon = 'div[aria-label="My Patterns"]>button'
     recordsAvailableInDashboard = 'tbody>tr>td>p-tablecheckbox'
     patternStatusColumn = "p-multiselect[id='multiselect-filter']"
     patternStatusOptions = 'p-multiselectitem>li'
     deletePatternButtonInDashboard = '#delete-pattern'
     deletePopUp = 'dls-popup>dls-dialog'
     advanceFilterAppliedOnRecords = 'span>strong'
     clearAllFiltersButton = '#clear-all-filter'
     modalityFilter = "//div[contains(text(),'DXR')]"
     recordsNaviagationLink = 'td>span[class="btn-link ng-star-inserted"]'
     servicecontextColumn = 'th[id="column_metadata.service_context"]'
     servicecontextApplyButton = 'button[id="metadata.service_context_applyBtn"]'
     modalityColumn = 'th[id="column_metadata.modality"]'
     modalityApplyButton = 'button[id="metadata.modality_applyBtn"]'
     checkboxInDashboard = "div[role='checkbox']"
     deleteButtonInsidePattern = "footer > .align-right > :nth-child(1)"
     patternNameColumn = 'th[id="Pattern Name"]'
     publishButton = '#publish-pattern'
     withdrawButton = '#withdraw-pattern'
     systemIdSelection = '#systemId'
     systemIdOptions = 'li[aria-label]'
     systemIdApplyButton = '#applyBtn'
     calenderDateSelection = 'table tr td span[draggable="false"]';
     limitSelection = 'input[formcontrolname="limit"]';
     validateButton = '#validate-btn';
     notificationClass = '.pt-notification-item-text-content';
     selectedModality = '.p-checkbox-box.p-highlight'
     CTModality = 'li[aria-label="CT"]'
     IGTModality = 'li[aria-label="IGT"]'
     patternSectionCollapse = 'div[aria-label="Patterns"]>button'
     monthBackNavigationIcon = '.p-datepicker-header>button[type="button"]'
     filterForKeyword = 'input[placeholder="Search by Keyword"]';
     publishedPatternRecordInRulePattern = '[class="p-element p-resizable-column ng-star-inserted"]'
     editTagAssociations = '[id="Edit Tag Associations"]';
     severityField = "//tbody/tr[23]/td[1]/p-treetabletoggler[1]";
     criticalNeedField = "//span[contains(text(),'1-Critical Need')]";
     bulkStepNext = "#pat-bulk-step-next";
     updateButton = "#update-pattern";
     removeButton = "#remove-pattern";
     addButton = "#add-pattern";
     selectTagHeading = ".select-tag-heading";
     tagSelectionDropdown = "#tag-selection";
     bulkPublishButton = "#pat-bulk-publish";
     metadataSeverity = '[id="metadata.severity"]';
     backAccordian = '[alt="Back"]';
     patternInfoInsidePattern = '#patInfo svg';
     fullScreenIcon = '[alt="Expand"]';
     collapseScreenIcon = '[alt="Collapse"]';
      versionColumn = 'th[id="Version"]';
      closeButtonInsidePattern = '#pat-bulk-close';
      saveAsDraftButtonInsidePattern = '#pat-bulk-draft';
      previousButtonInsidePattern = '#pat-bulk-step-prev';
      tagsField = "//tbody/tr[1]/td[1]/span[1]";
      selectAllCheckboxClick = "#selectall_checkbox span.p-checkbox-icon";
      rightsideAccordians = "#patInfo section";
      cancelButtonInsidePattern = ".dialog-button.cancel";
      selectButtonInsidePattern = ".dialog-button";
      patternNameInsidePattern = "#pattern-name";

}

export default CreatePatternPageLocators;