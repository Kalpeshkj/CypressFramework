/// <reference types="Cypress" />
/// <reference types='cypress-tags' />

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import IncludeKnowledge from "../../../../support/pageObjects/pages/PatternAuthoring/includeKnowledgepageObj";
const includeKnowledge = new IncludeKnowledge();
import CreateKnowledge from "../../../../support/pageObjects/pages/KnowledgeAuthoring/CreateKnowledge";
const createKnowledge = new CreateKnowledge();

When("Expands Symptom section and clicks on Select Symptom", () => {
    createKnowledge.symptomsClick();
    createKnowledge.selectSymptomsButtonClick();
    console.log(printTimestamp(), ' Symptom section expanded and clicked on Select Symptom')
});

Then('Search any keyword in common search', () => {
    includeKnowledge.commonFilterClickAndType();
    console.log(printTimestamp(), ' keyword searched in common search')
});

Then("Verifies column level filter should be displayed Name column with textbox and tags with multi dropdown", () => {
    includeKnowledge.knowledgeDetailsVerification();
    includeKnowledge.symptomNameAndTagsColumnFiltersTypeVerification();
    console.log(printTimestamp(), ' column level filter displayed')
});

Then("User Click on drop down of multi select dropdown and verify UI for filter options drop down", () => {
    includeKnowledge.symptomTagsColumnDropdownClick();
    includeKnowledge.symptomTagsMultiValuesDropdownVerification();
    console.log(printTimestamp(), ' Clicked on drop down of multi select dropdown and verify UI for filter options drop down')
});

When("User Clicks on column filter for tags ,select one value available in drop down and click on apply button", () => {
    includeKnowledge.symptomTagsSingleValueClickFromDropdown();
    console.log(printTimestamp(), ' Clicked on column filter for tags and selected one value available in drop down')
});

Then('After clicking on apply button filtered data should be displayed and drop down should be closed', () => {
    includeKnowledge.dropdownPopUpNotExistVerification();
    console.log(printTimestamp(), ' After clicking on apply button filtered data displayed')
});

Then("Verify that filtered result available as per applied filter for drop down option", () => {
    includeKnowledge.filteredDataVerification();
    console.log(printTimestamp(), ' Filtered result available as per applied filter')
});

Then("Verify that filter result available as per applied filter for drop down option", () => {
    includeKnowledge.filteredataVerification();
    console.log(printTimestamp(), ' Filtered result available as per applied filter')
});

Then("Verify that filtered result available as per applied filter for dropdown option", () => {
    includeKnowledge.filteredataVerification();
    console.log(printTimestamp(), ' Filtered result available as per applied filter')
});

Then("Verify that filtered result available as per applied filter", () => {
    includeKnowledge.filteredDataVerificationForMultplefilters();
    console.log(printTimestamp(), ' Filtered result available as per applied filter')
});

When("User Click on column tags and select multiple options from available in drop down", () => {
    includeKnowledge.symptomTagsSingleMultipleClickFromDropdown();
    console.log(printTimestamp(), ' Clicked on column tags and select multiple options ')
});

When("User Click on tags column level filter and search any value", () => {
    includeKnowledge.symptomTagsColumnDropdownClick();
    includeKnowledge.tagsColumnFilterByTypeVerification();
    console.log(printTimestamp(), ' Clicked on tags column level filter')
});

Then("Searched result should be displayed", () => {
    includeKnowledge.filteredDataVerification();
    console.log(printTimestamp(), ' Searched result displayed')
});

Then("Search result should be displayed", () => {
    includeKnowledge.filteredataVerification();
    console.log(printTimestamp(), ' Searched result displayed')
});

When("User Click on Clear button available in drop down", () => {
    includeKnowledge.symptomTagsColumnDropdownClick();
    includeKnowledge.symptomTagsColumnDropdownClearButtonClick();
    console.log(printTimestamp(), ' Clicked on Clear button')
});

Then("Filter drop down should be closed", () => {
    includeKnowledge.dropdownPopUpNotExistVerification();
    console.log(printTimestamp(), ' Filter drop down closed')
});

When("Clicks on tags column level filter and select single, multi or all check box", () => {
    includeKnowledge.symptomTagsColumnDropdownClick();
    includeKnowledge.tagsColumnFilterForSelectAllValuesVerification();
    console.log(printTimestamp(), ' Clicked on tags column level filter and select single, multi or all check box')
});

When("User Enter any value in text box related filter Name and Description then click on enter", () => {
    createKnowledge.symptomNameColumnType();
    console.log(printTimestamp(), ' Enter any value in text box')
});

Then("Verify search icon and x mark when filtered applied", () => {
    createKnowledge.crossIconInSelectSymptomsVisible();
    createKnowledge.searchIconInSelectSymptomVisible();
    createKnowledge.crossIconInSelectSymptomClick()
    console.log(printTimestamp(), ' Verified search icon and x mark when filtered applied')
});

And("Verify that filtered result available on top of applied filter for drop down option", () => {
    cy.wait(2000)
    includeKnowledge.searchedDataVisible();
    console.log(printTimestamp(), ' filtered result available on top of applied filter')
});

When("User Enter keyword in common search  text box by keeping 'All' in dropdown option", () => {
    includeKnowledge.commonFilterClickAndType();
    console.log(printTimestamp(), ' Entered keyword in common search  text box by keeping "All" in dropdown option')
});

Then("Verify filtered result available in grid", () => {
    console.log(printTimestamp(), ' Verified filtered result available in grid')
});

And("Verify Entries per page , Showing current page of total page and total number of records", () => {
    includeKnowledge.recordsFoundVisible();
    includeKnowledge.entriesPerPageVisible();
    includeKnowledge.totalNumberOfRecordsVisible();
    console.log(printTimestamp(), ' Verified Entries per page , Showing current page of total page and total number of records')
});

When("User Select any option from drop down of common search and enter keyword", () => {
    includeKnowledge.commonDropdownClick();
    includeKnowledge.commonFilterClickAndType();
    console.log(printTimestamp(), ' Selected any option from drop down of common search')
});

And("Click on search icon", () => {
    includeKnowledge.searchIconInSelectSymptomClick();
    console.log(printTimestamp(), ' Clicked on search icon')
});

When("User Click on search icon of common search text box after entering keyword", () => {
    includeKnowledge.searchIconInSelectSymptomClick();
    console.log(printTimestamp(), '  Clicked on search icon of common search text box')
});

Then("Click on X mark available in knowledge name textbox after verifing the data", () => {
    includeKnowledge.crossIconInSelectSymptomsClick();
    console.log(printTimestamp(), ' Clicked on X mark available in knowledge name textbox')
});

When("User Apply filter on one or multiple columns and click on clear all filter", () => {
    includeKnowledge.applyFilterOnMultipleColumnsLevel();
    includeKnowledge.clearAllFilterButtonClick();
    console.log(printTimestamp(), ' Applied filter on one or multiple columns ')
});

Then("After clicking on Clear All Filter data should get cleared", () => {
    includeKnowledge.recordsFoundVisible();
    createKnowledge.cancelButtonClick()
    console.log(printTimestamp(), ' After clicking on Clear All Filter data should got cleared')
});

Then("Repeat above steps by covering all drop down options in common filter text box", () => {
    console.log(printTimestamp(), ' Repeated above steps by covering all drop down options available in common filter text box')
});

Then("Repeat above steps by applying column level filters and verify filtered result", () => {
    console.log(printTimestamp(), ' Repeated above steps by applying column level filter and verify filtered result')
});

When("Expand causes and solutions section and click on Select cause", () => {
    createKnowledge.causesAndSolutionSectionClick();
    createKnowledge.causeButtonClick();
    console.log(printTimestamp(), ' Symptom section expanded and clicked on Select Symptom')
});

Then("Verifies column level filter should be displayed Name column with textbox and tags with multi dropdown in select cause", () => {
    includeKnowledge.knowledgeDetailsVerification();
    includeKnowledge.causeNameAndTagsColumnFiltersTypeVerification();
    console.log(printTimestamp(), ' column level filter displayed')
});

When("User Enter any value in text box related filter Name and Description and then click on enter", () => {
    includeKnowledge.causeNameColumnType();
    console.log(printTimestamp(), ' Enter any value in text box')
});

When("User Apply filter on one or multiple columns and then click on clear all filter", () => {
    includeKnowledge.applyFilterOnMultipleColumnsLevelForSelectCause();
    includeKnowledge.clearAllFilterButtonClick();
    console.log(printTimestamp(), ' Applied filter on one or multiple columns ')
});