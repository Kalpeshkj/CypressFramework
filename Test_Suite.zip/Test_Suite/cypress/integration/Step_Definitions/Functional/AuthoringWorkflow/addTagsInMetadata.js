/// <reference types="Cypress" />
/// <reference types = 'cypress-tags' />

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';

import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();

When("User enters all details in create pattern section and Clicks Next button", () => {
    cy.createPattern()
    createPattern.nextButtonClick()
    console.log(printTimestamp(), ' All details entered in create pattern')
})

Then("User should navigate to apply metadata section", () => {
    createPattern.applyMetadataActiveVerification()
    console.log(printTimestamp(), ' Navigated to apply metadata section')
})

And("User removes earlier added tag", () => {
    createPattern.removeAddedTags()
    console.log(printTimestamp(), ' Tag removed')
})

When("User Clicks on With Keyword and verify its content as like Keyword, Operator and value should present with dropdown", () => {
    createPattern.withKeywordClick()
    createPattern.keywordDropdownVisibleInTagSection()
    createPattern.operatorDropdownVisibleInTagSection()
    createPattern.valueDropdownVisibleInTagSection()
    console.log(printTimestamp(), ' Contens verified at with keyword section')
})

And("Verifies added tags section should be available for both with and without keyword tags", () => {
    createPattern.keywordDropdownClick()
    createPattern.operatorDropdownClick()
    createPattern.valueDropdownClick()
    createPattern.addtagPlusButtonClick()
    createPattern.addedTagVisible()
    createPattern.withoutKeywordClick()
    createPattern.addedTagVisible()
    createPattern.removeAddedTags()
    console.log(printTimestamp(), ' Added tags present in both sections with and without')
})

When("User Selects keyword ,operator and value from dropdown and clicks on + icon", () => {
    createPattern.withKeywordClick()
    createPattern.keywordDropdownClick()
    createPattern.operatorDropdownClick()
    createPattern.valueDropdownClick()
    createPattern.addtagPlusButtonClick()
    createPattern.doneButtonClick()
    console.log(printTimestamp(), ' User selects values from dropdown')
})

Then("Added tag should be available as removable token in added tags section", () => {
    createPattern.removeMarkVerification()
    console.log(printTimestamp(), ' removable mark available in added tags')
})

When("User removes added tags and re add any new tag", () => {
    cy.wait(1000)
    createPattern.removeAddedTags()
    createPattern.keywordDropdownClick()
    createPattern.operatorDropdownClick()
    createPattern.valueDropdownClick()
    createPattern.addtagPlusButtonClick()
    createPattern.doneButtonClick()
    createPattern.withKeywordClick()
    createPattern.keywordDropdownClick()
    createPattern.operatorDropdownClick()
    createPattern.valueDropdownClick()
    createPattern.addtagPlusButtonClick()
    createPattern.keywordDropdownClick()
    createPattern.operatorDropdownClick()
    createPattern.valueDropdownClick()
    console.log(printTimestamp(), ' User removed one tag and added another one')
})

Then("Similar Value should not be available in dropdown once its added by users in previous tag", () => {
    createPattern.addedTagNotAvailableInWithoutKeywordDropdownVerification()
    console.log(printTimestamp(), ' Same value verified as not present in dropdown')
})                          