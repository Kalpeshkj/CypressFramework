/// <reference types="Cypress" />
/// <reference types='cypress-tags' /> 

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';

import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();

import PatternDashboard from "../../../../support/pageObjects/pages/Dashboard/PatternDashboard";
const patternDashboard = new PatternDashboard();
Then("By default , Pattern Dashboard page should be displayed", () => {
    patternDashboard.patternDashboardTitleVisible()
    patternDashboard.patternDashboardBreadCrumVisible()
    cy.wait(3000)
    console.log(printTimestamp(), 'Pattern Dashboard displayed')
});

When("User Click on Pattern name", () => {
    patternDashboard.patternClick()
    console.log(printTimestamp(), 'Clicked on any pattern')
});

Then("Pattern Details should be displayed in grid", () => {
    patternDashboard.patternDetailsIngridVisible()
    console.log(printTimestamp(), 'Pattern Details displayed in grid')
});

And("Pattern name at left corner,Version: Version Value, Draft icon , screen expand icon", () => {
    patternDashboard.patternNameExist()
    patternDashboard.versionLableExist()
    patternDashboard.versionValueExist()
    patternDashboard.draftIconVisible()
    patternDashboard.screenExpandIconVisible()
    console.log(printTimestamp(), 'Pattern name at left corner,Version: Version Value, Draft icon , screen expand icon visible')
});

And("Pattern Details By default expanded Metadata,Knowledge,Audit Details,Delete,Withdraw,"
    + "Clone,Edit and Close buttons Buttons should be available and enabled disabled based on user access", () => {
        patternDashboard.patternDetailsExpanded()
        patternDashboard.MetadataInfoVisible()
        patternDashboard.knowledgeInfoVisible()
        patternDashboard.auditInfoVisible()
        patternDashboard.deleteButtonVisibleAndEnabled()
        patternDashboard.withdrawButtonVisible()
        patternDashboard.cloneButtonVisibleAndEnabled()
        patternDashboard.editButtonVisibleAndEnabled()
        patternDashboard.closeButtonVisibleAndEnabled()
        console.log(printTimestamp(), "Pattern Details By default expanded Metadata,Knowledge,Audit Details,Delete,Withdraw,"
            + "Clone,Edit and Close buttons Buttons available and enabled disabled based on user access")
    });

And("At each section level icon should be available for expand and collapse Pattern Details,Metadata,Knowledge,Audit,Details", () => {
    patternDashboard.expandAndCollapseIconVisible()
    console.log(printTimestamp(), 'At each section level icon available for expand and collapse Pattern Details,Metadata,Knowledge,Audit,Details')
});

And("Pattern ID- Value,Description-Value,Order of execution-Value,Data Models-Values,Conditions-Logical expression as value and all added conditions,Action Value Details visible", () => {
    patternDashboard.patternIdVisible()
    patternDashboard.patternDescriptionVisible()
    patternDashboard.orderOfExecutionVisible()
    patternDashboard.dataModelVisible()
    patternDashboard.conditionLogicalExpressionVisible()
    patternDashboard.actionDetailsVisible()
    console.log(printTimestamp(), 'Pattern ID- Value,Description-Value,Order of execution-Value,Data Models-Values,Conditions-Logical expression as value and all added conditions,Action Value Details visible"')
});

When("User Click on Pattern Details", () => {
    patternDashboard.patternDetailsoptionClick()
    cy.wait(1000)
    console.log(printTimestamp(), 'Clicked on Pattern Details')
});

Then("Pattern Details section should get collapsed", () => {
    patternDashboard.patternDetailsCollapsed()
    console.log(printTimestamp(), 'Pattern Details section get collapsed')
});

When("User Click on Pattern Details", () => {
    patternDashboard.patternDetailsoptionClick()
    cy.wait(1000)
    console.log(printTimestamp(), 'Clicked on Pattern Details')
});

Then("Pattern Details should get expanded", () => {
    patternDashboard.patternDetailsExpanded()
    console.log(printTimestamp(), 'Pattern Details get expanded')
});

When("User Click on Metadata", () => {
    patternDashboard.metadataOptionClick()
    console.log(printTimestamp(), 'Clicked on Metadata')
});

Then("Metadata section should get collapsed", () => {
    patternDashboard.metadataDetailsCollapsed()
    console.log(printTimestamp(), 'Metadata section gets collapsed')
});

And("At a time multiple section can be available in expanded state", () => {
    patternDashboard.metadataOptionClick()
    patternDashboard.metadataDetailsExpanded()
    patternDashboard.patternDetailsExpanded()
    console.log(printTimestamp(), 'At a time multiple section available in expanded state')
});

And("Pattern Type-Value,Service Context-Value,Time Span-Value,Modality-Value,Relevance-Value", () => {
    patternDashboard.patternTypeExist()
    patternDashboard.patternValueExist()
    patternDashboard.serviceContextTextExist()
    patternDashboard.serviceContextValueExist()
    patternDashboard.timeSpanTextExist()
    patternDashboard.timeSpanValueExist()
    patternDashboard.modalityTextExist()
    patternDashboard.modalityValueExist()
    patternDashboard.relevanceTextExist()
    console.log(printTimestamp(), 'Pattern Type-Value,Service Context-Value,Time Span-Value,Modality-Value,Relevance-Value')
});

And("Default expansion should be available at product family level,Comment-Value,Severity-Value,Tags-Values as token", () => {
    patternDashboard.expandedProductfamilyVisible()
    patternDashboard.commentTextVisible()
    patternDashboard.commentValueExist()
    patternDashboard.severityTextVisible()
    patternDashboard.severityValueExist()
    patternDashboard.tagsTextVisible()
    console.log(printTimestamp(), 'Default expansion available at product family level,Comment-Value,Severity-Value,Tags-Values as token')
});

And("Order should be available in mandatory fields in alphabetic order followed by nonmandatory fields in alphabetic order where Relevance Data should be available at right side", () => {


    console.log(printTimestamp(), 'Order available in mandatory fields in alphabetic order followed by nonmandatory fields in alphabetic order where Relevance Data available at right side')
});

When("User Click on any product family and verify details", () => {


    console.log(printTimestamp(), 'Clicked on any product family and verify details')
});

Then("Product Family , System Type ,Release, Version, Level , Build should be displayed under product family", () => {


    console.log(printTimestamp(), 'Product Family , System Type ,Release, Version, Level , Build displayed under product family')
});

When("User Click on Close button", () => {
    patternDashboard.closeButtonClick()
    console.log(printTimestamp(), 'Clicked on Close button')
});

Then("User should be able to navigate to Dashboard from where pattern details page opened", () => {
    patternDashboard.patternDashboardTitleVisible()
    patternDashboard.patternDashboardBreadCrumVisible()
    cy.wait(3000)
    console.log(printTimestamp(), 'navigate to Dashboard from where pattern details page opened')
});

And("Repeat above steps in My  Pattern Dashboard", () => {
    patternDashboard.myPatternArrowClick()
    createPattern.myPatternDashboardClick()
    cy.wait(3000)
    patternDashboard.patternClick()

    patternDashboard.patternDetailsIngridVisible()

    patternDashboard.patternNameExist()
    patternDashboard.versionLableExist()
    patternDashboard.versionValueExist()
    patternDashboard.draftIconVisible()
    patternDashboard.screenExpandIconVisible()

    patternDashboard.patternDetailsExpanded()
    patternDashboard.MetadataInfoVisible()
    patternDashboard.knowledgeInfoVisible()
    patternDashboard.auditInfoVisible()
    patternDashboard.deleteButtonVisibleAndEnabled()
    patternDashboard.withdrawButtonVisibleAndEnabled()
    patternDashboard.cloneButtonVisibleAndEnabled()
    patternDashboard.editButtonVisibleAndEnabled()
    patternDashboard.closeButtonVisibleAndEnabled()

    patternDashboard.expandAndCollapseIconVisible()

    patternDashboard.patternIdVisible()
    patternDashboard.patternDescriptionVisible()
    patternDashboard.orderOfExecutionVisible()
    patternDashboard.dataModelVisible()
    patternDashboard.conditionLogicalExpressionVisible()
    patternDashboard.actionDetailsVisible()

    patternDashboard.patternDetailsoptionClick()
    cy.wait(1000)

    patternDashboard.patternDetailsCollapsed()

    patternDashboard.patternDetailsoptionClick()
    cy.wait(1000)

    patternDashboard.patternDetailsExpanded()

    patternDashboard.metadataOptionClick()

    patternDashboard.metadataDetailsCollapsed()

    patternDashboard.metadataOptionClick()
    patternDashboard.metadataDetailsExpanded()
    patternDashboard.patternDetailsExpanded()

    patternDashboard.patternTypeExist()
    patternDashboard.patternValueExist()
    patternDashboard.serviceContextTextExist()
    patternDashboard.serviceContextValueExist()
    patternDashboard.timeSpanTextExist()
    patternDashboard.timeSpanValueExist()
    patternDashboard.modalityTextExist()
    patternDashboard.modalityValueExist()
    patternDashboard.relevanceTextExist()

    patternDashboard.expandedProductfamilyVisible()
    patternDashboard.commentTextVisible()
    patternDashboard.commentValueExist()
    patternDashboard.severityTextVisible()
    patternDashboard.severityValueExist()
    patternDashboard.tagsTextVisible()



    patternDashboard.closeButtonClick()
    patternDashboard.myPatternDashboardBreadCrumVisible()
    console.log(printTimestamp(), 'Repeated above steps in My  Pattern Dashboard')
});


