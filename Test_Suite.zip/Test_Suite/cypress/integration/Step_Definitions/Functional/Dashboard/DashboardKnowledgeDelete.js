/// <reference types='cypress-tags' /> 
import "../../../../support/index";
import {When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import KnowledgeDashboard from "../../../../support/pageObjects/pages/Knowledge_Dashboard/KnowledgeDashboard";
const knowledgeDashboard = new KnowledgeDashboard();
import CreateKnowledge from "../../../../support/pageObjects/pages/KnowledgeAuthoring/CreateKnowledge";
const createKnowledge = new CreateKnowledge();

And("create a new knowledge Import existing symptoms and cause, add new cause"
+" and symptoms and publish-draft knowledge as required.", () => {
    createKnowledge.addKnowledgeWorkflowButtonClick()
    cy.wait(2000) 
    cy.CreateMyKnowledgeNormal()
    createKnowledge.saveAsDraftClick() 
    cy.wait(4000) 
    createKnowledge.getPatternName()
    cy.wait(1000)
    knowledgeDashboard.knowledgeDashboardClick()
    cy.wait(1000)
    createKnowledge.knowledgeNameSearch()
    knowledgeDashboard.searchIconForKnowledgeNameClick()
    cy.wait(2000)
    knowledgeDashboard.searchedKnowledgeClick()
    knowledgeDashboard.knowledgePublishOptionClick()
    knowledgeDashboard.okButtonButtonInPopUpClick()
    createKnowledge.addKnowledgeWorkflowButtonClick()
    cy.wait(2000)
    cy.CreateMyKnowledgeNormal()
    createKnowledge.saveAsDraftClick()
    cy.wait(3000) 
    createKnowledge.getPatternName()
    cy.wait(1000)
    knowledgeDashboard.knowledgeDashboardClick()
    cy.wait(1000)
    createKnowledge.secondKnowledgeSearch()
    knowledgeDashboard.searchIconForKnowledgeNameClick()
    cy.wait(2000)
    knowledgeDashboard.searchedKnowledgeClick()
    knowledgeDashboard.knowledgePublishOptionClick()
    knowledgeDashboard.okButtonButtonInPopUpClick()
    createKnowledge.addKnowledgeWorkflowButtonClick()
    cy.wait(3000)
    cy.CreateMyKnowledgeForBulkDelete()
    createKnowledge.saveAsDraftClick()
    cy.wait(4000) 
    createKnowledge.getPatternName()
    cy.wait(1000)
    createKnowledge.addKnowledgeWorkflowButtonClick()
    cy.wait(3000)
    cy.CreateMyKnowledgeForBulkDelete()
    createKnowledge.saveAsDraftClick()
    cy.wait(3000) 
    createKnowledge.getPatternName()
    cy.wait(1000)
    knowledgeDashboard.knowledgeDashboardClick()
    cy.wait(1000)
    console.log(printTimestamp(),  "created a new knowledge Import existing symptoms and cause, add new cause"
    +" and symptoms and publish-draft knowledge as required.")
});

Then("Delete button present in the right-side corner of dashboard should be disabled", () => {
    cy.wait(2000)
	knowledgeDashboard.deleteButtonInKnowledgeDashboardDisabled()
    console.log(printTimestamp(), 'Delete button present in the right-side corner of dashboard disabled')
});

When("User select a knowledge", () => {
	knowledgeDashboard.selectingPublishedKnowledges()
    console.log(printTimestamp(), 'selects a knowledge')
});

Then("Delete button should be enabled at top right corner", () => {
	knowledgeDashboard.deleteButtonInKnowledgeDashboardEnabled()
    console.log(printTimestamp(), 'Delete button enabled at top right corner')
});

When("User Select Published state of  knowledge and click on delete button from top right corner", () => {
    cy.wait(4000)
	knowledgeDashboard.deleteButtonInKnowledgeDashboardClick()
    cy.wait(1000)
    console.log(printTimestamp(), 'Selected Published state of  knowledge and clicked on delete button from top right corner')
});

Then("Confirmation message should be displayed Delete icon - The below 1 knowledges will be deleted. Are you sure you want to proceed?", () => {
	knowledgeDashboard.confirmationPopUpHeaderForDeletingPublishedJnowledgeVisible()
    console.log(printTimestamp(), 'Delete icon - The below 1 knowledges will be deleted. Are you sure you want to proceed?')
});

And("Knowledge Name,Cancel and Delete buttons should be displayed", () => {
	knowledgeDashboard.deleteButtonOnPopUpVisible()
    knowledgeDashboard.cancelButtonVisible()
    knowledgeDashboard.knowledgeNamesOnPopUpVisible()
    console.log(printTimestamp(), 'Knowledge Name,Cancel and Delete button displayed')
});

When("Click on Cancel button", () => {
	knowledgeDashboard.cancelButtonClick()
    console.log(printTimestamp(), 'Clicked on Cancel button')
});

Then("Knowledge should not get deleted", () => {
	createKnowledge.publishedKnowledgeVisible()
    console.log(printTimestamp(), 'Knowledge not get deleted')
});

When("Click on the Delete button and click on Delete button from pop up", () => {
	knowledgeDashboard.deleteButtonInKnowledgeDashboardClick()
    cy.wait(1000)
    knowledgeDashboard.deleteButtonOnPopUpClick()
    cy.wait(4000)
    console.log(printTimestamp(), 'Click edon the Delete button and clicked on Delete button from pop up')
});

Then("Knowledge including all version should get deleted from UI", () => {
	createKnowledge.publishedKnowledgeNotExist()
    console.log(printTimestamp(), 'Knowledge including all version  get deleted from UI')
});

// And("Verify details in db", () => {
	
//     console.log(printTimestamp(), 'Verified details in db')
// });

And("Deleted knowledge should not be displayed in UI , In Pattern deleted knowledge should not be displayed in UI", () => {
	createKnowledge.publishedKnowledgeNotExist()
    console.log(printTimestamp(), 'Deleted knowledge not be displayed in UI , In Pattern deleted knowledge not be displayed in UI')
});

When("Select knowledge Other than Published Status , and Delete knowledge", () => {
	knowledgeDashboard.checkBoxSelectingDraftKnowledgeClick()
    cy.wait(2000)
    knowledgeDashboard.deleteButtonInKnowledgeDashboardClick()
    cy.wait(1000)
    knowledgeDashboard.deleteButtonOnPopUpClick()
    cy.wait(2000)
    console.log(printTimestamp(), 'Selects knowledge than Published Status , and Delete knowledge')
});

// Then("Draft knowledge should get deleted , In db", () => {

//     console.log(printTimestamp(), 'Draft knowledge get deleted , In db')
// });

And("Deleted knowledge latest version should not be displayed in UI , In Pattern deleted knowledge latest"
+" version should not be displayed in UI Another version of that knowledge should get displayed in UI", () => {
	
    console.log(printTimestamp(),"Deleted knowledge latest version not be displayed in UI , In Pattern deleted knowledge latest"
    +" version not be displayed in UI Another version of that knowledge get displayed in UI")
});

When("User Select combination of Published-Withdraw-Draft and other state of knowledge and Click on Delete button", () => {
    cy.wait(1000)
	knowledgeDashboard.checkBoxSelectingDraftKnowledgeClick()
    knowledgeDashboard.checkBoxSelectingKnowledgeWithOutAssociationClick()
    knowledgeDashboard.deleteButtonInKnowledgeDashboardClick()
    cy.wait(1000)
    knowledgeDashboard.deleteButtonOnPopUpClick()
    cy.wait(2000)
    console.log(printTimestamp(), ' Selected combination of Published-Withdraw-Draft and other state of knowledge and Clicked on Delete button')
});

// Then("Depending on which state of knowledge deleted ,details should be updated in UI and db", () => {
	
//     console.log(printTimestamp(), ' Depending on which state of knowledge deleted ,details updated in UI and db')
// });

// When("Select knowledge which has withdrawn pattern association ,and Delete knowledge", () => {
	
//     console.log(printTimestamp(), 'Selected knowledge which has withdrawn pattern association ,and Delete knowledge')
// });

// Then("knowledge should get deleted", () => {
	
//     console.log(printTimestamp(), ' knowledge gets deleted')
// });

When("Click on three dot of any knowledge and delete knowledge", () => {
    createKnowledge.addKnowledgeWorkflowButtonClick()
    cy.wait(2000)
    cy.CreateMyKnowledgeNormal()
    createKnowledge.saveAsDraftClick()
    cy.wait(3000) 
    createKnowledge.getPatternName()
    cy.wait(1000)
    knowledgeDashboard.knowledgeDashboardClick()
    cy.wait(1000)
    createKnowledge.knowledgeSearchType()
    knowledgeDashboard.searchIconForKnowledgeNameClick()
    cy.wait(2000)
    knowledgeDashboard.rowLevelThreeDotsClick()
    knowledgeDashboard.deleteButtonUnderThreeDotsClick()
    cy.wait(1000)
    knowledgeDashboard.deleteButtonOnPopUpClick()
    cy.wait(2000)
    console.log(printTimestamp(), 'Clicked on three dot of any knowledge and delete knowledge')
});

Then("Based on which states knowledge deleted details should get updated in db and UI as mentioned in above steps", () => {
	createKnowledge.publishedKnowledgeNotExistAfterDeletingFromThreeDots()

    console.log(printTimestamp(), ' Based on which states knowledge deleted details gets updated in db and UI as mentioned in above steps')
});

When("Click on knowledge name and delete knowledge", () => {
	createKnowledge.addKnowledgeWorkflowButtonClick()
    cy.wait(2000)
    cy.CreateMyKnowledgeNormal()
    createKnowledge.saveAsDraftClick()
    cy.wait(4000) 
    createKnowledge.getPatternName()
    cy.wait(1000)
    knowledgeDashboard.knowledgeDashboardClick()
    cy.wait(1000)
    createKnowledge.knowledgeSearchFourthKnowledgeType()
    knowledgeDashboard.searchIconForKnowledgeNameClick()
    cy.wait(2000)
    knowledgeDashboard.searchedKnowledgeClick()
    cy.wait(2000)
    knowledgeDashboard.deleteButttonWhenClickedOnlinkEnabled()
    cy.wait(1000)
    knowledgeDashboard.deleteButttonWhenClickedOnlinkClick()
    knowledgeDashboard.deleteButtonOnPopUpClick()
    cy.wait(2000)
    knowledgeDashboard.crossIconClick()
    cy.wait(1000)
    console.log(printTimestamp(), 'Clicked on knowledge name and delete knowledge')
});

Then("based on which states knowledge deleted details should get updated in db and UI as mentioned in above steps", () => {
    createKnowledge.secondKnowledgeSearch()
    knowledgeDashboard.searchIconForKnowledgeNameClick()
    cy.wait(2000)
    knowledgeDashboard.noResultsFoundInRelevanceMessageVisible()
    console.log(printTimestamp(), 'Based on which states knowledge deleted details get updated in db and UI as mentioned in above steps')
});

// When("Select knowledge which has multiple versions in db and click on delete", () => {
	
//     console.log(printTimestamp(), ' Select knowledge which has multiple versions in db and clicked on delete')
// });

// Then("latest version deleted from dashboard Within same knowledgeuid another latest version knowledge should be displayed", () => {
	
//     console.log(printTimestamp(), 'latest version deleted from dashboard Within same knowledgeuid another latest version knowledge displayed')
// });

And("Repeat above steps in My knowledge Dashboard", () => {
    cy.knowledgeDeleteInMyPatternDashboard()
    console.log(printTimestamp(), 'Repeated above steps in My Knowledge Dashboard')
});

