/// <reference types="Cypress" />
/// <reference types='cypress-tags' />

import "../../../support/index";
import { Given, When, Then, And } from "cypress-cucumber-preprocessor/steps";
import {printTimestamp} from '../../../support/commands';

import TagDashboard from "../../../support/pageObjects/pages/Dashboard/TagDashboard";
const tagDashboard = new TagDashboard();
var commonData = {};

const pageRecordsCountValue = '15';
const tagManagementDashboardText = 'Tag Management';

When("click on Tag management", () => {
    tagDashboard.settingsDropdownClick()
    tagDashboard.settinsOptionClick()
    tagDashboard.tagManagementDashboardVerification().eq(1).invoke('text').should('include', tagManagementDashboardText)
    console.log(printTimestamp() ,' Clicked on Tag management')
});

Then("create tag an delete tag buttons are visible", () => {
    tagDashboard.tagsHeadingTextVisible()
    tagDashboard.createTagVisible()
    tagDashboard.deleteTagVisible()
    tagDashboard.tagsDropDownCountVisible()
    tagDashboard.tagsDropDownCount().invoke('text').should('eq','Tag Name ... +6 more');
    tagDashboard.recordsFoundText()
    tagDashboard.clearAllFilterVisible()
    tagDashboard.entriesPerPageFieldVisible()
    tagDashboard.pageRecordVisible()
    tagDashboard.pageRecord().invoke('text').should('eq', pageRecordsCountValue)
    tagDashboard.showingCountVisible()
    console.log(printTimestamp() ,' Verified create and delete tag buttons availibility')
});

And("total number of records and entries per page available", () => {
    tagDashboard.recordsFoundText()
    tagDashboard.clearAllFilterVisible()
    tagDashboard.entriesPerPageFieldVisible()
    tagDashboard.pageRecordVisible()
    tagDashboard.pageRecord().invoke('text').should('eq','15')
    tagDashboard.showingCountVisible()
    console.log(printTimestamp() ,' Verified total number of records and entries per page available')
});

And("by default user name filter applied", () => {
    cy.get('p-sorticon[arialabelasc="Activate to sort in descending order"]').eq(6).should('be.visible')
    console.log(printTimestamp() ,' Verified by default filter for modality')
});

And("All the datagrid column values are present", () => {
    tagDashboard.tagNameColumnVisible()
    tagDashboard.matadataColumnVisible()
    tagDashboard.keywordColumnVisible()
    tagDashboard.valuetypeColumnVisible()
    tagDashboard.valueColumnVisible()
    tagDashboard.usergroupColumnVisible()
    console.log(printTimestamp() ,' Verified Data grid for Pattern Dashboard')
});

When("User Clicks on column configuration drop down and select all unchecked options", () => {
    tagDashboard.tagsDropDownCountClick()
    tagDashboard.modifyByDropdownVisible()
    tagDashboard.modifyByDropdownClick()
    tagDashboard.createdbyDropdownVisible()
    tagDashboard.createdbyDropdownClick()
    tagDashboard.createdonDropdownVisible()
    tagDashboard.createdonDropdownClick()
    tagDashboard.hierarchyDropdownVisible()
    tagDashboard.hierarchyDropdownClick()
    tagDashboard.mandatoryDropdownVisible()
    tagDashboard.mandatoryDropdownClick()
    console.log(printTimestamp() ,' clicked on column configuration drop down and selected all unchecked options')
});

Then("All the datagrid column values are present for tag dashboard", () => {
    tagDashboard.modifiedbyColumnVisible()
    tagDashboard.modifiedonColumnVisible()
    tagDashboard.createdonColumnClick()
    tagDashboard.createdbyColumnClick()
    tagDashboard.hierarchyColumnClick()
    console.log(printTimestamp() ,' verified data grid for tag dashboard')
});

And("User clicks on Tag name and verifies available Tag details", () => {
    tagDashboard.firstTagVisible()
    tagDashboard.firstTagClick();
    tagDashboard.valueTypeInsideTagVisible()
    tagDashboard.tagNameInsideTagVisible()
    console.log(printTimestamp() ,' clicked on Tag name and verified Tag details')
});

And("Close DAW Application", () => {
    cy.log("Test Case Executed Successfully")
    console.log(printTimestamp() ,' Test Case Executed Successfully')
});
