/// <reference types="Cypress" />
/// <reference types='cypress-tags' />

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';

import KnowledgeDashboard from "../../../../support/pageObjects/pages/Knowledge_Dashboard/KnowledgeDashboard";
const knowledgeDashboard = new KnowledgeDashboard();
import PatternDashboard from "../../../../support/pageObjects/pages/Dashboard/PatternDashboard";
const patternDashboard = new PatternDashboard();

When("By default pattern dashboard page is displayed", () => {
    patternDashboard.dashboardButtonVisible();
    console.log(printTimestamp(), ' Pattern dashboard page displayed')
});

When("User clicks on knowledge dropdown and clicks on dashboard", () => {
    knowledgeDashboard.knowledgeClick()
    knowledgeDashboard.knowledgeDashboardClick()
    console.log(printTimestamp(), ' Knowledge dashboard clicked')
});

Then("User should be navigated to knowledge Dashboard", () => {
    knowledgeDashboard.knowledgedashboardHeadingVisible()
    console.log(printTimestamp(), ' Knowledge details verified')
});

And("Verifies navigation panel, Knowledge as title, Delete button, Data grids, Advance filter hyperlink, "
    + "Checkboxes available, entries per page and showing results are present", () => {
        knowledgeDashboard.knowledgedashboardHeadingVisible()
        knowledgeDashboard.nextPageIconVisible()
        knowledgeDashboard.previousPageIconVisible()
        knowledgeDashboard.changeEntriesPerPageCountVerification()
        knowledgeDashboard.modalityOptionClick()
        knowledgeDashboard.navigationPanelVerification()
        knowledgeDashboard.deleteButtonInKnowledgeDashboardVisible()
        knowledgeDashboard.advanceFilterHyperlinkVisible()
        knowledgeDashboard.knowledgeColumnsDropdownVisible()
        knowledgeDashboard.entriesPerPageVisible()
        knowledgeDashboard.showingResultsVisible()
        console.log(printTimestamp(), ' Details verified in knowledge dashboard')
    });

And("Verifies pre selected columns from dropdown", () => {
    knowledgeDashboard.knowledgePreSelectedColumnsVerification()
    knowledgeDashboard.gridColumnsVerification()
    console.log(printTimestamp(), ' Pre selected columns verified')
});

And("By default knowledge details should be displayed in Desc order of Modified on column", () => {
    knowledgeDashboard.modifiedOnColumnDESCVisible()
    console.log(printTimestamp(), ' Modified on column available in desc order')
});

And("Verifies total number of pages showing at right side bottom", () => {
    knowledgeDashboard.showingResultsVisible()
    console.log(printTimestamp(), ' Number of pages verified')
});

When("User clicks on > icon", () => {
    knowledgeDashboard.nextPageIconClick()
    console.log(printTimestamp(), ' > icon clicked')
});

Then("User should be able to navigate to next page", () => {
    knowledgeDashboard.nextPageMovedVerification()
    console.log(printTimestamp(), ' Navigated to next page')
});

When("User clicks on < icon", () => {
    knowledgeDashboard.previousPageIconClick()
    console.log(printTimestamp(), ' < icon clicked')
});

Then("User should be able to navigate to previous page", () => {
    knowledgeDashboard.previousPageMovedVerification()
    console.log(printTimestamp(), ' Navigated to previous page')
});

And("Verifies Entries per page UI validation", () => {
    knowledgeDashboard.entriesPerPageVisible()
    knowledgeDashboard.entriesPerPageValidation()
    console.log(printTimestamp(), '  Entries per page verified')
});

And("Selects different value available for Entries per page drop down and verify number of knowledge in data grid", () => {
    knowledgeDashboard.differentValueSelectionFromEnterPerPageDropdown()
    console.log(printTimestamp(), ' Entries per page dropdown verified')
});

Then("Verifies delete and publish buttons are available", () => {
    knowledgeDashboard.buttonsVerificationInRecords()
    console.log(printTimestamp(), ' delete and publish button verified')
});

Then("Verifies delete button is available", () => {
    knowledgeDashboard.deleteButtonVerificationInRecords()
    console.log(printTimestamp(), ' delete button verified')
});


When("User clicks on any knowledge from list", () => {
    knowledgeDashboard.firstKnowledgeRecordClick()
    console.log(printTimestamp(), ' Knowledge clicked')
});

Then("User should be navigated to knowledge details page", () => {
    knowledgeDashboard.knowledgeNameVisible()
    console.log(printTimestamp(), ' User navigated to knowledge details page')
});

When("User clicks on My Knowledge dashboard under knowledge option", () => {
    knowledgeDashboard.knowledgeClick()
    knowledgeDashboard.myKnowledgeClick()
    knowledgeDashboard.myKnowledgeDashboardClick()
    console.log(printTimestamp(), ' Knowledge dashboard clicked')
});

Then("User should be navigated to my knowledge Dashboard", () => {
    knowledgeDashboard.knowledgedashboardHeadingVisible()
    console.log(printTimestamp(), ' Knowledge details verified')
});