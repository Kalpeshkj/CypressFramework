/// <reference types="Cypress" />
/// <reference types='cypress-tags' />  
import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();

When("Add conditions from Data Model including condition", () => {
    createPattern.addConditionTabClick()
    cy.AddingNewEvent()
    createPattern.operatorForEventOneClick()
    createPattern.equaltoOperatorClick()
    createPattern.ValueForTestOneType()
    createPattern.addConditionButtonForeventOneClick()
    createPattern.attributeForSecondConditionInFirstEventClick()
    createPattern.componentAttributeOptionsForEventTwoConditionFourClick()
    createPattern.operatorDropDownForSecondConditionClick()
    createPattern.equalToOperatorForSecondConditonClick()
    createPattern.valueForSecondConditionFirstEventType()
    createPattern.addConditionPlusIconClick()
    createPattern.formDataModelClick()
    cy.wait(1000)
    createPattern.importedEventLogModelClick()
    createPattern.dataModelAdditionalInfoAttributeClick()
    createPattern.mainOperatorDropdownArrowUnderTesttwoClick()
    createPattern.andOperatorUnderTesttwoClick()
    createPattern.operatorOneFortetsTwoClick()
    createPattern.equalToOperatorUnderOperatorOneDropdownListOfTestTwoClick()
    createPattern.ValueOptionForTestTwoType()
    createPattern.addConditionButtonAtConditionThreeClick()
    createPattern.addedCondtionAttributeDropdownForLog2Click()
    createPattern.lineNumberAttributeClick()
    createPattern.operatorForEventTwoClick()
    createPattern.equalToOperatorUnderOperatorOneDropdownListOfTestTwoClick()
    createPattern.ValueForEventTwoType()
    console.log(printTimestamp(), 'Add conditions from Data Model including condition')
});
 
Then("LogEvent1,Logevent2 etc.DataModel Name appended with sequence number C1,C2 etc.", () => {
    createPattern.eventsAndConditionsInSequence()
    console.log(printTimestamp(), 'LogEvent1,Logevent2 etc.DataModel Name appended with sequence number C1,C2 etc.')
});

When("User Add multiple events with multiple conditions", () => {
    cy.AddingNewEvent()
    createPattern.opeartorDropDownForEvent3ConditionOneClick()
    createPattern.equaltoOperatorClick()
    createPattern.valueForFirstConditionInThridEventType()
    createPattern.addConditionButtonAtConditionTwoClick()
    createPattern.attributeDropdownAtConditionThreeClick()
    createPattern.evenetIdAttributeClick()
    createPattern.operatorDropdownBetweenAttrAndValueConditionThreeClick()
    createPattern.equaltoOperatorClick()
    createPattern.valueInputBoxForConditionThreeType()
    createPattern.addConditionPlusIconAtC6Click() 
    createPattern.attributeDropdownAtConditionThreeInEventFiveClick()
    createPattern.processIdAttributeClick()
    createPattern.operatorDropdownForConditionFourInEvenetFiveClick()
    createPattern.equaltoOperatorClick()
    createPattern.valueOptionForFourthConditionInEventFiveType()
    createPattern.addConditionButtonAtConditionThreeInEventTwoClick()
    createPattern.attributeDropDownForConditionFourEventTwoClick()
    createPattern.relatedEventIndexAttributeClick()
    createPattern.operatorDropdownBetweenAttrAndValueForconditionSevenClick()
    createPattern.equaltoOperatorClick()
    createPattern.valueInputBoxForConditionSevenType()
    createPattern.addConditionButtonForEventThreeClick()
    createPattern.attributeDropDownForConditionEightClick()
    createPattern.systemUIDAttributeClick()
    createPattern.operatorDropdownBetweenAttrAndValueForconditionEightClick()
    createPattern.equaltoOperatorClick()
    createPattern.valueInputBoxForConditionEightType()
    createPattern.operatorDropdownBetweenEvent2And3Click()
    createPattern.andNOtOperatorForCondition2Event2()
    createPattern.operatorSelectionForConditions()
    createPattern.eventLevelOperatorForEventFour()
    createPattern.andOperatorForEventFiveClick()
    createPattern.operatorDropdownAtEventAndConditionBetweenEventThreeAndFourClick()
    createPattern.andOperatorForEventFiveClick()
    createPattern.operatorDropdownAtEventAndConditionAtSecondEventGroupClick()
    createPattern.andOperatorForEventFiveClick()
    createPattern.operatorDropdownAtEventAndConditionForSecondGroupEventOneClick()
    createPattern.andOperatorForEventFiveClick()
    createPattern.addedCondtionAttributeDropdownInFirstEventClick()
    createPattern.addCondtionOptionForTestOneClick()
    createPattern.operatorOneDropdownFortetsOneClick()
    createPattern.absOperatorforTestOneClick()
    createPattern.attributeOneDropDownArrowForTestOneClick()
    createPattern.eventLog1OptionUnderattriubuteOneClick()
    createPattern.lelAttributeOfTestOneClick()
    createPattern.operatorTwoFortetsOneClick()
    createPattern.starOperatorforTestOneClick()
    createPattern.attributetwoArrowForTestOneClick()
    createPattern.eventLog1OptionUnderAttributeTwoclick()
    createPattern.uwlattributeOfAttributeTwoOfTestoneClick()
    createPattern.doneButtonClickInPopUpClick()
    createPattern.addedCondtionAttributeDropdownForEventTwoInRulepatternClick()
    createPattern.addCondtionOptionForTestOneClick()
    createPattern.operatorOneOfAddExpressionFortetsTwoClick()
    createPattern.absOperatorOfAddExpressionFortetsTwoClick()
    createPattern.attributeOneGropDownArrowForTestTwoClick()
    createPattern.eventLog1OptionUnderattributeOneOfTestTwoClick()
    createPattern.uwlDropdownOptionUnderattributeOneOfTestTwoClick()
    createPattern.operatorTwoOptionFortestTwoClick()
    createPattern.starOperatorUnderOperatorTwoDropdownListFortestTwoClick()
    createPattern.attributeTwoDropdownArrowUnderTestTwoClick()
    createPattern.eventLog2OptionUnderAttributeTwoDropdownOfTestTwoClick()
    createPattern.uwlDropdownOptionUnderAttributeTwoDropdownOfTestTwoClick()
    createPattern.doneButtonClickInPopUpClick()
    cy.wait(2000)
    console.log(printTimestamp(), 'Added multiple events with multiple conditions')
});

When("Delete one of event e.g LogEvent1", () => {
    createPattern.eventOneRemoveOptionClick()
    createPattern.popUpDeleteOption()
    console.log(printTimestamp(), 'Deleted one of event e.g LogEvent2')
});

Then("All conditions should be highlighted with red color when referenced event deleted", () => {
    createPattern.addedExpressionForEventTwoInRedColor()
    console.log(printTimestamp(), 'All conditions highlighted with red color when referenced event deleted')
});

Then("Logical expression should be available as per updated for events with operator", () => {
	createPattern.logicalExpressionWithDeletedFirstEvent()
    console.log(printTimestamp(), 'Logical expression available as per updated for events with operator')
});

When("User Add event for same data model", () => {
    cy.AddingNewEvent()
    console.log(printTimestamp(), 'Added event for same data model')
});

Then("Auto generated event name should be available in sequence based on highest number of event available for a data model e.g LogEvent4", () => {
	createPattern.incrementedNameOfEventAfterEventThree()
    console.log(printTimestamp(), 'Auto generated event name available in sequence based on highest number of event available for a data model e.g LogEvent4')
});

When("User Delete one of event e.g LogEvent4", () => {
	createPattern.crossMarkOfEventFourClick()
    createPattern.popUpDeleteOption()
    console.log(printTimestamp(), 'Deleted one of event e.g LogEvent4')
});


When("Delete one of condition within event e.g deleted C2 from Logevent2", () => {
	createPattern.crossMarkAtConditionTwoInEventOneClick()
    console.log(printTimestamp(), 'Deleted one of condition within event e.g deleted C2 from Logevent2')
});

Then("Logical expression should be available as per available updated conditions within event including operator", () => {
	createPattern.updatedLogicalExpressionUnderEventAfterRemovingConditionTwo()
    console.log(printTimestamp(), 'Logical expression available as per available updated conditions within event including operator')
});

When("Add condition within event for which condition deleted in above step", () => {
	createPattern.addConditionButtonAtConditionThreeClick()
    console.log(printTimestamp(), 'Add condition within event for condition deleted in above step')
});

Then("Condition should be generated in sequence based on highest number of condition available within event e.g C4", () => {
	createPattern.sequenceOfConditionAfterClickPplusIconAtC4()
    console.log(printTimestamp(), 'Condition generated in sequence based on highest number of condition available within event e.g C4')
});

When("Delete one of condition within event e.g deleted C4 from Logevent1", () => {
    createPattern.removeConditionButtonForConditionFourClick()
    console.log(printTimestamp(), 'Deleted one of condition within event e.g deleted C4 from Logevent1')
});

