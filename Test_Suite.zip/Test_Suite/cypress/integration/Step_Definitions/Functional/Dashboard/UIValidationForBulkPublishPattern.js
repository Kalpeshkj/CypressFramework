/// <reference types="Cypress" />
/// <reference types='cypress-tags' /> 
import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();
import PatternDashboard from "../../../../support/pageObjects/pages/Dashboard/PatternDashboard";
const patternDashboard = new PatternDashboard();

Given("DAW application is available",()=>{
    cy.visit("https://daw-automation.eu-west.philips-healthsuite.com/home/patterns/dashboard")
})

Then("Verify publish button at top right corner on dashboard,row level,from three dot and from"
+" pattern details view page Publish button should not be displayed", () => {
    cy.wait(4000)
    patternDashboard.publishButtonInPatternDashboardDisabled()
    patternDashboard.patternClick()
    cy.wait(1000)
    patternDashboard.publishButtonInPatternDashboardDisabled()
    patternDashboard.backArrowClick()
    patternDashboard.firstRecordThreeDotClick()
    cy.wait(2000)
    patternDashboard.publishButtonInPatternDashboardUnderThreeDotsDisabled()
    console.log(printTimestamp(), "Verified publish button at top right corner on dashboard,row level,from three dot and from"
    +" pattern details view page Publish button not be displayed")
});

When("Navigate to my pattern dashboard", () => {
    patternDashboard.myPatternArrowClick()
	patternDashboard.myPattrenDashboardClick()
    console.log(printTimestamp(), 'Navigated to my pattern dashboard')
});

Then("verify publish button at top right corner on dashboard , row level , from three dot and from"
+" pattern details view page Publish button should not be displayed", () => {
	patternDashboard.publishButtonInPatternDashboardNotExist()
    patternDashboard.firstRecordThreeDotClick()
    cy.wait(2000)
    patternDashboard.publishButtonInPatternDashboardNotExist()
    console.log(printTimestamp(), "verified publish button at top right corner on dashboard , row level , from three dot and from"
    +" pattern details view page Publish button not be displayed")
});

When("Launch DAW Application as User2", () => {
	cy.reload()
    cy.wait(5000)
    cy.reload()
    cy.wait(5000)
    cy.CreateMultiplePatternsAsPerUserInput(3)
    console.log(printTimestamp(), 'Launched DAW Application as User2')
});

When("Select multiple patterns Valid Draft-Withdrawn", () => {
	patternDashboard.patternNameSearchOptionWFnameType()
    patternDashboard.patternNameSearchIconClick()
    cy.wait(2000)
    patternDashboard.patternClick()
    cy.wait(1000)
    cy.wait(3000)
    patternDashboard.publishButtonInPatternDashboardClick()
    cy.wait(2000)
    patternDashboard.publishButtonInPopUpClick()
    cy.wait(4000)
    patternDashboard.patternClick()
    cy.wait(1000)
    patternDashboard.withdrawButtonInpatternDetailsPageClick()
    cy.wait(1000)
    createPattern.okButtonClick()
    cy.wait(1000)
    patternDashboard.secondPatternClick()
    cy.wait(2000)
    patternDashboard.publishButtonInPatternDashboardClick()
    patternDashboard.publishButtonInPopUpClick()
    cy.wait(5000)
    cy.wait(5000)
    patternDashboard.myPatternTextScrollElement()
    cy.wait(5000)
    cy.wait(2000)
    patternDashboard.selectingDraftAndWithdrawPattern()
    console.log(printTimestamp(), 'Selected multiple patterns Valid Draft-Withdrawn')
});

Then("Publish button should be displayed and it should be available in enabled state", () => {
    patternDashboard.publishButtonInPatternDashboardExist()
	patternDashboard.publishButtonInPatternDashboardEnable()
    console.log(printTimestamp(), 'Publish button displayed and it available in enabled state')
}); 

When("Select multiple patterns Published-Draft pattern which doesn't have mandatory fields data and verify Publish button", () => {
	patternDashboard.checkedCheckBoxClick()
    cy.wait(1000)
    patternDashboard.selectingSecondRecord()
    console.log(printTimestamp(), "Selected multiple patterns Published-Draft pattern which doesn't have mandatory fields data and verified Publish button")
});

Then("Publish button should be displayed and it should be available in disabled state", () => {
	patternDashboard.publishButtonInPatternDashboardExist()
    patternDashboard.publishButtonInPatternDashboardDisabled()
    console.log(printTimestamp(), 'Publish button displayed and it available in disabled state')
});

When("Select multiple patterns Combination of Valid Draft-Withdrawn and Published-Draft pattern which doesn't have"
+" mandatory fields data and verify Publish button", () => {
	patternDashboard.selectingWithdrawAndDraftPattern()
    console.log(printTimestamp(), "Selected multiple patterns Combination of Valid Draft-Withdrawn and Published-Draft pattern which doesn't have"
    +" mandatory fields data and verified Publish button")
});

Then("publish button Should be displayed and it should be available in disabled state", () => {
	patternDashboard.publishButtonInPatternDashboardExist()
    patternDashboard.publishButtonInPatternDashboardDisabled()
    patternDashboard.deleteButtonIndashbaordClick()
    cy.wait(2000)
    createPattern.okButtonClick()
    cy.wait(2000)
    console.log(printTimestamp(), 'Publish button displayed and it available in disabled state')
});

Then("Publish button should not be displayed as publish t top right corner on dashboard ,row level,from"
+" three dot and from pattern details view page", () => {
	patternDashboard.publishButtonInPatternDashboardNotExist()
    console.log(printTimestamp(), "Publish button not be displayed as publish t top right corner on dashboard ,row level,from"
    +" three dot and from pattern details view page")
});

When("Launch DAW Application as User3", () => {
	cy.reload()
    cy.wait(5000)
    cy.reload()
    cy.wait(5000)
    console.log(printTimestamp(), 'Launched DAW Application as User3')

});

When("Select multiple patterns Valid Draft-Withdrawn with only IGT modality and verify Publish button", () => {
    cy.CreateMultiplePatternsAsPerUserInputWithIGTModality(2)
    patternDashboard.patternDashboardClick()
    cy.wait(5000)
    patternDashboard.IGTmodalitySelect()
    patternDashboard.modalityApplyButtonClick()
    cy.wait(5000)
	patternDashboard.patternNameSearchOptionWFnameType()
    patternDashboard.patternNameSearchIconClick()
    cy.wait(2000)
    patternDashboard.patternClick()
    cy.wait(4000)
    patternDashboard.publishButtonInPatternDashboardClick()
    cy.wait(2000)
    patternDashboard.publishButtonInPopUpClick()
    cy.wait(4000)
    patternDashboard.patternClick()
    cy.wait(1000)
    patternDashboard.withdrawButtonInpatternDetailsPageClick()
    cy.wait(1000)
    createPattern.okButtonClick()
    cy.wait(4000)
    patternDashboard.publishButtonInPopUpClick()
    cy.wait(10000)
    patternDashboard.myPatternTextScrollElement()
    cy.wait(5000)
    patternDashboard.selectingDraftAndWithdrawPattern()
    console.log(printTimestamp(), 'Selected multiple patterns Valid Draft-Withdrawn with only IGT modality and verify Publish button')
});

Then("publish button should be displayed and it should be available in enabled state", () => {
    patternDashboard.publishButtonInPatternDashboardDisabled()
    patternDashboard.deleteButtonIndashbaordClick()
    cy.wait(2000)
    createPattern.okButtonClick()
    cy.wait(2000)
    console.log(printTimestamp(), 'Publish button displayed and it available in enabled state')
});