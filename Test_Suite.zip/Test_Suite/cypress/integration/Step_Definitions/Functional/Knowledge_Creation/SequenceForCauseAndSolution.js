/// <reference types="Cypress" />
/// <reference types = 'cypress-tags' /> 

import "../../../../support/index"
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import CreateKnowledge from "../../../../support/pageObjects/pages/KnowledgeAuthoring/CreateKnowledge";
const createKnowledge = new CreateKnowledge();
import { printTimestamp } from '../../../../support/commands';

When("User Navigate to existing knowledge workflow", () => {
    createKnowledge.knowledgeOptionArrowClick()
    createKnowledge.addKnowledgeWorkflowButtonClick() 
    cy.wait(3000)
    console.log(printTimestamp(), 'Navigated to newly created knowledge workflow')
});

And("Add details in Knowledge Information section", () => {
    createKnowledge.knowledgeNameTextBoxType()
    createKnowledge.descriptionFiledTextBoxType()
    console.log(printTimestamp(), 'Added details in Knowledge Information section')
});

And("Expand Causes and Solution Import cause from Select Casue e.g Knowledge1.Casue1", () => {
    createKnowledge.symptomOptionClick()
    createKnowledge.addSymptomButtonClick()
    createKnowledge.symptomOneTextBoxType()
    createKnowledge.tickAtSymptomOneClick()
    cy.wait(2000)
    createKnowledge.causeAndSolutionOptionClick()
    createKnowledge.addCauseButtonClick()
    console.log(printTimestamp(), 'Expanded Causes and Solution Import cause from Select Casue e.g Knowledge1.Casue1')
});

And("Add multiple causes and solutions with content", () => {
    createKnowledge.causeOneInputBoxType()
    createKnowledge.addSolutionButtonClick()
    createKnowledge.causeOneSolutionOneInputTextBoxType()
    createKnowledge.addSolutionButtonClick()
    createKnowledge.causeOneSolutionTwoInputTextBoxType()
    createKnowledge.addSolutionButtonClick()
    createKnowledge.causeOneSolutionThreeInputTextBoxType()
    createKnowledge.addCauseButtonClick()
    createKnowledge.causeTwoInputTextBoxType()
    createKnowledge.addSolutionButtonClick()
    createKnowledge.causeTwoSolutionOneInputTextBoxType()
    createKnowledge.addSolutionButtonClick()
    createKnowledge.causeTwoSolutionTwoInputTextBoxType()
    createKnowledge.addSolutionButtonClick()
    createKnowledge.causeTwoSolutionThreeInputTextBoxType()
    createKnowledge.addCauseButtonClick()
    createKnowledge.causeThreeInputTextBoxType()
    createKnowledge.addSolutionButtonClick()
    createKnowledge.causeThreeSolutionOneInputTextBoxType()
    createKnowledge.addSolutionButtonClick()
    createKnowledge.causeThreeSolutionTwoInputTextBoxType()
    createKnowledge.addSolutionButtonClick()
    createKnowledge.causeThreeSolutionThreeInputTextBoxType()
    createKnowledge.addCauseButtonClick()
    createKnowledge.causeFourInputTextBoxType()
    createKnowledge.addSolutionButtonClick()
    createKnowledge.causeFourSolutionOneInputTextBoxType()
    createKnowledge.addSolutionButtonClick()
    createKnowledge.causeFourSolutionTwoInputTextBoxType()
    createKnowledge.addSolutionButtonClick()
    createKnowledge.causeFourSolutionThreeInputTextBoxType()
    createKnowledge.tickAtCauseFourClick()
    console.log(printTimestamp(), 'Added multiple causes and solutions with content')

});

And("Update priority value for solution e.g Cause 2  Solution 1 Priority 3, Solution 2 Priority 2 ,Solution 3 Priority 1", () => {
    createKnowledge.editOptionAtCauseTwoClick()
    createKnowledge.causeTwoSolutionOnePriorityDropdownClick()
    createKnowledge.prioritythreeOptionOfPriorityDropdownclick()
    createKnowledge.causeTwoSolutionTwoPriorityDropdownClick()
    createKnowledge.priorityTwoOptionOfPriorityDropdownclick()
    createKnowledge.causeTwoSolutionThreePriorityDropdownClick()
    createKnowledge.priorityOneOptionOfPriorityDropdownclick()
    console.log(printTimestamp(), 'Updated priority value for solution e.g Cause 2  Solution 1 Priority 3, Solution 2 Priority 2 ,Solution 3 Priority 1')
});

When("Click on Remove icon available at cause level", () => {
    createKnowledge.removeIconOfCauseThreeClick()
    console.log(printTimestamp(), 'Clicked on Remove icon available at cause level')
});

Then("Pop up should be displayed  Delete icon Are you sure you want to delete this cause? Causename will be deleted Cancel and Delete buttons", () => {
    createKnowledge.popUpVisible()
    createKnowledge.popUpTextOneVisible()
    createKnowledge.causeNameInPopUp()
    createKnowledge.cancelButtonVisible()
    createKnowledge.deletebuttonVisible()
    console.log(printTimestamp(), 'Pop up displayed Delete icon Are you sure you want to delete this cause? Causename will be deleted Cancel and Delete buttons')
});

When("User Click on cancel button", () => {
    createKnowledge.cancelButtonClick()
    console.log(printTimestamp(), 'Clicked on cancel button')
});

Then("Cause should not get deleted", () => {
    createKnowledge.cause3()
    console.log(printTimestamp(), 'Cause not get deleted')
});

When("User Click on Delete of e.g Cause 3", () => {
    createKnowledge.removeIconOfCauseThreeClick()
    createKnowledge.deletebuttonClick()
    console.log(printTimestamp(), 'Clicked on Delete of e.g Cause 3')
});

Then("cause 3 is deleted , cause 4 name should get changed to cause 3", () => {
    createKnowledge.cause4TextNotExist()
    createKnowledge.cause3NotExist()
    console.log(printTimestamp(), 'cause 3 is deleted , cause 4 name gets changed to cause 3')
});

When("Click on Remove icon available at solution level", () => {
    createKnowledge.cause2Solution2RemoveIconClick()
    console.log(printTimestamp(), 'Clicked on Remove icon available at solution level')
});

Then("Pop up should be displayed Delete icon Are you sure you want to delete this cause? ,Solutionname will be deleted,Cancel and Delete buttons", () => {
    createKnowledge.popUpVisible()
    createKnowledge.solutionPopUpTextOneVisible()
    createKnowledge.solutionNameInPopUp()
    createKnowledge.cancelButtonVisible()
    createKnowledge.deletebuttonVisible()
    console.log(printTimestamp(), 'Pop up displayed Delete icon Are you sure you want to delete this cause? ,Solutionname will be deleted,Cancel and Delete buttons')
});

When("User Click on cancel button", () => {
    createKnowledge.cancelButtonClick()
    console.log(printTimestamp(), 'Clicked on cancel button')
});

Then("Solution should not get deleted", () => {
    createKnowledge.solutionTwoTextVisible()
    console.log(printTimestamp(), 'Solution gets deleted')
});

When("User Delete any of solution e.g Solution 2", () => {
    createKnowledge.cause2Solution2RemoveIconClick()
    createKnowledge.deletebuttonClick()
    cy.wait(3000)
    console.log(printTimestamp(), 'Deleted any of solution e.g Solution 2')
});

Then("Solution 2 should get deleted Solution 3 name should get change to Solution 2", () => {
    createKnowledge.solutionTwoTextVisible()
    createKnowledge.solutionThreeTextNotExist()
    console.log(printTimestamp(), 'Solution 2 gets deleted Solution 3 name gets change to Solution 2')
});

And("Priority drop down for Solution 1 should get highlighted with red border", () => {
    createKnowledge.redBorderVisible()
    console.log(printTimestamp(), 'Priority drop down for Solution 1 highlighted with red border')
});

When("User Change priority value for Solution 2 ,Priority value Select-- , 1 and 2 should be available in Priority drop down", () => {
    createKnowledge.causeTwoSolutionTwoPriorityDropdownClick()
    createKnowledge.Priority2OptionForSolution2Click()
    console.log(printTimestamp(), 'Changed priority value for Solution 2 ,Priority value Select-- , 1 and 2 should be available in Priority drop down')
});

Then("Priority drop down should not get highlighted with red border", () => {
    createKnowledge.redBorderNotExist()
    console.log(printTimestamp(), 'Priority drop down not highlighted with red border')
});

When("duplicate priority assigned to multiple solutions", () => {
    createKnowledge.causeTwoSolutionOnePriorityDropdownClick()
    createKnowledge.priorityTwoOptionForCauseOneClick()
    console.log(printTimestamp(), 'duplicate priority assigned to multiple solutions')
});

Then("Priority drop down should get highlighted with red border", () => {
    createKnowledge.redBorderVisible()
    console.log(printTimestamp(), 'Priority drop down get highlighted with red border')
});

And("User should be able to navigate to next  page", () => {
    createKnowledge.causeTwoSolutionOnePriorityDropdownClick()
    createKnowledge.priorityOneOptionForCauseOneClick()
    createKnowledge.tickAtCauseOneClick()
    createKnowledge.nextButtonOnCreatePageClick()
    console.log(printTimestamp(), 'User navigated to next page')
});

And("User should be able to navigate back to create knowledge page when click on previous button Sequence of added causes and solution should be maintained", () => {
    createKnowledge.previousButtonClickInKnowledge()
    console.log(printTimestamp(), 'User navigate back to create knowledge page when clicked on previous button Sequence of added causes and solution maintained')
});

When("Click on save as draft", () => {
    createKnowledge.causeAndSolutionOptionClick()
    createKnowledge.saveAsDraftClick()
    cy.wait(2000)
    console.log(printTimestamp(), 'Clicked on save as draft')
});

Then("All data should get saved", () => {
    createKnowledge.messageVisible()
    console.log(printTimestamp(), 'All data gets saved')
});

When("User relaunch application navigate from other wf", () => {
    cy.reload()
    cy.wait(3000)
    createKnowledge.existingWorkflow()
    createKnowledge.newlyCreatedWokFlow()
    cy.wait(2000)
    createKnowledge.causeAndSolutionOptionClick()
    console.log(printTimestamp(), 'relaunched application navigating from other wf')
});

Then("verify sequence of added causes and solutions", () => {
    createKnowledge.sequenceOfCausesAndSolutionsForCauseOne()
    createKnowledge.sequenceOfCausesAndSolutionsForCauseTwo()
    createKnowledge.sequenceOfCausesAndSolutionsForCauseThree()
    console.log(printTimestamp(), 'verified sequence of added causes and solutions')
});

And("Close DAW application", () => {
    cy.DeleteWorkflow()
    cy.log('Test case executed successfully')
    console.log(printTimestamp(), 'Test case executed successfully')
});

