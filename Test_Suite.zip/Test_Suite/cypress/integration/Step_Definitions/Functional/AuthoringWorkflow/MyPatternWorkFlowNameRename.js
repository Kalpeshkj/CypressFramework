/// <reference types="Cypress" />
/// <reference types='cypress-tags' />

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import PatternDashboard from "../../../../support/pageObjects/pages/Dashboard/PatternDashboard";
const patternDashboard = new PatternDashboard();
import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();

Then("By default pattern dashboard page is displayed", () => {
    patternDashboard.dashboardButtonVisible();
    console.log(printTimestamp(), 'By default pattern dashboard page is displayed')
});

When("User Enter Pattern Name and fill all other details", () => {
    createPattern.patternNameType()
    createPattern.descriptionType()
    createPattern.orderOfExecutionType()
    console.log(printTimestamp(), 'Enters Pattern Name and filled all other details')
});

And("Click on Save as Draft", () => {
    createPattern.saveAsDraftBButtonClick()
    cy.wait(1000)
    console.log(printTimestamp(), 'Clicked on Save as Draft')
});

Then("workflow is saved with pattern name", () => {
    createPattern.messageVisible()
    createPattern.fetchPatternName()
    createPattern.authoringWFName()
    console.log(printTimestamp(), 'workflow is saved with pattern name')
});

When("Rename the created workflow with Authoring_WF", () => {
    createPattern.NewPatternThreeDotsClick()
    createPattern.renameOptionClick()
    createPattern.renameInputBoxType()
    createPattern.patternInformationTabClick()
    console.log(printTimestamp(), 'Renamed the created workflow with Authoring_WF')
});

Then("On renaming the workflow name, the workflow name should not be updated as per pattern name", () => {
    createPattern.changedPatternNameType()
    createPattern.saveAsDraftBButtonClick()
    cy.wait(1000)
    createPattern.workFlowNameAfterUpdatingPatternName()
    console.log(printTimestamp(), 'On renaming the workflow name, the workflow name not updated as per pattern name')
});

And("Pattern name should match in pattern details table", () => {

    console.log(printTimestamp(), 'Pattern name match in pattern details table')
});

And("workflow name in workflow table in db", () => {

    console.log(printTimestamp(), 'Workflow name match in workflow table')
});

When("User Go to Existing pattern Update the pattern name multiple times", () => {
    createPattern.myPatternThreeDotsClick()
    createPattern.createPatternButtonClick()
    cy.wait(2000)
    createPattern.patternNameType()
    createPattern.descriptionType()
    createPattern.orderOfExecutionType()
    createPattern.saveAsDraftBButtonClick()
    cy.wait(2000)
    createPattern.changedPatternNameType()
    cy.wait(1000)
    createPattern.saveAsDraftBButtonClick()
    cy.wait(2000)
    createPattern.patternNameAfterUpdation()
    console.log(printTimestamp(), 'Goes to Existing pattern Updated the pattern name multiple times')
});

Then("Pattern name and workflow name should match", () => {
    createPattern.updatedWorkFlowNameAfterUpdatingPatternName()
    createPattern.getPatternName()
    console.log(printTimestamp(), 'Pattern name and workflow name matched')
});

When("User Open existing pattern Rename the workflow in between Update pattern name", () => {
    createPattern.existingWorkFlowClick()
    cy.wait(2000)
    createPattern.threeDotsOfExistingWfClick()
    createPattern.renameOptionClick()
    createPattern.renameInputBoxForExistingWFType()
    createPattern.patternInformationTabClick()
    createPattern.patternNameType()
    createPattern.getPatternName()
    console.log(printTimestamp(), 'Opens existing pattern Renamed workflow in between Updated pattern name')
});

Then("Workflow name should not match with pattern name", () => {
    createPattern.existingWfNameNotMatchedWithPatternName()
    createPattern.deletePattern()
    createPattern.deleteOption().click({ force: true });
    createPattern.okButtonClick()
    cy.wait(3000)
    createPattern.deleteSecondPattern()
    createPattern.deleteOption().click({ force: true });
    createPattern.okButtonClick()
    cy.wait(3000)
    console.log(printTimestamp(), 'Workflow name should not matched with pattern name')
});
