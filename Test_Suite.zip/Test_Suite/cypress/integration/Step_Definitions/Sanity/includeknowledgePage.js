/// <reference types="Cypress" />
/// <reference types='cypress-tags' />

import "../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../support/commands';
import CreatePattern from "../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
import IncludeKnowledge from "../../../support/pageObjects/pages/PatternAuthoring/includeKnowledgepageObj";
import AssertionConstants from "../../../support/pageObjects/pages/AssertionConstants";
import NavigationPanel from "../../../support/pageObjects/pages/Dashboard/NavigationPanel";
const constants = new AssertionConstants()
const navigationPanel = new NavigationPanel()
const createPattern = new CreatePattern()
const includeKnowledge = new IncludeKnowledge()


When("User Enter all the mandatory details in Create pattern,Apply metadata page and click on Next button", () => {
  cy.createPattern()
  createPattern.nextButtonClick()
  cy.wait(5000)
  cy.ApplyMetaDetaPageCompletion()
  createPattern.nextButtonClick()
  cy.wait(5000)
  console.log(printTimestamp(), ' Entered all the mandatory details in Create pattern,Apply metadata page and clicked Next button')

})

Then("User should be navigated to the include knowledge page", () => {
  includeKnowledge.includeKnowledgePage()
  console.log(printTimestamp(), ' Navigated to the include knowledge page')
})

Then('Pattern name should be displayed on top left corner', () => {
  cy.readFile('cypress/fixtures/patternNameCreation.json').then(function (result) {
    var PatternName = result.name;
    includeKnowledge.patternName().last().should('have.text', PatternName).and(constants.beVisibleAssertion)
  })
  console.log(printTimestamp(), ' Verified Pattern name should be displayed on top left corner')
})

Then('One dropdown filter should be present giving the user option to search on a field of a knowledge', () => {
  includeKnowledge.dropdownFilterVisible()
  console.log(printTimestamp(), ' Verified dropdown filter which allows user to search a field of knowledge')
})

And('Another filter should be present for the keyword to be entered', () => {
  includeKnowledge.filterForKeywordWithSearchIcon()
  console.log(printTimestamp(), ' Verified Another filter for keyword to be entered')
})

When('User Click on show all', () => {
  includeKnowledge.showAllCheckboxClick()
  console.log(printTimestamp(), ' Clicked on show all')
})

Then('The check box should be selected and the page should be populated with various knowledge with two filters Name and tags', () => {
  includeKnowledge.checkBox().should('be.checked')
  includeKnowledge.firstKnowledgeVisible()
  includeKnowledge.nameFilterVisible()
  includeKnowledge.tagsFilterVisible()
  console.log(printTimestamp(), ' Verified check box is selected and the pages populated with various knowledge with filters Name and tags')
}) 

Then('Clear all filters,Previous,Close,Save as Draft,Next buttons should be present and enabled', () => {
  includeKnowledge.clearAllFilterButtonVisible().and(constants.notBeDisabledAssertion)
  includeKnowledge.previousButtonVisible().and(constants.notBeDisabledAssertion)
  includeKnowledge.closeButtonVisible().and(constants.notBeDisabledAssertion)
  includeKnowledge.saveAsDraftButtonVisible().and(constants.notBeDisabledAssertion)
  includeKnowledge.nextButton().last().should(constants.beVisibleAssertion).and(constants.notBeDisabledAssertion)
  console.log(printTimestamp(), ' Verified Clear all filters,Previous,Close,Save as Draft,Next buttons present and enabledd')
})

Then('records should be displayed in the format of XXXX of XXXX records found,Entries per page should be defaulted to 10', () => {
  includeKnowledge.recordsCount().invoke("text")
    .then((text) => {
      expect(text).to.contain('records found')
    })
  includeKnowledge.entriesPerPageTextVisible()
  includeKnowledge.entriesPerPageCount().find('span').should('have.text', 10)
  console.log(printTimestamp(), ' Verified records are displayed in the format of XXXX of XXXX records found and Entries per page should be defaulted to 10')
})

And("Page selection information should be displayed in the format of 'Showing 1 of xxx' with arrow symbol to Navigate to different pages", () => {
  includeKnowledge.pageSelectionInformation().should('contain', ' Showing 1 of ')
  includeKnowledge.arrowSymbol().last().should(constants.beVisibleAssertion)
  console.log(printTimestamp(), " Verified Page selection information in the format of 'Showing 1 of xxx' with arrow symbol to Navigate to different pages")
})

When("User Enter any value in the Tags_Name filter", () => {
  includeKnowledge.nameFilter().type('AWS')
  includeKnowledge.tagsfilter().click()
  includeKnowledge.knowledgeFromDropDown().find('.p-checkbox.p-component').click()
  includeKnowledge.applyButton().click()
  cy.wait(2000)
  console.log(printTimestamp(), ' Entered value in Tags_Name filter')
});

Then('filter is happening as per selected value', () => {
  includeKnowledge.filteredKnowledges().eq(0).find('span').eq(0).should(constants.beVisibleAssertion)
  includeKnowledge.filteredKnowledgesRow2().eq(1).find('span').eq(0).invoke('text').should('include', 'AWS')
  console.log(printTimestamp(), ' Verified filter is happening as per selected value')
})

When('User Click on Clear filter', () => {
  includeKnowledge.clearFilterOptionClick()
  console.log(printTimestamp(), ' Clicked on Clear filter')
})

Then('The applied filter should be removed', () => {
  includeKnowledge.nameFilter().should('not.have.text', 'AWS')
  includeKnowledge.tagsfilter().should('not.have.text', 'AWS')
  console.log(printTimestamp(), ' Verified The applied filter to be removed')
})

When('User Navigate to the include tab and click on any of the knowledge rows', () => {
  includeKnowledge.firstKnowledgeRowClick()
  console.log(printTimestamp(), ' Navigated to the include tab and clicked on any of the knowledge rows')
})

Then('The right section should populate with knowledge details', () => {
  includeKnowledge.knowledgeDetail1Visible()
  includeKnowledge.knowledgeDetail2Visible()
  includeKnowledge.knowledgeDetail3Visible()
  console.log(printTimestamp(), ' Verified The right section gets populated with knowledge details')
})

When('User Click on full screen topmost', () => {
  includeKnowledge.fullScreenButton().first().click()
  console.log(printTimestamp(), ' Clicked on full screen topmost')
})

Then('the navigation panel should collapse and include and review sections should be in full screen', () => {
  includeKnowledge.collapsedNavigationPanel().should('not.be.visible')
  includeKnowledge.expandedDetailOrReviewSection().should(constants.haveClassAssertion, constants.enableFullscreenValidation)
  console.log(printTimestamp(), ' Verified the navigation panel with collapse ,include and review sections with full screen')
})

When('User Click on full screen knowledge details Section', () => {
  includeKnowledge.fullScreenKnowledgeButton().last().click()
  console.log(printTimestamp(), ' Clicked on full screen knowledge details Section')
})

Then('The details section should expand removing the row', () => {
  includeKnowledge.expandedDetailOrReviewSection().should(constants.haveClassAssertion, constants.enableFullscreenValidation)
  console.log(printTimestamp(), ' Verified The details section should expand removing the row')
})

When('Select more than one of the knowledge by clicking on the check box next to the knowledge', () => {
  includeKnowledge.fullScreenKnowledgeButton().last().click()
  includeKnowledge.selectMoreThanOneKnowlwdge().eq(0).click()
  includeKnowledge.selectMoreThanOneKnowlwdge().eq(1).click()
  includeKnowledge.selectMoreThanOneKnowlwdge().eq(2).click()
  console.log(printTimestamp(), ' Selected more than one knowledge by clicking on the check box next to the knowledge')
})

Then('the tab should append with as Review x , x being number of knowledge selected', () => {
  includeKnowledge.reviewTab().last().should('have.text', 'Review (3)')
  console.log(printTimestamp(), ' Verified tab to gets append with as Review x , x being number of knowledge selected')
})

And('The knowledge name should contain the knowledge selected in the include knowledge tab', () => {
  includeKnowledge.selectMoreThanOneKnowlwdge().eq(0).click()
  includeKnowledge.selectMoreThanOneKnowlwdge().eq(1).click()
  includeKnowledge.selectMoreThanOneKnowlwdge().eq(2).click()
  includeKnowledge.selectMoreThanOneKnowlwdge().eq(0).click()
  includeKnowledge.knowledgeNameInDetailsSection().first().should('have.text', '  Check the motor voltage')
  console.log(printTimestamp(), ' Verified The knowledge name should contain the knowledge selected in the include knowledge tab')
})

And('there should be cross mark next to the knowledge tab', () => {
  includeKnowledge.reviewTab().last().click()
  includeKnowledge.crossMarkVisible()
  console.log(printTimestamp(), ' Verified cross mark next to the knowledge tab')
})

And('The details of knowledge selected should be displayed', () => {
  includeKnowledge.knowledgeDetailDecriptionInReviewTab().last().find('span').should('have.text', 'Description ').and(constants.beVisibleAssertion)
  includeKnowledge.knowledgeDetailSymptomsInReviewTab().eq(3).should(constants.beVisibleAssertion)
  includeKnowledge.knowledgeDetailCausesAndSolutionsInReviewTab().eq(4).should(constants.beVisibleAssertion)
  console.log(printTimestamp(), ' Verified The details of knowledge selected')
})

When('click on the full screen icon on the details section', () => {
  includeKnowledge.fullScreenKnowledgeButton().last().click()
  cy.wait(2000)
  console.log(printTimestamp(), ' clicked on the full screen icon on the details section')
})

Then('Only the knowledge details section should be displayud in full screen', () => {
  includeKnowledge.expandedDetailOrReviewSection().should(constants.haveClassAssertion, constants.enableFullscreenValidation)
  console.log(printTimestamp(), ' Verified Only the knowledge details section should be displayud in full screen')
})

And('User should be able to save knowledge', () => {
  includeKnowledge.fullScreenKnowledgeButton().last().click()
  includeKnowledge.fullScreenButton().first().click()
  includeKnowledge.saveKnowledgeButton().click({ force: true })
  cy.wait(2000)
  cy.contains('Workflow Saved Successfully').should(constants.beVisibleAssertion)
  console.log(printTimestamp(), 'User should be able to save knowledge')
})

When('User navigate to another workflow and come back to the same', () => {
  includeKnowledge.includeTab().first().click()
  includeKnowledge.selectMoreThanOneKnowlwdge().eq(0).click({ force: true })
  includeKnowledge.selectMoreThanOneKnowlwdge().eq(1).click({ force: true })
  includeKnowledge.selectMoreThanOneKnowlwdge().eq(1).click({ force: true })
  includeKnowledge.selectMoreThanOneKnowlwdge().eq(0).click({ force: true })
  console.log(printTimestamp(), ' navigated to another workflow and come back to the same')
})

Then('Selected knowledge should be present in the review section', () => {
  includeKnowledge.knowledgeNameInDetailsSection().first().should('have.text', '  Check the motor voltage')
  console.log(printTimestamp(), ' Verified Selected knowledge edin the review section')
})

Then('User should be able to navigate to include tab', () => {
  includeKnowledge.includeTab().first().click()
  includeKnowledge.saveAsDraftButton().click()
  cy.wait(2000)
  console.log(printTimestamp(), 'User should be able to navigate to include tab')
})

When('User Click on Add knowledge Hyperlink', () => {
  includeKnowledge.addKnowledgeHyperlink().click({ force: true })
  cy.wait(3000)
  includeKnowledge.workFlowMessage().should(constants.beVisibleAssertion)
  cy.wait(5000);
  console.log(printTimestamp(), 'Clicked on Add knowledge Hyperlink')
})

Then('User should be navigated to knowledge creation workflow and new knowledge should be created in the knowledge section', () => {
  includeKnowledge.knowledgeOptionVisible()
  navigationPanel.DeleteLastWorkflowThreeDotsbasedOnPatternName()
  cy.wait(2000);
  cy.DeleteWorkflow()
  console.log(printTimestamp(), ' navigated to knowledge creation workflow and new knowledge should be created in the knowledge section')
})
