/// <reference types="Cypress" />
/// <reference types='cypress-tags' />  

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();

And("at least two to three published status and some patterns present in draft status should be present and should be selectable", () => {
    createPattern.publishedPatternCountVerification()
    console.log(printTimestamp(), 'at least two to three published status and some patterns present in draft status present and selectable')
});

When("User Select multiple patterns which are in published state", () => {
    cy.CreatePatternsTillValidateStageCompletion(1)
    cy.wait(3000)
    // createPattern.patternDashboardClick()
    cy.visit(Cypress.env("DAWAutomationURL"));
    cy.wait(2000)
    createPattern.clearAllFiltersButtonClick()
    createPattern.patternNameTypeInSearchFilter()
    cy.wait(2000)
    createPattern.selectAllRecordClickInDashboard()
    createPattern.publishButtonClick()
    console.log(printTimestamp(), 'Selected multiple patterns which are in published state')
});

Then("The Withdrawn button should be enabled", () => {
    createPattern.selectAllRecordClickInDashboard()
    createPattern.withdrawButtonVisibleAsEnabled()
    console.log(printTimestamp(), 'The Withdrawn button is enabled')
});

And("Based on selected number of patterns '8 patterns selected' should be displayed beside Advance Search", () => {
    console.log(printTimestamp(), 'Based on selected number of patterns 8 patterns selected displayed beside Advance Search')
});

When("Click on the enabled withdraw Button of confirmation pop up", () => {
    createPattern.withdrawButtonClick()
    console.log(printTimestamp(), 'Clicked on the enabled withdraw Button of confirmation pop up')
});

Then("Delete icon - Are you sure you want to withdraw the following 8 patterns 'All 8 Pattern Names'", () => {
    createPattern.popUpTitleVisible()
    createPattern.cancelButtonInDeleteWFPopupVisible()
    createPattern.deleteButtonInDeleteWFPopupVisible()
    console.log(printTimestamp(), "Delete icon - Are you sure you want to withdraw the following 8 patterns 'All 8 Pattern Names'")
});

And("Cancel and Withdraw buttons All selected patterns should get withdrawn", () => {
    createPattern.okButtonClick()
    console.log(printTimestamp(), 'Cancel and Withdraw buttons All  selected patterns get withdrawn')
});

And("Details should get updated in UI and Db as mentioned in above steps", () => {
    console.log(printTimestamp(), 'Details get updated in UI and Db as mentioned in above steps')
});

And("Pattern State WITHDRAWN,Modified By User Id and Modified On to date should get updated in db", () => {
    console.log(printTimestamp(), 'Pattern State WITHDRAWN,Modified By User Id and Modified On to date get updated in db')
});

And("Pattern State Withdrawn,Modified By User Name and Modified On to date should get updated in UI", () => {
    // createPattern.withdrawnPatternCountVerification()
    console.log(printTimestamp(), 'Pattern State Withdrawn,Modified By User Name and Modified On to date get updated in UI')
});

When("Select entries per page as 50", () => {
    createPattern.changeEntriesPerPageCountSizeInPatternDashboard()
    console.log(printTimestamp(), 'Selects entries per page as 500')
});

Then("Max 50 pattern should be displayed in a page", () => {
    createPattern.clearAllFiltersButtonClick()
    createPattern.recordsAvailableInDashboardVerification()
    console.log(printTimestamp(), 'Max 500 patterns displayed in a page')
});

When("Filter Pattern state Published, select all 10 pattern check box  and click on withdraw", () => {
    createPattern.clearAllFiltersButtonClick()
    createPattern.publishedPatternStatusSelectionFromList()
    cy.wait(2000)
    createPattern.selectAllRecordClickInDashboard()
    createPattern.withdrawButtonClick()
    console.log(printTimestamp(), 'Filter Pattern state Published, selected all 10 pattern check box  and clicked on withdraw')
});

Then("10 pattern name should be displayed and for remaining patterns count should be displayed as below  e.g 500 patterns selected", () => {
    createPattern.fiveRecordsSelectedVisible()
    console.log(printTimestamp(), '10 pattern name displayed and for remaining patterns count displayed as below  e.g 500 patterns selected')
});

And("Delete icon - Are you sure you want to withdraw the following 500 patterns 'All 10 Pattern Names' +490 more Cancel and Withdraw buttons", () => {
    createPattern.popUpTitleVisible()
    createPattern.cancelButtonInDeleteWFPopupVisible()
    createPattern.deleteButtonInDeleteWFPopupVisible()
    createPattern.cancelButtonInDeleteWFPopupClick()
    console.log(printTimestamp(), "Delete icon - Are you sure you want to withdraw the following 500 patterns 'All 10 Pattern Names' +490 more Cancel and Withdraw buttons")
});

And("Pattern State WITHDRAWN,Modified By User Id and Modified On to date should get updated in db", () => {
    console.log(printTimestamp(), 'Pattern State WITHDRAWN,Modified By User Id and Modified On to date gets updated in db')
});

When("Click on clear all filter", () => {
    createPattern.clearAllFiltersButtonClick()
    console.log(printTimestamp(), 'Clicked on clear all filter')
});

Then("All selected pattern state ,modified by and modified on should get updated Same details should get updated in db", () => {
    console.log(printTimestamp(), 'All selected pattern state ,modified by and modified on gets updated Same details get updated in db')
});

When("Select multiple patterns which are in a combination of pattern state of published, Draft-Reviewed-Proposal", () => {
    createPattern.selectAllRecordClickInDashboard()
    console.log(printTimestamp(), 'Selects multiple patterns which are in a combination of pattern state of published, Draft-Reviewed-Proposal')
});

Then("The Withdrawn button should be disabled", () => {
    createPattern.patternNameTypeInSearchFilter()
    cy.wait(2000)
    createPattern.selectAllRecordClickInDashboard()
    createPattern.withdrawButtonVisibleAsDisabled()
    createPattern.deletePatternButtonInDashboardClick()
    createPattern.okButtonClick()
    console.log(printTimestamp(), 'The Withdrawn button disabled')
});

And("Repeats above step in My Pattern Dashboard", () => {
    cy.visit(Cypress.env("URL"));
    createPattern.myPatternsSectionCollapseIconClick()
    createPattern.myPatternDashboardClick()
    cy.CreatePatternsTillValidateStageCompletion(1)
    cy.wait(3000)
    cy.visit(Cypress.env("DAWAutomationURL"));
    cy.wait(2000)
    createPattern.clearAllFiltersButtonClick()
    createPattern.patternNameTypeInSearchFilter()
    cy.wait(2000)
    createPattern.selectAllRecordClickInDashboard()
    createPattern.publishButtonClick()
    cy.wait(5000)
    createPattern.selectAllRecordClickInDashboard()
    createPattern.withdrawButtonVisibleAsEnabled()
    createPattern.selectAllRecordClickInDashboard()
    createPattern.withdrawButtonClick()
    createPattern.popUpTitleVisible()
    createPattern.cancelButtonInDeleteWFPopupVisible()
    createPattern.deleteButtonInDeleteWFPopupVisible()
    createPattern.okButtonClick()
    createPattern.clearAllFiltersButtonClick()
    createPattern.patternNameTypeInSearchFilter()
    cy.wait(2000)
    createPattern.selectAllRecordClickInDashboard()
    createPattern.deletePatternButtonInDashboardClick()
    createPattern.okButtonClick()
    console.log(printTimestamp(), 'Repeats above steps in My Pattern Dashboard')
});