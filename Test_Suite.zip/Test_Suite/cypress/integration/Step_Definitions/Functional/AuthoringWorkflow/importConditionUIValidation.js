/// <reference types="Cypress" />
/// <reference types='cypress-tags' />

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';

import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();
var arr = [];
var arr1 = [];

Then("From Data Model, From Rule Pattern, From Variable are available after click of + icon", () => {
    createPattern.addConditionPlusIconClick()
    createPattern.fromdataModelVisible()
    createPattern.fromrulePatternVisible()
    createPattern.fromVariableVisible()
    console.log(printTimestamp(), ' From Data Model, From Rule/Pattern, From Variable are displayed')
});

When("User clicks on From Rule Patterns", () => {
    createPattern.fromRulePatternClick()
    console.log(printTimestamp(), ' Clicked on  Rule/Patterns')
});

Then("Verifies Import Conditions as title and Rule Disabled and Ptterns are selected", () => {
    createPattern.importConditionsHeadingVisible()
    createPattern.ruleDisabled()
    createPattern.patternSelected()
    console.log(printTimestamp(), ' Verified Import Conditions as title and Rule Disabled and Ptterns as selected')
});

And("None of pattern details should not be displayed and Search for a pattern or click on 'Show All' to view all available patterns text displayed", () => {
    createPattern.noDataVisibleInTable()
    createPattern.searchByShowAllTextVisible()
    console.log(printTimestamp(), ' No patterns dsiplayed')
});

And("verifies Show All check box displayed and Drop down for keyword where All is by default selected", () => {
    createPattern.showAllCheckboxVisible()
    createPattern.keywordDropDownWithAllSelected()
    console.log(printTimestamp(), ' Show All check box displayed')
});

And("Search textbox with 'Search by Keyword' watermark is available", () => {
    createPattern.searchBoxTestVisible()
    console.log(printTimestamp(), ' "Search by Keyword" is displyed')
});

And("Records count, cancel and import button, Entries per page and total count of page is available", () => {
    createPattern.showAllCheckboxClick()
    createPattern.recordsFoundTextVerification()
    createPattern.CancelButtonVisible()
    createPattern.importButtonVisible()
    createPattern.entriesPerPageVisible()
    createPattern.totalCountOfPageVisible()
    console.log(printTimestamp(), ' Records count, cancel and import button, Entries per page and total count of page displayed')
});

And("By default pattern details are displayed as per ASC order of Pattern name", () => {
    createPattern.patternNameASCOrderSortedVisible()
    console.log(printTimestamp(), ' By default pattern details displayed')
});

And("Based on selected value from drop down number of records should be displayed", () => {
    createPattern.totalrecordsPerPageVerificationforTen()
    console.log(printTimestamp(), '  Based on selected value from drop down number of records value verified')
});

And("User should be able to navigate to next page by clicking on >", () => {
    createPattern.nextPageNavigationClickandVerification()
    console.log(printTimestamp(), ' navigated to next page by clicking on >')
});

And("User should be able to navigate to next page by clicking on <", () => {
    createPattern.previousPageNavigationClickandVerification()
    console.log(printTimestamp(), ' navigated to previous page by clicking on >')
});

And("User should be able to change number of entries per page", () => {
    createPattern.changeEntriesPerPageCount()
    createPattern.totalrecordsPerPageVerificationforTwenty()
    console.log(printTimestamp(), ' Entries per page changed')
});

And("User should be able to click on Cancel button and pop up should get closed", () => {
    createPattern.cancelButtonClick()
    createPattern.popUpCloseVerification()
    console.log(printTimestamp(), ' Clicked on Cancel button and pop up got closed')
});

And("Reopen import condition and verifies entries per page and total count of page", () => {
    createPattern.addConditionPlusIconClick()
    createPattern.fromRulePatternClick()
    createPattern.showAllCheckboxClick()
    createPattern.totalrecordsPerPageVerificationforTen()
    console.log(printTimestamp(), ' Reverified entries per page and total count of page')
});

And("Verifies Import button should be disabled when none of pattern is selected", () => {
    createPattern.importButtonDisabledVerification()
    console.log(printTimestamp(), ' Verified Import button disabled when none of pattern is selected')
});

When("User opens any pattern then Grid should be resized and pattern details should be displayed in right side", () => {
    createPattern.firstPatternOpenClick()
    createPattern.sizeAndPatternDetailsVerification()
    console.log(printTimestamp(), ' Pattern Grid resized and pattern details displayed')
});

Then("<> icons should be available and clickable", () => {
    createPattern.navigationIconsClick()
    cy.wait(2000)
    createPattern.navigationIconsClick()
    console.log(printTimestamp(), ' <> icons displayed and clickable')
});

And("Verifies details after expanding the details", () => {
    createPattern.expandedDetails().invoke('text').then((text) => {
        arr.push(text)
    })
    cy.log(arr)
    console.log(printTimestamp(), ' Verified details after expanding the details')
});

And("Verifies details after collapsing the details and and At right side horizontally Pattern Details name should be available", () => {
    createPattern.navigationIconsClick()
    createPattern.sizeAndPatternDetailsVerificationAfterCollapse()
    createPattern.horizontalPanelVerification()
    console.log(printTimestamp(), ' Verified details after collapsing the details')
});

And("Import button should be enabled when any pattern is selected", () => {
    createPattern.importButtonEnabledVerification()
    console.log(printTimestamp(), ' Import button enabled when any pattern is selected')
});

And("Data should be available in tooltip while hovering mouse on pattern details grid", () => {

    console.log(printTimestamp(), ' Data available in tooltip while hovering mouse')
});

And("Pattern name, Description, Data models and Tags column are available", () => {
    createPattern.nameColumnVisible()
    createPattern.discriptionColumnVisible()
    createPattern.dataModelColumnVisible()
    createPattern.tagsColumnVisible()
    console.log(printTimestamp(), ' Pattern name, Description, Data models and Tags column displayed')
});

And("Data Models and tags values are displayed as comma seperated", () => {
    // createPattern.tagsValuesWithCommaVerification()
    console.log(printTimestamp(), ' Data Models and tags values are displayed as comma seperated')
});

And("Clicks on From Rule Pattern and verifies show All should be available in unchecked state and None of data should be available in grid", () => {
    createPattern.addConditionPlusIconClick()
    createPattern.fromRulePatternClick()
    createPattern.tableNotPresentVerification()
    createPattern.cancelButtonClick()
    console.log(printTimestamp(), ' Clicked on From Rule/Pattern and reverifies show All checkbox available in unchecked state')
});

And("Close DAW application", () => {
    cy.DeleteWorkflow()
    cy.log("Test Case Executed Successfully")
    console.log(printTimestamp(), ' Test Case Executed Successfully')
});
