/// <reference types="Cypress" /> 
/// <reference types = 'cypress-tags' />   

import "../../../../support/index"
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';

import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();

When("User create Authoring Workflow", () => {
    createPattern.myPatternThreeDotsClick()
    createPattern.createPatternButtonClick()
    cy.wait(2000)
    createPattern.patternNameType()
    createPattern.descriptionType()
    createPattern.orderOfExecutionType()
    console.log(printTimestamp(), 'created Authoring Workflow')
});

And("Click on Add Condition  Click on + - Click on From Rule Pattern", () => {
    createPattern.addConditionTabClick()
    createPattern.addConditionPulsIconClick()
    cy.wait(1000)
    createPattern.rulePatternOptionClick()
    console.log(printTimestamp(), 'Clicked on Add Condition  Click on + - Click on From Rule Pattern')
});

Then("Import Condition pop up should be displayed", () => {
    createPattern.importConditionPopUpVisible()
    console.log(printTimestamp(), 'Import Condition pop up displayed')
});

When("User Search any keyword in common search", () => {
    createPattern.commonSearchTextBoxClick()
    createPattern.nameOptionUnderCommonSearchClick()
    createPattern.commonSearchBoxType()
    createPattern.searchButtonClick()
    cy.wait(1000)
    console.log(printTimestamp(), 'Searched any keyword in common search')
});

Then("Column level filter should be displayed with textbox drop down -Name free text box,-Description free"
    + " text box,-Data Models Multi select drop down,-Tags Multi select drop down displayed", () => {
        createPattern.coloumLevelNameFilterVisible()
        createPattern.coloumLevelDecriptionFilterVisible()
        createPattern.coloumLevelDataModelFilterVisible()
        createPattern.coloumLevelTagsFilterVisible()
        console.log(printTimestamp(), ' Column level filter with all the options displayed')
    });

When("User Click on drop down of any multi select drop down", () => {
    cy.wait(3000)
    createPattern.coloumLevelDataModelFilterClick()
    createPattern.coloumLevelDataModelfilterClick()
    console.log(printTimestamp(), 'Clicked on drop down of any multi select drop down')
});

Then("Select all-to select all listed values Filter option text box with icon,Check box at each value level to select,single multiple value,Clear button,Apply button displayed", () => {
    createPattern.selectAllCheckBoxVisible() 
    createPattern.filterOptionVisible()
    createPattern.checkBoxAtEachValueLevelVisible()
    createPattern.clearButtonVisible()
    createPattern.applyButtonVisible()
    console.log(printTimestamp(), 'Select all-to select all listed values Filter option text box with icon,Check box at each value level to select,single multiple value,Clear button,Apply button displayed')
});

When("User Click on column level filter for data model , select one value available in drop down and click on apply button", () => {
    createPattern.eventLogDataModelInColumnLevelFilterClick()
    createPattern.applyButtonClick()
    cy.wait(2000)
    console.log(printTimestamp(), 'Clicked on column level filter for data model , select one value available in drop down and clicked on apply button')
});

Then("filtered data should be displayed and drop down should be closed", () => {
    createPattern.filteredDataVisible()
    createPattern.dataModelDropDownNotExist()
    console.log(printTimestamp(), 'filtered data displayed and drop down closed')
});

And("Value should be displayed on drop down", () => {
    createPattern.valueOnDropDownVisible()
    console.log(printTimestamp(), 'Value displayed on drop down')
});

And("Value should be displayed in tooltip while hovering mouse on column drop down", () => {
    // createPattern.valueOnToolTipVisible()
    console.log(printTimestamp(), 'Value displayed in tooltip while hovering mouse on column drop down')
});

And("Filter will get applied-cleared when buttons apply and clear clicked respectively", () => {
    createPattern.coloumLevelDataModelfilterClick()
    createPattern.clearButtonClick()
    createPattern.valueOnDropDownNotVisible()
    createPattern.coloumLevelDataModelFilterClick()
    createPattern.eventLogDataModelInColumnLevelFilterClick()
    createPattern.applyButtonClick()
    cy.wait(1000)
    createPattern.valueOnDropDownVisible()
    console.log(printTimestamp(), 'Filter will gets applied-cleared when buttons apply and clear clicked respectively')
});

And("The filtered result should be available", () => {
    createPattern.filteredDataVisible()
    console.log(printTimestamp(), 'The filtered result available')
});
// code commented For remaining deta models
// And("If no result available then the “No Record Found” message should be displayed", () => {
// 	createPattern.coloumLevelDataModelFilterClick()
//     createPattern.clearButtonClick()
//     createPattern.coloumLevelDataModelFilterClick()
//     createPattern.testDataModelClick()
//     createPattern.applyButtonClick()
//      createPattern.noRecordsTextVisible()
//     console.log(printTimestamp() ,'If no result available then the “No Data Available” message displayed')
// });

// When("Click on column level filter  data model and select multiple options from available in drop down", () => {
//     createPattern.coloumLevelDataModelFilterClick()
//     createPattern.systemParameterDataModelClick()
//     createPattern.eventLogDataModelClick()
//     createPattern.applyButtonClick()
//     console.log(printTimestamp() ,'Clicked on column level filter  data model and selects multiple options from available in drop down')
// });

// Then("One value and after that count should be displayed on drop down e.g. CV +2", () => {
//     createPattern.valueOnDropDownWithMultiSelectVisible()
//     console.log(printTimestamp() ,'One value and after that count displayed on drop down e.g. CV +2')
// });

// And("All values should be displayed in tooltip while hovering mouse on drop down", () => {

//     console.log(printTimestamp() ,'All values displayed in tooltip while hovering mouse on drop down')
// });

// And("Filtered result should be available", () => {
// 	 createPattern.filteredDataVisible()
//     console.log(printTimestamp() ,'Filtered result available')
// });

// And("If no result available then “No records found” message should be displayed", () => {
//     createPattern.coloumLevelDataModelFilterClick()
//     createPattern.eventLogDataModelClick()
//     createPattern.testDataModelClick()
//     createPattern.applyButtonClick()
//     createPattern.noRecordsTextVisible()
//     console.log(printTimestamp() ,'If no result available then the “No Data Available” message displayed')
// });

When("Click on data model column level filter and search any value", () => {
    createPattern.coloumLevelDataModelFilterClick()
    createPattern.filterOptionInDropDownType()
    console.log(printTimestamp(), 'Clicked on data model column level filter and searched any value')
});

Then("searched result should be available", () => {
    createPattern.eventLogDataModelInDropDownVisible()
    console.log(printTimestamp(), 'searched results available')
});

When("Click on Clear button available in drop down", () => {
    createPattern.clearButtonClick()
    cy.wait(1000)
    console.log(printTimestamp(), 'Clicked on Clear button in drop down')
});

Then("Filter drop down should be closed,Filtered data should get cleared", () => {
    createPattern.dataModelDropDownNotExist()
    console.log(printTimestamp(), 'Filter drop down closed,Filtered data gets cleared')
});

When("Click on data model column level filter and select single-multi or all in check box", () => {
    createPattern.coloumLevelDataModelfilterClick()
    // createPattern.systemParameterDataModelClick()
    createPattern.eventLogDataModelInColumnLevelFilterClick()
    createPattern.applyButtonClick()
    cy.wait(1000)
    console.log(printTimestamp(), 'Clicedk on data model column level filter and select single-multi or all in check box')
});

Then("Based on selected items data should be filtered", () => {
    createPattern.filteredDataVisible()
    console.log(printTimestamp(), 'Based on selected items data filtered')
});
And("Search icon should be in disabled state when none of text entered in text box", () => {
    createPattern.nameFilterSearchIconDisabled()
    createPattern.descriptionFilterSearchIconDisabled()
    console.log(printTimestamp(), 'Search icon in disabled state when none of text entered in text box')
});

When("User enter value for Name and Description", () => {
    createPattern.nameFilterTextBoxType()
    createPattern.descriptionFilterTextBoxType()
    console.log(printTimestamp(), 'entered value for Name and Description')
});

And("click on enter search icon", () => {
    createPattern.descriptionFilterSearchIconClick()
    cy.wait(1000)
    console.log(printTimestamp(), 'clicked on enter search icon')
});

And("Verify search icon and x mark when filter applied", () => {
    createPattern.nameFilterSearchIconEnabled()
    createPattern.descriptionFilterSearchIconEnabled()
    createPattern.crosssIconAtNameFilterVisible()
    createPattern.crosssIconAtDescriptionFilterVisible()
    console.log(printTimestamp(), 'Verified search icon and x mark when filter applied')
});

Then("Filtered result should be available on top of applied filter for drop down option related column", () => {
    // createPattern.filteredDataVisible()
    console.log(printTimestamp(), 'Filtered result available on top of applied filter for drop down option related column')
});

When("Enter keyword in common search  text box by keeping “All” in drop down option", () => {
    createPattern.commonSearchTextBoxNameSelectedClick()
    createPattern.allOptionUnderCommonSearchClick()
    createPattern.commonSearchBoxdetectorType()
    createPattern.searchButtonClick()
    cy.wait(1000)
    console.log(printTimestamp(), 'Entered keyword in common search  text box by keeping “All” in drop down option')
});

Then("The filtered result should be available in grid on top of filtered result available in above step", () => {
    createPattern.filteredDataVisible()
    console.log(printTimestamp(), 'The filtered result available in grid on top of filtered result available in above step')
});

And("Verify that Entries per page , Showing current page of total page and total number of records diaplayed in grid", () => {
    createPattern.entriesPerPageTextVisible()
    createPattern.pageCountVisible()
    createPattern.recordCountVisible()
    console.log(printTimestamp(), 'Verify that Entries per page , Showing current page of total page and total number of records diaplayed in grid')
});

When("Select any option from drop down of common search and enter keyword-words", () => {
    createPattern.commonSearchTextBoxNameSelectedClick()
    createPattern.attributeDropDownOptionsInCommonSearchClick()
    createPattern.commonSearchBoxErrorType()
    console.log(printTimestamp(), 'Select any option from drop down of common search and enter keyword-words')
});

And("Click on search icon-press enter", () => {
    createPattern.searchButtonClick()
    cy.wait(1000)
    console.log(printTimestamp(), 'Clicked on search icon-press enter')
});

Then("Filtered result should be available,If no result available then “No records found” message should be displayed", () => {
    createPattern.filteredDataVisible()
    console.log(printTimestamp(), 'Filtered result available,If no result available then “No records found” message displayed')
});

And("Filtered result should be match with db", () => {

    console.log(printTimestamp(), 'Filtered result matched with db')
});

When("User Click on search icon of common search text box", () => {
    // createPattern.coloumLevelDataModelfilterClick()
    // createPattern.eventLogDataModelInColumnLevelFilterClick()
    // createPattern.applyButtonClick()
    createPattern.commonSearchBoxErrorType()
    createPattern.searchButtonClick()
    cy.wait(1000)
    console.log(printTimestamp(), 'Clicked on search icon of common search text box')
});

Then("searched result should get cleared", () => {
    createPattern.valueOnDropDownNotVisible()
    console.log(printTimestamp(), 'searched result  get cleared')
});

And("Filtered result should be available,If no result available then “No records found” message should be displayed", () => {
    createPattern.filteredDataVisible()
    console.log(printTimestamp(), 'Filtered result available,If no result available then “No records found” message displayed')
});

When("User Click on X mark available in knowledge name textbox", () => {
    createPattern.nameFilterTextBoxType()
    createPattern.nameFilterSearchIconClick()
    createPattern.crossMarkAtKnowledgeNameClick()
    console.log(printTimestamp(), 'Clicked on X mark available in knowledge name textbox')
});

Then("If filtered applied then filtered data and searched text should get cleared,If no filter applied then searched text should get cleared", () => {
    createPattern.nameFilterTextBoxWithoutText()
    console.log(printTimestamp(), 'If filtered applied then filtered data and searched text gets cleared,If no filter applied then searched text get cleared')
});

And("Search icon should be disabled", () => {
    createPattern.nameFilterSearchIconDisabled()
    console.log(printTimestamp(), 'Search icon disabled')
});

And("X icon should not be displayed", () => {
    createPattern.crossMarkAtKnowledgeNamenotExist()
    console.log(printTimestamp(), 'X icon not displayed')
});

When("User Apply filter on one or multiple columns", () => {
    createPattern.nameFilterTextBoxType()
    createPattern.descriptionFilterTextBoxType()
    console.log(printTimestamp(), 'Applied filter on one or multiple columns')
});

Then("Filtered data should be available", () => {
    createPattern.filteredDataVisible()
    console.log(printTimestamp(), 'Filtered data available')
});

When("click on clear all filter", () => {
    createPattern.cancelButtonClick()
    console.log(printTimestamp(), 'clicked on clear all filter')
});

Then("Filter data should get cleared", () => {
    createPattern.importConditionPopUpNotExist()
    console.log(printTimestamp(), 'Filtered data get cleared')
});

When("Click on Add Condition  Click on + ,- Click on From Rule Pattern , Click on Select Show All", () => {
    createPattern.addConditionPlusIconClick()
    cy.wait(1000)
    createPattern.rulePatternOptionClick()
    createPattern.showAllButtonClick()
    console.log(printTimestamp(), 'Clicked on Add Condition  Click on + ,- Click on From Rule Pattern , Click on Select Show All')
});

Then("pattern details should be displayed, Column level filter should be work as expected", () => {
    createPattern.filteredDataVisible()
    console.log(printTimestamp(), 'pattern details displayed, Column level filter work as expected')
});

And("Repeat above steps by covering all drop down options available in common filter text box", () => {
    createPattern.commonSearchTextBoxClick()
    createPattern.conditionDropDownOptionsInCommonSearchClick()
    createPattern.commonSearchBoxDicomType()
    createPattern.searchButtonClick()
    cy.wait(1000)
    createPattern.filteredDataVisible()
    createPattern.commonSearchTextBoxNameSelectedClick()
    createPattern.dataModelDropDownOptionsInCommonSearchClick()
    createPattern.commonSearchBoxEventLogType()
    createPattern.searchButtonClick()
    cy.wait(2000)
    createPattern.filteredDataVisible()
    createPattern.commonSearchTextBoxNameSelectedClick()
    createPattern.descriptionDropDownOptionsInCommonSearchClick()
    createPattern.commonSearchBoxErrorType()
    createPattern.searchButtonClick()
    cy.wait(1000)
    createPattern.filteredDataVisible()
    createPattern.commonSearchTextBoxNameSelectedClick()
    createPattern.tagsDropDownOptionsInCommonSearchClick()
    createPattern.commonSearchBoxDicomType()
    createPattern.searchButtonClick()
    cy.wait(1000)
    createPattern.filteredDataVisible()
    console.log(printTimestamp(), 'Repeated above steps by covering all drop down options available in common filter text box')
});

And("Repeat above steps by applying column level filter and verify filtered result", () => {
    createPattern.commonSearchTextBoxNameSelectedClick()
    createPattern.allOptionUnderCommonSearchClick()
    createPattern.commonSearchBoxType()
    createPattern.searchButtonClick()
    cy.wait(1000)
    // createPattern.tagsDropdownClick()
    // createPattern.collimeterOptionClick()
    // createPattern.applyButtonInTagsDropdownClick()
    cy.wait(1000)
    // createPattern.filteredDataVisible()
    createPattern.commonSearchBoxErrorType()
    createPattern.searchButtonClick()
    cy.wait(1000)
    // createPattern.tagsDropdownClick()
    // createPattern.doseMeasurementOptionClick()
    // createPattern.applyButtonInTagsDropdownClick()
    // cy.wait(2000)
    // createPattern.filteredDataVisible()
    console.log(printTimestamp(), 'Repeat above steps by applying column level filter and verify filtered result')
});