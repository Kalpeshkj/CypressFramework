
/// <reference types="Cypress" />
/// <reference types = 'cypress-tags' />    

import "../../../../support/index"
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';

import IncludeKnowledge from "../../../../support/pageObjects/pages/PatternAuthoring/includeKnowledgepageObj";
const includeKnowledge = new IncludeKnowledge();
import Constants from "../../../../support/pageObjects/pages/PatternAuthoring/constants";
const constants = new Constants();

When("Navigate to existing wf, fill details in create pattern and apply metadata page", () => {
    cy.createPattern()
    cy.get('#pat-step-next > .pt-layout-container > span').click()
    cy.wait(5000)

    cy.ApplyMetaDetaPageCompletion()
    cy.get('#pat-step-next > .pt-layout-container > span').click({ force: true })
    cy.wait(5000)
    console.log(printTimestamp(), 'navigate to new workflow fill details in create pattern and apply metadata page')
});

Then("User should be able to navigate to Include Knowledge step", () => {
    includeKnowledge.includeKnowledgePage()
    console.log(printTimestamp(), 'naigate to Include Knowledge step')
});

When("Click on show all checkbox", () => {
    includeKnowledge.showAllCheckboxClick()
    console.log(printTimestamp(), 'Clicked on show all checkbox')
});

Then("Data should be displayed in grid", () => {
    includeKnowledge.dataInGridVisible()
    console.log(printTimestamp(), 'Data displayed in grid')
});

When("Select any knowledge", () => {
    includeKnowledge.firstKnowledgwSelect()
    console.log(printTimestamp(), 'Selects knowledge')
});

Then('Previous - enabled,Close - enabled,Save as Draft - enabled,Next - enabled', () => {
    includeKnowledge.previousButtonEnabled()
    includeKnowledge.closeButtonEnabled()
    includeKnowledge.saveAsDraftEnabled()
    includeKnowledge.nextButtonEnabled()
    console.log(printTimestamp(), 'Previous - enabled,Close - enabled,Save as Draft - enabled,Next - enabled')
});

When("Click on Next button", () => {
    includeKnowledge.nextClick()
    cy.wait(2000)
    console.log(printTimestamp(), 'Clicked on Next button')
});

And("Create Pattern, Apply Metadata and Include Knowledge should be displayed with right mark as completed", () => {
    includeKnowledge.createPatternWithRightMarkVisible()
    includeKnowledge.applyMetadataWithRightMarkVisible()
    includeKnowledge.includeKnowledgeWithRightMarkVisible()
    console.log(printTimestamp(), 'Create Pattern, Apply Metadata and Include Knowledge displayed with right mark as completed')
});

Then("User should be able to navigate to Review Step", () => {
    includeKnowledge.previousButtonClick()
    console.log(printTimestamp(), 'User navigate to Review Step')
});

When("Navigate back to Include tab", () => {
    includeKnowledge.includeTabClick()
    console.log(printTimestamp(), 'Navigate back to Include tab')
});

And("remove selected knowledge", () => {
    includeKnowledge.showAllCheckboxClick()
    includeKnowledge.firstKnowledgwClick()
    console.log(printTimestamp(), 'removeed selected knowledge')
});

Then('Previous - enabled,Close - enabled,Save as Draft - enabled,Next - disabled', () => {
    includeKnowledge.previousButtonEnabled()
    includeKnowledge.closeButtonEnabled()
    includeKnowledge.saveAsDraftEnabled()
    includeKnowledge.nextButtonDisabled()
    console.log(printTimestamp(), ' Buttons Verified')
});

Then("Previous - enabled,Close - enabled,Save as Draft - enabled,Next - Disabled", () => {
    includeKnowledge.previousButtonEnabled()
    includeKnowledge.closeButtonEnabled()
    includeKnowledge.saveAsDraftEnabled()
    includeKnowledge.nextButtonDisabled()
    console.log(printTimestamp(), ' Buttons Verified')
});

When("User Navigate to Review tab", () => {
    includeKnowledge.reviewTabClick()
    console.log(printTimestamp(), 'Navigated to Review tab')
});

When("User Navigate to Include tab", () => {
    includeKnowledge.includeTabClick()
    console.log(printTimestamp(), 'Navigate to Include tab')
});

And("select multiple knowledge", () => {
    includeKnowledge.firstKnowledgwSelect()
    includeKnowledge.secondKnowledgwSelect()
    console.log(printTimestamp(), 'selects multiple knowledge')
});

And("navigate to review tab", () => {
    includeKnowledge.reviewTabClick()
    console.log(printTimestamp(), 'navigated to review tab')
});

When("User Remove one of knowledge", () => {
    includeKnowledge.removeKnowledgeIconClick()
    console.log(printTimestamp(), 'Removed one of knowledge')
});

When("User Click on Next button", () => {
    includeKnowledge.nextClick()
    console.log(printTimestamp(), 'Clicked on Next button')
});

And("Create Pattern, Apply Metadata and Include Knowledge should be displayed with right mark as completed", () => {
    includeKnowledge.createPatternWithRightMarkVisible()
    includeKnowledge.applyMetadataWithRightMarkVisible()
    includeKnowledge.includeKnowledgeWithRightMarkVisible()
    console.log(printTimestamp(), 'Create Pattern, Apply Metadata and Include Knowledge displayed with right mark as completed')
});

Then("User should be able to navigate to Review Step", () => {
    includeKnowledge.previousButtonClick()
    cy.wait(2000)
    console.log(printTimestamp(), 'navigate to Review Step')
});

When("User Remove all knowledge", () => {
    includeKnowledge.removeKnowledgesIconsClick()
    console.log(printTimestamp(), 'Removed all knowledge')
});

When("User Select multiple knowledge", () => {
    includeKnowledge.includeTabClick()
    includeKnowledge.showAllCheckboxClick()
    includeKnowledge.firstKnowledgwSelect()
    includeKnowledge.secondKnowledgwSelect()
    console.log(printTimestamp(), 'Selects multiple knowledge')
});

And("click on Save as Draft", () => {
    includeKnowledge.saveasDraftClick()
    cy.wait(5000)
    console.log(printTimestamp(), 'clicked on Save as Draft')
});

Then("Previous - enabled,Close - enabled,Save as Draft - disabled,Next - enabled", () => {
    includeKnowledge.previousButtonEnabled()
    includeKnowledge.closeButtonEnabled()
    includeKnowledge.saveAsDraftDisabled()
    includeKnowledge.nextButtonDisabled()
    console.log(printTimestamp(), 'Buttons Verified')
});

Then("Previous - enabled,Close -enabled,Save as Draft - disabled,Next -enabled", () => {
    includeKnowledge.previousButtonEnabled()
    includeKnowledge.closeButtonEnabled()
    includeKnowledge.saveAsDraftDisabled()
    includeKnowledge.nextButtonEnabled()
    console.log(printTimestamp(), 'Buttons Verified')
});

Then("Previous - enabled,Close -enabled,Save as Draft - enabled,Next -enabled", () => {
    includeKnowledge.previousButtonEnabled()
    includeKnowledge.closeButtonEnabled()
    includeKnowledge.saveAsDraftEnabled()
    includeKnowledge.nextButtonEnabled()
    console.log(printTimestamp(), 'Buttons Verified')
});

When("User Remove or add additional knowledge", () => {
    includeKnowledge.firstKnowledgwClick()
    console.log(printTimestamp(), 'Remove or add additional knowledge')
});

When("User Click on close button", () => {
    cy.ExistingWorkFlowText()
    includeKnowledge.closeButtonClick()
    console.log(printTimestamp(), 'Clicked on close button')
});

Then("Confirmation pop up should be displayed WARNING: You have unsaved changes.Press OK to continue or Cancel to stay on this page. With Cancel and OK button", () => {
    includeKnowledge.confirmationPopUpHeaderVisible()
    includeKnowledge.confirmationPopUpDialogVisible()
    includeKnowledge.cancelButtonVisible()
    includeKnowledge.okButtonOnPopUpVisible()
    console.log(printTimestamp(), ' Confirmation pop up displayed WARNING: You have unsaved changes.Press OK to continue or Cancel to stay on this page. With Cancel and OK button')
});

When("Click on Ok in confirmation pop up", () => {
    includeKnowledge.okButtonOnPopUpClick()
    console.log(printTimestamp(), 'Clicked on Ok in confirmation pop up')
});

Then("User should be able to navigate to My Pattern Dashboard", () => {
    includeKnowledge.myPatternDashboardSelected()
    console.log(printTimestamp(), 'navigate to My Pattern Dashboard')
});

When("User Navigate to existing wf and verify details and button", () => {
    cy.ExistingWFClick()
    console.log(printTimestamp(), 'Navigate to existing wf and verified details and button')
});

Then("Updated details should not be available", () => {
    includeKnowledge.additionalKnowledgeNotVisible()
    console.log(printTimestamp(), 'Updated details not available')
});

And("Close DAW application", () => {
    cy.DeleteWorkflow()
    cy.log("Test Case Executed Successfully")
    console.log(printTimestamp(), ' Test Case Executed Successfully')
});
