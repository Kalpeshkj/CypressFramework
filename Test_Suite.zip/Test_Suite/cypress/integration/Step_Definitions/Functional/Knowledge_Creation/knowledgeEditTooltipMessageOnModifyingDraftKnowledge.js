/// <reference types="Cypress" />
/// <reference types='cypress-tags' /> 
import "../../../../support/index";
import {Given, When, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import CreateKnowledge from "../../../../support/pageObjects/pages/KnowledgeAuthoring/CreateKnowledge";
const createKnowledge = new CreateKnowledge();
import KnowledgeDashboard from "../../../../support/pageObjects/pages/Knowledge_Dashboard/KnowledgeDashboard";
const knowledgeDashboard = new KnowledgeDashboard();

When("Navigate to Knowledge Dashboard", () => {
    createKnowledge.knowledgeOptionArrowClick()
    createKnowledge.addKnowledgeWorkflowButtonClick()
    cy.wait(5000)
	cy.CreateMyKnowledge()
    createKnowledge.saveAsDraftClick() 
    cy.wait(4000)
    createKnowledge.getPatternName()
    knowledgeDashboard.knowledgeDashboardClick() 
    cy.wait(2000)
    console.log(printTimestamp(), 'Navigated to Newly Created knowledge workflow')
});

Then("Verify the 3 dots available for published-Withdraw knowledge", () => {
	createKnowledge.knowledgeNameSearchValueType()
    knowledgeDashboard.selectingAllModalitiesAndApplyButtonClicked()
    knowledgeDashboard.threeDotsOfKnowledgeOnKnowledgeDashboardClick()
    console.log(printTimestamp(), 'Verify the 3 dots available for published/Withdraw knowledge')
});

And("Edit option should be available", () => {
	knowledgeDashboard.editButtonOnKnowledgeDashboardPageVisible()
    console.log(printTimestamp(), 'Edit option should be available')
});

When("Click on edit button", () => {
	knowledgeDashboard.editButtonOnKnowledgeDashboardPageClick()
    console.log(printTimestamp(), 'Click on edit button')
});

Then("User should be able to edit and save it", () => {
	createKnowledge.knowledgeNameInputBoxType()
    createKnowledge.saveAsDraftClick() 
    cy.wait(4000)
    createKnowledge.getPatternName()
    console.log(printTimestamp(), 'User should be able to edit and save it')
});

When("Click on Knowledge Dashboard", () => {
    knowledgeDashboard.knowledgeDashboardClick() 
    cy.wait(2000)
    console.log(printTimestamp(), 'Click on Knowledge Dashboard')
});

Then("The edited knowledge should be available in dashboard in draft state", () => {
	createKnowledge.knowledgeNameSearchValueTypeAfterEditing()
    knowledgeDashboard.selectingAllModalitiesAndApplyButtonClicked()
    knowledgeDashboard.editedKnowledgeInPatternDashboardPageVisible()
    knowledgeDashboard.editedKnowledgeInDraftState()
    console.log(printTimestamp(), 'The edited knowledge should be available in dashboard in draft state')
});

When("Click on the Knowledge which the user was editing before", () => {
	knowledgeDashboard.FirstRecordClick()
    console.log(printTimestamp(), 'Click on the Knowledge which the user was editing before')
});

Then("User should be navigated to knowledge details page", () => {
	knowledgeDashboard.knowledgeDetailsPageVisibel()
    console.log(printTimestamp(), 'User should be navigated to knowledge details page')
});

When("Click on Edit button available at the bottom right corner", () => {
	knowledgeDashboard.editButtonOnKnowledgeDetailsPageClick()
    cy.wait(2000)
    console.log(printTimestamp(), 'Click on Edit button available at the bottom right corner')
});

Then("User should be navigated to same workflow where he was editing this knowledge before.", () => {
    createKnowledge.createStageVisibleAndHighlighted()
    createKnowledge.modalityDropdownInApplyMetadata()
    createKnowledge.dcpModalityOptionClick()
    createKnowledge.modalityDropdownInApplyMetadata()
    createKnowledge.saveAsDraftClick() 
    cy.wait(4000)
    knowledgeDashboard.knowledgeDashboardClick() 
    cy.wait(2000)
    createKnowledge.knowledgeNameSearchValueTypeAfterEditing()
    knowledgeDashboard.selectingAllModalitiesAndApplyButtonClicked()
    console.log(printTimestamp(), 'User should be navigated to same workflow where he was editing this knowledge before.')
});

When("Right Click on the knowledge which user was editing Before and click on the edit button", () => {
	knowledgeDashboard.FirstRecordRightClick()
    cy.wait(1000)
    knowledgeDashboard.editButtonOnKnowledgeDashboardPageClick()
    console.log(printTimestamp(), 'Right Click on the knowledge which user was editing Before and click on the edit button')
});

Then("User should be navigated to same workflow where he was editing this knowledge before", () => {
    createKnowledge.createStageVisibleAndHighlighted()
    console.log(printTimestamp(), 'User should be navigated to same workflow where he was editing this knowledge before.')
});


