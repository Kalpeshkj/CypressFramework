/// <reference types="Cypress" />
/// <reference types='cypress-tags' />
import "../../../../support/index";
import { When, Then, Given } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();
import PatternDashboard from "../../../../support/pageObjects/pages/Dashboard/PatternDashboard";
const patternDashboard = new PatternDashboard();
import ValidationPage from "../../../../support/pageObjects/pages/PatternAuthoring/ValidatePage";
const validationPage = new ValidationPage();
import IncludeKnowledge from "../../../../support/pageObjects/pages/PatternAuthoring/includeKnowledgepageObj";
const includeKnowledge = new IncludeKnowledge();

Given("DAW application is available",()=>{
    cy.visit("https://daw-tags-test.eu-west.philips-healthsuite.com/home/patterns/dashboard")
    console.log(printTimestamp(), "DAW application is available")
})

And("Create patterns As per user input", () => {
    cy.CreateMultiplePatternsAsPerUserInput(2)
    console.log(printTimestamp(), "Created patterns As per user input")
});

When("Select single pattern and click on delete button", () => {
    cy.visit(Cypress.env("DAWAutomationURL"));
    cy.wait(2000)
    cy.reload()
    cy.wait(5000)
    createPattern.clearAllFiltersButtonClick()
    patternDashboard.patternNameSearchOptionWFnameType()
    patternDashboard.patternNameSearchIconClick()
    cy.wait(2000)
    patternDashboard.patternClick()
    cy.wait(4000)
    patternDashboard.deleteButtonInDetailsPageClick()
    cy.wait(1000)
    patternDashboard.popUpOkButtonClick()
    cy.wait(2000)
    console.log(printTimestamp(), 'Selects single pattern and clicked on delete button')
});

Then("should be able to delete pattern", () => {
	patternDashboard.patternDeleteMessageVisible()
    console.log(printTimestamp(), 'able to delete pattern')
});

When("Select multiple patterns and click on delete button", () => {
    patternDashboard.selectingFirstTwoRecords()
    cy.wait(1000)
    patternDashboard.deleteButtonIndashbaordClick()
    cy.wait(1000)
    patternDashboard.popUpOkButtonClick()
    console.log(printTimestamp(), 'Selects multiple patterns and clicked on delete button')
});

Then("All selected patterns should get deleted", () => {
	patternDashboard.patternDeleteMessageVisible()
    console.log(printTimestamp(), 'All selected patterns gets deleted')
});

When("Navigate to wf and verify deleted patterns Published state in import condition pop up", () => {
	createPattern.myPatternThreeDots().eq(1).click({ force: true });
    createPattern.createPatternButtonClick()
    cy.wait(2000)
    createPattern.addConditionTabClick()
    createPattern.addConditionPlusIconClick()
    cy.wait(1000)
    createPattern.formRulePatternOptionClick()
    cy.wait(1000)
    createPattern.showAllCheckboxClick()
    cy.wait(1000)
    createPattern.searchByKeyWordPublishedPatternNameType()
    cy.wait(1000)
    createPattern.searchIconClicked()
    cy.wait(1000)
    console.log(printTimestamp(), 'Navigated to wf and verified deleted patterns Published state in import condition pop up')
});

Then("Deleted pattern should not be available in import condition pop up", () => {
    createPattern.noResultsFoundInRelevanceMessageVisible()
    createPattern.cancelButtononPopUpClick()
    console.log(printTimestamp(), 'Deleted pattern not be available in import condition pop up')
});

Then("ES document count should get decreases when patterns are deleted", () => {
	
    console.log(printTimestamp(), 'ES document count gets decreases when patterns are deleted')
});

When("Select single pattern and click on withdraw button", () => {
	cy.CreateMultiplePatternsAsPerUserInput(2)
    cy.visit(Cypress.env("DAWAutomationURL"));
    cy.wait(2000)
    cy.reload()
    cy.wait(5000)
    patternDashboard.modalityDropdownColumnClick()
    cy.wait(1000)
    patternDashboard.selectAllCheckBoxClick()
    patternDashboard.modalityApplyButtonClick()
    patternDashboard.patternNameSearchOptionWFnameType()
    patternDashboard.patternNameSearchIconClick()
    cy.wait(2000)
    patternDashboard.patternClick()
    cy.wait(2000)
    patternDashboard.publishButtonInPatternDashboardClick()
    cy.wait(2000)
    patternDashboard.publishButtonInPopUpClick()
    cy.wait(30000)
    patternDashboard.patternClick()
    cy.wait(2000)
    patternDashboard.withdrawButtonInDetailsPageClick()
    cy.wait(1000)
    patternDashboard.popUpOkButtonClick()
    cy.wait(1000)
    console.log(printTimestamp(), 'Selects single pattern and clicked on withdraw button')
});

Then("User should be able to withdraw pattern", () => {
	patternDashboard.patternWithdrawMessageVisible()
    patternDashboard.backArrowClick()
    console.log(printTimestamp(), 'User able to withdraw pattern')
});

When("Select multiple patterns and click on withdraw button", () => {
    patternDashboard.secondPatternClick()
    cy.wait(3000)
    patternDashboard.publishButtonInPatternDashboardClick()
    cy.wait(2000)
    patternDashboard.publishButtonInPopUpClick()
    cy.wait(30000)
    patternDashboard.thirdPatternClick()
    cy.wait(4000)
    patternDashboard.publishButtonInPatternDashboardClick()
    cy.wait(2000)
    patternDashboard.publishButtonInPopUpClick()
    cy.wait(30000)
    patternDashboard.selectingSecondAndThirdRecords()
    cy.wait(1000)
    patternDashboard.withdrawPatternButtonClick()
    patternDashboard.popUpOkButtonClick()
    cy.wait(4000)
    console.log(printTimestamp(), 'Selects multiple patterns and clicked on withdraw button')
});

Then("All selected patterns should get withdrawn", () => {
	patternDashboard.patternWithdrawMessageVisible()
    console.log(printTimestamp(), 'All selected patterns gets withdrawn')
});

When("Navigate to wf and verify deleted patterns in import condition pop up", () => {
	createPattern.myPatternThreeDots().eq(1).click({ force: true });
    createPattern.createPatternButtonClick()
    cy.wait(2000)
    createPattern.addConditionTabClick()
    createPattern.addConditionPlusIconClick()
    cy.wait(1000)
    createPattern.formRulePatternOptionClick()
    cy.wait(2000)
    createPattern.showAllCheckboxClick()
    cy.wait(2000)
    createPattern.searchByKeyWordPublishedPatternNameType()
    cy.wait(1000)
    createPattern.searchIconClicked()
    cy.wait(2000)
    console.log(printTimestamp(), 'Navigated to wf and verify deleted patterns in import condition pop up')
});

Then("Withdrawn pattern should not be available in import condition pop up", () => {
	createPattern.noResultsFoundInRelevanceMessageVisible()
    createPattern.cancelButtononPopUpClick()
    cy.visit(Cypress.env("DAWAutomationURL"));
    cy.wait(2000)
    cy.reload()
    cy.wait(5000)
    createPattern.clearAllFiltersButtonClick()
    patternDashboard.patternNameSearchOptionWFnameType()
    createPattern.searchIconClicked()
    cy.wait(2000)
    patternDashboard.selectAllRecords()
    patternDashboard.deleteButtonIndashbaordClick()
    cy.wait(2000)
    patternDashboard.popUpOkButtonClick()
    console.log(printTimestamp(), 'Withdrawn pattern not be available in import condition pop up')
});

Then("ES document count should get decreases when patterns are withdrawn", () => {
	
    console.log(printTimestamp(), 'ES document count get decreases when patterns are withdrawn')
});

Then("Repeat steps in My Pattern Dashboard", () => {
    cy.visit(Cypress.env("DAWAutomationURL"));
    cy.wait(2000)
    cy.reload()
    cy.wait(5000)
    cy.CreateMultiplePatternsAsPerUserInput(1)
    cy.wait(3000)
    createPattern.myPatternsSectionCollapseIconClick()
    createPattern.myPatternDashboardClick()
    createPattern.clearAllFiltersButtonClick()
    createPattern.patternNameTypeInSearchFilter()
    cy.wait(2000)
    createPattern.selectAllRecordClickInDashboard()
    cy.wait(1000)
    createPattern.publishButtonClick()
    cy.wait(30000)
    createPattern.selectAllRecordClickInDashboard()
    cy.wait(1000)
    createPattern.withdrawButtonClick()
    cy.wait(2000)
    patternDashboard.popUpOkButtonClick()
    cy.wait(1000)
    createPattern.selectAllRecordClickInDashboard()
    patternDashboard.deleteButtonIndashbaordClick()
    cy.wait(2000)
    patternDashboard.popUpOkButtonClick()
    console.log(printTimestamp(), 'Repeats above steps in My Pattern Dashboard')
});