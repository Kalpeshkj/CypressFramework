/// <reference types="Cypress" />
/// <reference types='cypress-tags' />  

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';

import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();
import PatternDashboard from "../../../../support/pageObjects/pages/Dashboard/PatternDashboard";
const patternDashboard = new PatternDashboard();
var arr = [];
var newArr = [];


Then("By default , Pattern Dashboard page should be displayed", () => {
    patternDashboard.patternDashboardTitleVisible()
    patternDashboard.patternDashboardBreadCrumVisible()
    cy.wait(3000)
    console.log(printTimestamp(), 'Pattern Dashboard displayed')
});

And("Pattern should be present and should be selectable", () => {
    patternDashboard.patternsVisible()
    patternDashboard.patternsCheckboxUnchecked()
    console.log(printTimestamp(), 'Pattern is present and selectable')
});

When("Click on the 3 vertical dots next to any of the pattern", () => {
    patternDashboard.threeDotsClick()
    console.log(printTimestamp(), 'Clicked on the 3 vertical dots next to any of the pattern')
});

Then("Clone enabled button should be displayed in menu", () => {
    patternDashboard.cloneButtonEnabledVisible()
    console.log(printTimestamp(), 'Clone enabled button displayed in menu')
});

And("Make a note of all the values added in the selected pattern which is supposed to be cloned", () => {
    createPattern.firstPatternClick()
    cy.wait(5000)
    createPattern.patterndescriptionDetails()
    createPattern.patternDataModelDetails()
    createPattern.patternExpression()
    createPattern.modelityDetails()
    createPattern.patternTypeDetails()
    createPattern.daySpanDetails()

    console.log(printTimestamp(), 'Make a note of all the values added in the selected pattern which is supposed to be cloned')
});

When("User Click on the Clone menu", () => {
    createPattern.cloneOptionInPatternDetailClick()
    cy.wait(5000)
    console.log(printTimestamp(), 'User Click on the Clone menu')
});

Then("new workflow should be created with Create Pattern"
    + " workflow page and user should be navigated to newly created wf", () => {
        createPattern.createPatternPageVisible()
        console.log(printTimestamp(), 'user navigated to newly created wf')
    });

And("The pattern name field should not be empty and in red color indicating that it should be filled", () => {
    createPattern.patternNameIndicatorTextVisible()
    console.log(printTimestamp(), 'The pattern name field not empty and in red color indicating that it  filled')
});

When("Click on the next button without filling any Pattern name in the pattern name section", () => {
    createPattern.nextButtonClick()
    console.log(printTimestamp(), 'Clicked on the next button without filling any Pattern name in the pattern name section')
});

Then("User should not be able to proceed to the next workflow", () => {
    createPattern.createPatternPageVisible()
    console.log(printTimestamp(), 'User not proceed to the next workflow')
});

And("All the values present in the current pattern is cloned from. should match field by field", () => {
    createPattern.importDataModelDetailInCreatePatternPage()
    console.log(printTimestamp(), 'All the values present in the current pattern is cloned from match field by field')
});

When("User Enter Pattern name and make some changes  in cloned newly created workflow", () => {
    createPattern.patternNameTextBoxType()
    createPattern.orderOfExecutionType()
    console.log(printTimestamp(), 'Entered Pattern name and make some changes  in cloned newly created workflow')
});

And("Clicks on Save as Draft", () => {
    createPattern.addActionClick()
    createPattern.addActionPlusIconClick()
    createPattern.raiseAlertOptionClick()
    createPattern.clicksOnPopUpOkButton()
    cy.wait(2000)
    console.log(printTimestamp(), 'Clicked on Save as Draft')
});

When("Click on Next and Verify Apply Metadata Page", () => {
    createPattern.nextButtonClick()
    cy.wait(5000)
    console.log(printTimestamp(), 'Clicked on Next and Verify Apply Metadata Page')
});

Then("Prepopulated Pattern metadata details based on which pattern cloned should be available", () => {
    createPattern.daySpanInApplyMetadataPage()
    console.log(printTimestamp(), 'Prepopulated Pattern metadata details based on which pattern cloned available')
});

When("Update Data in Create Pattern and Apply Metadata Page Click on Save as Draft", () => {
    createPattern.serviceContextDropDownInApplyMetadataPageClick()
    createPattern.fseOptionClick()
    createPattern.saveAsDraftButtonClick()
    cy.wait(1000)
    console.log(printTimestamp(), 'Update Data in Create Pattern and Apply Metadata Page Clicked on Save as Draft')
});

Then("All details should be saved successfully", () => {
    createPattern.messageVisible()
    console.log(printTimestamp(), 'All details saved successfully')
});

And("In db data should get inserted for newly created workflow including pattern details Workflow Pattern"
    + " id as itemid,Patterns,pattern_data_model,pattern_action,pattern_metadata_tags,pattern_tags,pattern_tag_key_values", () => {


        console.log(printTimestamp(), 'In db data gets inserted for newly created workflow including pattern details')
    });

And("Newly created pattern should be displayed in pattern and my pattern dashboard", () => {
    createPattern.newlyCreatedWorkFlowText()
    createPattern.breadcumbClassFind().find('ul').children('li').last().find('a').find('span').invoke('text').then((Name) => {
        arr.length = 0
        cy.wait(2000)
        arr.push(Name)
        cy.wait(3000)
        cy.log(arr)
        createPattern.patternDashboardClick()
        cy.wait(3000)
        createPattern.patternInPatternDashboardVisible()
        createPattern.PatternInMyPatternDashboardPage()
        cy.get("section[id='" + arr[0] + "'] > #nav-dropdown-btn > .ng-star-inserted > #Layer_1")
            .click({ force: true })
        createPattern.deleteOption().click({ force: true });
        createPattern.okButtonClick()
    })
    console.log(printTimestamp(), 'Newly created pattern displayed in pattern and my pattern dashboard')
});

// When("the User Logging in the DB when Clone operation is performed by all the user levels", () => {


//     console.log(printTimestamp(), 'the User Logging in the DB when Clone operation is performed by all the user levels')
// });

// Then("Cloning operation log should be created.", () => {


//     console.log(printTimestamp(), 'Cloning operation log created.')
// });

And("Repeat above steps in My Pattern Dashboard", () => {
    cy.createPattern()
    createPattern.nextButtonClick()
    cy.ApplyMetaDetaPageCompletion()
    createPattern.nextButtonClick()
    createPattern.showAllCheckboxClick()
    patternDashboard.firstKnowledgwSelect()
    createPattern.saveAsDraftButtonClick()
    cy.wait(1000)
    createPattern.nextButtonClick()
    cy.wait(2000)
    createPattern.breadcumbClassFind().find('ul').children('li').last().find('a').find('span').invoke('text').then((Name) => {
        newArr.length = 0
        cy.wait(3000)
        newArr.push(Name)
        cy.wait(3000)
        cy.log(newArr)
    })
    createPattern.newlyCreatedWorkFlowInMyPatternText()
    createPattern.myPatternDashboardClick()
    cy.wait(1000)
    createPattern.searchBarType()
    createPattern.searchIconClick()
    cy.wait(3000)
    createPattern.firstPatternInMyPatternClick()
    cy.wait(1000)
    createPattern.cloneOptionInPatternDetailClick()
    cy.wait(5000)
    createPattern.createPatternPageVisible()
    createPattern.patternNameIndicatorTextVisible()
    createPattern.myPatternImportDataModelDetailInCreatePatternPage()
    createPattern.myPatternAddConditionDetailInCreatePatternPage()
    createPattern.patternNameBoxType()
    createPattern.saveAsDraftButtonForceClick()
    cy.wait(3000)
    cy.reload()
    cy.wait(5000)
    createPattern.nextButtonForceClick()
    createPattern.myPatternModalityInApplyMetadataPage()
    createPattern.myPatternPatternNameInApplyMetadataPage()
    createPattern.commentAreaType()
    createPattern.newlyCreatedWorkFlowInMyPatternText()
    createPattern.saveAsDraftButtonClick()
    cy.wait(1000)
    cy.reload()
    createPattern.breadcumbClassFind().find('ul').children('li').last().find('a').find('span').invoke('text').then((Name) => {
        arr.length = 0
        cy.wait(3000)
        arr.push(Name)
        cy.wait(2000)
        cy.log(arr)
        createPattern.myPatternDashboardClick()
        cy.wait(2000)
        cy.get("section[id='" + arr[0] + "'] > #nav-dropdown-btn > .ng-star-inserted > #Layer_1")
            .click({ force: true })
        createPattern.deleteOption().click({ force: true });
        createPattern.okButtonClick()
        cy.wait(2000)
        cy.get("section[id='" + newArr[0] + "'] > #nav-dropdown-btn > .ng-star-inserted > #Layer_1")
            .click({ force: true })
        createPattern.deleteOption().click({ force: true });
        cy.wait(2000)
        createPattern.okButtonClick()
    })
    console.log(printTimestamp(), 'Repeated above steps in My Pattern Dashboard')
});

And("close DAW  application", () => {
    cy.log('Test case executed successfully')
    console.log(printTimestamp(), 'Close DAW application')
});

















































