/// <reference types="Cypress" />
/// <reference types='cypress-tags' />
import "../../../../support/index";
import { When, Then, Given } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();
import PatternDashboard from "../../../../support/pageObjects/pages/Dashboard/PatternDashboard";
const patternDashboard = new PatternDashboard();
import ValidationPage from "../../../../support/pageObjects/pages/PatternAuthoring/ValidatePage";
const validationPage = new ValidationPage();

Given("DAW application is available",()=>{
    cy.visit("https://daw-automation.eu-west.philips-healthsuite.com/home/patterns/dashboard")
})

When("Create Workflow and Add pattern details for Create Pattern,Metadata and Include knowledge page", () => {
    cy.CreateMultiplePatternsWithValidation()
    console.log(printTimestamp(), ' Created Workflow and Added pattern details for Create Pattern,Metadata and Include knowledge page') 
});

And("Right click on created pattern", () => {
    patternDashboard.modalityDropdownColumnClick()
    cy.wait(2000)
    patternDashboard.selectAllCheckBoxClick()
    patternDashboard.modalityApplyButtonClick()
    cy.wait(1000)
    createPattern.PatternNameSearchInSearchOption()
    createPattern.searchIconClicked()
    cy.wait(2000)
    patternDashboard.patternClick()
    cy.wait(1000)
    console.log(printTimestamp(), ' Right clicked on created pattern') 
});

Then("For pattern Publish button should be displayed in enabled state.", () => {
    patternDashboard.publishButtonInPatternDashboardEnable()
    console.log(printTimestamp(), 'For pattern Publish button displayed in enabled state.') 
});

And("message should be displayed in pop up Delete icon The below 1 Pattern will be published."
+" Are you sure you want to proceed? Pattern name with Cancel and Publish buttons", () => {
	patternDashboard.publishButtonInPatternDashboardClick()
    patternDashboard.messageInPublishPopUpVisible()
    patternDashboard.patternNameInPopUpVisible()
    patternDashboard.cancelButtonInPopUpVisible()
    patternDashboard.publishButtonInPopUpVisible()
    patternDashboard.cancelButtonInPopUpClick()
    console.log(printTimestamp(), "message displayed in pop up Delete icon The below 1 Pattern will be published."
    +" Are you sure you want to proceed? Pattern name with Cancel and Publish buttons") 
});


Then("Pop up should get closed and Pattern should not get published", () => {
	patternDashboard.publishPatternPopUpNotExist()
    patternDashboard.backArrowClick()
    patternDashboard.patternInDraft()
    console.log(printTimestamp(), ' Pop up gets closed and Pattern not get published') 
});

When("click on Publish button", () => {
    patternDashboard.patternClick()
    cy.wait(2000)
    patternDashboard.publishButtonInPatternDashboardClick()
    patternDashboard.publishButtonInPopUpClick()
    cy.wait(2000)
    console.log(printTimestamp(), ' clicked on Publish button') 
});

Then("Pattern Status should be displayed as 'Published',Pattern Version should be displayed as latest"
+" incremental number e.g from Draft to 1.0 or from 1.0 to 1.1-2.0,Modified by should be displayed"
+" as User name,Modified on should be displayed as current date", () => {
	patternDashboard.patternInPublished()


    console.log(printTimestamp(), "Pattern Status displayed as 'Published',Pattern Version displayed as latest"
    +" incremental number e.g from Draft to 1.0 or from 1.0 to 1.1-2.0,Modified by should be displayed"
    +" as User name,Modified on displayed as current date") 
});

And("Draft pattern which is published for that workflow should get deleted from My Pattern workflow", () => {

    console.log(printTimestamp(), ' Draft pattern which is published for that workflow gets deleted from My Pattern workflow') 
});

And("Verify published pattern in Add Condition Import Rule-Pattern", () => {
    createPattern.myPatternThreeDots().eq(1).click({ force: true });
    createPattern.createPatternButtonClick()
    cy.wait(2000)
    createPattern.addConditionTabClick()
    createPattern.addConditionPlusIconClick()
    cy.wait(1000)
    createPattern.formRulePatternOptionClick()
    cy.wait(2000)
    createPattern.showAllCheckboxClick()
    cy.wait(2000)
    createPattern.searchByKeyWordPublishedPatternNameType()
    cy.wait(1000)
    createPattern.searchIconClicked()
    cy.wait(4000)
    
    createPattern.cancelButtononPopUpClick()
    console.log(printTimestamp(), ' Verified published pattern in Add Condition Import Rule-Pattern') 
});

And("Validate pattern data with db Table Name  Patterns", () => {
	
    console.log(printTimestamp(), ' Validated pattern data with db Table Name  Patterns') 
});

And("Validate pattern data with db Table Name  workflow", () => {
	
    console.log(printTimestamp(), ' Validated pattern data with db Table Name  workflow') 
});


When("Navigate to Pattern Dashboard,Edit published pattern e.g remove existing knowledge and add new knowledge and publish again", () => {
    createPattern.patternDashboardClick()
    cy.wait(3000)
    patternDashboard.modalityDropdownColumnClick()
    cy.wait(2000)
    patternDashboard.selectAllCheckBoxClick()
    patternDashboard.modalityApplyButtonClick()
    cy.wait(1000)
    createPattern.PatternNameSearchInSearchOption()
    createPattern.searchIconClicked()
    cy.wait(2000)
    patternDashboard.patternClick()
    cy.wait(1000)
    patternDashboard.editButtonClick()
    cy.wait(3000)
    createPattern.addActionClick()
    createPattern.plusIconUnderAddActionClick()
    cy.wait(1000)
    createPattern.insertAlertOptionClick()
    validationPage.saveAsDraftButtonClick()
    cy.wait(3000)
    console.log(printTimestamp(), ' Navigated to Pattern Dashboard,Edit published pattern e.g remove existing knowledge and add new knowledge and publish again') 
});

And("Delete Publish pattern", () => {
	createPattern.patternDashboardClick()
    cy.wait(2000)
    patternDashboard.modalityDropdownColumnClick()
    cy.wait(1000)
    patternDashboard.selectAllCheckBoxClick()
    patternDashboard.modalityApplyButtonClick()
    cy.wait(1000)
    createPattern.PatternNameSearchInSearchOption()
    createPattern.searchIconClicked()
    cy.wait(2000)
    patternDashboard.firstRecordThreeDotClick()
    cy.wait(2000)
    patternDashboard.deleteOptionClick()
    cy.wait(2000)
    createPattern.okButtonClick()
    cy.wait(5000)
    console.log(printTimestamp(), ' Deleted Publish pattern') 
});

Then("Deleted pattern's version should not get displayed in dashboard and import condition", () => {
    patternDashboard.removeFilterButtonOfDescriptionFilterClick()
    createPattern.PatternNameSearchInSearchOption()
    createPattern.searchIconClicked()
    cy.wait(2000)
    patternDashboard.firstRecordThreeDotClick()
    cy.wait(2000)
    patternDashboard.withdrawButtonClick()
    cy.wait(2000)
    createPattern.okButtonClick()
    cy.wait(1000)
    patternDashboard.firstRecordThreeDotClick()
    cy.wait(2000)
    patternDashboard.deleteOptionClick()
    cy.wait(2000)
    createPattern.okButtonClick()
    cy.wait(2000)
    patternDashboard.scrollElemntAfterDeleringPattern()
    cy.wait(1000)
    patternDashboard.norecordTextVisible() 
    console.log(printTimestamp(), ' Deleted patterns version not get displayed in dashboard and import condition') 
});

And("Repeate above steps and Publish pattern from three dot options available at row level and pattern details view page", () => {
    cy.CreateMultiplePatternsWithValidation()
    createPattern.PatternNameSearchInSearchOptionForPublishingPatternFromThreeDots()
    createPattern.searchIconClicked()
    cy.wait(2000)
    patternDashboard.firstRecordThreeDotClick()
    cy.wait(3000)
    patternDashboard.publishButtonInPatternDashboardUnderThreeDotsClick()
    cy.wait(3000)
    createPattern.okButtonClick()
    cy.wait(2000)
    patternDashboard.patternInPublished()
    patternDashboard.firstRecordThreeDotClick()
    cy.wait(2000)
    patternDashboard.deleteOptionClick()
    cy.wait(2000)
    createPattern.okButtonClick()
    cy.wait(2000)
    cy.ExistingWFClick()
    cy.DeleteWorkflow()
    console.log(printTimestamp(), ' Repeates above steps and Publish pattern from three dot options available at row level and pattern details view page') 
});