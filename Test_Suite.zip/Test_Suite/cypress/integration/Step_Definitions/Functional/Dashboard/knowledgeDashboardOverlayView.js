/// <reference types="Cypress" />
/// <reference types = 'cypress-tags' /> 

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import KnowledgeDashboard from "../../../../support/pageObjects/pages/Knowledge_Dashboard/KnowledgeDashboard";
const knowledgeDashboard = new KnowledgeDashboard();
import PatternDashboard from "../../../../support/pageObjects/pages/Dashboard/PatternDashboard";
const patternDashboard = new PatternDashboard();


When("User Navigate to knowledge dashboard", () => {
    knowledgeDashboard.knowledgeClick()
    knowledgeDashboard.knowledgeDashboardClick()
    cy.wait(5000)
    console.log(printTimestamp(), ' Navigated to knowledge dashboard')
})

Then("Knowledge Dashboard page should be displayed", () => {
    knowledgeDashboard.knowledgeDashboardNavigationVerification()
    console.log(printTimestamp(), 'Knowledge Dashboard page displayed')
})

When("User Select any Knowledge name", () => {
    patternDashboard.patternDashboardColumnFirstRecordClick();
    console.log(printTimestamp(), 'Selects any Knowledge name')
})

Then("Knowledge Details,Knowledge Name,Knowledge Description,Tags,Tag Values,Associations,Associated patterns should be displayed in right side screen", () => {

    console.log(printTimestamp(), 'Knowledge Details,Knowledge Name,Knowledge Description,Tags,Tag Values,Associations,Associated patterns displayed in right side screen')
})

And("Cross icon, Edit and View button  should be displayed in right side screen", () => {
    knowledgeDashboard.crossIconVisible()
    knowledgeDashboard.editButtonVisible()
    knowledgeDashboard.viewButtonVisible()
    console.log(printTimestamp(), 'Cross icon, Edit and View button displayed in right side screen')

})

And("Data should be matched with db as Knowledge,Pattern_knowledge,Knowledge tags,Cause tags,Symptom tags,Solution tags", () => {

    console.log(printTimestamp(), ' Data matched with db as Knowledge,Pattern_knowledge,Knowledge tags,Cause tags,Symptom tags,Solution tags')
})

When("User hovering on tags respective source should get displayed in tooltip details", () => {

    console.log(printTimestamp(), 'User hovering on tags respective source gets displayed in tooltip details')
})

And("if tag associated with knowledge for that tooltip should not be displayed", () => {

    console.log(printTimestamp(), 'if tag associated with knowledge for that tooltip not be displayed')
})

When("User Update-Remove group priviledges", () => {

    console.log(printTimestamp(), 'User Update-Removed group priviledges')
})

Then("Based on updated-removed group privileges modality access Data should be populated", () => {

    console.log(printTimestamp(), 'Based on updated-removed group privileges modality access Data populated')
})

When("User Select any other Knowledge name", () => {
    knowledgeDashboard.patternDashboardColumnFirstRecordClick()
    console.log(printTimestamp(), 'Selects any other Knowledge name') 
})

Then("Knowledge Details should be displayed in rightside screen", () => {
    knowledgeDashboard.knowledgeDetailsOnRightSideVisible()
    console.log(printTimestamp(), 'Knowledge Details displayed in rightside screen')
})

When("User Click on View button", () => {
    knowledgeDashboard.viewButtonClick()
    console.log(printTimestamp(), 'Clicked on View button')
})

Then("User should be navigate to knowledgedetails view page", () => {
    knowledgeDashboard.knowledgeDetailsPageVisibel()
    console.log(printTimestamp(), 'User navigated to knowledgedetails view page')
})

Then("Edit button should be displayed when user has author priviledge for respective content category", () => {

    console.log(printTimestamp(), 'Edit button displayed when user has author priviledge for respective content category')
})

And("Edit button should not be displayed for unauthorized user", () => {

    console.log(printTimestamp(), 'Edit button not displayed for unauthorized user')
})

And("Tooltip should be displayed when pattern is available in Draft state and user-modifier is different users", () => {

    console.log(printTimestamp(), 'Tooltip displayed when pattern is available in Draft state and user-modifier is different users')
})

When("User Navigate to my knowledge dashboard", () => {
    knowledgeDashboard.myKnowledgeClick()
    knowledgeDashboard.myKnowledgeDashboardClick()
    console.log(printTimestamp(), 'Navigated to my knowledge dashboard')
})

Then("Functionality mentioned for each steps should work as expected", () => {

    console.log(printTimestamp(), 'Functionality mentioned for each steps work as expected')
})

And("close the DAW application", () => {
    cy.log("Test case executed successfully");
    console.log(printTimestamp(), ' Test case executed successfully')
});
