/// <reference types="Cypress" />
/// <reference types='cypress-tags' />  
import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();
import ApplyMetadata from "../../../../support/pageObjects/pages/PatternAuthoring/applyMetadata";
const applyMetadata = new ApplyMetadata();
import IncludeKnowlegePage from "../../../../support/pageObjects/pages/PatternAuthoring/includeKnowledgepageObj";
const includeKnowlegePage = new IncludeKnowlegePage();
import PatternDashboard from "../../../../support/pageObjects/pages/Dashboard/PatternDashboard";
const patternDashboard = new PatternDashboard();
When("Navigate to Pattern Workflow", () => {
    cy.createPattern()
    createPattern.nextButtonClick()
    cy.wait(4000)
    cy.ApplyMetaDetaPageCompletionForPatternCreation()
    createPattern.nextButtonClick()
    cy.wait(4000)
    includeKnowlegePage.showAllCheckboxClick()
    cy.wait(2000)
    includeKnowlegePage.firstRecordClick()
    includeKnowlegePage.nextClick()
    cy.wait(2000)
    console.log(printTimestamp(), 'Navigate to Pattern Workflow')
});

When("Navigate to include knowledge page when pattern creation step is loading", () => {
	includeKnowlegePage.previousButtonClick()
    console.log(printTimestamp(), 'Navigate to include knowledge page when pattern creation step is loading')
});

Then("After navigating to dashboard-workflow-setting from user name user should be able to access functionalities", () => {
	includeKnowlegePage.loadingSymbolVisible()
    includeKnowlegePage.nextClick()
    cy.wait(2000)
    includeKnowlegePage.nextClick()
    cy.wait(2000)
    console.log(printTimestamp(), 'After navigating to dashboard-workflow-setting from user name user able to access functionalities')
});

When("Navigate to pattern Workflow", () => {
    createPattern.patternDashboardClick()
    console.log(printTimestamp(), 'Navigated to Pattern Workflow')
});

Then("Pop up should be displayed as below : WARNING Please wait ......... Press Cancel to wait until the"
+" workflow is saved to avoid losing changes in case of failure or OK to continue.cancel and ok button", () => {
	includeKnowlegePage.confirmationPopUpHeaderVisible()
    includeKnowlegePage.confirmationPopUpDialogVisible()
    includeKnowlegePage.cancelButtonVisible()
    includeKnowlegePage.okButtonOnPopUpVisible()
    console.log(printTimestamp(), "Pop up displayed as below : WARNING Please wait ......... Press Cancel to wait until the"
    +" workflow is saved to avoid losing changes in case of failure or OK to continue.cancel and ok button")
});

When("Click on cancel", () => {
	includeKnowlegePage.cancelButtonClick()
    cy.ExistingWorkFlowText()
    console.log(printTimestamp(), 'Clicked on cancel')
});

Then("User should not be navigate to other workflow and user should stay in same workflow where save is in progress", () => {
	includeKnowlegePage.validateHeadingActiveVerification()
    console.log(printTimestamp(), 'User not navigate to other workflow and user stay in same workflow where save is in progress')
});

When("Click on save as draft , try to navigate to other workflow-dashboard-setting from user name and click on Ok from pop up", () => {
	includeKnowlegePage.saveasDraftClick()
    createPattern.patternDashboardClick()
    includeKnowlegePage.popUpMessageVisible()
    includeKnowlegePage.okButtonOnPopUpClick()
    console.log(printTimestamp(), 'Clicked on save as draft , try to navigate to other workflow-dashboard-setting from user name and clicked on Ok from pop up')
});

Then("user should be navigate to other workflow-dashboard-setting from user name", () => {
	patternDashboard.dashboardButtonVisible();
    console.log(printTimestamp(), 'user navigated to other workflow-dashboard-setting from user name')
});

When("Edit same workflow data click on save as draft and tries to navigate to other workflow", () => {
	cy.ExistingWFClick()
    includeKnowlegePage.previousButtonClick()
    cy.wait(1000)
    includeKnowlegePage.previousButtonClick()
    cy.wait(1000)
    applyMetadata.modalityDropdownfield()
    applyMetadata.serviceContextRMEOptionClick()
    createPattern.patternDashboardClick()
    console.log(printTimestamp(), 'Edit same workflow data clicked on save as draft and tries to navigate to other workflow')
});

Then("then pop up should be displayed", () => {
	includeKnowlegePage.confirmationPopUpHeaderVisible()
    includeKnowlegePage.confirmationPopUpDialogVisible()
    includeKnowlegePage.cancelButtonClick()
    console.log(printTimestamp(), 'then pop up displayed')
});

