/// <reference types="Cypress" />
/// <reference types='cypress-tags' />  

import "../../../../support/index";
import { When, Then } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();
import PatternDashboard from "../../../../support/pageObjects/pages/Dashboard/PatternDashboard";
const patternDashboard = new PatternDashboard();

Then("Verifies publish pattern button at top right corner on pattern dashboard", () => {
    cy.visit('https://daw-automation.eu-west.philips-healthsuite.com/home/patterns/dashboard')
    patternDashboard.publishButtonVisibleAsDisabled()
    console.log(printTimestamp(), ' Verified publish pattern button at top right corner on pattern dashboard')
});

When("User Right clicks on pattern row with Valid Draft,Withdrawn data and verifies Publish button", () => {
    createPattern.withdrawnPatternStatusSelection()
    cy.wait(2000)
    patternDashboard.firstKnowledgeRightClick()
    console.log(printTimestamp(), ' Right clicked on pattern row with Valid Draft/Withdrawn data and verified Publish button')
});

Then("Publish button should be displayed in enabled state", () => {
    patternDashboard.publishButtonByRightClickVisibleAsEnabled()
    console.log(printTimestamp(), ' Publish button displayed in enabled state')
});

When("User Right clicks on pattern row with invalid Published,Draft data and verifies Publish button", () => {
    createPattern.publishedPatternStatusSelection()
    cy.wait(2000)
    patternDashboard.secondKnowledgeRightClick()
    console.log(printTimestamp(), ' Right clicked on pattern row with invalid Published/Draft data and verified Publish button')
});

Then("Publish button should be displayed in disabled state", () => {
    patternDashboard.publishButtonByRightClickVisibleAsDisabled()
    console.log(printTimestamp(), ' Publish button displayed in disabled state')
});

When("User Clicks on three dot available at pattern level with Valid Draft,Withdrawn data and verifies Publish button", () => {
    createPattern.withdrawnPatternStatusSelection()
    cy.wait(2000)
    patternDashboard.threeDotsGridButtonClick()
    console.log(printTimestamp(), " Clicked on three dot available at pattern level with Valid Draft/Withdrawn data and verified Publish button")
});

When("User Clicks on three dot available at pattern level with invalid Published,Draft and verifies Publish button", () => {
    createPattern.publishedPatternStatusSelection()
    cy.wait(2000)
    patternDashboard.threeDotsGridButtonClick()
    console.log(printTimestamp(), ' Clicked on three dot available at pattern level with invalid Published/Draft and verified Publish button')
});

When("Click on pattern with Valid Draft,Withdrawn data and verifies Publish button", () => {
    createPattern.publishedPatternStatusSelection()
    cy.wait(2000)
    createPattern.firstPatternOpenClick()
    console.log(printTimestamp(), ' Clicked on pattern with Valid Draft/Withdrawn data and verified Publish button')
});

Then("Publish button should be displayed in enable state", () => {
    patternDashboard.publishButtonVisibleAsEnabled()
    console.log(printTimestamp(), ' Publish button displayed in enabled state')
});

Then("Relaunch the Application", () => {
    patternDashboard.backButtonClick()
    patternDashboard.clearAllFilterButtonClick()
    cy.wait(4000)
    console.log(printTimestamp(), ' Relaunched application')
});

When("User Right clicks on pattern row Valid Draft,Withdrawn with CT or CT,IGT modality and verifies Publish button", () => {
    createPattern.modalityColumnClickAndCTSelection()
    cy.wait(2000)
    patternDashboard.secondKnowledgeRightClick()
    console.log(printTimestamp(), ' Right clicked on pattern row Valid Draft/Withdrawn with CT or CT,IGT modality and verified Publish button')
});

Then("Publish button should be displayed in disabled state as user has CT View access", () => {
    patternDashboard.publishButtonByRightClickVisibleAsDisabled()
    console.log(printTimestamp(), ' Publish button displayed in disabled state as user has CT View access')
});

Then("Publish button should be displayed in disable state as user has CT View access", () => {
    patternDashboard.publishButtonByRightClickVisibleAsDisable()
    console.log(printTimestamp(), ' Publish button displayed in disabled state as user has CT View access')
});

When("User Clicks on three dot available at pattern with CT or CT,IGT modality with Valid Draft,Withdrawn and verifies Publish button", () => {
    patternDashboard.threeDotsGridButtonClick()
    console.log(printTimestamp(), ' Clicked on three dot available at pattern with CT or CT,IGT modality with Valid Draft/Withdrawn and verified Publish button')
});

When("User Clicks on pattern with Valid Draft,Withdrawn with CT or CT,IGT modality and verifies Publish button", () => {
    createPattern.firstPatternClick()
    console.log(printTimestamp(), ' Clicked on pattern with Valid Draft/Withdrawn with CT or CT,IGT modality and verified Publish button')
});

When("User Right clicks on pattern row with Valid Draft,Withdrawn with only IGT modality and verifies Publish button", () => {
    patternDashboard.backButtonClick()
    createPattern.modalityColumnClickAndIGTSelection()
    cy.wait(2000)
    patternDashboard.secondKnowledgeRightClick()
    console.log(printTimestamp(), " Right clicked on pattern row with Valid Draft/Withdrawn with only IGT modality and verified Publish button")
});

Then("Publish button should be displayed in enabled state as user has IGT publish access", () => {
    patternDashboard.publishButtonByRightClickVisibleAsEnabled()
    console.log(printTimestamp(), ' Publish button displayed in enabled state as user has IGT publish access')
});

When("User Clicks on three dot available at pattern with only IGT modality with Valid Draft,Withdrawn and verifies Publish button", () => {
    patternDashboard.threeDotsGridButtonClick()
    console.log(printTimestamp(), ' Clicked on three dot available at pattern with only IGT modality with Valid Draft/Withdrawn and verified Publish button')
});

Then("Publish button should be displayed in enable state as user has IGT publish access", () => {
    patternDashboard.publishButtonVisibleAsEnabled()
    console.log(printTimestamp(), ' Publish button displayed in enabled state as user has IGT publish access')
});

When("User Clicks on pattern with Valid Draft,Withdrawn with only IGT modality and verifies Publish button", () => {
    createPattern.firstPatternOpenClick()
    console.log(printTimestamp(), ' Clicked on pattern with Valid Draft/Withdrawn with only IGT modality and verified Publish button')
});