/// <reference types="Cypress" />
/// <reference types = 'cypress-tags' />

import "../../../../support/index"
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import PatternDashboard from "../../../../support/pageObjects/pages/Dashboard/PatternDashboard";
const patternDashboard = new PatternDashboard();
import CreateKnowledge from "../../../../support/pageObjects/pages/KnowledgeAuthoring/CreateKnowledge";
const createKnowledge = new CreateKnowledge();
var commonData = {};

Then("By default, Pattern Dashboard page should be displayed", () => {
    patternDashboard.patternDashboardTitleVisible()
    cy.wait(2000)
    console.log(printTimestamp(), 'Pattern Dashboard page displayed')
});


And("User create new Authoring  Workflow", () => {
    createKnowledge.knowledgeClick()
    // createKnowledge.MyknowledgeArrowClick()
    createKnowledge.AddAuthoringWokFlowButtonClick()
    cy.wait(3000)
    createKnowledge.workFlowMessageVisible()
    console.log(printTimestamp(), 'New Authoring Workflow Created')
});

When("User Expand Cause and Solution section", () => {
    createKnowledge.causeAndSolutionSectionClick()
    console.log(printTimestamp(), 'Expanded Cause and Solution section')
});

Then("Select Cause,Add Cause are available", () => {
    createKnowledge.selectCauseVisible()
    createKnowledge.addCauseVisible()
    console.log(printTimestamp(), 'Select Cause,Add Cause are available')
});

When("User Click on Add Cause button", () => {
    createKnowledge.addCauseClick()
    console.log(printTimestamp(), 'Clicked on Add Cause button')
});

Then("Rich text Editor window should appear under Cause", () => {
    createKnowledge.richTextEditorWindowVisible()
    console.log(printTimestamp(), 'Rich text Editor window displayed')
});

And("Font Family drop down, Paragraph Format drop down,Bold,Italic,Underline,More Text, Align Left,Align Center options are available", () => {
    createKnowledge.fontFamilyDropDownVisible()
    createKnowledge.paragraphFormatDropDownVisible()
    createKnowledge.boldVisible()
    createKnowledge.italicVisible()
    createKnowledge.underlineVisible()
    createKnowledge.moreTextVisible()
    createKnowledge.alignLeftVisible()
    createKnowledge.alignCenterVisible()
    console.log(printTimestamp(), 'Font Family drop down, Paragraph Format drop down,Bold,Italic,Underline,More Text, Align Left,Align Center options are available')
});

And("Align Justify,Align Right,More Paragraph,Insert Link,Insert Image,Upload file,Insert Table,Insert Horizontal Line, options are available", () => {
    createKnowledge.alignJustifyVisible()
    createKnowledge.alignRightVisible()
    createKnowledge.moreParagraphVisible()
    createKnowledge.insertLinkVisible()
    createKnowledge.insertImageVisible()
    createKnowledge.insertFileVisible()
    createKnowledge.insertTableVisible()
    createKnowledge.insertHorizontalLineVisible()
    console.log(printTimestamp(), 'Align Justify,Align Right,More Paragraph,Insert Link,Insert Image,Upload file,Insert Table,Insert Horizontal Line, options are available')
});

And("for cause 1 Full Screen, Undo,Redo,More Misc,Inline with cause name,Tick,Close options are available", () => {
    createKnowledge.moreMiscVisible()
    createKnowledge.moreMiscClick()
    createKnowledge.undoVisible()
    createKnowledge.redoVisible()
    createKnowledge.tickVisible()
    createKnowledge.closeVisible()
    console.log(printTimestamp(), 'Full Screen, Undo,Redo,More Misc,Inline with cause name,Tick,Close options are available')
})

And("for Solution 1 Full Screen,Close,Undo and in More Misc Redo,Priority drop down- applicable for solution option should be displayed", () => {
    createKnowledge.cause1TextFillBox()
    createKnowledge.addSolutionClick()
    createKnowledge.moreMiscUnderSolution1Visible()
    createKnowledge.moreMiscUnderSolution1Click()
    createKnowledge.undoUnderSolution1Visible()
    createKnowledge.redoUnderSolution1Visible()
    createKnowledge.closeUnderSolution1Visible()
    createKnowledge.priorityDropDownVisible()
    console.log(printTimestamp(), 'for Solution 1 Full Screen,Close,Undo and in More Misc Redo,Priority drop down- applicable for solution options displayed')
});

When("Click on Font Family", () => {
    createKnowledge.fontFamilyDropDownClick()
    console.log(printTimestamp(), 'Clicked Font Family')
});

Then("Dropdown options Arial,Georgia,impact,Tahoma,Times New Roman,Verdana should be available", () => {
    createKnowledge.arialVisible()
    createKnowledge.GeorgiaVisible()
    createKnowledge.impactVisible()
    createKnowledge.tahomaVisible()
    createKnowledge.timesNewRomanVisible()
    createKnowledge.VerdanaVisible()
    console.log(printTimestamp(), 'Dropdown options Arial,Georgia,impact,Tahoma,Times New Roman,Verdana available')
});

When("User Click on Paragraph Format", () => {
    createKnowledge.paragraphFormatClick()
    console.log(printTimestamp(), 'Clicked on Paragraph Format')
});

Then("Heading 1, Heading 2,Heading 3,Heading 4 and Code drop down values should appeared", () => {
    createKnowledge.heading1Visible()
    createKnowledge.heading2Visible()
    createKnowledge.heading3Visible()
    createKnowledge.heading4Visible()
    createKnowledge.codeVisible()
    console.log(printTimestamp(), 'Heading 1, Heading 2,Heading 3,Heading 4 and Code drop down values are appeared')
});

When("User Click on More text", () => {
    createKnowledge.moreTextClick()
    console.log(printTimestamp(), 'Clicked on More text')
});

Then("options Strikethrough,Subscript,Superscript,Font size on clicking it size appears in the range 8-96,Text color should appear", () => {
    createKnowledge.StrikethroughVisible()
    createKnowledge.subScriptVisible()
    createKnowledge.superScriptVisible()
    createKnowledge.fontSizeVisible()
    createKnowledge.textColorVisible()
    createKnowledge.fontSizeDropDown()
    console.log(printTimestamp(), 'options Strikethrough,Subscript,Superscript,Font size on clicking it size appears in the range 8-96,Text color are displayed')
});

And("Background color,Inline Class with drop down values Code, Highlighted and Transparent,Inline Style with Big Red and Small Blue options,Clear formatting should appear", () => {
    createKnowledge.backgroundColorVisible()
    createKnowledge.inlineClassVisible()
    createKnowledge.inlineClassClick()
    createKnowledge.codeVisible()
    createKnowledge.HighlightedVisible()
    createKnowledge.TransparentVisible()
    createKnowledge.inlineStyleVisible()
    createKnowledge.inlineStyleClick()
    createKnowledge.bigRedVisible()
    createKnowledge.smallBlueVisible()
    createKnowledge.clearFormattingVisible()
    console.log(printTimestamp(), 'Background color,Inline Class with drop down values Code'
        + 'Highlighted and Transparent,Inline Style with Big Red and Small Blue options,Clear formatting appear')
})

When("User Click on More Paragraph", () => {
    createKnowledge.moreParagraphClick()
    console.log(printTimestamp(), 'Clicked on More Paragraph')
});

Then("options Ordered List with drop down values,Unordered List " +
    "with drop down values,Paragraph Style with drop down values,Line height with drop down values should appear", () => {
        createKnowledge.oplListWithDropDownVisible()
        createKnowledge.ulListWithDropDownVisible()
        createKnowledge.paragraphStyleVisible()
        createKnowledge.lineHeightVisible()
        createKnowledge.lineHeightClick()
        createKnowledge.lineHeightValueDefaultVisible()
        createKnowledge.lineHeightValueSingleVisible()
        createKnowledge.lineHeightValue3rdVisible()
        createKnowledge.lineHeightValue4thVisible()
        createKnowledge.lineHeightValueDoubleVisible()
        console.log(printTimestamp(), "options Ordered List with drop down values,Unordered List with drop down values,"
            + "Paragraph Style with drop down values,Line height with drop down values appear")

    });

And("Decrease Indent Disabled as text has not applied increase indent,Increase Indent,Quote with drop down values should appear", () => {
    createKnowledge.decreaseIndentVisible()
    createKnowledge.increaseIndentVisible()
    createKnowledge.quoteVisible()
    createKnowledge.quoteClick()
    createKnowledge.increaseOptionUnderQuotes()
    createKnowledge.decreaseOptionUnderQuotes()
    console.log(printTimestamp(), ' Decrease Indent Disabled as text has not applied increase indent,Increase Indent,Quote with drop down values appear')

})

And("drop down values Order list with drop down values Default,"
    + "Lower Alpha,Lower Greek,Lower Roman,Upper Alpha,Upper Roman,Unorder list with drop down "
    + "values Default,Circle,Disc,Square should appear", () => {
        createKnowledge.oplListWithDropDownVisible()
        createKnowledge.oplListWithDropDownButtonClick()
        createKnowledge.defaultOptionVisible()
        createKnowledge.lowerAlphaVisible()
        createKnowledge.lowerRomanVisible()
        createKnowledge.upperAlphaVisible()
        createKnowledge.upperRomanVisible()
        createKnowledge.unorderListDropDownButtonClick()
        createKnowledge.unorderListCircleOptionVisible()
        createKnowledge.unorderListDiscOptionVisible()
        createKnowledge.unorderListSquareOptionVisible()
        console.log(printTimestamp(), 'drop down values Order list with drop down values Default,'
            + 'Lower Alpha,Lower Greek,Lower Roman,Upper Alpha,Upper Roman,Unorder list with drop '
            + 'down values Default,Circle,Disc,Square appear')
    });

And("Paragraph Style with drop down values Bordered,Spaced,UpperCase ,Line Height with "
    + "drop down values Default,Single,1.15,1.5,Double,  Quotes with drop down values Increase"
    + " Ctrl+ , Decrease Ctrl+Shift+ should appear", () => {
        createKnowledge.photoGraphStyleVisible()
        createKnowledge.photoGraphStyleClick()
        createKnowledge.grayVisible()
        createKnowledge.borderedVisible()
        createKnowledge.SpacedVisible()
        createKnowledge.upperCaseVisible()
        console.log(printTimestamp(), 'Paragraph Style with drop down values Bordered,Spaced,UpperCase ,'
            + 'Line Height with drop down values Default,Single,1.15,1.5,Double,  '
            + 'Quotes with drop down values Increase Ctrl+ , Decrease Ctrl+Shift+" appear')
    })

And("close the Application", () => {
    cy.DeleteWorkflow()
    cy.log("Test Case Executed Successfully")
    console.log(printTimestamp(), ' Test Case Executed Successfully')
});





























