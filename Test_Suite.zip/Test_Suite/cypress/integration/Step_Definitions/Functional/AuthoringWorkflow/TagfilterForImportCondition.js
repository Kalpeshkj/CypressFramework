/// <reference types="Cypress" />
/// <reference types='cypress-tags' />

import "../../../../support/index";
import { When, Then } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import PatternDashboard from "../../../../support/pageObjects/pages/Dashboard/PatternDashboard";
const patternDashboard = new PatternDashboard();
import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();


When("User Navigate to existing or created new wf and click on add condition from rule pattern", () => {
    createPattern.myPatternThreeDotsClick()
    createPattern.createPatternButtonClick()
    createPattern.addConditionTabClick()
    createPattern.addConditionPulsIconClick()
    createPattern.fromrulePatternClick()
    console.log(printTimestamp(), ' Created new Wf')
});

Then("Verifies order of filter values in drop down", () => {
    patternDashboard.tagColumnClick()
    patternDashboard.tagColumnValuesSortedDataVerification()
    console.log(printTimestamp(), ' Verified order of filter value in drop down')
});

When("User Clicks on any tag value and verifies filtered pattern details", () => {
    patternDashboard.tagColumnFirstValueClick()
    createPattern.tagsColumnFirstValueSelectedVerification()
    console.log(printTimestamp(), ' Clicked on any tag value and verified filtered pattern details')
});

When("User Clicks on drop down of tags and enter tag value in filter text box", () => {
    patternDashboard.tagColumnClick()
    patternDashboard.tagColumnSearchBoxType()
    console.log(printTimestamp(), ' Clicked on drop down of tags and enter tag value')
});

Then("Matched tags values should get displayed", () => {
    patternDashboard.tagColumnSearchValueVisible()
    console.log(printTimestamp(), ' Matched tag values displayed')
});

Then("Filter option popup for tags should get closed", () => {
    patternDashboard.TagsColumnPopUpNotVisible()
    console.log(printTimestamp(), ' Filter option pop for tags should got closed')
});

When("User Clicks on dropdown and verify entered value text", () => {
    patternDashboard.tagColumnClick()
    patternDashboard.tagColumnSelectedValueVisible()
    console.log(printTimestamp(), ' Clicked on dropdown and verified entered value')
});

Then("Select multiple tags value and verify pattern data", () => {
    patternDashboard.multipleTagsSelectionFromDropdown()
    createPattern.tagsColumnMultipleValueSelectedVerification()
    console.log(printTimestamp(), ' Selected multiple tag values and verified pattern data')
});

When("User Click on drop down of Tags and verify UI for filter options drop down", () => {
    patternDashboard.tagColumnClick()
    patternDashboard.tagColumnClick()
    console.log(printTimestamp(), " Clicked on drop down of Tags and verify UI")
});

When("User Clicks on drop down of tags and select all tags", () => {
    patternDashboard.tagColumnClick()
    patternDashboard.tagColumnAllValueSelectionClick()
    console.log(printTimestamp(), ' Clicked on drop down of tags and select all tags')
});

Then("All Associated patterns should be displayed", () => {
    createPattern.selectedTagsVisible()
    console.log(printTimestamp(), ' All associated patterns displayed')
});

When("User Unselect few tags and verify data", () => {
    patternDashboard.tagColumnClick()
    patternDashboard.multipleTagsSelectionFromDropdown()
    console.log(printTimestamp(), ' Unselect few tag values and verified data')
});

Then("For unselected tags associated pattern should not displayed", () => {
    createPattern.tagsColumnFirstValueSelectedNotVisible()
    console.log(printTimestamp(), ' For unselected tags associated pattern should not displayed')
});

Then("Search any keyword or clicks on show all check box", () => {
    createPattern.ShowCheckboxClick()
    console.log(printTimestamp(), ' Clicked on show all check box')
});

Then("Apply filter on columns and search data on top of filter data", () => {
    createPattern.dataModelsColumnClickAndValueSelection()
    createPattern.searchByKeywordType()
    createPattern.datamodelsColumnValueNotFilteredVerification()
    console.log(printTimestamp(), ' Filter multiple columns')
});

And("Search by keyword and on top of that apply filter for columns", () => {
    createPattern.ShowCheckboxClick()
    createPattern.searchByKeywordType()
    createPattern.datamodelsColumnValueNotFilteredVerification()
    console.log(printTimestamp(), " Clicked on drop down of Tags and verify UI")
});