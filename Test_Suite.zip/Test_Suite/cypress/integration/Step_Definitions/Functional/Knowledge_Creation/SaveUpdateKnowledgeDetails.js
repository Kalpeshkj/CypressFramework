/// <reference types="Cypress" />
/// <reference types='cypress-tags' />

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import KnowledgeDashboard from "../../../../support/pageObjects/pages/Knowledge_Dashboard/KnowledgeDashboard";
const knowledgeDashboard = new KnowledgeDashboard();
import CreateKnowledge from "../../../../support/pageObjects/pages/KnowledgeAuthoring/CreateKnowledge";
const createKnowledge = new CreateKnowledge();
const filePath = 'cypress/fixtures/patternNameCreation.json'
var arr = []

When("User expands knowledge and clicks on add knowledge", () => {
    knowledgeDashboard.knowledgeClick()
    knowledgeDashboard.addKnowledgeClick()
    console.log(printTimestamp(), ' Knowledge expanded and add knowledge clicked')
});

Then("User should be navigated to new workflow", () => {
    knowledgeDashboard.knowledgeStepsVisible()
    console.log(printTimestamp(), ' Navigated to new workflow')
});

And("Verifies mandatory sections in Create Knowledge step", () => {
    createKnowledge.mandatorySectionVisible()
    console.log(printTimestamp(), ' Verified mandatory sections')
});

And("Verifies buttons available at right side corner as close enabled and save as draft disabled", () => {
    knowledgeDashboard.closeButtonVisibleAsEnabled()
    createKnowledge.saveButtonVisibleAsDisbled()
    console.log(printTimestamp(), ' Buttons Verified')
});

When("User Enters existing knowledge name and verifies Save as Draft", () => {
    createKnowledge.breadcumbCaptureValue()
    cy.readFile(filePath).then(function (result) {
        var PatternName = result.name;
        createKnowledge.knowledgeNameType().type(PatternName);
    });
    console.log(printTimestamp(), ' Verified Save as Draft button as disabled')
});

Then("Save as Draft button should not get enabled as knowledge name validation is failed", () => {
    createKnowledge.saveButtonVisibleAsDisbled()
    console.log(printTimestamp(), ' Save as Draft button verified as disabled')
});

When("User Enters unique knowledge name and verify Save as Draft", () => {
    cy.PatternCreation()
    cy.wait(2000)
    createKnowledge.knowledgeNameType().clear();
    cy.readFile(filePath).then(function (result) {
        var PatternName = result.name;
        createKnowledge.knowledgeNameType().type(PatternName);
        cy.wait(2000)
    });
    console.log(printTimestamp(), ' User Enters unique knowledge name and verified Save as Draft button')
});

Then("Save as Draft button should get enabled as knowledge name validation is successfull", () => {
    createKnowledge.saveButtonVisibleAsEnabled()
    console.log(printTimestamp(), ' Save as Draft button verified as enabled')
});

When("User navigates under cause and solution section and clicks upload file option", () => {
    createKnowledge.causesAndSolutionSectionInKnowledgeClick()
    console.log(printTimestamp(), ' User navigated under cause and solution section and clicked on upload file option')
});

Then("User should be able to upload image or pdf file by drag and drop option", () => {
    knowledgeDashboard.browseFileIconClick().attachFile('SampleFile.pdf')
    console.log(printTimestamp(), ' pdf file uploaded')
});

And("Verifies uploaded image or file in Cause and solution section", () => {
    knowledgeDashboard.uploadedImageVerification()
    console.log(printTimestamp(), ' uploaded image or file verified')
});

And("User should be able to add cause and solution tags and solution parts data", () => {
    createKnowledge.addSolutionButtonClick()
    createKnowledge.solutionTextType()
    createKnowledge.partsAddition()
    createKnowledge.tagsAddition()
    console.log(printTimestamp(), ' cause and solution tags and solution parts data added')
});

When("User clicks on Select Cause and imports existing causes", () => {
    createKnowledge.causeButtonClick()
    createKnowledge.importExistingCauses()
    createKnowledge.cancelButtonClick()
    console.log(printTimestamp(), ' Select Cause clicked and imported existing causes')
});

And("User adds all mandatory details in knowledge", () => {
    createKnowledge.additionOfMandatoryDetails()
    console.log(printTimestamp(), ' All mandatory details added')
});

When("User clicks on save as draft button at the bottom corner of the page", () => {
    cy.wait(5000)
    createKnowledge.saveAsDraftClick()
    console.log(printTimestamp(), ' Save as draft btton clicked from the bottom corner')
});

Then("All saved detail should be displayed", () => {
    createKnowledge.savedDetailsVerificationInKnowledge()
    console.log(printTimestamp(), ' All saved details displayed')
});

And("User verifies Next button should be in enabled state when all details are added", () => {
    createKnowledge.nextButtonDisabledInKnowledge()
    console.log(printTimestamp(), ' Next button Enabled')
});