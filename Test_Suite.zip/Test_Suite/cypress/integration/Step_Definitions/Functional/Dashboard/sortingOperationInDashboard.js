/// <reference types="Cypress" />
/// <reference types='cypress-tags' />

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import KnowledgeDashboard from "../../../../support/pageObjects/pages/Knowledge_Dashboard/KnowledgeDashboard";
import PatternDashboard from "../../../../support/pageObjects/pages/Dashboard/PatternDashboard";
const patternDashboard = new PatternDashboard();
const knowledgeDashboard = new KnowledgeDashboard();

When("By default pattern dashboard page is displayed", () => {
    patternDashboard.dashboardButtonVisible();
    console.log(printTimestamp(), ' Pattern dashboard page displayed')
});

Then("User Removes by default filter available for Modality", () => {
    patternDashboard.modalityColumnClick();
    patternDashboard.clearButtonClick();
    console.log(printTimestamp(), ' Removed by default filter available for Modality')
});

And('Verifies by default sorting available for "Modified On" column', () => {
    patternDashboard.byDefaultModifiedOnColumnSortedVerification();
    console.log(printTimestamp(), ' Verified by default sorting available for "Modified On" column')
});

And("By default DESC sorting should be available", () => {
    patternDashboard.modifiedOnColumnSortedVerification();
    console.log(printTimestamp(), ' By default DESC sorting available')
});

When("Verifies sorting icon on Modified On column", () => {
    patternDashboard.modifiedOnColumnSortedIconVerificationDESC();
    console.log(printTimestamp(), ' Verified sorting icon on Modified On column')
});

Then("For DESC sorting , downward facing triangle should be available", () => {
    patternDashboard.modifiedOnColumnDESCSortedVerification();
    console.log(printTimestamp(), ' For DESC sorting , downward facing triangle displayed')
});

When('User Clicks on "Modified On" column', () => {
    knowledgeDashboard.modifiedOnColumnClick();
    console.log(printTimestamp(), ' modified on column clicked')
});

Then("Data should be displayed in ASC order", () => {
    patternDashboard.sortedDataVerification();
    console.log(printTimestamp(), ' Data displayed in ASC order')
});

When("Verifies sorting icon in Modified On column", () => {
    patternDashboard.modifiedOnColumnSortedIconVerificationForASC();
    console.log(printTimestamp(), ' Verified sorting icon on Modified On column')
});

Then("For ASC sorting , upward facing triangle should be available", () => {
    patternDashboard.modifiedOnColumnASCSortedVerification();
    console.log(printTimestamp(), ' For ASC sorting , upward facing triangle displayed')
});

And("Performs sorting operation on all the columns present by default", () => {
    patternDashboard.patternNameColumnClickAndSortingOfDataVerification();
    patternDashboard.patternStateColumnClickAndSortingOfDataVerification();
    patternDashboard.versionColumnClickAndSortingOfDataVerification();
    patternDashboard.modifiedbyColumnClickAndSortingOfDataVerification();
    patternDashboard.modifiedonColumnClickAndSortingOfDataVerification();
    patternDashboard.modalityColumnClickkAndSortingOfDataVerification();
    patternDashboard.patterntypeColumnClickAndSortingOfDataVerification();
    patternDashboard.serciceconextColumnClickAndSortingOfDataVerification();
    patternDashboard.severityColumnClickAndSortingOfDataVerification();
    console.log(printTimestamp(), ' sorting operation performed on all columns')
});

When("User Adds additional column and repeat the above steps", () => {
    patternDashboard.patternDropdownClick();
    patternDashboard.selectDropdownValues();
    patternDashboard.patternNameColumnClickAndSortingOfDataVerification();
    patternDashboard.patternStateColumnClickAndSortingOfDataVerification();
    patternDashboard.versionColumnClickAndSortingOfDataVerification();
    patternDashboard.modifiedbyColumnClickAndSortingOfDataVerification();
    patternDashboard.modifiedonColumnClickAndSortingOfDataVerification();
    patternDashboard.modalityColumnClickkAndSortingOfDataVerification();
    patternDashboard.patterntypeColumnClickAndSortingOfDataVerification();
    patternDashboard.serciceconextColumnClickAndSortingOfDataVerification();
    patternDashboard.severityColumnClickAndSortingOfDataVerification();
    patternDashboard.reviewdByColumnClick();
    patternDashboard.publishedByColumnClick();
    patternDashboard.publishedOnColumnClick();
    patternDashboard.createdByColumnClick();
    patternDashboard.createdOnColumnClick();
    patternDashboard.tagsColumnClick();
    console.log(printTimestamp(), ' Additional columns added and sorting operation performed')

});

Then("Repeat all the above steps for my pattern Dashboard", () => {
    patternDashboard.myPatternClick();
    patternDashboard.myPatternDashboardButtonClick();
    patternDashboard.byDefaultModifiedOnColumnSortedVerification();
    patternDashboard.modifiedOnColumnSortedVerification();
    patternDashboard.modifiedOnColumnSortedIconVerificationDESC();
    patternDashboard.modifiedOnColumnDESCSortedVerification();
    knowledgeDashboard.modifiedOnColumnClick();
    patternDashboard.sortedDataVerification();
    patternDashboard.modifiedOnColumnSortedIconVerificationForASC();
    patternDashboard.modifiedOnColumnASCSortedVerification();
    patternDashboard.patternNameColumnClickAndSortingOfDataVerification();
    patternDashboard.patternStateColumnClickAndSortingOfDataVerification();
    patternDashboard.versionColumnClickAndSortingOfDataVerification();
    patternDashboard.modifiedbyColumnClickAndSortingOfDataVerification();
    patternDashboard.modifiedonColumnClickAndSortingOfDataVerification();
    patternDashboard.modalityColumnClickkAndSortingOfDataVerification();
    patternDashboard.patterntypeColumnClickAndSortingOfDataVerification();
    patternDashboard.serciceconextColumnClickAndSortingOfDataVerification();
    patternDashboard.severityColumnClickAndSortingOfDataVerification();
    patternDashboard.patternDropdownClick();
    patternDashboard.selectDropdownValues();
    patternDashboard.reviewdByColumnClick();
    patternDashboard.publishedByColumnClick();
    patternDashboard.publishedOnColumnClick();
    patternDashboard.createdByColumnClick();
    patternDashboard.createdOnColumnClick();
    patternDashboard.tagsColumnClick();
    console.log(printTimestamp(), ' All steps repeated in my pattern dashboard')
});

Then("Close the Application", () => {
    cy.log("Test case executed successfully");
    console.log(printTimestamp(), ' Test case executed successfully')

});
