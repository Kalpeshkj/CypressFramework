/// <reference types="Cypress" />
/// <reference types = 'cypress-tags' />

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';

import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();

Then("Verifies UI for workflow", () => {
    createPattern.workflowStepsListVisible()
    createPattern.createPatternHeadingActiveVerification()
    console.log(printTimestamp(), ' Verified UI for workflow')
})

Then("Fills all the mandatory field and click on next", () => {
    createPattern.createPatternPageInformationSubmission()
    createPattern.nextButtonClick()
    console.log(printTimestamp(), ' Filled all the mandatory field and clicked on next')
})

And("Verifies UI for workflow step When user is on Apply Metadata page", () => {
    createPattern.applyMetadataHeadingActiveVerification()
    console.log(printTimestamp(), ' Verified UI for workflow step When user is on Apply Metadata page')
})

And("Verifies UI for workflow step of Create Page when user is on Apply Metadata page", () => {
    createPattern.createPatternHeadingCompletedVerification()
    console.log(printTimestamp(), ' Verified UI for workflow step of Create Page when user is on Apply Metadata page')
})

Then("Verifies UI for other workflow steps 3,4 and 5", () => {
    createPattern.includeKnowledgeHeadingPendingVerification()
    createPattern.validateHeadingPendingVerification()
    createPattern.requestReviewHeadingPendingVerification()
    console.log(printTimestamp(), ' Verified UI for other workflow steps (3,4,5)')
})

When("User Navigates to Create Page by clicking on right symbol available at workflow step", () => {
    createPattern.createPatternHeadingClick()
    console.log(printTimestamp(), ' Navigated to Create Page by clicking on right symbol available at workflow step')
})

Then("Verifies UI of workflow steps after landing on create pattern section", () => {
    createPattern.applyMetadataHeadingInProgressVerification()
    console.log(printTimestamp(), ' Verified UI of workflow steps after landing on create pattern section')
})

And("Removes any mandatory field data from create pattern", () => {
    createPattern.removeActionForceClick()
    console.log(printTimestamp(), ' Removed mandatory field data from create pattern')
})

Then("Clicks on next workflow e.g apply metadata and verify tooltip", () => {
    createPattern.nextButtonClick()
    createPattern.nextButtonVisibleAsDisabled()
    console.log(printTimestamp(), ' Clicked on next workflow and verified tooltip')
})       

When("User Fills all mandatory field data and click on workflow step of Apply metadata", () => {
    createPattern.addAction()
    createPattern.nextButtonClick()
    console.log(printTimestamp(), ' Filled all mandatory field data and clicked on workflow step of Apply metadata')
})

Then("Repeat above steps for each workflow step and verify functionality of clickable workflow steps", () => {
    cy.ApplyMetaDetaPageCompletion()
    createPattern.nextButtonClick()
    createPattern.applyMetadataHeadingCompletedVerification()
    createPattern.includeKnowledgeHeadingActiveVerification()
    cy.DeleteWorkflow()
    console.log(printTimestamp(), ' Repeated above steps for each workflow step and verified functionality of clickable workflow steps')
})  

And("Clones pattern from pattern dashboard which has apply metadata related date and verify workflow step", () => {  
    cy.wait(3000)
    createPattern.threeDotsGridButtonClickAndClone()
    createPattern.createPatternHeadingActiveVerification()
    createPattern.applyMetadataHeadingInprogressVerification()
    console.log(printTimestamp(), ' Cloned pattern from pattern dashboard which has apply metadata related date and verified workflow step')
})