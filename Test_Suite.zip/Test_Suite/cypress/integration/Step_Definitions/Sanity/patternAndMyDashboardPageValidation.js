/// <reference types="Cypress" />
/// <reference types='cypress-tags' />

import "../../../support/index";
import { When, Then} from "cypress-cucumber-preprocessor/steps";
import {printTimestamp} from '../../../support/commands';

import PatternDashboard from "../../../support/pageObjects/pages/Dashboard/PatternDashboard";
const patternDashboard = new PatternDashboard();

Then("Click on My Pattern Dashboard", () => {
  patternDashboard.myPatternClick();
  patternDashboard.myPatternDashboardButtonVisible();
  patternDashboard.myPatternDashboardButtonClick();
  console.log(printTimestamp() ,' Clicked on My Pattern Dashboard')
});

Then("Validate breadcrumbs", () => {
  patternDashboard.breadcrumbVisible();
  console.log(printTimestamp() ,' breadcrumbs Validated')
});

Then(
  "Pattern Dashboard should contain patterns title, Delete Withdraw button",
  () => {
    patternDashboard.patternTitleVisible();
    patternDashboard.deletePatternButtonVisible();
    patternDashboard.withdrawPatternButtonVisible();
    console.log(printTimestamp() ,' Verified Pattern Dashboard with patterns title, Delete Withdraw button')

  }
);

When("User clicks on pattern Name", () => {
  patternDashboard.firstPatternClick();
  console.log(printTimestamp() ,' clicked on pattern Name')
});

Then("Pattern details should be displayed in page", () => {
  patternDashboard.patternDiscriptionVisible();
  patternDashboard.patternGuidVisible();
  patternDashboard.closeButtonClick();
  console.log(printTimestamp() ,' Verified Pattern details')

}); 

When("User selects all columns in the select options", () => {
  patternDashboard.patternDropdownVisible();
  patternDashboard.patternDropdownClick();
  patternDashboard.selectdropdownValues();
  patternDashboard.patternDropdownWithAdditionOfColumnVisible();
  console.log(printTimestamp(), ' Selected all the columns from the select options')

});

Then("Close Application", () => {
  cy.log("Test case executed successfully");
  console.log(printTimestamp() ,' Test case executed successfully')

});
