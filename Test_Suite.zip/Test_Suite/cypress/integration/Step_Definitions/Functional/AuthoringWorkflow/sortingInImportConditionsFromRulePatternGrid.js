/// <reference types="Cypress" />
/// <reference types='cypress-tags' />

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();

When("User creates new workflow", () => {
    createPattern.myPatternThreeDotsClick();
    createPattern.createPatternClick()
    cy.wait(2000)
    console.log(printTimestamp(), ' New WF created')
});

Then("Clicks on Add Condition and Click on From Rule Pattern option", () => {
    createPattern.addConditionTabClick();
    createPattern.addConditionPlusIconClick();
    createPattern.fromrulePatternClick();
    console.log(printTimestamp(), ' Clicked on Add Condition and Clicked on From Rule Pattern option')
});

And('Selects Show All checkbox', () => {
    createPattern.showAllCheckboxClick();
    console.log(printTimestamp(), ' Show All checkbox selected')
});

Then("Verifies default order of pattern data that should be in ASC of pattern name", () => {
    createPattern.patternNameInAddConditionAscSortedVerification();
    console.log(printTimestamp(), ' Verified default order of pattern data in ASC')
});

Then("Verifies sort icon available for Pattern Name column", () => {
    createPattern.patternNameIconInAddConditionAscVerification();
    console.log(printTimestamp(), ' Verified sort icon available for Pattern Name column')
});

When("User Clicks on Pattern name column", () => {
    createPattern.nameColumnClick();
    console.log(printTimestamp(), ' Clicked on Pattern name column')
});

Then('Verifies sorting order of data', () => {
    createPattern.patternNameIconInAddConditionDescVerification();
    createPattern.PatternNameColumnClickAndSortingOfDataVerification();
    console.log(printTimestamp(), ' Verified sorting order of data')
});

And("Verifies sorting icons for other columns", () => {
    createPattern.descriptionIconInAddConditionIconVerification();
    console.log(printTimestamp(), ' Verified sorting icons for other columns')
});

When("User clicks on other columns and verifies sorting order", () => {
    createPattern.descriptionColumnClickAndSortingOfDataVerification();
    console.log(printTimestamp(), ' clicked on other columns and verified sorting order')
});

Then("Clicks on cancel button", () => {
    createPattern.cancelButtonClick();
    console.log(printTimestamp(), ' Clicked on cancel button')
});

And("Verifies Import condition section should get closed", () => {
    createPattern.importConditionHeadingNotVisible();
    console.log(printTimestamp(), ' Import condition section got closed')
});

When("User again Click on Add Condition and Click on From Rule Pattern section", () => {
    createPattern.addConditionTabClick();
    createPattern.addConditionPlusIconClick();
    createPattern.fromrulePatternClick();
    createPattern.showAllCheckboxClick();
    console.log(printTimestamp(), ' Clicked on Add Condition and Clicked on From Rule Pattern section')
});

And("Up arrow should be available in pattern name column", () => {
    createPattern.patternNameIconInAddConditionAscVerification();
    console.log(printTimestamp(), ' Up arrow available in pattern name column')
});
