/// <reference types="Cypress" />
/// <reference types='cypress-tags' /> 

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import CreateKnowledge from "../../../../support/pageObjects/pages/KnowledgeAuthoring/CreateKnowledge";
const createKnowledge = new CreateKnowledge();
var arr = [];

Then("User should be able to add details in Knowledge Information section and User expands symptoms section", () => {
    createKnowledge.symptomsVisible()
    createKnowledge.symptomsClick()
    console.log(printTimestamp(), ' Details added in Knowledge Information section')
});

When("User clicks on 'X' icon and entered text should gets cleared", () => {
    createKnowledge.crossMarkClick()
    createKnowledge.searchBoxTestVisible()
    console.log(printTimestamp(), ' Data got cleared after click of X')
});

And("Clicks on Show all checkbox", () => {
    createKnowledge.showAllCheckboxClick()
    console.log(printTimestamp(), ' Show all checkbox clicked')
});

And("User enters data in column level filter, then filtered data should be available", () => {
    createKnowledge.symptomNameColumnType()
    console.log(printTimestamp(), ' Filtered data displayed')
});

And("Clicks on drop down and verifies ALl, Name, Description, Associations, Tags are available", () => {
    createKnowledge.dropdownValuesVerification()
    console.log(printTimestamp(), ' Details verified from dropdown section')
});

And("Searched result should be displayed as per content search", () => {
    createKnowledge.clearSearchBoxType()
    createKnowledge.searchBoxType()
    cy.wait(2000)
    console.log(printTimestamp(), '  Verified data as per entered text')
});

Then("filtered result should be available in grid", () => {
    console.log(printTimestamp(), ' Filtered data displayed')
});

And("Close DAW Application", () => {
    createKnowledge.cancelButtonClickForClaus()
    cy.DeleteWorkflow()
    cy.log("Test Case Executed Successfully")
    console.log(printTimestamp(), ' Test Case Executed Successfully')
});
