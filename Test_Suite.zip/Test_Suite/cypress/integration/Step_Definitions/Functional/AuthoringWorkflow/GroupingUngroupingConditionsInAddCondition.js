/// <reference types="Cypress" />
/// <reference types='cypress-tags' />   

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();
import NavigationPanel from "../../../../support/pageObjects/pages/Dashboard/NavigationPanel";
const navigationPanel = new NavigationPanel();

var arr = [];

When("User Clicks on three dots of my pattern", () => {
    createPattern.myPatternThreeDotsClick()
    console.log(printTimestamp(), ' Clicked on three dots of my pattern')
});

Then("Create Pattern option is displayed", () => {
    navigationPanel.createPatternButtonVisible()
    console.log(printTimestamp(), 'Create Pattern option displayed')
});

When("User  click on Import Data Model and Select any Data Model from drop down option", () => {
    createPattern.createPatternButtonClick()
    cy.wait(2000)
    createPattern.importDataModelClick()
    createPattern.dataModelDropArrowClick()
    createPattern.dataModelCommonOptionDropArrowClick()
    createPattern.eventLogDataModelClick()
    createPattern.dataModelDropArrowClick()
    console.log(printTimestamp(), 'User  clicked on Import Data Model and Selects any Data Model from drop down option')
});

And("User clicks on Add Condition and Add Condition gets expanded", () => {
    createPattern.addConditionTabClick()
    createPattern.expandedAddConditionSectionVerification()
    console.log(printTimestamp(), 'User clicked on Add Condition and Add Condition expanded')
});

When("User Click on + drop down", () => {
    createPattern.addConditionPlusIconClick()
    cy.wait(2000)
    console.log(printTimestamp(), 'Clicked on + drop down')
});

Then("From Data Model From Rule-Pattern From Variable option should be displayed", () => {
    createPattern.fromdataModelVisible()
    createPattern.fromrulePatternVisible()
    createPattern.fromVariableVisible()
    console.log(printTimestamp(), 'From Data Model From Rule-Pattern From Variable option displayed')
});

When("User Add event by From Data model", () => {
    createPattern.formDataModelClick()
    cy.wait(1000)
    createPattern.eventLogAttributeClick()
    createPattern.additionalInfoAttributeClick()
    createPattern.operatorForEventOneClick()
    createPattern.equaltoOperatorClick()
    createPattern.ValueForTestOneType()
    console.log(printTimestamp(), 'Add event by From Data model')
});

Then("group disabled,X mark enabled options should be available inline with logical expression of condition", () => {
    createPattern.groupConditionOptionVisibleAndDisabled()
    createPattern.crossMarkAtConditionLevelVisible()
    console.log(printTimestamp(), 'group disabled,X mark enabled options available inline with logical expression of condition')
});

When("User Add multiple events", () => {
    createPattern.addConditionPlusIconClick()
    cy.wait(1000)
    createPattern.formDataModelClick()
    cy.wait(1000)
    createPattern.importedEventLogModelClick()
    createPattern.dataModelAdditionalInfoAttributeClick()
    createPattern.opeartorDropDownForEvent3ConditionOneClick()
    createPattern.equaltoOperatorClick()
    createPattern.valueForFirstConditionInThridEventType()
    console.log(printTimestamp(), 'Added multiple events')
});

And("Add multiple conditions within each event and fill data operator,attribute , operator , value", () => {
    createPattern.addConditionButtonForeventOneClick()
    createPattern.attributeForSecondConditionInFirstEventClick()
    createPattern.attributeForSecondConditionClick()
    createPattern.operatorDropDownForSecondConditionClick()
    createPattern.equalToOperatorForSecondConditonClick()
    createPattern.valueForSecondConditionFirstEventType()
    createPattern.addConditionButtonAtConditionTwoClick()
    createPattern.attributeDropdownAtConditionThreeClick()
    createPattern.attributeForSecondConditionClick()
    createPattern.operatorDropdownBetweenAttrAndValueConditionThreeClick()
    createPattern.equaltoOperatorClick()
    createPattern.valueInputBoxForConditionThreeType()
    createPattern.addConditionButtonAtConditionThreeClick()
    createPattern.attributeDropdownAtConditionFourClick()
    createPattern.attributeForSecondConditionClick()
    createPattern.operatorDropdownBetweenAttrAndValueConditionFourClick()
    createPattern.equaltoOperatorClick()
    createPattern.valueInputBoxForConditionFourType()
    createPattern.addConditionButtonAtConditionFourClick()
    createPattern.attributeDropdownAtConditionFiveClick()
    createPattern.attributeForSecondConditionClick()
    createPattern.operatorDropdownBetweenAttrAndValueConditionFiveClick()
    createPattern.equaltoOperatorClick()
    createPattern.valueInputBoxForConditionFiveType()
    console.log(printTimestamp(), 'Added multiple conditions within each event and filled data operator,attribute , operator , value')
});

And("operator between condition is selected in event", () => {
    createPattern.operatorDropdownAtEventAndConditionForConditionTwoClick()
    createPattern.orOperatorOptionsUnderDropdownForConditionTwoClick()
    createPattern.operatorDropdownAtEventAndConditionForConditionThreeClick()
    createPattern.andOperatorOptionsUnderDropdownForConditionThreeClick()
    createPattern.operatorDropdownAtEventAndConditionForConditionFourClick()
    createPattern.andOperatorOptionsUnderDropdownForConditionFourClick()
    console.log(printTimestamp(), 'operator between condition is selected in event')
});

Then("Logical expression should be displayed under event", () => {
    createPattern.logicalExpressionUnderEventVisible()
    console.log(printTimestamp(), 'Logical expression displayed under event')
});

When("User Select one check box available at condition level and verify group option", () => {
    createPattern.checkBoxAtSecondConditionClick()
    console.log(printTimestamp(), 'Selected one check box available at condition level and verified group option')
});

Then("Group option should be disabled", () => {
    createPattern.groupConditionOptionDisabled()
    console.log(printTimestamp(), 'Group option disabled')
});

When("Select two check box of  condition level across event and verify group option", () => {
    createPattern.checkBoxAtFirstConditionInEventTwoClick()
    console.log(printTimestamp(), 'Selected two check box of  condition level across event and verified group option')
});

Then("Group option should be disabled", () => {
    createPattern.groupConditionOptionDisabled()
    console.log(printTimestamp(), 'Group option disabled')
});

When("User Select two check box of condition level within event", () => {
    createPattern.checkBoxAtFirstConditionInEventTwoClick()
    createPattern.checkBoxAtThirdConditionClick()
    console.log(printTimestamp(), 'Selects two check box of condition level within event')
});

Then("Group option should be enabled", () => {
    createPattern.groupConditionOptionEnabled()
    console.log(printTimestamp(), 'Group option enabled')
});

When("User Click on group", () => {
    createPattern.groupConditionOptionClick()
    console.log(printTimestamp(), 'Clicked on group')
});

Then("Logical expression should get updated", () => {
    createPattern.updatedlogicalExpressionUnderEventVisible()
    console.log(printTimestamp(), 'Logical expression gets updated')
});

And("Grouped condition should be displayed in new block  with Ungroup enabled and X enabled options", () => {
    createPattern.groupedConditionsVisible()
    createPattern.ungroupConditionOptionVisibleAndEnabled()
    createPattern.crossMarkAtGroupedConditionlevelEnabled()
    console.log(printTimestamp(), 'Grouped condition displayed in new block  with Ungroup enabled and X enabled options')
});

And("one check box and Operator None,NOT for whole block should be displayed for grouped condition and first condition", () => {
    createPattern.operatorDropdownAtEventAndConditionForGroupedConditionClick()
    createPattern.noneOperatorVisible()
    createPattern.notOperatorVisible()
    console.log(printTimestamp(), 'one check box and Operator None,NOT for whole block displayed for grouped condition and first condition')
});

When("User Click on Ungroup", () => {
    createPattern.ungroupConditionOptionClick()
    console.log(printTimestamp(), 'Clicked on Ungroup')
});

Then("Logical expression should get updated based on ungrouping", () => {
    createPattern.updatedlogicalExpressionUnderEventAfterUngroupingVisible()
    console.log(printTimestamp(), 'Logical expression gets updated based on ungrouping')
});

And("Ungrouped condition should be displayed with Group disabled and X options", () => {
    createPattern.groupConditionOptionVisibleAndDisabled()
    createPattern.crossMarkAtGroupedConditionlevelEnabled()
    console.log(printTimestamp(), 'Ungrouped condition displayed with Group disabled and X options')
});

And("Each condition should be displayed with one check box for ungrouped condition", () => {
    createPattern.conditionsWithCheckBoxVisible()
    console.log(printTimestamp(), 'Each condition displayed with one check box for ungrouped condition')
});

When("User Click on “X” mark of ungrouped conditions", () => {
    createPattern.removeConditionButtonForConditionFourClick()
    console.log(printTimestamp(), 'Clicked on “X” mark of ungrouped conditions')
});

Then("UnGrouped conditions should be removed", () => {
    createPattern.conditionFourNotExist()
    console.log(printTimestamp(), 'UnGrouped conditions removed')
});

And("Logical expression has to be updated after removing conditions", () => {
    createPattern.updatedLogicalExpressionUnderEventAfterRemovingFourthCondition()
    console.log(printTimestamp(), 'Logical expression updated after removing conditions')
});

When("User Group conditions and Click on “X” mark of grouped conditions", () => {
    createPattern.checkBoxAtSecondConditionClick()
    createPattern.checkBoxAtThirdConditionClick()
    createPattern.groupConditionOptionClick()
    createPattern.crossMarkAtGroupedConditionlevelClick()
    console.log(printTimestamp(), 'Group conditions and Clicked on “X” mark of grouped conditions')
});

Then("Grouped conditions should be removed", () => {
    createPattern.conditionTwoNotExist()
    createPattern.conditionThreeNotExist()
    console.log(printTimestamp(), 'Grouped conditions removed')
});

And("Logical expression has to be updated after  removing conditions", () => {
    createPattern.updatedLogicalExpressionUnderEventAfterRemovingGroupedCondition()
    console.log(printTimestamp(), 'Logical expression updated after  removing conditions')
});

When("User Fill all mandatory fields in Create Pattern page and click on Save as Draft", () => {
    createPattern.patternInformationOptionClick()
    createPattern.patternNameType()
    createPattern.descriptionType()
    createPattern.orderOfExecutionType()
    createPattern.addActionClick()
    createPattern.addActionPlusIconClick()
    cy.wait(1000)
    createPattern.raiseAlertOptionClick()
    createPattern.saveAsDraftBButtonClick()
    cy.wait(1000)
    createPattern.messageVisible()
    createPattern.getPatternName()
    console.log(printTimestamp(), 'Filled all mandatory fields in Create Pattern page and clicked on Save as Draft')
});

Then("All details should be available in db Table Name Patterns", () => {


    createPattern.deletePattern()
    createPattern.deleteOption().click({ force: true });
    createPattern.okButtonClick()
    cy.wait(3000)
    console.log(printTimestamp(), 'All details available in db Table Name Patterns')
});

And("Repeat above steps for grouping ungrouping of conditions within each event by importing Condition from rule pattern", () => {
    createPattern.myPatternThreeDotsClick()
    createPattern.createPatternButtonClick()
    cy.wait(2000)
    createPattern.importDataModelClick()
    createPattern.dataModelDropArrowClick()
    createPattern.dataModelCommonOptionDropArrowClick()
    createPattern.eventLogDataModelClick()
    createPattern.dataModelDropArrowClick()
    createPattern.addConditionTabClick()
    createPattern.expandedAddConditionSectionVerification()
    createPattern.addConditionPlusIconClick()
    cy.wait(2000)
    createPattern.fromdataModelVisible()
    createPattern.fromrulePatternVisible()
    createPattern.fromVariableVisible()
    createPattern.rulePatternOptionClick()
    createPattern.showAllCheckboxClick()
    cy.wait(2000)
    createPattern.patternClick()
    createPattern.importButtonClick()
    createPattern.addConditionButtonAtConditionThreeClick()
    createPattern.attributeDropdownAtConditionFourClick()
    createPattern.attributeForSecondConditionClick()
    createPattern.operatorDropdownBetweenAttrAndValueConditionFourClick()
    createPattern.equaltoOperatorClick()
    createPattern.valueInputBoxForConditionFourType()
    createPattern.addConditionButtonAtConditionFourClick()
    createPattern.attributeDropdownAtConditionFiveClick()
    createPattern.attributeForSecondConditionClick()
    createPattern.operatorDropdownBetweenAttrAndValueConditionFiveClick()
    createPattern.equaltoOperatorClick()
    createPattern.valueInputBoxForConditionFiveType()
    createPattern.operatorDropdownAtEventAndConditionForConditionTwoClick()
    createPattern.orOperatorOptionsUnderDropdownForConditionTwoClick()
    createPattern.operatorDropdownAtEventAndConditionForConditionThreeClick()
    createPattern.andOperatorOptionsUnderDropdownForConditionThreeClick()
    createPattern.operatorDropdownAtEventAndConditionForConditionFourClick()
    createPattern.andOperatorOptionsUnderDropdownForConditionFourClick()
    createPattern.logicalExpressionUnderEventVisible()
    createPattern.checkBoxAtSecondConditionClick()
    createPattern.groupConditionOptionDisabled()
    createPattern.checkBoxAtFirstConditionInEventTwoClick()
    createPattern.groupConditionOptionDisabled()
    createPattern.checkBoxAtFirstConditionInEventTwoClick()
    createPattern.checkBoxAtThirdConditionClick()
    createPattern.groupConditionOptionEnabled()
    createPattern.groupConditionOptionClick()
    createPattern.updatedlogicalExpressionUnderEventVisible()
    createPattern.groupedConditionsVisible()
    createPattern.ungroupConditionOptionVisibleAndEnabled()
    createPattern.crossMarkAtGroupedConditionlevelEnabled()
    createPattern.operatorDropdownAtEventAndConditionForGroupedConditionClick()
    createPattern.noneOperatorVisible()
    createPattern.notOperatorVisible()
    createPattern.ungroupConditionOptionClick()
    createPattern.updatedlogicalExpressionUnderEventAfterUngroupingVisible()
    createPattern.groupConditionOptionVisibleAndDisabled()
    createPattern.crossMarkAtGroupedConditionlevelEnabled()
    createPattern.conditionsWithCheckBoxVisible()
    createPattern.removeConditionButtonForConditionFourClick()
    createPattern.conditionFourNotExist()
    createPattern.updatedLogicalExpressionUnderEventAfterRemovingFourthCondition()
    createPattern.checkBoxAtSecondConditionClick()
    createPattern.checkBoxAtThirdConditionClick()
    createPattern.groupConditionOptionClick()
    createPattern.crossMarkAtGroupedConditionlevelClick()
    createPattern.conditionTwoNotExist()
    createPattern.conditionThreeNotExist()
    createPattern.updatedLogicalExpressionUnderEventAfterRemovingGroupedCondition()
    createPattern.patternInformationOptionClick()
    createPattern.patternNameType()
    createPattern.descriptionType()
    createPattern.orderOfExecutionType()
    createPattern.addActionClick()
    createPattern.addActionPlusIconClick()
    cy.wait(1000)
    createPattern.raiseAlertOptionClick()
    createPattern.saveAsDraftBButtonClick()
    cy.wait(1000)
    createPattern.messageVisible()
    console.log(printTimestamp(), 'Repeats above steps for grouping ungrouping of conditions within each event by importing Condition from rule pattern')
});

