/// <reference types="Cypress" /> 
/// <reference types='cypress-tags' /> 

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import CreateKnowledge from "../../../../support/pageObjects/pages/KnowledgeAuthoring/CreateKnowledge";
const createKnowledge = new CreateKnowledge();

Then("User Expand Causes and Solutions section and click on Add Cause button", () => {
    createKnowledge.causesAndSolutionSectionClick()
    createKnowledge.addCausesButtonClick()
    console.log(printTimestamp(), ' Expanded Causes and Solutions section and clicked on Add Cause button')
});

Then("Rich text editor for cause should be available", () => {
    createKnowledge.richTextEditorSectionVisible()
    console.log(printTimestamp(), ' Rich text editor for cause available')
});

And("User Adds content in Cause rich text editor", () => {
    createKnowledge.insertTextInCauseRichTextEditorSection()
    console.log(printTimestamp(), ' Content added in Cause rich text editor')
});

Then("Verifies user should not able to upload excel file in rich text editor", () => {
    createKnowledge.notAbleToAddExcelFileInCauseAndSolutionSectionVerification()
    console.log(printTimestamp(), ' Verified user not able to upload excel file in rich text editor')
});

Then("Verifies User should not able to upload excel file in rich text editor", () => {
    createKnowledge.notAbleToAddExcelFileInCauseAndSolutionTwoSectionVerification()
    console.log(printTimestamp(), ' Verified user not able to upload excel file in rich text editor')
});

When("User Clicks on Add Solution and add content in Solution Rich text editor", () => {
    createKnowledge.insertTextInCauseRichTextEditorSection()
    createKnowledge.addSolutionButtonClick()
    createKnowledge.solutionTextType()
    console.log(printTimestamp(), ' Clicked on Add Solution and add content in Solution')
});

When("User Adds multiple causes with multiple solutions", () => {
    createKnowledge.addSolutionButtonClick()
    console.log(printTimestamp(), '  Multiple causes with multiple solutions added')
});

Then("Provide same priority to multiple solutions", () => {
    createKnowledge.priorityDropdownClickAndChangeValue()
    console.log(printTimestamp(), ' Same priority given to multiple solution')
});

And("Verifies priority drop down should get highlighted with red border", () => {
    console.log(printTimestamp(), ' Verified priority drop down got highlighted with red border')
});

When("User Collapse Causes and Solutions section or expand other sections", () => {
    createKnowledge.causesAndSolutionSectionClick()
    console.log(printTimestamp(), ' Causes and Solutions section collapsed')
});

Then("Added cause names should be displayed in removable token", () => {
    createKnowledge.causeNameAndRemoveIconVisible()
    console.log(printTimestamp(), ' Cause names displayed in removable token')
});

When("User Remove cause from token", () => {
    createKnowledge.causeNameOneRemoveIconClick()
    console.log(printTimestamp(), ' Removed cause from token')
});

Then("'Are you sure you want to delete this cause?' Pop should be displayed", () => {
    createKnowledge.areYouSureToDeleteCauseTestVisble()
    console.log(printTimestamp(), '  Pop up displayed')
});

And("'CauseName' will be deleted text should be displayed", () => {
    createKnowledge.dialogBodyInCauseTextVisble()
    console.log(printTimestamp(), ' Pop up displayed')
});

And("Cancel and Delete button should be displayed", () => {
    createKnowledge.buttonsVisibleInCauseRemovePopup()
    console.log(printTimestamp(), ' Cancel and Delete button displayed')
});

When("User Clicks on cancel button", () => {
    createKnowledge.cancelButtonClickInCause()
    console.log(printTimestamp(), ' Clicked on cancel button')
});

Then("Cause should not get removed from token and from Causes and Solutions section", () => {
    createKnowledge.causeNameAndRemoveIconVisible()
    console.log(printTimestamp(), ' Cause not get removed from token ')
});

When("User Click on Remove token option", () => {
    createKnowledge.causeNameOneRemoveIconClick()
    createKnowledge.popUpOkButtonClick()
    console.log(printTimestamp(), ' Clicked on Remove token option')
});

Then("Verifies removed cause in Causes and Solutions section", () => {
    createKnowledge.causeNameAndRemoveIconNotVisible()
    console.log(printTimestamp(), ' Verifies removed cause in Causes and Solutions section')
});

And("Repeats all the above steps for adding Symptom", () => {
    createKnowledge.symptomsClick()
    createKnowledge.addSymptomsButtonClick()
    createKnowledge.insertTextInCauseRichTextEditorSection()
    createKnowledge.notAbleToAddExcelFileInCauseAndSolutionSectionVerification()
    createKnowledge.symptomsClick()
    createKnowledge.causeNameOneRemoveIconClick()
    createKnowledge.popUpOkButtonClick()
    console.log(printTimestamp(), ' Repeated all the above steps for adding Symptom')
});


