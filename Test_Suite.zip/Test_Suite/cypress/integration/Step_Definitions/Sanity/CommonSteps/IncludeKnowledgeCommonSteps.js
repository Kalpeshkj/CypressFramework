import "../../../../support/index";
import { Then, When, And } from "cypress-cucumber-preprocessor/steps";
import CreateKnowledge from "../../../../support/pageObjects/pages/KnowledgeAuthoring/CreateKnowledge";
const createKnowledge = new CreateKnowledge();
import {printTimestamp} from '../../../../support/commands'; 


And("Selects attribute from drop down option and writes keyword in search box", () => {
    createKnowledge.attributeClickForClaus()
    createKnowledge.searchBoxType()
    console.log(printTimestamp(), ' Selected attribute from drop down option and written keyword in search box')
});

And("User should be able to apply filter at column level with available filtered or searched result", () => {
    createKnowledge.attributeClickForClaus()
    createKnowledge.searchBoxType()
    console.log(printTimestamp(), ' Apply filer functionality verified')
});

And("User enters data in column level filter then filtered data should be available", () => {
    createKnowledge.causeNameColumnType()
    console.log(printTimestamp(), ' Filtered data displayed')
});

When("Create new knowledge workflow", () => {
    createKnowledge.knowledgeClick()
    console.log(printTimestamp(), ' New knowledge workflow created')
});
And("Select Symptom pop up should get displayed when user clicked on Select cause button", () => {
    createKnowledge.selectSymptomsButtonVisible()
    createKnowledge.selectSymptomsButtonClick()
    createKnowledge.selectSymptomsHeadingVisible()
    console.log(printTimestamp(), ' Cause pop up displayed')
});
Then("User should be able to add details in Knowledge Information section and User expands Causes and Solutions section", () => {
    createKnowledge.causesAndSolutionsVisible()
    createKnowledge.causesAndSolutionsClick()
    console.log(printTimestamp(), ' Details added in Knowledge Information section')
});