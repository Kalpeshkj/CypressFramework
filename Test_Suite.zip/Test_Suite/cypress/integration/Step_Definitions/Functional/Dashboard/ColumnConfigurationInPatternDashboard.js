/// <reference types="Cypress" />
/// <reference types='cypress-tags' />

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import PatternDashboard from "../../../../support/pageObjects/pages/Dashboard/PatternDashboard";
const patternDashboard = new PatternDashboard();


When("By default pattern dashboard page is displayed", () => {
    patternDashboard.dashboardButtonVisible();
    console.log(printTimestamp(), ' Pattern dashboard page displayed')
});

Then("Verifies data grid present in dashboard", () => {
    patternDashboard.dataGridInPatternDashboardVerification();
    console.log(printTimestamp(), ' Data grid verified')
});

And('Verifies drop down for column configuration as 9 columns pre selected', () => {
    patternDashboard.columnConfiurationDropdownTextVerification();
    console.log(printTimestamp(), ' Verified drop down for column configuration as 9 columns pre selected')
});

When("User clicks on column dropdown", () => {
    patternDashboard.columnConfigurationDropdownClick();
    console.log(printTimestamp(), ' Column dropdown clicked')
});

Then("By default 9 columns should be selected and rest should be in unselected state", () => {
    patternDashboard.selectedColumnsChekboxCountVerification();
    patternDashboard.unSelectedColumnsChekboxCountVerification();
    console.log(printTimestamp(), ' By default 9 columns selected and rest was in unselected state')
});

When("User Verifies list of columns in Drop down options as per checked or unchecked state", () => {
    patternDashboard.selectedColumnsTextCountVerification();
    patternDashboard.unSelectedColumnsTextCountVerification();
    console.log(printTimestamp(), ' Verified list of columns in Drop down options as per checked or unchecked state')
});

When('User adds any new unchecked column from the list', () => {
    patternDashboard.unSelectedSingleColumnsChekboxClick();
    console.log(printTimestamp(), ' User added any new unchecked column')
});

Then("New Column should get displayed in data grid with results", () => {
    patternDashboard.newlyAddedColumnsInDataGridVerify();
    console.log(printTimestamp(), ' New Column displayed in data grid with results')
});

When("User naviagtes to next page and again revisits in same page", () => {
    patternDashboard.pageNavigationClick();
    console.log(printTimestamp(), ' User naviagted to next page and again revisited in same page')
});

Then("Newly added column should be retained", () => {
    patternDashboard.newlyAddedColumnsInDataGridVerification();
    console.log(printTimestamp(), ' Newly added column retained as it is')
});

Then("Newly added column should be retain", () => {
    patternDashboard.newlyAddedColumnsInDataGridVerify();
    console.log(printTimestamp(), ' Newly added column retained as it is')
});

When("User relaunches the application", () => {
    cy.reload()
    cy.wait(2000)
    console.log(printTimestamp(), ' sorting operation performed on all columns')
});

Then("Newly added column should not be retained", () => {
    patternDashboard.newlyAddedColumnsInDataGridNotPresentVerification();
    console.log(printTimestamp(), ' Newly added column not retained')
});

When("User adds all unselected columns from the list", () => {
    patternDashboard.unSelectedAllColumnsChekboxClick();
    console.log(printTimestamp(), ' All unselected columns added')
});

Then("Newly added columns should be displayed in dashboard", () => {
    patternDashboard.newlyAddedColumnsInDataGridVerification();
    console.log(printTimestamp(), ' Newly added columns displayed')
});

When("User unchecks all the columns from the list", () => {
    patternDashboard.selectedAllColumnsChekboxClick();
    console.log(printTimestamp(), ' User unchecksed all the columns')
});

Then("User should not able to remove all the columns and atleast one column must be present in dashboard", () => {
    patternDashboard.singleColumnPresentVerification();
    console.log(printTimestamp(), ' User removed all the columns except one')
});

When("User selects all the columns from the list", () => {
    patternDashboard.columnConfigurationDropdownClick()
    cy.wait(3000)
    patternDashboard.unSelectedAllColumnsChekboxClick();
    console.log(printTimestamp(), ' Selected all the columns')
});

Then("Number of item selected should get updated in drop down", () => {
    patternDashboard.newlyAddedColumnsInDataGridVerification();
    console.log(printTimestamp(), ' Number of item selected are updated in drop down')
});

When("User adds all unselected columns from the list and removes selected columns", () => {
    patternDashboard.unSelectedAllColumnsChekboxClick();
    console.log(printTimestamp(), ' All unselected columns added')
});

And("Repeat all the above steps for My Pattern Dashboard", () => {
    patternDashboard.myPatternClick();
    patternDashboard.myPatternDashboardButtonClick();
    patternDashboard.columnConfigurationDropdownClick();
    patternDashboard.selectedColumnsChekboxCountVerification();
    patternDashboard.unSelectedColumnsChekboxCountVerification();
    patternDashboard.unSelectedColumnsTextCountVerification();
    patternDashboard.unSelectedSingleColumnsChekboxClick();
    patternDashboard.pageNavigationClick();
    cy.reload()
    cy.wait(2000)
    patternDashboard.unSelectedAllColumnsChekboxClick();
    patternDashboard.pageNavigationClick();
    cy.reload()
    cy.wait(2000)
    patternDashboard.selectedAllColumnsChekboxClick();
    patternDashboard.singleColumnPresentVerification();
    patternDashboard.pageNavigationClick();
    console.log(printTimestamp(), ' Repeated all steps in my pattern dashboard')
});