
import "../../index"; 
 
class AssertionConstants {
clickedFromRulePatternLogText = 'clicked on From Rule-Pattern from + Add Condition';
notHaveTextAssertion = 'not.have.text';
beVisibleAssertion = 'be.visible';
patternNameThreeDots = " > #nav-dropdown-btn > .ng-star-inserted > #Layer_1";
notBeDisabledAssertion = 'not.be.disabled';
notBeEnabledAssertion = 'not.be.enabled'
haveClassAssertion = 'have.class';
enableFullscreenValidation = 'enable-fullscreen';
haveTextAssertion = 'have.text';
notExistsAssertion = 'not.exist' 
haveAttributeAssertion = 'have.attr'
notVisibleAssertion = 'not.be.visible'
beExistAssertion = 'be.exist'
notContainAssertion = 'not.contain' 
containAssertion = 'contain'
notHaveClassAssertion = 'not.have.class'
notBeCheckedAssertion = 'not.be.checked'
havelengthAssertion = 'have.length'
notIncludeTextAssertion = 'not.include.text'
haveLengthGreaterThanAssertion = 'have.length.greaterThan'
haveNotAttributeAssertion = 'not.have.attr'
haveCssAssertion = 'have.css'
beEmptyAssertion  = 'be.empty'
}
export default AssertionConstants;


