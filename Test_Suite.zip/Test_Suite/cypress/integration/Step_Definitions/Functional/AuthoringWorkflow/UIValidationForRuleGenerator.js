/// <reference types="Cypress" />
/// <reference types='cypress-tags' />

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';

import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();

Then("Click on three vertical dots of My patterns", () => {
    createPattern.myPatternThreeDotsClick()
    console.log(printTimestamp(), ' Clicked on three vertical dots of My patterns')
});

And("Clicks on Create Pattern", () => {
    createPattern.createPatternClick()
    console.log(printTimestamp(), ' Clicked on Create Pattern')
});

Then("Verifies the available flow in Grid", () => {
    createPattern.gridVerificationInPattern()
    console.log(printTimestamp(), ' Verified the available flow in Grid')
});

Then('Verifies availability of all component when "Create Pattern" is selected', () => {
    createPattern.mandatoryFieldsInCreatePatternPageVisible()
    console.log(printTimestamp(), ' Verified availability of all component')
});

And("Verifies Fields available under Pattern Information", () => {
    createPattern.createPatternGridAsSelected()
    console.log(printTimestamp(), ' Verified Fields available under Pattern Information')
});

And("Verifies all the mandatory fields are marked with asterisk to indicate the fields are mandatory", () => {
    createPattern.mandatoryFieldsWithAsteriskInCreatePatternPageVisible()
    console.log(printTimestamp(), ' All mandatory fields are visible')
});

When("User Click or expand any option field", () => {
    createPattern.addActionTabClick()
    console.log(printTimestamp(), ' User Clicked or expand any option field')
});

Then("Verifies field should get expanded", () => {
    createPattern.addActionTabExpandedVisible()
    console.log(printTimestamp(), ' Verified field')
});

When("User relaunches Application", () => {
    cy.reload()
    console.log(printTimestamp(), ' App relaunched')
});

Then("Verifies Create Pattern page by navigate to Authoring wf", () => {
    createPattern.createPatternGridAsSelected()
    console.log(printTimestamp(), ' Verified Create Pattern page')
});

When("User again Click or expand any option field", () => {
    createPattern.addActionTabClick()
    console.log(printTimestamp(), ' User again Clicked or expand any option field')
});

Then("Verifies field should get collapsed", () => {
    // createPattern.patternNameNotVisible()
    console.log(printTimestamp(), '  Verified field should get collapsed')
});

Then("User Verifies buttons available at right button corner", () => {
    createPattern.buttonsVerification()
    console.log(printTimestamp(), ' Available Buttons verified')
});

When("User Enter all mandatory fields and navigate to Apply metadata page", () => {
    createPattern.patternInformationTabClick()
    createPattern.createPatternPageInformationSubmission()
    createPattern.nextButtonClick()
    console.log(printTimestamp(), ' Entered all mandatory fields and navigated to Apply metadata page')
});

Then("User Fills any one mandatory field and Verify Next Button that should be disabled", () => {
    cy.wait(2000)
    createPattern.patternTypeDropdownInApplyMetadataPageSelection()
    createPattern.nextButtonVisibleAsDisabled()
    console.log(printTimestamp(), ' Fills any one mandatory field and Verify Next Button that should be disabled')
});

When("User Validates all the mandatory fields", () => {
    createPattern.invalidDataValidationTestingAtDaySpanInApplyMetadataPage()
    console.log(printTimestamp(), ' Validated all the mandatory fields')
});

Then("Section level highlighting should be displayed incase of validation failure from API", () => {
    createPattern.validationFailureVisible()
    console.log(printTimestamp(), ' Section level highlighting displayed')
});

When("User fills all mandatory fields and Verify Next Button that should be enabled", () => {
    createPattern.validDataValidationTestingAtDaySpanInApplyMetadataPage()
    cy.ApplyMetaDetaPageCompletion()
    console.log(printTimestamp(), ' filled all mandatory fields ')
});

Then("Clicks on Next Button", () => {
    createPattern.nextButtonClick()
    console.log(printTimestamp(), ' Next button clicked')
});

And("Deletes the workflow immediately", () => {
    cy.DeleteWorkflow()
    console.log(printTimestamp(), ' Workflow deleted')
});

And("Repeats all above steps and clicks next button", () => {
    cy.createPattern()
    createPattern.nextButtonClick()
    cy.ApplyMetaDetaPageCompletion()
    createPattern.nextButtonClick()
    cy.DeleteWorkflow()
    console.log(printTimestamp(), ' all above steps repeated and next button clicked')
});

When("User clicks on other workflow available in the Left Pane", () => {
    createPattern.myPatternThreeDots().eq(0).click();
    createPattern.createPattern().click();
    console.log(printTimestamp(), ' clicked on other workflow')
});

Then("User should be navigated to the workflow", () => {
    createPattern.patternInformationTabVisible()
    cy.DeleteWorkflow()
    console.log(printTimestamp(), ' Navigated to the workflow')
});