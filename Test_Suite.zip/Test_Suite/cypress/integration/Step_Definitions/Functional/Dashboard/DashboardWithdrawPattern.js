/// <reference types="Cypress" />
/// <reference types='cypress-tags' /> 

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';

import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();
import PatternDashboard from "../../../../support/pageObjects/pages/Dashboard/PatternDashboard";
const patternDashboard = new PatternDashboard();


Then("By default , Pattern Dashboard page should be displayed", () => {
    patternDashboard.patternDashboardTitleVisible()
    patternDashboard.patternDashboardBreadCrumVisible()
    cy.wait(3000)
    console.log(printTimestamp(), 'Pattern Dashboard displayed')
});

And("at least two to three published status and some patterns present in draft status should be present and should be selectable", () => {
    createPattern.publishedPatternCountVerification()
    console.log(printTimestamp(), 'two to three published status and some patterns present in draft status present and selectable')
});

And("Withdraw button should be displayed in disabled state", () => {
    createPattern.withdrawButtonVisibleAsDisabled()
    console.log(printTimestamp(), 'Withdraw button displayed in disabled state')
});

When("User select a pattern other than published state", () => {
    createPattern.clearAllFiltersButtonClick()
    createPattern.draftPatternStatusSelection()
    cy.wait(2000)
    createPattern.selectAllRecordClickInDashboard()
    console.log(printTimestamp(), 'selects a pattern other than published state')
});

Then("Withdraw button should be disabled at right top corner", () => {
    createPattern.withdrawButtonVisibleAsDisabled()
    console.log(printTimestamp(), 'Withdraw button disabled at right top corner')
});

When("User  select a pattern which is in published stage", () => {
    createPattern.clearAllFiltersButtonClick()
    createPattern.publishedPatternStatusSelectionFromList()
    cy.wait(2000)
    createPattern.firstFiveRecordClickInDashboard()
    console.log(printTimestamp(), 'selects a pattern which is in published stage')

});

Then("Withdraw button should be enabled at right top corner", () => {
    createPattern.withdrawButtonVisibleEnabled()
    console.log(printTimestamp(), 'Withdraw button enabled at right top corner')
});

And("Based on selected number of patterns '8 patterns selected' should be displayed beside Advance Search", () => {
    createPattern.fiveRecordsSelectedVerification()
    console.log(printTimestamp(), 'Based on selected number of patterns 8 patterns selected  displayed beside Advance Search')
});

When("User Click on the Withdraw button with less than 10 patterns are selected", () => {
    createPattern.withdrawButtonClick()
    console.log(printTimestamp(), 'User Clicks on the Withdraw button with less than 10 patterns are selected')
});

Then("Confirmation message should be displayed as below :Delete icon - Are you sure you want to"
    + " withdraw the following 8 patterns? 'All 8 Pattern Names' Cancel and Withdraw buttons", () => {
        createPattern.popUpTitleVisible()
        createPattern.cancelButtonInDeleteWFPopupVisible()
        createPattern.deleteButtonInDeleteWFPopupVisible()
        console.log(printTimestamp(), 'Confirmation message displayed')
    });

When("Click on cancel button", () => {
    createPattern.cancelButtonInDeleteWFPopupClick()
    cy.wait(2000)
    console.log(printTimestamp(), 'Clicks on cancel button')
});

Then("Pattern should not get withdraw", () => {
    createPattern.withdrawButtonVisibleEnabled()
    console.log(printTimestamp(), 'Pattern not get withdraw')
});

When("User Click on the Withdraw button with more than 10 patterns are selected", () => {
    createPattern.withdrawButtonClick()
    cy.wait(2000)
    console.log(printTimestamp(), 'User Clicks on the Withdraw button with more than 10 patterns are selected')
});

Then("in pop up 10 pattern name should be displayed and for remaining patterns count"
    + " should be displayed as below : e.g 15 patterns selected Delete icon - Are you sure"
    + " you want to withdraw the following 15 patterns ? 'All 10 Pattern Name' +5 more", () => {
        createPattern.popUpTitleVisible()
        createPattern.cancelButtonInDeleteWFPopupVisible()
        createPattern.deleteButtonInDeleteWFPopupVisible()
        console.log(printTimestamp(), 'in pop up 10 pattern name displayed')
    });

And("Cancel and withdraw buttons displayed", () => {
    createPattern.cancelButtonInDeleteWFPopupVisible()
    createPattern.deleteButtonInDeleteWFPopupVisible()
    console.log(printTimestamp(), 'Cancel and withdraw buttons displayed')
});

When("Click on cancel button", () => {
    createPattern.cancelButtonInDeleteWFPopupClick()
    cy.wait(2000)
    console.log(printTimestamp(), 'Clicked on cancel button')
});

Then("Pattern should not get withdraw", () => {
    createPattern.withdrawButtonVisibleEnabled()
    console.log(printTimestamp(), 'Pattern  not get withdraw')
});

When("Click on withdraw button available at top right corner and click on  withdraw button from pop up", () => {
    cy.CreatePatternsTillValidateStageCompletion(1)
    cy.wait(3000)
    cy.visit('https://daw-automation.eu-west.philips-healthsuite.com/home/patterns/dashboard')
    cy.wait(2000)
    createPattern.clearAllFiltersButtonClick()
    createPattern.patternNameTypeInSearchFilter()
    cy.wait(3000)
    createPattern.selectAllRecordClickInDashboard()
    createPattern.publishButtonClick()
    createPattern.withdrawButtonVisibleAsEnabled()
    cy.wait(2000)
    createPattern.withdrawButtonClick()
    createPattern.okButtonClick()
    console.log(printTimestamp(), 'Clicked on withdraw button available at top right corner and clicked on  withdraw button from pop up')
});

Then("Pattern should get Withdraw", () => {
    createPattern.withdrawButtonVisibleAsDisabled()
    console.log(printTimestamp(), 'Pattern get Withdraw')
});

And("Pattern State WITHDRAWN ,Modified By User Id and Modified On to date should get updated in db", () => {
    console.log(printTimestamp(), 'Pattern State WITHDRAWN ,Modified By User Id and Modified On to date  gets updated in db')
});

When("Click on three dot of published pattern and click on Withdraw button from menu", () => {
    createPattern.clearAllFiltersButtonClick()
    createPattern.publishedPatternStatusSelectionFromList()
    cy.wait(2000)
    patternDashboard.threeDotsGridButtonClick()
    patternDashboard.withdrawButtonClick()
    console.log(printTimestamp(), 'Clicked on three dot of published pattern and clicked on Withdraw button from menu')
});

Then("confirmation pop up should be displayed", () => {
    createPattern.popUpTitleVisible()
    createPattern.cancelButtonInDeleteWFPopupVisible()
    createPattern.deleteButtonInDeleteWFPopupVisible()
    console.log(printTimestamp(), 'confirmation pop up  displayed')
});

When("User After clicking on cancel", () => {
    createPattern.cancelButtonInDeleteWFPopupClick()
    console.log(printTimestamp(), 'User After clicked on cancel')
});

Then("none of details should not get changed in UI and DB", () => {
    patternDashboard.withdrawPatternButtonVisible()
    createPattern.clearAllFiltersButtonClick()
    patternDashboard.patternNameTypeInKnowledgeSearchFilter()
    cy.wait(3000)
    createPattern.selectAllRecordClickInDashboard()
    createPattern.publishButtonClick()
    console.log(printTimestamp(), 'none of details not gets changed in UI and DB')
});

When("User Click on Withdraw button from menu and pop up", () => {
    createPattern.clearAllFiltersButtonClick()
    patternDashboard.patternNameTypeInKnowledgeSearchFilter()
    createPattern.selectAllRecordClickInDashboard()
    createPattern.withdrawButtonClick()
    createPattern.okButtonClick()
    console.log(printTimestamp(), 'User Clicked on Withdraw button from menu and pop up')
});

Then("Pattern state should get changed in UI and DB Table : patterns-Pattern State, Modified By, Modified On", () => {
    createPattern.clearAllFiltersButtonClick()
    patternDashboard.patternNameTypeInKnowledgeSearchFilter()
    createPattern.selectAllRecordClickInDashboard()
    createPattern.publishButtonClick()
    console.log(printTimestamp(), 'Pattern state gets changed in UI and DB Table : patterns-Pattern State, Modified By, Modified On')
});

When("Click on published state of pattern name and click on withdraw button from pattern details page", () => {
    createPattern.clearAllFiltersButtonClick()
    patternDashboard.patternNameTypeInKnowledgeSearchFilter()
    createPattern.selectAllRecordClickInDashboard()
    patternDashboard.firstPatternOpenClick()
    patternDashboard.withdrawButtonClickFromPattern()
    console.log(printTimestamp(), 'Clicked on published state of pattern name and clicked on withdraw button from pattern details page')
});

Then("confirmation pop up should be displayed", () => {
    createPattern.popUpTitleVisible()
    createPattern.cancelButtonInDeleteWFPopupVisible()
    createPattern.deleteButtonInDeleteWFPopupVisible()
    console.log(printTimestamp(), 'confirmation pop up displayed')
});

When("Click on Cancel button", () => {
    createPattern.cancelButtonInDeleteWFPopupClick()
    console.log(printTimestamp(), 'Clicked on Cancel button')
});

Then("Pattern state should not get changed in UI and DB", () => {
    console.log(printTimestamp(), 'Pattern state not get changed in UI and DB')
});

When("Click on Withdraw button from pattern details page and from pop up", () => {
    patternDashboard.withdrawButtonClickFromPattern()
    createPattern.okButtonClick()
    patternDashboard.backArrowClick()
    console.log(printTimestamp(), 'Clicked on Withdraw button from pattern details page and from pop up')
});

Then("Withdraw button should get disabled in pattern details page", () => {
    createPattern.clearAllFiltersButtonClick()
    patternDashboard.patternNameTypeInKnowledgeSearchFilter()
    createPattern.selectAllRecordClickInDashboard()
    createPattern.withdrawButtonVisibleAsDisabled()
    createPattern.deletePatternButtonInDashboardClick()
    createPattern.okButtonClick()
    console.log(printTimestamp(), 'Withdraw button gets disabled in pattern details page')
});

And("Repeat above steps for withdraw in My Pattern Dashboard", () => {
    cy.visit(Cypress.env("URL"));
    createPattern.myPatternsSectionCollapseIconClick()
    createPattern.myPatternDashboardClick()
    cy.CreatePatternsTillValidateStageCompletion(1)
    cy.wait(3000)
    cy.visit('https://daw-automation.eu-west.philips-healthsuite.com/home/patterns/dashboard')
    cy.wait(2000)
    createPattern.clearAllFiltersButtonClick()
    createPattern.patternNameTypeInSearchFilter()
    cy.wait(2000)
    createPattern.selectAllRecordClickInDashboard()
    createPattern.publishButtonClick()
    createPattern.withdrawButtonVisibleAsEnabled()
    cy.wait(2000)
    createPattern.withdrawButtonClick()
    createPattern.okButtonClick()
    createPattern.withdrawButtonVisibleAsDisabled()
    createPattern.clearAllFiltersButtonClick()
    createPattern.publishedPatternStatusSelectionFromList()
    cy.wait(2000)
    patternDashboard.threeDotsGridButtonClick()
    patternDashboard.withdrawButtonClick()
    createPattern.popUpTitleVisible()
    createPattern.cancelButtonInDeleteWFPopupVisible()
    createPattern.deleteButtonInDeleteWFPopupVisible()
    createPattern.cancelButtonInDeleteWFPopupClick()
    patternDashboard.withdrawPatternButtonVisible()
    createPattern.clearAllFiltersButtonClick()
    patternDashboard.patternNameTypeInKnowledgeSearchFilter()
    cy.wait(3000)
    createPattern.selectAllRecordClickInDashboard()
    createPattern.publishButtonClick()
    createPattern.clearAllFiltersButtonClick()
    patternDashboard.patternNameTypeInKnowledgeSearchFilter()
    createPattern.selectAllRecordClickInDashboard()
    createPattern.withdrawButtonClick()
    createPattern.okButtonClick()
    createPattern.clearAllFiltersButtonClick()
    patternDashboard.patternNameTypeInKnowledgeSearchFilter()
    createPattern.selectAllRecordClickInDashboard()
    createPattern.publishButtonClick()
    createPattern.clearAllFiltersButtonClick()
    patternDashboard.patternNameTypeInKnowledgeSearchFilter()
    createPattern.selectAllRecordClickInDashboard()
    patternDashboard.firstPatternOpenClick()
    patternDashboard.withdrawButtonClickFromPattern()
    createPattern.popUpTitleVisible()
    createPattern.cancelButtonInDeleteWFPopupVisible()
    createPattern.deleteButtonInDeleteWFPopupVisible()
    createPattern.cancelButtonInDeleteWFPopupClick()
    patternDashboard.withdrawButtonClickFromPattern()
    createPattern.okButtonClick()
    patternDashboard.backArrowClick()
    createPattern.selectAllRecordClickInDashboard()
    createPattern.deletePatternButtonInDashboardClick()
    createPattern.okButtonClick()
    console.log(printTimestamp(), 'Repeats above steps in My Pattern Dashboard')
});
