/// <reference types="Cypress" />
/// <reference types = 'cypress-tags' /> 

import "../../../../support/index"
import {When, Then, And } from "cypress-cucumber-preprocessor/steps"
import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();
import CreateKnowledge from "../../../../support/pageObjects/pages/KnowledgeAuthoring/CreateKnowledge";
const createKnowledge = new CreateKnowledge();
import {printTimestamp} from '../../../../support/commands';

Then("Clicks on Add button", () => {
    createKnowledge.breadcumbCaptureValue()
    createPattern.bulkStepNextClick()
	createPattern.addButtonClick()
    cy.wait(3000)
    createPattern.showAllButtonClick()
    console.log(printTimestamp(), ' Clicked on Add button')
});

When("User Selects single pattern name", () => {
    cy.wait(3000)
    createPattern.selectAllCheckboxClick()
    console.log(printTimestamp(), ' Selected single pattern name')
});

Then("Verifies the accordion on the pattern details", () => {
    createPattern.rightsideAccordiansVerification()
    console.log(printTimestamp(), ' Verified the accordion on the pattern details')
});

Then("Selects multiple patterns", () => {
    createPattern.selectAllCheckboxClick()
    console.log(printTimestamp(), ' Selected multiple patterns')
});

And("Selects on cancel button", () => {
	createPattern.cancelButtonInsidePatternClick()
    console.log(printTimestamp(), ' Clicked on cancel button')
});

Then("Repeat step of select multiple pattern and click on the 'Select' button", () => {
	createPattern.addButtonClick()
    cy.wait(3000)
    createPattern.showAllButtonClick()
    cy.wait(3000)
    createPattern.selectAllCheckboxClick()
    createPattern.patternNameInsidePatternTextCapture()
    createPattern.selectButtonInsidePatternClick()
    console.log(printTimestamp(), ' Repeated step of select multiple pattern and click on the Select button')
});

And("Clicks on the Save as Draft", () => {
	createPattern.saveAsDraftButtonInsidePatternClick()
    console.log(printTimestamp(), ' Clicked on Save as Draft')
});

Then("Click on workflow delete button", () => {
    cy.DeleteDynamicPattern()
    cy.wait(3000)
    cy.visit(Cypress.env("DAWAutomationURL"));
    cy.wait(3000)
    createPattern.clearAllFiltersButtonClick()
	createPattern.patternNameTypeInSearchFilter()
    cy.wait(2000)
    createPattern.selectAllRecordClickInDashboard()
    createPattern.deletePatternButtonInDashboardClick()
    createPattern.okButtonClick()
    console.log(printTimestamp(), ' Clicked on the workflow delete button')
});

Then("Navigate to pattern dashboard and search for the pattern", () => {
    cy.visit('https://daw-bulk-edit-db.eu-west.philips-healthsuite.com/home')
    createPattern.clearAllFiltersButtonClick()
	createPattern.patternNameTypeInFilter()
    cy.wait(3000)
    console.log(printTimestamp(), ' Navigated to pattern dashboard and search for the pattern')
});

Then("validates if delete and withdraw is possible from the pattern dashboard", () => {
    createPattern.selectAllCheckboxClick()
    createPattern.buttonsVisibleAsDisabled()
    console.log(printTimestamp(), ' Validated if delete and withdraw is possible from the pattern dashboard')
});