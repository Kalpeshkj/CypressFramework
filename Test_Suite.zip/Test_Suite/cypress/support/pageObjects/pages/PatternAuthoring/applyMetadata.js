import "../../../index";
import AssertionConstants from "../../../../support/pageObjects/pages/AssertionConstants"
import ApplyMetadataPageLocators from "../../../../support/pageObjects/PageComponents/applyMeta"

const [arr1,fieldsText] = [[], []]
const arreyOfFieldsInAscendingOrder = [ "Day Span","Modality","Pattern Type","Relevance","Service Context","Severity","Comment","Tags"]
const assertionConstants = new AssertionConstants();
const applyMetadataPageLocators = new ApplyMetadataPageLocators();

// constants
const fieldChatactersOriginalCount = 'Characters left: 4000/4000 '
const createPatternTextIniApplyMetadataPage = ' Create Pattern '
const applyMetadataText = ' Apply Metadata '
const patternTypeText = 'Diagnostics'
const serviceContextText = 'FSE'
const fieldsOnApplyMetadataPage = 'label[class="field-name mb-0"]'
const asteriskMark = '*'
const serviceContextRMEOption = 'RME'

class ApplyMetadata {
    selectModalityOneByOne() {
        arr1.length = 0
        cy.get(applyMetadataPageLocators.addTagFromList).each((index) => {
            cy.wrap(index).scrollIntoView().click()
                .find('span[class="pt-option-label"]').invoke('text').then((value) => {
                    arr1.push(value)
                })
        })
    }
    uncheckAllTheModalities() {
        cy.get(applyMetadataPageLocators.modalityDropdownInApplyMetadata).eq(0).click()
        cy.get(applyMetadataPageLocators.addTagFromList).eq(1).click()
    }
    modalityMultipleDropdownSelectionWithoutDefaultSelectedValue() {
        cy.get(applyMetadataPageLocators.addTagFromList).eq(2).click()
        cy.get(applyMetadataPageLocators.modalityDropdownInApplyMetadata).eq(0).click()
        cy.get(applyMetadataPageLocators.addTagFromList).eq(1).invoke('text').then((value) => {
            arr1.length = 0;
            arr1.push(value)
        })
    }
    modalityDropdownSelection() {
        cy.get(applyMetadataPageLocators.modalityDropdownInApplyMetadata).eq(0).click()
        cy.get(applyMetadataPageLocators.addTagFromList).eq(3).click()
        cy.get(applyMetadataPageLocators.modalityDropdownInApplyMetadata).eq(0).click()
    }
    modalitySelection() {
        cy.get(applyMetadataPageLocators.addTagFromList).eq(3).click()
        cy.get(applyMetadataPageLocators.modalityDropdownInApplyMetadata).eq(0).click()
    }
    modalityMultipleDropdownSelectionWithDefaultSelectedValue() {
        cy.get(applyMetadataPageLocators.modalityDropdownInApplyMetadata).eq(0).click()
        cy.get(applyMetadataPageLocators.addTagFromList).eq(1).click()
        cy.get(applyMetadataPageLocators.addTagFromList).eq(3).invoke('text').then((value) => {
            arr1.length = 0;
            arr1.push(value)
        })
    }
    newlyAddedModalitySequentiallyVisible() {
        cy.get(arr1).each(($el, index) => {
            cy.wrap($el).then(() => {
                cy.get('div[aria-label="' + arr1[index] + '"]').scrollIntoView().should(assertionConstants.beVisibleAssertion);
            })
        })
    }
    newlyAddedModalityVisible() {
        cy.get(applyMetadataPageLocators.modalityDropdownInApplyMetadata).eq(0).click()
        cy.get('div[aria-label="DCP"]').scrollIntoView().should(assertionConstants.beVisibleAssertion);
    }
    productFamilyRelevanceClick() {
        cy.get(applyMetadataPageLocators.productFamilyRelevanceInCollapsed).eq(3).click()
    }
    productFamilyRelevanceVisible() {
        cy.get(applyMetadataPageLocators.productFamilyRelevanceInCollapsed).eq(3).should(assertionConstants.beVisibleAssertion);
    }
    systemTypeInRelevanceClick() {
        cy.get(applyMetadataPageLocators.modalityDropdownInRelevance).eq(5).click()
    }
    systemTypeInRelevanceVisible() {
        cy.get(applyMetadataPageLocators.modalityDropdownInRelevance).eq(5).should(assertionConstants.beVisibleAssertion);
    }
    productLevelsRelevanceClick() {
        cy.get(applyMetadataPageLocators.modalityDropdownInRelevance).eq(6).click()
    }
    productLevelsRelevanceVisible() {
        cy.get(applyMetadataPageLocators.modalityDropdownInRelevance).eq(6).should(assertionConstants.beVisibleAssertion);
    }
    productReleasesInRelevanceClick() {
        cy.get(applyMetadataPageLocators.modalityDropdownInRelevance).eq(7).click()
    }
    productReleasesInRelevanceVisible() {
        cy.get(applyMetadataPageLocators.modalityDropdownInRelevance).eq(7).should(assertionConstants.beVisibleAssertion);
    }
    productsMajorBuildReleaseInRelevanceClick() {
        cy.get(modalityDropdownInRelevance).eq(8).click()
    }
    productsMajorBuildReleaseInRelevanceVisible() {
        cy.get(applyMetadataPageLocators.modalityDropdownInRelevance).eq(8).should(assertionConstants.beVisibleAssertion);
    }
    productFamilyRelevanceInCollapsedStateVerification() {
        cy.get(applyMetadataPageLocators.productFamilyRelevanceInCollapsed).eq(3).should(assertionConstants.beVisibleAssertion);
    }
    relevanceInExpandedStateClick() {
        cy.get(applyMetadataPageLocators.modalityDropdownInApplyMetadata).eq(0).click()
        cy.get(applyMetadataPageLocators.modalityDropdownInRelevance).eq(3).click({ force: true })
    }
    relevanceInExpandedStateVerification() {
        cy.get(applyMetadataPageLocators.relevanceInExpanded).eq(3).should(assertionConstants.beVisibleAssertion);
    }
    modalityDropdownInApplyMetadataSectionVerification() {
        cy.get(applyMetadataPageLocators.modalityDropdownInApplyMetadataSection).eq(1).should(assertionConstants.beVisibleAssertion);
        return cy.get(applyMetadataPageLocators.modalityDropdownInApplyMetadata).eq(0).should(assertionConstants.haveAttributeAssertion, 'class', 'width-100 pt-multiselect ng-untouched ng-star-inserted ng-dirty ng-valid')
    }
    modalityDropdownInApplyMetadataVerification() {
        cy.get(applyMetadataPageLocators.modalityDropdownInApplyMetadataSection).eq(1).should(assertionConstants.beVisibleAssertion);
        return cy.get(applyMetadataPageLocators.modalityDropdownInApplyMetadata).eq(0).should(assertionConstants.haveAttributeAssertion, 'class', 'width-100 pt-multiselect ng-untouched ng-pristine ng-valid ng-star-inserted')
    }
    clickingOnCreatedWorkflow() {
        cy.readFile('cypress/fixtures/patternNameCreation.json').then(function (result) {
            let PatternName = result.name;
            return cy.get("#" + PatternName).click();
        })
    } 
    dayspanDayTextbox() {
        return cy.get(applyMetadataPageLocators.dayspanDayTextbox)
    }
    dayspanUnitDropdown() {
        return cy.get(applyMetadataPageLocators.applymetadataDropdownContainers).eq(0)
    }
    fullScreenButtonClick() {
        return cy.get(applyMetadataPageLocators.fullScreenButton).click({ force: true })
    }
    collapsednavigationPanelBlock() {
        return cy.get(applyMetadataPageLocators.collapsedNavigationPanelBlock)
    }


    applyMetadataActiveVerification() {
        cy.wait(2000)
        return cy.get(applyMetadataPageLocators.applyMetadataActiveVerification).should(assertionConstants.haveAttributeAssertion, 'class', ngStarInsertedActiveClass)
    }

    applyMetadataHeadingActiveVerification() {
        return cy.get(applyMetadataPageLocators.applyMetadataHeading).should(assertionConstants.haveAttributeAssertion, 'class', applyMetadataPageLocators.ngStarInsertedActiveClass)
    }
    
    newlyCreatedPatternTextWithISymbolVisible(){
        cy.get(applyMetadataPageLocators.newlyCreatedPatternText).invoke('text').then((patternText)=>{
        expect(patternText).to.exist
        cy.get(applyMetadataPageLocators.newlyCreatedPatternText).find('span').should(assertionConstants.beVisibleAssertion)
        })
    }

    previousButtonVisible() {
        cy.xpath(applyMetadataPageLocators.previousButtonClick).should(assertionConstants.beVisibleAssertion)
    }


    closeButtonEnabled() {
        cy.get(applyMetadataPageLocators.closeButton).should(assertionConstants.notBeDisabledAssertion)
      }
    
    saveAsDraftEnabled() {
        cy.get(applyMetadataPageLocators.saveAsDraftButton).should(assertionConstants.notBeDisabledAssertion)
    }

    nextButtonEnabledVerification() {
        return cy.get(applyMetadataPageLocators.nextButtonDisabledVerification).should(assertionConstants.haveAttributeAssertion, 'class', 'pt-primary pt-button ng-star-inserted')
    }

    timeSpanOptionVisible(){
        cy.get(applyMetadataPageLocators.optionOnApplyMetadataPage).eq(0).should(assertionConstants.beVisibleAssertion)
    }
    
    commentBoxWithWatermark() {
        return cy.get(applyMetadataPageLocators.commentBox).should(assertionConstants.haveAttributeAssertion,'placeholder','Comment')
    }
    
    
    tagsOptionVisible(){
        cy.get(applyMetadataPageLocators.optionOnApplyMetadataPage).last().should(assertionConstants.beVisibleAssertion)
    }

    daySpanTextBoxWithDefaultWatermark(){
        cy.get(applyMetadataPageLocators.daySpanTextBoxWithDefaultWatermark).should(assertionConstants.haveAttributeAssertion,'placeholder','24 (Default)')
      }
    
    daySpanUnitTextBoxWithDefaultUnit(){
        cy.get(applyMetadataPageLocators.daySpanUnitTextBox).find('span').first().should(assertionConstants.haveTextAssertion,'h').and(assertionConstants.beVisibleAssertion)
      }
    
    daySpanUnitTextBoxClick(){
        cy.get(applyMetadataPageLocators.daySpanUnitTextBox).click()
      }
    
    daySpanUnitDropdownOptions(){
        cy.get(applyMetadataPageLocators.daySpanUnits).last().children().first().invoke('text').then((unitText)=>{
          expect(unitText).include('h').to.exist
        })
          cy.get(applyMetadataPageLocators.daySpanUnits).last().children().last().invoke('text').then((unitText)=>{
          expect(unitText).include('d').to.exist
      })
    }   
    
    rangePlaceholderVisible(){
        cy.get(applyMetadataPageLocators.rangePlaceholder).invoke('text').then((rangeText)=>{
          expect(rangeText).include('1 to 999').to.exist
      })
    }
    
    daySpanTextBoxTypeLessThanOneShowingRedBorderVerification(){
        cy.get(applyMetadataPageLocators.daySpanTextBoxWithDefaultWatermark).clear().type('0')
        cy.get(applyMetadataPageLocators.daySpanTextBoxWithDefaultWatermark).should(assertionConstants.haveCssAssertion,'border-color','rgb(230, 88, 0)')
    }
    
    daySpanTextBoxTypeMoreThan999ShowingRedBorderVerification(){
        cy.get(applyMetadataPageLocators.daySpanTextBoxWithDefaultWatermark).should(assertionConstants.haveAttributeAssertion,'maxlength','3')
       
    }
    
    removingValueFromDaySpanTextBox(){
        cy.get(applyMetadataPageLocators.daySpanTextBoxWithDefaultWatermark).clear()
    }
    
    commentBoxWithCommentype(){
        cy.get(applyMetadataPageLocators.commentBox).click({ force: true }).type('s')
    }
    
    fieldChatactersOriginalCountDecreasedCountVerification(){
        cy.get(fieldChatactersOriginalCount).should('not.equal',fieldChatactersOriginalCount)
    }
    
    commentFieldCharacterTextDecreased(){
        cy.get(applyMetadataPageLocators.commentFieldCharacterText).invoke('text').then((countText)=>{
          expect(countText).not.eql(fieldChatactersOriginalCount )
      })
    }
    
    commentBoxWithOutComment(){
        cy.get(applyMetadataPageLocators.commentBox).click({ force: true }).clear()
    }
    
    commentFieldCharacterTextWithOriginalCount(){
        cy.get(applyMetadataPageLocators.commentFieldCharacterText).invoke('text').then((countText)=>{
          expect(countText).to.eql(fieldChatactersOriginalCount )
      })
    }
    
    fullScreenViewButtonClick(){
        cy.get(applyMetadataPageLocators.fullScreenViewButton).click()
    }
    
    previousButtonNotVisible() {
        cy.xpath(applyMetadataPageLocators.previousButtonClick).should(assertionConstants.notVisibleAssertion)
    }
    
    applyMatadataPageResizedToDefaultSizeVerification(){
        cy.contains(createPatternTextIniApplyMetadataPage).should(assertionConstants.beVisibleAssertion)
        cy.contains(applyMetadataText).should(assertionConstants.beVisibleAssertion)
    }
    
    versionIconVisible(){
        cy.get(applyMetadataPageLocators.version).should(assertionConstants.beVisibleAssertion)
    }
    
    daySpanTextBoxTypeTen(){
        cy.get(applyMetadataPageLocators.daySpanTextBoxWithDefaultWatermark).clear().type('10')
    }
    
    addCommnetInCommentBoxType(){
        cy.get(applyMetadataPageLocators.commentBox).type('TestComment')
    }
    
    saveAsDraftOnCreatePatternEnabled() {
        cy.get(applyMetadataPageLocators.saveAsDraftButton).should(assertionConstants.notBeDisabledAssertion)
    }
    
    SaveAsDraftClick() {
        return cy.get(applyMetadataPageLocators.saveAsDraftButton).click()
    }

    previousButtonClick() {
        return cy.xpath(applyMetadataPageLocators.previousButtonClick).click()
    }

    enteredDetailsOfApplyMetadataPageVisibleVerification(){
        cy.contains(patternTypeText).should(assertionConstants.beVisibleAssertion)
        cy.contains(serviceContextText).should(assertionConstants.beVisibleAssertion)
    }


    buttonsNotVisibleOnApplyMetadataPageVerification(){
        cy.contains(applyMetadataPageLocators.previousButtonClick).should(assertionConstants.notExistsAssertion)
        cy.contains(applyMetadataPageLocators.closeButton).should(assertionConstants.notExistsAssertion)
        cy.contains(applyMetadataPageLocators.saveAsDraftButton).should(assertionConstants.notExistsAssertion)
        cy.contains(applyMetadataPageLocators.nextButtonDisabledVerification).should(assertionConstants.notExistsAssertion)
    }


    fieldsOnApplyMetadataPageVerification(){
        cy.get(fieldsOnApplyMetadataPage).eq(0).should(assertionConstants.beVisibleAssertion)
        cy.get(fieldsOnApplyMetadataPage).eq(1).should(assertionConstants.beVisibleAssertion)
        cy.get(fieldsOnApplyMetadataPage).eq(2).should(assertionConstants.beVisibleAssertion)
        cy.get(fieldsOnApplyMetadataPage).eq(3).should(assertionConstants.beVisibleAssertion)
        cy.get(fieldsOnApplyMetadataPage).eq(4).should(assertionConstants.beVisibleAssertion)
    }

    fieldsOnApplyMetadataPageWithAsteriskVerification(){
        cy.get(fieldsOnApplyMetadataPage).eq(0).find('span').should(assertionConstants.haveTextAssertion,asteriskMark).and(assertionConstants.beVisibleAssertion)
        cy.get(fieldsOnApplyMetadataPage).eq(1).find('span').should(assertionConstants.haveTextAssertion,asteriskMark).and(assertionConstants.beVisibleAssertion)
        cy.get(fieldsOnApplyMetadataPage).eq(2).find('span').should(assertionConstants.haveTextAssertion,asteriskMark).and(assertionConstants.beVisibleAssertion)
        cy.get(fieldsOnApplyMetadataPage).eq(3).find('span').should(assertionConstants.haveTextAssertion,asteriskMark).and(assertionConstants.beVisibleAssertion)
        cy.get(fieldsOnApplyMetadataPage).eq(4).find('span').should(assertionConstants.haveTextAssertion,asteriskMark).and(assertionConstants.beVisibleAssertion)
    }

    patternTypeWaterMaskVisible(){
      cy.get(applyMetadataPageLocators.WaterMarks).first().find('span').should(assertionConstants.haveTextAssertion,'Pattern Type').and((assertionConstants.beVisibleAssertion))
    }

    serviceContextWaterMarkVisible(){
      cy.get(applyMetadataPageLocators.serviceContextWaterMark).last().should(assertionConstants.haveTextAssertion,'Service Context').and((assertionConstants.beVisibleAssertion))
    }

    severityWaterMarkVisible(){
      cy.get(applyMetadataPageLocators.WaterMarks).last().find('span').should(assertionConstants.haveTextAssertion,'Severity').and((assertionConstants.beVisibleAssertion))
    }

  
    mandatoryFieldsInAlphabeticalOrderVerification(){
      cy.get(fieldsOnApplyMetadataPage).each(($el)=>{
        let text1 = $el.text().trim()
        if(text1.slice(-1)=='*'){
          fieldsText.push(text1.slice(0,-2))
        }
        else{
          fieldsText.push(text1)
        }  
      }).then(()=>{
        expect(fieldsText).to.deep.equal(arreyOfFieldsInAscendingOrder)
      })
  
    }

    serviceContextFields() {
      cy.get(applyMetadataPageLocators.serviceContextFields).eq(0).click()
      cy.wait(2000)
      cy.get(applyMetadataPageLocators.serviceContextFields).eq(0).click()
      cy.wait(1000)
    }

    modalityDropdownfield() {
      cy.get(applyMetadataPageLocators.modalityDropdownfield).eq(2).click({ force: true })
    }

    severityContextFieldWithRedBorder(){
      cy.get(applyMetadataPageLocators.fieldsWithRedBorder).should(assertionConstants.haveCssAssertion,'border-color','rgb(230, 88, 0)')
    }

    clearingDaySpanField(){
      cy.get(applyMetadataPageLocators.daySpanTextBoxWithDefaultWatermark).clear()
    }

    daySpanTextBoxWithRedBorder(){
      cy.get(applyMetadataPageLocators.daySpanTextBoxWithDefaultWatermark).should(assertionConstants.haveCssAssertion,'border-color','rgb(230, 88, 0)')
    }

    nextButtonDisabledVerification() {
      cy.get(applyMetadataPageLocators.nextButtonDisabledVerification).should(assertionConstants.haveAttributeAssertion, 'class', 'opacity-05 pt-button ng-star-inserted')
    }

    modalityDropdownfieldClick() {
      cy.get(applyMetadataPageLocators.modalityDropdownfield).eq(0).click({ force: true })
    }

    dxrTagClick(){
      cy.get(applyMetadataPageLocators.addTagFromList).eq(2).click()
    }

    modalityFieldWithRedBorder(){
      cy.get(applyMetadataPageLocators.fieldsWithRedBorder).first().should(assertionConstants.haveCssAssertion,'border-color','rgb(230, 88, 0)')
    }

    severityFiledWithRedMark(){
      cy.get(applyMetadataPageLocators.WaterMarks).last().find('span').should(assertionConstants.haveCssAssertion,'border-color','rgb(230, 88, 0)')
    }
 
    serviceContextFieldsWithRME() {
        cy.get(applyMetadataPageLocators.serviceContextFields).click()
        cy.wait(2000) 
    }

    serviceContextRMEOptionClick(){
        cy.get(applyMetadataPageLocators.serviceContextFields).eq(0).click()
        cy.contains(serviceContextRMEOption).click()
    }

    addTagOptionClick(){
        cy.get(applyMetadataPageLocators.addTagOption).click()
    }

    addTagPopUpVisible(){
        cy.get(applyMetadataPageLocators.addTagPopUp).should(assertionConstants.beVisibleAssertion)
    }

    withOutKeywordOptionVisible(){
        cy.get(applyMetadataPageLocators.withOutKeywordOption).should(assertionConstants.beVisibleAssertion)
    }

    withKeywordOptionVisible(){
        cy.get(applyMetadataPageLocators.withkeywordOption).should(assertionConstants.beVisibleAssertion)
    }

    withOutKeywordOptionClick(){
        cy.get(applyMetadataPageLocators.withOutKeywordOption).click()
    }

    withOutKeywordSerchOptionClick(){
        cy.get(applyMetadataPageLocators.withOutKeywordSerchOption).click()
    }

    tagValuesUnderDropdownVisible(){
        cy.get(applyMetadataPageLocators.tagValuesUnderDropdown).should(assertionConstants.beVisibleAssertion)
    }

    tagValuesUnderDropdownClick(){
        cy.get(applyMetadataPageLocators.tagValuesUnderDropdown).first().click()
    }

    withOutKeywordSerchOptionWithSelectedTagText(){
        cy.get(applyMetadataPageLocators.withOutKeywordSerchOption).find('dls-layout-container').children('span').should(assertionConstants.haveTextAssertion,'AWS').and((assertionConstants.beVisibleAssertion))
    }

    addTagPlusIconClick(){
        cy.get(applyMetadataPageLocators.addTagPlusIcon).click()
    }

    addedTagsSectionWithAddedTags(){
        cy.get(applyMetadataPageLocators.addedTagsSection).should(assertionConstants.containAssertion,'AWS')
    }

    withKeywordOptionClick(){
        cy.get(applyMetadataPageLocators.withkeywordOption).click()
    }

    withKeywordOptionSelected(){
        cy.get(applyMetadataPageLocators.withkeywordOption).should(assertionConstants.haveClassAssertion,'shadow-none pt-button pt-primary')
    }

    fieldsUnderWithkeywordOptionVisible(){
       cy.get(applyMetadataPageLocators.keywordField).should(assertionConstants.beVisibleAssertion)
       cy.get(applyMetadataPageLocators.operatorField).should(assertionConstants.beVisibleAssertion)
       cy.get(applyMetadataPageLocators.valueField).should(assertionConstants.beVisibleAssertion)
    }

   operatorDropdownClick(){
    cy.get(applyMetadataPageLocators.operatorField).click()
   }

   operatorOptionsVisible(){
    cy.get(applyMetadataPageLocators.dropdownOptions).eq(0).should(assertionConstants.containAssertion,' ==').and(assertionConstants.beVisibleAssertion)
    cy.get(applyMetadataPageLocators.dropdownOptions).eq(1).should(assertionConstants.containAssertion,' >=').and(assertionConstants.beVisibleAssertion)
    cy.get(applyMetadataPageLocators.dropdownOptions).eq(2).should(assertionConstants.containAssertion,' <=').and(assertionConstants.beVisibleAssertion)
   }

   keywordDropdownOptionClick(){
    cy.get(applyMetadataPageLocators.keywordField).click()
   }

   valueDropdownOptionClick(){
    cy.get(applyMetadataPageLocators.valueField).click()
   }

   dropdownOptionUnderDiffFiledsClick(){
    cy.get(applyMetadataPageLocators.dropdownOptions).eq(0).click()
   }

   keywordfieldWithSelectedValue(){
    cy.get(applyMetadataPageLocators.keywordField).find('dls-layout-container').children('span').should(assertionConstants.containAssertion,'FV').and((assertionConstants.beVisibleAssertion))
   }

   operatorfieldWithSelectedValue(){
    cy.get(applyMetadataPageLocators.operatorField).find('dls-layout-container').children('span').should(assertionConstants.containAssertion,'==').and((assertionConstants.beVisibleAssertion))
   }
  
   valuefieldWithSelectedValue(){
    cy.get(applyMetadataPageLocators.valueField).find('dls-layout-container').children('span').should(assertionConstants.containAssertion,'DICOM and Interoperability').and((assertionConstants.beVisibleAssertion))
   }

   addedKeywordValueOperatorAddedTagTextArea(){
    cy.get(applyMetadataPageLocators.addedTagsSection).should(assertionConstants.containAssertion,'FV ==DICOM and Interoperability')
   }

   doneButtonClick(){
    cy.get(applyMetadataPageLocators.doneButton).click()
   }

   selectedTagValueUnderAddtagSectionWithRemoveableTokonVisible(){
    cy.get(applyMetadataPageLocators.tagValueUnderAddtagSection).eq(0).children('span').should(assertionConstants.haveClassAssertion,'pt-token-label').and(assertionConstants.beVisibleAssertion)
   }

   addedTagValueUnderAddtagSectionWithRemoveableTokonVisible(){
    cy.get(applyMetadataPageLocators.tagValueUnderAddtagSection).eq(1).children('span').should(assertionConstants.haveClassAssertion,'pt-token-label').and(assertionConstants.beVisibleAssertion)
   }

   selectiongAllUnderRelevnceClick(){
    cy.get(applyMetadataPageLocators.selectiongAllUnderRelevnce).eq(0).click({force: true})
   }

   nextButtonClick(){
    cy.get(applyMetadataPageLocators.nextButtonDisabledVerification).click()
   }


}

export default ApplyMetadata;