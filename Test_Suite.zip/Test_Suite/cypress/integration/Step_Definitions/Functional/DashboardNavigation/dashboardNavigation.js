/// <reference types="Cypress" />
/// <reference types = 'cypress-tags' />

import "../../../../support/index"
import { Then } from "cypress-cucumber-preprocessor/steps";
import NavigationPanel from "../../../../support/pageObjects/pages/Dashboard/NavigationPanel";
import { printTimestamp } from '../../../../support/commands';

const navigationPanel = new NavigationPanel();

Then("Application Name: {string} should be Displayed", (pagetitle) => {
   navigationPanel.displayAppName(pagetitle)
   console.log(printTimestamp(), 'Application Name displayed')
});

Then("Close Application", () => {
   cy.log('Test case executed successfully')
   console.log(printTimestamp(), 'Test case executed successfully')
});


