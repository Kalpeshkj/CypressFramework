/// <reference types="Cypress" />  
/// <reference types = 'cypress-tags' />    

import "../../../../support/index"
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import IncludeKnowledge from "../../../../support/pageObjects/pages/PatternAuthoring/includeKnowledgepageObj";
const includeKnowledge = new IncludeKnowledge();

And("Drop down with option should be available next to common search box", () => {
    includeKnowledge.dropDownNextToCommonSearchVisible()
    console.log(printTimestamp(), 'Drop down with option available next to common search box')
}); 

And("By default, All should be displayed in drop down", () => {
    includeKnowledge.dropDownNextToCommonSearchWithAllTextVisible()
    console.log(printTimestamp(), 'By default, All displayed in drop down')
});

And("Common Search text box with search icon should be displayed", () => {
    includeKnowledge.filterForKeywordWithSearchIcon()
    includeKnowledge.searchIconInCommonSearchVisible()
    console.log(printTimestamp(), 'Common Search text box with search icon displayed')
});

And("In text box “Search by keyword” should be displayed", () => {
    includeKnowledge.commonSearchBoxWithTextVisible()
    console.log(printTimestamp(), 'In text box “Search by keyword” displayed')
});

When("User click on drop down", () => {
    includeKnowledge.dropDownNextToCommonSearchClick()
    console.log(printTimestamp(), 'clicked on drop down')
});

Then("Name,Description,Cause,Solution,Symptoms,Parts,Tags Options displayed", () => {
    includeKnowledge.dropDownOptionsUnderDropdownNextToCommonSearchVisible()
    console.log(printTimestamp(), 'Name,Description,Cause,Solution,Symptoms,Parts,Tags Options displayed')
});

When("User Enter keyword-word with space in common filter text box by keeping “All” in drop down option", () => {
    includeKnowledge.filterForKeywordTypeMotor()
    cy.wait(3000)
    includeKnowledge.searchIconInCommonSearchClick()
    console.log(printTimestamp(), 'User Entered keyword/word with space in common filter text box by keeping “All” in drop down option')
});

Then("As per searched result,Showing records of total records found should get displayed in grid", () => {
    includeKnowledge.recordsCount().invoke("text")
        .then((text) => {
            expect(text).to.contain('records found')
        })
    console.log(printTimestamp(), 'As per searched result,Showing records of total records found gets displayed in grid')
});

And("Searched result should be available in grid", () => {
    includeKnowledge.searchedResultsIngridVisible()
    console.log(printTimestamp(), 'Searched result available in grid')
});

And("Search result should be displayed as per content search", () => {
    includeKnowledge.searchedResultsAsPerContentIngridVisible()
    console.log(printTimestamp(), 'Search result displayed as per content search')
});

And("Searched result should be match with generic search api", () => {

    console.log(printTimestamp(), 'Searched result match with generic search api')
});

When("User Click on “X” icon of search text box", () => {
    includeKnowledge.xmarkInSearchTextBoxClick()
    console.log(printTimestamp(), 'User Clicked on “X” icon of search text box')
});

Then("entered text in search box should get cleared", () => {
    includeKnowledge.filterForKeywordWithOutSearchedWord()
    console.log(printTimestamp(), 'entered text in search box get cleared')
});

Then("All Data should be displayed", () => {
    includeKnowledge.searchedResultsIngridVisible()
    console.log(printTimestamp(), 'All Data displayed')
});

When("Select attribute from drop down option and write keyword in search box", () => {
    includeKnowledge.dropDownNextToCommonSearchClick()
    includeKnowledge.nameOptionClick()
    includeKnowledge.filterForKeywordWithSearchIconType()
    console.log(printTimestamp(), 'Selected attribute from drop down option and write keyword in search box')
});

Then("Filtered result should be available in grid,If data not available based on applied filter "
    + "then “No Data available” message should be displayed", () => {
        includeKnowledge.searchedResultsIngridVisible()
        console.log(printTimestamp(), "Filtered result available in grid,If data not available based on applied filter"
            + "then “No Data available” message displayed")
    });

And("Filtered result should be match with generic search api", () => {

    console.log(printTimestamp(), 'Filtered result match with generic search api')
});

When("Repeat above steps and verify search functionality after clicking on select all", () => {
    includeKnowledge.selectAllCheckBoxClick()
    cy.wait(1000)
    includeKnowledge.filterForKeywordTypeError()
    includeKnowledge.searchIconInCommonSearchClick()
    cy.wait(1000)
    console.log(printTimestamp(), 'Repeated above steps and verified search functionality after clicking on select all')
});

And("After clicking on select all All data should be displayed Common search functionality should be work as expected", () => {
    includeKnowledge.searchedResultsIngridVisible()
    console.log(printTimestamp(), 'After clicking on select all All data displayed Common search functionality should be work as expected')
});

Then("User Apply column level filter on top of available searched result", () => {
    includeKnowledge.columnLevelTagsFiltercolumnLevelTagsFilterClick()
    includeKnowledge.diaomAndInteroperabilityTagClick()
    includeKnowledge.applyButtonClick()
    console.log(printTimestamp(), 'User Applied column level filter on top of available searched result')
});

When("User enter data in column level filter", () => {
    includeKnowledge.nameFilterType()
    includeKnowledge.searchIconInNameFilterClick()
    cy.wait(1000)
    console.log(printTimestamp(), 'User entered data in column level filter')
});

And("filtered data should be available", () => {
    includeKnowledge.searchedResultsIngridVisible()
    console.log(printTimestamp(), 'filtered data available')
});

When("Select attribute from dropdown option and write keyword in search box", () => {
    includeKnowledge.dropDownNextToCommonSearchClick()
    includeKnowledge.descriptionDropDownOptionsUnderDropdownNextToCommonSearchClick()
    includeKnowledge.filterForKeywordTypeSupply()
    includeKnowledge.searchIconInCommonSearchClick()
    cy.wait(1000)
    console.log(printTimestamp(), 'Selects attribute from drop down option and write keyword in search box')
});

Then("Search result should be displayed Filtered value in column level should get cleared", () => {
    includeKnowledge.searchedResultsIngridVisible()
    includeKnowledge.nameFilterWithoutText()
    console.log(printTimestamp(), 'Search result displayed Filtered value in column level get cleared')
});

And("Repeat above steps by covering all dropdown options available in common filter text box", () => {
    includeKnowledge.dropDownNextToCommonSearchClick()
    includeKnowledge.causeDropDownOptionsUnderDropdownNextToCommonSearchClick()
    includeKnowledge.filterForKeywordTypeError()
    includeKnowledge.searchIconInCommonSearchClick()
    cy.wait(1000)
    includeKnowledge.columnLevelTagsFiltercolumnLevelTagsFilterClick()
    includeKnowledge.allTagClick()
    includeKnowledge.applyButtonClick()
    includeKnowledge.searchedResultsIngridVisible()
    includeKnowledge.dropDownNextToCommonSearchClick()
    includeKnowledge.partsDropDownOptionsUnderDropdownNextToCommonSearchClick()
    includeKnowledge.filterForKeywordTypeScrews()
    includeKnowledge.searchIconInCommonSearchClick()
    cy.wait(1000)
    includeKnowledge.searchedResultsIngridVisible()
    includeKnowledge.dropDownNextToCommonSearchClick()
    includeKnowledge.solutionDropDownOptionsUnderDropdownNextToCommonSearchClick()
    includeKnowledge.filterForKeywordTypeVoltage()
    includeKnowledge.searchIconInCommonSearchClick()
    cy.wait(1000)
    includeKnowledge.searchedResultsIngridVisible()
    includeKnowledge.columnLevelTagsFiltercolumnLevelTagsFilterClick()
    includeKnowledge.nameFilterKnowledgeType()
    includeKnowledge.searchIconInNameFilterClick()
    cy.wait(1000)
    includeKnowledge.searchedResultsIngridVisible()
    includeKnowledge.dropDownNextToCommonSearchClick()
    includeKnowledge.symptomsDropDownOptionsUnderDropdownNextToCommonSearchClick()
    includeKnowledge.filterForKeywordTypeSympton1()
    includeKnowledge.searchIconInNameFilterClick()
    cy.wait(1000)
    includeKnowledge.columnLevelTagsFiltercolumnLevelTagsFilterClick()
    includeKnowledge.allTagClick()
    includeKnowledge.applyButtonClick()
    cy.wait(1000)
    includeKnowledge.firstRecordcheckedcheckBoxUnchecked()
    cy.wait(1000)
    includeKnowledge.searchedResultsIngridVisible()
    includeKnowledge.dropDownNextToCommonSearchClick()
    includeKnowledge.tagsDropDownOptionsUnderDropdownNextToCommonSearchClick()
    includeKnowledge.filterForKeywordTypeDicom()
    includeKnowledge.searchIconInNameFilterClick()
    includeKnowledge.searchedResultsIngridVisible()
    console.log(printTimestamp(), 'Repeats above steps by covering all drop down options available in common filter text box')
});


