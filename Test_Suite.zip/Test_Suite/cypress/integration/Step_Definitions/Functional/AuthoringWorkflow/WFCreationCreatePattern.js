/// <reference types="Cypress" /> 
/// <reference types = 'cypress-tags' />
import "../../../../support/index"
import { When, Then, And } from "cypress-cucumber-preprocessor/steps"
import { printTimestamp } from '../../../../support/commands';
import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();

Then("Enter Pattern Information", () => {
    createPattern.patternNameType()
    createPattern.descriptionType()
    createPattern.orderOfExecutionType()
    console.log(printTimestamp(), 'Entered Pattern Information')
});

When("User Click on Import Data Model", () => {
    createPattern.importDataModelClick()
    console.log(printTimestamp(), 'Clicked on Import Data Model')
});

Then("Select any Data Model from drop down option", () => {
    createPattern.dataModelDropArrowClick()
    createPattern.dataModelCommonOptionDropArrowClick()
    createPattern.eventLogDataModelClick()
    createPattern.dataModelDropArrowClick()
    console.log(printTimestamp(), 'Selects any Data Model from drop down option')
});

When("User Click on Add Condition", () => {
    createPattern.addConditionTabClick()
    console.log(printTimestamp(), 'Clicked on Add Condition')
});

Then("User should be able to Add Condition", () => {
    createPattern.addConditionPlusIconClick()
    cy.wait(2000)
    createPattern.formDataModelClick()
    cy.wait(1000)
    createPattern.eventLogAttributeClick()
    createPattern.additionalInfoAttributeClick()
    createPattern.operatorForEventOneClick()
    createPattern.equaltoOperatorClick()
    createPattern.ValueForTestOneType()
    console.log(printTimestamp(), 'User able to Add Condition')
});

When("User Click on Add Action", () => {
    createPattern.addActionClick()
    console.log(printTimestamp(), 'Clicked on Add Action')
});

Then("User should be able to add action", () => {
    createPattern.addActionPlusIconClick()
    createPattern.raiseAlertOptionClick()
    createPattern.patternNameDetailsOfUserOne()
    createPattern.importedDataModelDetailsOfUserOne()
    createPattern.addedConditionDetailsOfUserOne()
    createPattern.getPatternName()
    console.log(printTimestamp(), 'added action')
});

When("User Launch DAW application as User2", () => {
    cy.reload()
    cy.wait(3000)
    console.log(printTimestamp(), 'Launched DAW application as User2')
});

And("Clicks on three dots of my pattern", () => {
    createPattern.myPatternThreeDotsClick()
    console.log(printTimestamp(), 'Clicked on three dots of my pattern')
});

Then("Create Pattern option is displayed", () => {
    createPattern.createPatternVisible()
    console.log(printTimestamp(), 'Create Pattern option is displayed')
});

When("User Click on Create Pattern", () => {
    createPattern.createPatternButtonClick()
    cy.wait(5000)
    console.log(printTimestamp(), 'Clicked on Create Pattern')
});

Then("Details filled by User1 should not be available for User2", () => {
    createPattern.patternNameDetailsOfUserOneNotExist()
    createPattern.importedDataModelDetailsOfUserOneNotExist()
    createPattern.addedConditionDetailsOfUserOneNotExist()
    createPattern.deletePattern()
    createPattern.deleteOption().click({ force: true });
    createPattern.okButtonClick()
    cy.wait(3000)
    console.log(printTimestamp(), 'Details filled by User1 not available for User2')
});

And("Close DAW application", () => {
    cy.DeleteWorkflow()
    console.log(printTimestamp(), 'Closed DAW application')
});
