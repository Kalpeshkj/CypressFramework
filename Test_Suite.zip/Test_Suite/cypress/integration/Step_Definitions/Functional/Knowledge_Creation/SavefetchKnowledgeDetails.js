/// <reference types="Cypress" />
/// <reference types='cypress-tags' />

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';

import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();
import IncludeKnowlegePage from "../../../../support/pageObjects/pages/PatternAuthoring/includeKnowledgepageObj";
const includeKnowlegePage = new IncludeKnowlegePage();

When("User creates new workflow and fills pattern and apply metadata details", () => {
    cy.createPattern()
    createPattern.nextButtonClick()
    cy.ApplyMetaDetaPageCompletion()
    console.log(printTimestamp(), ' New knowledge workflow created')
});

Then("User clicks on Next button from apply metadata page", () => {
    createPattern.nextButtonClick()
    console.log(printTimestamp(), ' Next button clicked')
});

And("User should be able to navigate to Include Knowledge step", () => {
    createPattern.includeKnowledgeHeadingActiveVerification()
    console.log(printTimestamp(), ' Navigated to Include Knowledge step')
});

When("User Click on show all checkbox or search any keyword", () => {
    includeKnowlegePage.showAllCheckboxClick()
    console.log(printTimestamp(), ' Clicked on show all checkbox')
});

Then("Selects multiple knowledge and click on Save as Draft", () => {
    includeKnowlegePage.multipleKnowledgeSelectionFromRecords()
    includeKnowlegePage.saveAsDraftButtonClick()
    console.log(printTimestamp(), ' Selected multiple knowledge and clicked on Save as Draft')
});

Then("Relaunch DAW application and verify saved details", () => {
    cy.reload()
    createPattern.includeKnowledgeHeadingActiveVerification()
    includeKnowlegePage.savedKnowledgeDetailsVisible()
    console.log(printTimestamp(), ' DAW application relaunched and verified saved details')
});

Then("Verifies data in pattern, my pattern and Pattern details view page", () => {
    createPattern.patternDashboardClick()
    createPattern.patternNameSearch()
    console.log(printTimestamp(), ' Verified data in pattern dashboard')
});

Then("User clones saved pattern", () => {
    createPattern.threeDotsGridButtonClickAndClone()
    cy.DeleteDynamicPattern()
    cy.wait(3000)
    console.log(printTimestamp(), ' Cloned saved pattern')
});

And("Verifies previous entered pattern name and prepopulated cloned pattern name should match", () => {
    createPattern.clinedPatternNameVisibleInNewCreatedPattern()
    console.log(printTimestamp(), ' Verified previous entered pattern name and prepopulated cloned pattern name matched')
});