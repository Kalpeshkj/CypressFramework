/// <reference types="Cypress" />
/// <reference types = 'cypress-tags' />    

import "../../../../support/index"
import { When, Then } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import CreateKnowledge from "../../../../support/pageObjects/pages/KnowledgeAuthoring/CreateKnowledge";
const createKnowledge = new CreateKnowledge();

When("User Navigate to newly created knowledge workflow", () => {
    createKnowledge.knowledgeOptionArrowClick()
    createKnowledge.addKnowledgeWorkflowButtonClick()
    cy.wait(3000)
    console.log(printTimestamp(), 'Navigated to newly created knowledge workflow')
});

And("Add details in Knowledge Information section", () => {
    createKnowledge.knowledgeNameTextBoxType()
    createKnowledge.descriptionFiledTextBoxType()
    console.log(printTimestamp(), 'Added details in Knowledge Information section')

});

And("Expand causes and solutions section and add cause", () => {
    createKnowledge.causeAndSolutionOptionClick()
    createKnowledge.addCauseButtonClick()
    createKnowledge.causeOneInputBoxType()
    console.log(printTimestamp(), 'Expanded causes and solutions section and add cause')
});

When("User Click on Add Solution", () => {
    createKnowledge.addSolutionButtonClick()
    console.log(printTimestamp(), 'Clicked on Add Solution')
});

Then("Solution for cause should get added", () => {
    createKnowledge.addedSolutionVisible()
    console.log(printTimestamp(), 'Solution for cause  gets added')
});

And("Parts icon should be available at left botton corner of solution rich text editor", () => {
    createKnowledge.PartsIconVisible()
    console.log(printTimestamp(), 'Parts icon available at left botton corner of solution rich text editor')
});

When("User Click on parts  icon", () => {
    createKnowledge.PartsIconClick()
    console.log(printTimestamp(), 'Clicked on parts icon')
});

And("Add Part pop up should be displayed", () => {
    createKnowledge.addPartPopUpVisible()
    console.log(printTimestamp(), 'Add Part pop up displayed')
});

And("Add Part title should be displayed", () => {
    createKnowledge.addPartTitleVisible()
    console.log(printTimestamp(), 'Add Part title displayed')
});

And("12 NC column name - text box  with watermark Part Name should be displayed", () => {
    createKnowledge.twelveNCTextVisible()
    createKnowledge.twelveNCTextBoxVisible()
    console.log(printTimestamp(), '12 NC column name - text box  with watermark Part Name displayed')

});

And("Description column name - text box with waternark with Description should be displayed", () => {
    createKnowledge.descriptionTextVisible()
    createKnowledge.descriptionTextBoxVisible()
    console.log(printTimestamp(), 'Description column name - text box with waternark with Description  displayed')

});

And("Remove X icon disabled,Add + icon enabled ,Cancel button enabled,Done button disabled", () => {
    createKnowledge.removeXIconDisabled()
    createKnowledge.addPlusIconEnabled()
    createKnowledge.cancelButtonEnabled()
    createKnowledge.doneButtonDisabled()
    console.log(printTimestamp(), 'Remove X icon disabled,Add + icon enabled ,Cancel button enabled,Done button disabled')

});

And("Red color info icon with message “Validate the part information before proceeding” should be displayed inline with buttons", () => {
    createKnowledge.redColorInfoIconVisible()
    createKnowledge.partValidationMessageVisible()
    console.log(printTimestamp(), 'Red color info icon with message “Validate the part information before proceeding” displayed inline with buttons')
});

And("Maximumm 12 alphanumeric value should be allowed ,User should not be able to add data more than 12 characters", () => {
    createKnowledge.twelveNCTextBoxWithMaxTwelveCharacters()
    console.log(printTimestamp(), 'Maximumm 12 alphanumeric value allowed ,User not  able to add data more than 12 characters')
});

And("Maximumm 1000 alphanumeric value should be allowed     User should not be able to add data more than 1000 characters", () => {

    createKnowledge.descriptionTextBoxWithMaxThousandCharacters()
    console.log(printTimestamp(), 'Maximumm 1000 alphanumeric value allowed User not able to add data more than 1000 characters')
});

And("User should be able to add data in 12NC and Description", () => {
    createKnowledge.twelveNCTextBoxTypeSdd()
    createKnowledge.descriptionTextBoxTypebdd()
    console.log(printTimestamp(), 'User able to add data in 12NC and Description')
});

When("User click on + icon", () => {
    createKnowledge.addPlusIconClick()
    console.log(printTimestamp(), 'clicked on + icon')
});

Then("Next row should get added", () => {
    createKnowledge.secondRowTwelveNCTextBoxVisible()
    createKnowledge.secondRowDescriptionTextBoxVisible()
    console.log(printTimestamp(), 'Next row gets added')
})
When("User entered duplicate 12NC Part  Name", () => {
    createKnowledge.secondTwelveNCTextBoxType()
    createKnowledge.secondDescriptionTextBoxClick()
    console.log(printTimestamp(), 'entered duplicate 12NC Part Name')
});

Then("text box should get highlighted with red border", () => {
    createKnowledge.secondTwelveNCTextBoxInRedColor()
    console.log(printTimestamp(), 'text box gets highlighted with red border')
});

And("Validation Message should be displayed Red info icon with Part already added,please change.", () => {
    createKnowledge.redColorInfoIconWithValidationMessageVisible()
    createKnowledge.ValidationMessageForDuplicateNameVisible()
    console.log(printTimestamp(), 'Validation Message displayed Red info icon with Part already added,please change.')
});

When("User add more than one row  in Add Parts", () => {
    createKnowledge.secondTwelveNCTextBoxCleared()
    createKnowledge.addPlusIconToAddRoClick()
    createKnowledge.addPlusIconToAddRoClick()
    console.log(printTimestamp(), 'adds more than one row  in Add Parts')
});

Then("Remove X icon should get enabled", () => {
    createKnowledge.removeXIconEnabled()
    console.log(printTimestamp(), 'Remove X icon get enabled')
});

When("When 12NC and Description data are added for all added text boxes", () => {
    createKnowledge.secondRowtwelveNCTextBoxForType()
    createKnowledge.secondRowDescriptionTextBoxType()
    createKnowledge.thirdRowTwelveNCTextBoxForType()
    createKnowledge.thirdRowDescriptionTextBoxType()
    createKnowledge.fourthRowTwelveNCTextBoxForType()
    createKnowledge.fourthRowDescriptionTextBoxType()
    console.log(printTimestamp(), '12NC and Description data are added for all added text boxes')

});

Then("Done button should be enabled   Note : 12NC and Description fields are mandatory filled.", () => {
    createKnowledge.doneButtonEnabled()
    console.log(printTimestamp(), 'Done button is enabled ')
});

Then("close DAW application", () => {
    cy.DeleteWorkflow()
    cy.log('Test case executed successfully')
    console.log(printTimestamp(), 'Test case executed successfully')

});


























