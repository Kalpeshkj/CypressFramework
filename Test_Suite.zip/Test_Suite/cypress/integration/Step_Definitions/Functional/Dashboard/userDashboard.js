/// <reference types="Cypress" />
/// <reference types='cypress-tags' />

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';

import UserDashboard from "../../../../support/pageObjects/pages/Dashboard/UserDashboard";
const userDashboard = new UserDashboard();
import AssertionConstants from "../../../../support/pageObjects/pages/AssertionConstants";
const constants = new AssertionConstants();

When("User Clicks on username at right corner of page and verify settings option is available", () => {
    userDashboard.settingsDropdownClick()
    console.log(printTimestamp(), 'Clicked on userDashboard and navigated to User management section')
});

Then("Settings option should be available", () => {
    userDashboard.settinsOptionVisible()
    console.log(printTimestamp(), 'Verified available buttons present in user Management dashboard')
});

And("Relaunches the application", () => {
    cy.reload()
    console.log(printTimestamp(), 'Verified total number of records and entries per page available')
});

When("User clicks on settings button", () => {
    userDashboard.settingsDropdownClick()
    userDashboard.settinsOptionClick()
    console.log(printTimestamp(), ' Clicked on settings button')
});

Then("User should be navigated to User dashboard page", () => {
    userDashboard.userManagementButtonClick()
    userDashboard.usersDasboardNavigationTextVisible()
    console.log(printTimestamp(), ' Navigated to User dashboard page')
});

And("Verifies UI for User dashboard", () => {
    userDashboard.tabsVisible()
    userDashboard.deleteUserButtonVisible()
    userDashboard.addUserButtonVisible()
    userDashboard.entriesPerPageVerification()
    userDashboard.showingPerPageVerification()
    console.log(printTimestamp(), 'Test Case Executed Successfully')
});

And("All the datagrid column values are present in user dashboard", () => {
    userDashboard.userEmailColumnVisible()
    userDashboard.userNameColumnVisible()
    userDashboard.userNameColumnSortedVisible()
    userDashboard.groupameColumnVisible()
    userDashboard.createdonColumnVisible()
    userDashboard.createdbyColumnVisible()
    console.log(printTimestamp(), ' All the datagrid column values are present')
});

And("Verify the User Name column values that should not be as hyperlink", () => {
    userDashboard.hyperlinkNotVisibleInRecords()
    console.log(printTimestamp(), 'Verified User Name column values')
});