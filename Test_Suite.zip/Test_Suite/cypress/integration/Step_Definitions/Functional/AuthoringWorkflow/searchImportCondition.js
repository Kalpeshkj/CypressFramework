/// <reference types="Cypress" />
/// <reference types='cypress-tags' />

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();

Then("Dropdown option should available next to common search box", () => {
    createPattern.dropdownatSearchVisible()
    console.log(printTimestamp(), ' Dropdown option displayed')
});
 
And("By default All should be displayed in drop down", () => {
    createPattern.byDefaultAllisVisibleatSearch()
    console.log(printTimestamp(), ' By default All displayed')
});

When("Clicks on drop down and verifies Attributes, Condition, Data Models, Description, Name, Tags are available", () => {
    createPattern.dropdownValuesVerification()
    console.log(printTimestamp(), ' Verified Attributes by clicking on dropdown')
});

Then("Common search text box should be available", () => {
    createPattern.searchBoxVisible()
    console.log(printTimestamp(), ' Common search box available')
});

When("User clicks on 'X' icon and entered text should gets cleared", () => {
    createPattern.crossMarkClick()
    createPattern.searchBoxTestVisible()
    console.log(printTimestamp(), ' Data got cleared after click of X')
});

And("Clicks on Show all checkbox", () => {
    createPattern.showAllCheckboxClick()
    console.log(printTimestamp(), ' Show all checkbox clicked')
});

Then("Total count of result should be displayed", () => {
    createPattern.recordsFoundTextVerification()
    console.log(printTimestamp(), ' Total count displayed')
});

And("Results should be displayed after user select attribute and able to write keyword in searchbox simultaneously", () => {
    createPattern.attributeClick()
    createPattern.searchBoxType()
    console.log(printTimestamp(), ' Result displayed')
});

When("User clicks on search button", () => {
    createPattern.searchButtonClick()
    console.log(printTimestamp(), ' Clicked search button')
});

Then("Filtered result should be available in grid", () => {
    createPattern.searchedDataFoundVerification()
    console.log(printTimestamp(), ' Filtered data displayed')
});

And("User should able to select Show All checkbox", () => {
    createPattern.showAllCheckboxClick()
    console.log(printTimestamp(), ' Show all checkbox selected')
});

And("All data should gets displayed", () => {
    createPattern.showAllResultVerification()
    console.log(printTimestamp(), ' All data displayed')
});

And("User should be able to apply filter at column level on to of available filtered or searched result", () => {
    createPattern.attributeClick()
    createPattern.searchBoxType()
    createPattern.descriptionFilter()
    createPattern.nameColumnFilter()
    createPattern.dataModelFilter()
    createPattern.tagsFilter()
    console.log(printTimestamp(), ' Apply filer functionality verified')
});

And("User enters data in column level filter, filtered data should be available", () => {
    createPattern.patternFilterType()
    createPattern.descriptionFilterType()
    createPattern.dataModelsFilterType() 
    createPattern.tagsFilterType()
    console.log(printTimestamp(), ' Filtered data displayed')
});
