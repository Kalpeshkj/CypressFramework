/// <reference types="Cypress" />
/// <reference types='cypress-tags' />

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';

import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
import NavigationPanel from "../../../../support/pageObjects/pages/Dashboard/NavigationPanel";
import TagDashboard from "../../../../support/pageObjects/pages/Dashboard/TagDashboard";
const tagDashboard = new TagDashboard();
const navigationPanel = new NavigationPanel();
const createPattern = new CreatePattern();

When("Verifies Application Name is displayed at left corner of top header", () => {
    navigationPanel.displayNameVisible();
    console.log(printTimestamp(), ' Application Name displayed')
});

Then("Verifies User Name is displayed at right corner of top header", () => {
    tagDashboard.userNameisVisible()
    console.log(printTimestamp(), ' User Name displayed')
});

Then("Verifies that by default left panel in expanded state", () => {
    navigationPanel.leftPanelExpandedVisible()
    console.log(printTimestamp(), ' By default left panel was in expanded state')
});

And("Verifies left panel", () => {
    createPattern.dashboardButtonVisible()
    navigationPanel.myPatternOptionWithThreeDotsVisible()
    navigationPanel.knowledgeSectionCollapsedVisible()
    navigationPanel.rulesSectionCollapsedVisible()
    navigationPanel.modelsSectionCollapsedVisible()
    navigationPanel.plotsSectionCollapsedVisible()
    console.log(printTimestamp(), ' Left panel verified')
});

Then("Verifies breadcrumb available in header", () => {
    createPattern.breadcrumbValuesVisible()
    console.log(printTimestamp(), ' Verified breadcrumb available in header')
});

When("User Clicks on collapsible icon of Pattern option and Verify left pane", () => {
    navigationPanel.patternsSectionClick()
    console.log(printTimestamp(), ' Clicked on collapsible icon of Pattern option')
});

Then("Pattern, Knowledge, Rules, Models and Plots section should be visible", () => {
    navigationPanel.patternSectionCollapsedVisible()
    navigationPanel.knowledgeSectionCollapsedVisible()
    navigationPanel.rulesSectionCollapsedVisible()
    navigationPanel.modelsSectionCollapsedVisible()
    navigationPanel.plotsSectionCollapsedVisible()
    console.log(printTimestamp(), ' Pattern, Knowledge, Rules, Models and Plots section displayed')
});

Then("Verifies breadcrumb after collapsing all options available in left pane", () => {
    createPattern.breadcrumbValuesVisible()
    console.log(printTimestamp(), ' Verified breadcrumb after collapsing all options')
});

When("User Expand 'Patterns' option from left pane and verify available options", () => {
    navigationPanel.patternsSectionClick()
    console.log(printTimestamp(), ' User Expanded "Patterns" option from left pane')
});

Then("Dashboard, My Patterns and Review Dashboard should be displayed", () => {
    createPattern.dashboardButtonVisible()
    navigationPanel.myPatternOptionWithThreeDotsVisible()
    navigationPanel.myReviewDashboardSectionVisible()
    console.log(printTimestamp(), ' Dashboard, My Dashboard and Review Dashboard displayed')
});

When("User Expands My Pattern section from left pane", () => {
    navigationPanel.myPatternsSectionClick()
    console.log(printTimestamp(), ' Expanded My Pattern section')
});

Then("Dashboard and Workflows should be displayed", () => {
    createPattern.MyPatternDashboardVisible()
    createPattern.workflowsVisible()
    console.log(printTimestamp(), '  Dashboard and Workflows displayed')
});

When("User Clicks on three vertical dots of My Patterns and Verify available options", () => {
    createPattern.myPatternThreeDotsClick()
    console.log(printTimestamp(), ' Clicked on three vertical dots of My Patterns and Verified available options')
});

Then("Verifies Create Pattern Option should displayed", () => {
    createPattern.createPatternVisible()
    console.log(printTimestamp(), ' Create Pattern Option displayed')
});

When("User Clicks on Create Pattern and Verify Left Pane, Grid and Breadcrumb", () => {
    createPattern.createPatternClick()
    createPattern.NewPatternCreatedVerification()
    createPattern.breadcrumbValuesVisible()
    console.log(printTimestamp(), ' Clicked on Create Pattern and Verified Left Pane, Grid and Breadcrumb')
});

Then("Authoring Workflow should be displayed under My Patterns", () => {
    createPattern.patternVisibleInDashboard()
    console.log(printTimestamp(), ' Authoring Workflow displayed')
});

And("Verifies In Grid, Create Pattern screen should be displayed where create pattern option should be in selected state", () => {
    createPattern.createPatternHeadingActiveVerification()
    console.log(printTimestamp(), ' Create Pattern screen displayed')
});

And("Verifies In header,In header Home > Patterns > My Patterns > Authoring Workflow Name should be displayed", () => {
    createPattern.breadcrumbValuesVisible()
    console.log(printTimestamp(), ' Home > Patterns > My Patterns > Authoring Workflow Name Displayed')
});

And("Verify Authoring Workflow name in breadcrumb", () => {
    createPattern.NewPatternCreatedVerification()
    console.log(printTimestamp(), ' Authoring Workflow name in breadcrumb verified')
});

When("User clicks on Authoring Workflow then verify Rename and Delete options available for created Authoring Workflow", () => {
    createPattern.NewPatternCreatedThreeDotsClickAndVerification()
    console.log(printTimestamp(), ' clicked on Authoring Workflow then Rename and Delete options verified')
});

Then("User Navigate to backward and forward using breadcrumbs", () => {
    createPattern.myPatternPageNavigation()
    console.log(printTimestamp(), ' Navigate to backward and forward using breadcrumbs')
});

When("User Expand Patterns, My Patterns and select Authoring Workflow", () => {
    createPattern.newlyCreatedPatternVisit()
    console.log(printTimestamp(), ' User Expanded Patterns, My Patterns and select Authoring Workflow')
});

Then("Verifies arrow mark available at bottom for left pane", () => {
    navigationPanel.ArrowMarkVisible()
    console.log(printTimestamp(), ' Verified arrow mark available at bottom')
});

When("User clicks on arrow mark then verifies left pane Data grid should get resized", () => {
    navigationPanel.ArrowMarkClick()
    navigationPanel.leftPanelNotVisible()
    console.log(printTimestamp(), ' clicked on arrow mark')
});

Then("Verifies title for left pane when left pane is collapsed", () => {
    navigationPanel.navigationPanelLable()
    console.log(printTimestamp(), ' Verified title for left pane when left pane is collapsed')
});

And("User relauches application", () => {
    cy.reload()
    console.log(printTimestamp(), ' App relaunched')
});

Then("By default left pane should be in expanded state", () => {
    navigationPanel.leftPanelExpandedVisible()
    createPattern.NewPatternCreatedThreeDotsClickAndDeletion()
    console.log(printTimestamp(), ' By default left pane in expanded state')
});