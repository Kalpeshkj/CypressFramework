/// <reference types="Cypress" />
/// <reference types='cypress-tags' />
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern()
import IncludeKnowledge from "../../../../support/pageObjects/pages/PatternAuthoring/includeKnowledgepageObj";
const includeKnowledge = new IncludeKnowledge();
import KnowledgeDashboard from "../../../../support/pageObjects/pages/Knowledge_Dashboard/KnowledgeDashboard";
const knowledgeDashboard = new KnowledgeDashboard();
import CreateKnowledge from "../../../../support/pageObjects/pages/KnowledgeAuthoring/CreateKnowledge";
const createKnowledge = new CreateKnowledge();


Given("DAW Application is available", () => {
    cy.visit(Cypress.env("URL"));
    console.log(printTimestamp() ,'DAW Application is available')
});

When("User Create Pattern and Navigate to include knowledge Page And Click on Add Knowledge hyperlink", () => {
	cy.createIncludeKnowledge()
    console.log(printTimestamp() ,'creates Create Pattern and Navigate to include knowledge Page')
}); 

Then("A new workflow should be created with suffix incremented by 1 and name as AuthoringWF", () => {
	knowledgeDashboard.workflowSequencialNumberVerification()
    console.log(printTimestamp() ,'A new workflow created with suffix incremented by 1 and name as AuthoringWF')
});

And("Enter all the mandatory details and save knowledge details", () => {
    cy.CreateMyKnowledgeWithAllTags()
    createKnowledge.saveAsDraftClick()
    cy.wait(4000)
    createKnowledge.getPatternName()
    cy.wait(1000)
    console.log(printTimestamp() ,'Entered all the mandatory details and save knowledge details')
});

Then("The workflow name should be updated with the knowledge name", () => {
	createKnowledge.workflowAndKnowledgeNameTextVerification()
    console.log(printTimestamp() ,'The workflow name updated with the knowledge name')
});

When("Publish the knowledge using DB Manipulation", () => {
    knowledgeDashboard.KnowledgeDashboardSelect()
    cy.wait(5000)
    knowledgeDashboard.modalityColumnClick()
    cy.wait(5000)
    knowledgeDashboard.modalityColumnClick()
    knowledgeDashboard.checkBoxToSelectAllModalitiesClick()
    knowledgeDashboard.applyFilterButtonClick()
    createKnowledge.knowledgeNameSearch()
    knowledgeDashboard.searchIconClicked()
    cy.wait(3000)
    knowledgeDashboard.searchedKnowledgeClick()
    cy.wait(1000)
    knowledgeDashboard.publishButtonClick()
    cy.wait(1000)
    knowledgeDashboard.popUpOkButtonClick()
    cy.wait(1000)
    console.log(printTimestamp() ,'Published knowledge using DB Manipulation')
}); 

Then("the knowledge Appears in the include knowledge", () => {
    createPattern.createdPatternClick()
    cy.wait(2000)
    createPattern.nextButtonClick()
    cy.wait(3000)
    createKnowledge.commonFilterClickAndTypePublishedKnowledge()
    includeKnowledge.searchButtonOfSearchByKeyWordClick()
    cy.wait(2000)
    includeKnowledge.searchedKnowledgeVisible()
    console.log(printTimestamp() ,'the knowledge Appears in the include knowledge')
});

And("User should be able to see unique tags in include knowledge Section", () => {
	createKnowledge.uniqueTagsInIncludeKnowledgeSection()
    console.log(printTimestamp() ,'User abled to see unique tags in include knowledge Section')
});

And("Tooltip to be shown for the tags associated  with cause-solution-symptom with cause-solution-symptom name to which its associated", () => {
	createKnowledge.firstRecordClick()
    cy.wait(1000)


    console.log(printTimestamp() ,'Tooltip shown for the tags associated  with cause-solution-symptom with cause-solution-symptom name to which its associated')
});

And("For knowledge level tags, tooltip will not be shown", () => {
	
    console.log(printTimestamp() ,'For knowledge level tags, tooltip not shown')
});

And("knowledge level tag is also associated with any cause-solution-symptom then only cause-solution-symptom details to be shown in tooltip", () => {
	

    cy.DeleteWorkflow()
    console.log(printTimestamp() ,'knowledge level tag is also associated with any cause-solution-symptom then only cause-solution-symptom details to be shown in tooltip')
});
