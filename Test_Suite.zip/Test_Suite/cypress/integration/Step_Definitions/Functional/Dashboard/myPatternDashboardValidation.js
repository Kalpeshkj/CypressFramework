/// <reference types="Cypress" />
/// <reference types='cypress-tags' />

import "../../../../support/index";
import { When } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';

import PatternDashboard from "../../../../support/pageObjects/pages/Dashboard/PatternDashboard";
const patternDashboard = new PatternDashboard();
import TagDashboard from "../../../../support/pageObjects/pages/Dashboard/TagDashboard";
const tagDashboard = new TagDashboard();

When("By default pattern dashboard page is displayed", () => {
  patternDashboard.dashboardButtonVisible();
  console.log(printTimestamp(), ' Pattern dashboard page displayed')
});

Then("Close Application", () => {
  cy.log("Test case executed successfully");
  console.log(printTimestamp(), ' Test case executed successfully')
});