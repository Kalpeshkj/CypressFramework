import "../../../index";
import Constants from "../../../../support/pageObjects/pages/PatternAuthoring/constants"
const patternconstants = new Constants();
let arr = []
const displayAppName = "#app-name";
const selectedDashboard = ".p-treenode.p-treenode-leaf.ng-star-inserted";
const PatternTab = 'button[class="p-ripple p-element p-tree-toggler p-link"]';
const patternExpanded = " My Patterns ";
const threeverticalDots = 'span[class="ng-star-inserted"]';
const myReviewDashboard = '[aria-label="My Review Dashboard"]';
const rules = '[aria-label="Rules"]';
const models = '[aria-label="Models"]';
const plots = '[aria-label="Plots"]';
const breadCrumb = ".pt-breadcrumb";
const home = "Home";
const collasableCaretOfPatterns = ".p-tree-toggler.p-link.p-ripple";
const patterns = 'a[class="node-label-font"]';
const knowledge = 'a[class="node-label-font"]';
const allOptions = ".p-treenode.ng-star-inserted";
const myPattern = 'button[class="p-ripple p-element p-tree-toggler p-link"]';
const dashBoardUnderMyPattern = 'a[id="Dashboard"]';
const authoringWorkFlowUnderMyPattern = '.ng-star-inserted > div > span >span >section'
const createPatternButton = '#undefined';
const arrowMark = "#side-nav-toggle-icon ";
const leftPannel = 'a[id="Patterns"]';
const navigationPanelLable = ".collapse-label.ng-star-inserted";
const lableOfNavigationPanel = '"Navigation Panel"'
const myPatternOption = "a[id='My Patterns']";
const myPatternThreeDots = "#Layer_1";
const knowledgeSectionCollapsedIcon = 'div[aria-label="Knowledge"] span';
const rulesSectionCollapsedIcon = 'div[aria-label="Rules"] span';
const modelsSectionCollapsedIcon = 'div[aria-label="Models"] span';
const plotsSectionCollapsedIcon = 'div[aria-label="Plots"] span';
const CollapsedIcon = 'p-tree-toggler-icon pi pi-fw pi-chevron-right';
const patternsSectionCollapsedIcon = 'div[aria-label="Patterns"] span';
const myReviewDashboardSection = 'div[aria-label="My Review Dashboard"]';
const myPatternsSectionCollapsedIcon = 'div[aria-label="My Patterns"] span';
const navigationPanel = 'div[class="dashboard_left active"]'
const collapseIcon = "dls-layout-container img[alt='Collapse']"

import AssertionConstants from "../../../../support/pageObjects/pages/AssertionConstants"
const assertionConstants = new AssertionConstants()

class NavigationPanel {
  displayNameVisible() {
    cy.get(displayAppName).should(assertionConstants.beVisibleAssertion);
  }
  ArrowMarkVisible() {
    return cy.get(arrowMark).should(assertionConstants.beVisibleAssertion);
  }
  myReviewDashboardSectionVisible() {
    return cy.get(myReviewDashboardSection).should(assertionConstants.beVisibleAssertion);
  }
  myPatternsSectionClick() {
    cy.get(myPatternsSectionCollapsedIcon).eq(0).click()
  }
  patternsSectionClick() {
    cy.get(patternsSectionCollapsedIcon).eq(0).click()
  }
  patternSectionCollapsedVisible() {
    cy.get(patternsSectionCollapsedIcon).eq(0).should(assertionConstants.haveClassAssertion, CollapsedIcon);
  }
  modelsSectionCollapsedVisible() {
    cy.get(modelsSectionCollapsedIcon).eq(0).should(assertionConstants.haveClassAssertion, CollapsedIcon);
  }
  plotsSectionCollapsedVisible() {
    cy.get(plotsSectionCollapsedIcon).eq(0).should(assertionConstants.haveClassAssertion, CollapsedIcon);
  }
  rulesSectionCollapsedVisible() {
    cy.get(rulesSectionCollapsedIcon).eq(0).should(assertionConstants.haveClassAssertion, CollapsedIcon);
  }
  knowledgeSectionCollapsedVisible() {
    cy.get(knowledgeSectionCollapsedIcon).eq(0).should(assertionConstants.haveClassAssertion, CollapsedIcon);
  }
  myPatternOptionWithThreeDotsVisible() {
    cy.get(myPatternOption).should(assertionConstants.beVisibleAssertion);
    cy.get(myPatternThreeDots).should(assertionConstants.beVisibleAssertion);
  }
  leftPanelExpandedVisible() {
    return cy.get(navigationPanelLable).should(assertionConstants.notExistsAssertion);
  }
  launchApp() {
    cy.visit(Cypress.env("URL"));
  }

  displayName() {
    return cy.get(displayAppName)
  }

  displayAppName(pagetitle) {
    return cy.get(displayAppName).invoke("text")
      .then((text) => {
        expect(text.trim()).to.equal(pagetitle);
      })
  }

  patternExpanded() {
    return cy.contains(patternExpanded).should(assertionConstants.beVisibleAssertion);
  }

  selectedDashboard() {
    return cy.get(selectedDashboard).eq(0)
      .find("div")
      .should(assertionConstants.haveAttributeAssertion, "aria-selected", "true");
  }

  threeverticalDotsVisible() {
    return cy.get(threeverticalDots).eq(0).should(assertionConstants.beVisibleAssertion);
  }

  myReviewDashboard() {
    return cy.get(myReviewDashboard).should(assertionConstants.haveAttributeAssertion, "draggable", "false");
  }

  rules() {
    return cy.get(rules).should(assertionConstants.haveAttributeAssertion, "draggable", "false");
  }
  models() {
    return cy.get(models).should(assertionConstants.haveAttributeAssertion, "draggable", "false");
  }
  plots() {
    return cy.get(plots).should(assertionConstants.haveAttributeAssertion, "draggable", "false");
  }

  breadcrumbVisible() {
    return cy.get(breadCrumb).last().should(assertionConstants.beVisibleAssertion);
  }

  homeDisabled() {
    return cy.contains(home).should(assertionConstants.notBeDisabledAssertion);
  }

  collasableCaretOfPatternsClick() {
    return cy.get(collasableCaretOfPatterns).eq(0).click();
  }

  patternsVisible() {
    return cy.get(patterns).eq(0).should(assertionConstants.beVisibleAssertion);
  }

  knowledgeVisible() {
    return cy.get(knowledge).eq(1).should(assertionConstants.beVisibleAssertion);
  }
  rulesVisible() {
    return cy.get(rules).should(assertionConstants.beVisibleAssertion);
  }
  modelsVisible() {
    return cy.get(models).should(assertionConstants.beVisibleAssertion);
  }
  plotsVisible() {
    return cy.get(plots).should(assertionConstants.beVisibleAssertion);
  }

  patternCollapsableandExpandable() {
    cy.get(dashBoardUnderMyPattern).should(assertionConstants.notExistsAssertion)
    this.PatternTabClick()
    this.dashboardUnderMyPatternVisible()
    this.PatternTabClick()
  }

  allOptions() {
    return cy.get(allOptions).find("span")
      .should(assertionConstants.haveClassAssertion, "p-tree-toggler-icon pi pi-fw pi-chevron-right");
  }

  PatternTabClick() {
    return cy.get(PatternTab).eq(0).click()
  }

  MyPatternClick() {
    return cy.get(myPattern).eq(2).click({ force: true });
  }

  dashboardUnderMyPatternVisible() {
    return cy.get(dashBoardUnderMyPattern).last()
      .should(assertionConstants.beVisibleAssertion);
  }
  authoringWorkFlowUnderMyPatternvisible() {
    return cy.get(authoringWorkFlowUnderMyPattern).eq(4).should(assertionConstants.beVisibleAssertion)
  }

  threeverticalDotsClick() {
    return cy.get(threeverticalDots).eq(3).click()
  }
  createPatternButtonVisible() {
    return cy.get(createPatternButton).should(assertionConstants.beVisibleAssertion);
  }

  ArrowMarkClick() {
    return cy.get(arrowMark).click();
  }

  leftPanelNotVisible() {
    return cy.get(leftPannel).should(assertionConstants.notVisibleAssertion);
  }

  leftPanelVisible() {
    return cy.get(leftPannel).should(assertionConstants.beVisibleAssertion);
  }

  navigationPanelLable() {
    return cy.get(navigationPanelLable).then((el) => {
      const before = window.getComputedStyle(el[0], "before");
      const contentValue = before.getPropertyValue("content");
      expect(contentValue).to.equal(lableOfNavigationPanel);
    })
  }

  relaunchApplication() {
    return cy.reload();
  }

  scrolltoLastWorkflow() {
    return cy.get('a#Knowledge').scrollIntoView()
  }

  navigateToLastWorkflowThreeDots() {
    return cy.get("#" + arr[1] + patternconstants.patternNameThreeDots()
    ).click();
  }

  navigateToLastWorkflowThreeDotsAfterDeletion() {
    return cy.get("#" + arr[0] + patternconstants.patternNameThreeDots()
    )
  }

  pushLastWorkflowtoArray() {
    return cy.get(".pt-layout-container > ul > li > a > span")
      .last()
      .invoke("text")
      .then((text1) => {
        arr.push(text1);
      });
  }

  DeleteLastWorkflowThreeDotsbasedOnPatternName() {
    return cy.readFile('cypress/fixtures/patternNameCreation.json').then(function (result) {
      let PatternName = result.name;
      cy.get("#" + PatternName + patternconstants.patternNameThreeDots()).click();
      cy.DeletePattern()
    })

  }

  collapseIconClickandVerification() {
    cy.get(collapseIcon).click()
    cy.get(navigationPanel).should('not.exist')
  }
}
export default NavigationPanel;