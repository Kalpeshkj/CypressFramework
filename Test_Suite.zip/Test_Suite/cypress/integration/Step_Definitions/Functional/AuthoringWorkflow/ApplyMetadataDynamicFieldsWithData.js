/// <reference types="Cypress" />
/// <reference types='cypress-tags' />
import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import ApplyMetadata from "../../../../support/pageObjects/pages/PatternAuthoring/applyMetadata";
const applyMetadata = new ApplyMetadata();

And("navigates to the apply Metadata page",()=>{
    cy.wait(2000)
    applyMetadata.applyMetadataHeadingActiveVerification()
    console.log(printTimestamp(), 'navigates to the apply Metadata page')
})

Then("Pattern Type,Service Context,Severity,Modality,Relevance dynamic field should be available in Apply Metadata Page", () => {
	applyMetadata.fieldsOnApplyMetadataPageVerification()
    console.log(printTimestamp(), 'Pattern Type,Service Context,Severity,Modality,Relevance dynamic field available in Apply Metadata Page')
});

And("Pattern Type,Service Context,Day Span,Severity,Modality,Relevance fields should" 
+" be present which are mandatory and marked with asterisk", () => {
	applyMetadata.fieldsOnApplyMetadataPageWithAsteriskVerification()
    console.log(printTimestamp(), "Pattern Type,Service Context,Day Span,Severity,Modality,Relevance fields " 
    +" present which are mandatory and marked with asterisk")
});

And("Pattern Type,Service Context,Severity,Day Span-24 default,Comment water mark should be available", () => {
	applyMetadata.commentBoxWithWatermark()
    applyMetadata.daySpanTextBoxWithDefaultWatermark()
    applyMetadata.patternTypeWaterMaskVisible()
    applyMetadata.serviceContextWaterMarkVisible()
    applyMetadata.severityWaterMarkVisible()
    console.log(printTimestamp(), 'Pattern Type,Service Context,Severity,Day Span-24 default,Comment water mark available')
});

And("The Mandatory fields should be displayed first in Alphabetical order and then non mandatory fields should be displayed in Alphabetical order", () => {
	applyMetadata.mandatoryFieldsInAlphabeticalOrderVerification()
    console.log(printTimestamp(), 'first in Alphabetical order and then non mandatory fields displayed in Alphabetical order')
});

When("When user select and unselect values from drop down Service Context field", () => {
	applyMetadata.modalityDropdownfield()
    applyMetadata.serviceContextFields()
    console.log(printTimestamp(), 'user select and unselect values from drop down Service Context field')
});

Then("Service Context field should get highlighted with red color", () => {
    applyMetadata.severityContextFieldWithRedBorder()
    console.log(printTimestamp(), 'Service Context field highlighted with red color')
});

When("user remove value from Day Span", () => {
	applyMetadata.clearingDaySpanField()
    console.log(printTimestamp(), 'removed value from Day Span')
});

Then("Day Span text box should get highlighted with red color", () => {
	applyMetadata.daySpanTextBoxWithRedBorder()
    console.log(printTimestamp(), 'Day Span text box highlighted with red color')
});

Then("Next button should not be enabled unless all the mandatory fields are not entered", () => {
	applyMetadata.nextButtonDisabledVerification()
    console.log(printTimestamp(), 'Next button not be enabled unless all the mandatory fields are not entered')
});

Then("Repeat above steps for all the mandatory fields present", () => {
	applyMetadata.modalityDropdownfieldClick()
    applyMetadata.dxrTagClick()
    applyMetadata.modalityFieldWithRedBorder()
    console.log(printTimestamp(), 'Repeated above steps for all the mandatory fields present')
});
