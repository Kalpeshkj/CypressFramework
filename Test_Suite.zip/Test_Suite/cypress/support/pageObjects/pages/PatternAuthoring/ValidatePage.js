import AssertionConstants from "../../../../support/pageObjects/pages/AssertionConstants"
const assertionConstants = new AssertionConstants();

// constants
const validationCancelMessage = 'Pattern validation is cancelled for the pattern'

const validationIdDropdown = '[id="systemId"]'
const selectButton = '[id="applyBtn"]'
const idOptionsUnderDropdown = '[class="country-item ng-star-inserted"]'
const calenderOption = '[id="value-field"]'
const datesOnCalender = 'span[draggable="false"]'
const taskLimitInputBox = 'input[formcontrolname="limit"]'
const validateButton = '[id="validate-btn"]'
const validationStatusBox = '[class="p-element p-resizable-column ng-star-inserted"]'
const inprogressCrossIcon = '[id="inProgressIcon"]'
const saveAsDraftButton = '[id="pat-draft"]'
const nextButton = "#pat-step-next"
const previousButton = 'button[id="pat-step-prev"]'
const datePrevIcon = '.p-datepicker-prev-icon'


class ValidationPage {
    validationIdDropdownClick(){
        cy.get(validationIdDropdown).click()
    }

    selectFirstId(){
        cy.get(idOptionsUnderDropdown).eq(0).click()
    }

    selectButtonClick(){
        cy.get(selectButton).click()
    }

    calenderOptionClick(){
        cy.get(calenderOption).eq(0).click()
    }

    dateRangeSlection(){
        cy.get(datesOnCalender).eq(8).click()
        cy.get(datesOnCalender).eq(9).click()
        cy.get(calenderOption).eq(0).click()
    }

    taskLimitInputBoxTypeOne(){
        cy.get(taskLimitInputBox).clear().type('1')
    }

    validateButtonClick(){
        cy.get(validateButton).click({force:true})
    }

    validationStatusBoxWithInprocessStatus(){
        cy.get(validationStatusBox).eq(3).should(assertionConstants.haveTextAssertion,' Inprogress ').and(assertionConstants.beVisibleAssertion)
    }

    inprogressCrossIconClick(){
        cy.get(inprogressCrossIcon).click()
    }

    validationStatusBoxWithCancelledStatus(){
        cy.get(validationStatusBox).eq(3).should(assertionConstants.haveTextAssertion,' Cancelled ').and(assertionConstants.beVisibleAssertion)
    }

    jobValidationCancelMessageVisible(){
        cy.contains(validationCancelMessage).should(assertionConstants.beVisibleAssertion)
    }

    saveAsDraftButtonClick(){
        cy.get(saveAsDraftButton).click({force: true})
    }

    validationStatusBoxWithCompletedStatus(){
        cy.get(validationStatusBox).eq(3).should(assertionConstants.haveTextAssertion,' Completed ').and(assertionConstants.beVisibleAssertion)
    }

    selectSecondId(){
        cy.get(idOptionsUnderDropdown).eq(1).click()
    }

    validationStatusBoxWithOutCancelledStatus(){
        cy.get(validationStatusBox).eq(3).should(assertionConstants.notHaveTextAssertion,' Cancelled ')
    }

    nextButtonClick() {
        cy.get(nextButton).click({force: true})
    }

    previousButtonClick() {
        return cy.get(previousButton).click({force: true})
    }

    datePrevIconClick(){
        cy.get(datePrevIcon).click()
    }



}
export default ValidationPage;