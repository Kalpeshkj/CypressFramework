/// <reference types="Cypress" />
/// <reference types='cypress-tags' /> 

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import CreateKnowledge from "../../../../support/pageObjects/pages/KnowledgeAuthoring/CreateKnowledge";
const createKnowledge = new CreateKnowledge();

And("expand Causes and Solutions section", () => {
    createKnowledge.causeAndSolutionOptionClick()
    console.log(printTimestamp(), 'expanded Causes and Solutions section')
});

When("user click on Select cause button", () => {
    createKnowledge.selectCauseButtonClick()
    console.log(printTimestamp(), ' Clicked on Select cause button')
});

Then("Select Cause pop up should get displayed", () => {
    createKnowledge.selectCausePopupVisible()
    console.log(printTimestamp(), 'Selected Cause pop up displayed')
});

When("Click on show all", () => {
    createKnowledge.showAllCheckboxClick()
    cy.wait(2000)
    console.log(printTimestamp(), 'Clicked on show all')
});

Then("All existing published knowledges cause should be displayed", () => {
    createKnowledge.existingPublishedSymptomOrCausesVisible()
    createKnowledge.tagsFilterOptionClick()
    createKnowledge.detectorOptionInTagsDropDownClick()
    createKnowledge.applyButttonInSelectCauseTagsFilterClick()
    cy.wait(1000)
    createKnowledge.firstSymptomOrCauseText()
    console.log(printTimestamp(), 'All existing published knowledges cause displayed')
});

When("User Select one cause and click on select button", () => {
    createKnowledge.firstSymptomOrCauseClick()
    cy.wait(1000)
    createKnowledge.selectButtonClick()
    cy.wait(1000)
    console.log(printTimestamp(), 'Selects one cause and clicked on select button')
});

Then("Selected cause should get added under Causes and Solutions section", () => {
    createKnowledge.firstSelectedSymptomOrCauseInSymptomOrCauseAndSolutionSectionVisible()
    console.log(printTimestamp(), 'Selected cause gets added under Causes and Solutions section')
});

And("Name of Cause should remain same as displayed in Select Cause pop up", () => {
    createKnowledge.selectedFirstSymptomOrCauseNameInSymptomSection()
    console.log(printTimestamp(), 'Name of Cause should is same as displayed in Select Cause pop up')
});

And("Selected cause should be displayed in read only mode", () => {
    createKnowledge.editOptionNOtExists()
    console.log(printTimestamp(), 'Selected cause displayed')
});

And("Remove option inline with cause name should be displayed to remove selected cause", () => {
    createKnowledge.removeSymptomOrCauseButtonVisible()
    console.log(printTimestamp(), 'Remove option inline with cause name displayed to remove selected cause')
});

And("Cause Name , Cause Description, Solution Name with priority,Solution Description , Parts at solution level ,Cause tags , Solution tags should be displayed", () => {
    createKnowledge.nameOfFirstSymptomOrCauseInSymptomOrCauseAndSolutionSectionVisible()
    createKnowledge.symptomOrCauseDescriptionInSymptonOrCauseAndSolutionSectionVisible()
    createKnowledge.solutionsWithSolutionNameVisible()
    createKnowledge.solutionsWithPriorityVisible()
    createKnowledge.symptomOrCauseTagIconVisible()
    console.log(printTimestamp(), 'Cause Name , Cause Description, Solution Name with priority,Solution Description , Parts at solution level ,Cause tags , Solution tags displayed')
});

And("tags and parts data should be displayed in token", () => {
    createKnowledge.tagsInTokenVisible()
    console.log(printTimestamp(), ' Tags and parts data displayed')
});

When("user clicked on Select cause button", () => {
    createKnowledge.selectCauseButtonClick()
    console.log(printTimestamp(), ' clicked on Select cause button')
});

Then("Select Cause pop up should get displayed", () => {
    createKnowledge.selectSymptomOrCausePopUpVisible()
    console.log(printTimestamp(), 'Select Cause pop up  displayed')
});

Then("All existing published knowledges causes should be displayed", () => {
    createKnowledge.existingPublishedSymptomOrCausesVisible()
    createKnowledge.tagsFilterOptionClick()
    createKnowledge.detectorOptionInTagsDropDownClick()
    createKnowledge.applyButttonInSelectCauseTagsFilterClick()
    cy.wait(1000)
    createKnowledge.secondSymptomOrCauseText()
    createKnowledge.ThirdSymptomOrCauseText()
    console.log(printTimestamp(), 'Application launched successfully')
});

When("Select multiple causes", () => {
    createKnowledge.firstSymptomOrCauseClick()
    createKnowledge.secondSymptomClick()
    createKnowledge.FoutrhSymptomOrCauseClick()
    createKnowledge.selectButtonClick()
    cy.wait(2000)
    console.log(printTimestamp(), 'Select multiple causes')
});

Then("All selected cause should get added under Causes and Solutions section Note order of displaying causes should be displayed based on displayed cause in select cause pop up", () => {
    createKnowledge.firstSelectedSymptomOrCauseInSymptomOrCauseAndSolutionSectionVisible()
    createKnowledge.secondSelectedSymptomOrCauseInSymptomOrCauseAndSolutionSectionVisible()
    console.log(printTimestamp(), 'All selected cause should get added under Causes and Solutions section Note order of displaying causes displayed based on displayed cause in select cause pop up')
});

And("Name of Cause should remain same as displayed in Select Cause pop up", () => {
    createKnowledge.selectedSecondSymptomOrCauseNameInSymptomOrCauseAndSolutionSection()
    createKnowledge.selectedThirdSymptomOrCauseNameInSymptomOrCauseAndSolutionSection()
    console.log(printTimestamp(), 'Name of Cause remain same as displayed in Select Cause pop up')
});

And("Selected cause should be displayed in read only mode", () => {
    createKnowledge.editOptionNOtExists()
    console.log(printTimestamp(), ' Selected cause displayed ')
});

And("Remove option inline with cause name should be displayed to remove selected cause", () => {
    createKnowledge.removeSymptomOrCauseButtonVisible()
    console.log(printTimestamp(), 'Remove option inline with cause name displayed to remove selected cause')
});

And("Cause Name,Cause Description,Solution Name with priority,Solution Name with priority, Solution Description , Parts at solution level ,Cause tags , Solution tags should be displayed", () => {
    createKnowledge.nameOfFirstSymptomOrCauseInSymptomOrCauseAndSolutionSectionVisible()
    createKnowledge.nameOfSecondSymptomOrCauseInSymptomOrCauseAndSolutionSectionVisible()
    createKnowledge.symptomOrCauseDescriptionInSymptonOrCauseAndSolutionSectionVisible()
    createKnowledge.solutionsWithPriorityVisible()
    createKnowledge.symptomOrCauseTagIconVisible()
    console.log(printTimestamp(), 'Cause Name , Cause Description , Solution Name with priority,, Solution Name with priority, Solution Description , Parts at solution level ,Cause tags , Solution tags displayed')
});

And("Where tags and parts data should be displayed in token", () => {
    createKnowledge.multipleTagsInTokenVisible()
    console.log(printTimestamp(), ' Tags and parts data displayed in token')
});

When("User Add Cause from Add Cause option", () => {
    createKnowledge.addCauseClick()
    createKnowledge.causeOneInputBoxType()
    createKnowledge.addSolutionButtonClick()
    createKnowledge.solutionOneTextBoxType()
    createKnowledge.tickMarkAtAddedCauseClick()
    cy.wait(2000)
    console.log(printTimestamp(), 'Add Cause from Add Cause option')
});

And("clicked on Select cause button", () => {
    createKnowledge.selectCauseButtonClick()
    console.log(printTimestamp(), ' Clicked on select cause button')
});

Then("All existing published knowledges cause should be displayed", () => {
    createKnowledge.existingPublishedSymptomOrCausesVisible()
    console.log(printTimestamp(), 'All existing published knowledges cause displayed')
})

When("Click on checkbox available beside name", () => {
    createKnowledge.entriesPerPageDropDownClick()
    createKnowledge.FiveEntriesPerPageSelect()
    cy.wait(2000)
    createKnowledge.selectAllCheckBoxBesidesNameClick()
    console.log(printTimestamp(), 'Clicked on checkbox available beside name')
})

When("Navigate to next pages and select all cause", () => {
    createKnowledge.nextPageButtonClick()
    cy.wait(2000)
    createKnowledge.selectAllCheckBoxBesidesNameClick()
    cy.wait(2000)
    console.log(printTimestamp(), 'Navigated to next pages and selectd all cause')
});

And("Click on Select button", () => {
    createKnowledge.selectButtonClick()
    cy.wait(5000)
    console.log(printTimestamp(), 'Clicked on Select button')
});

Then("All  selected causes from multiple pages should get added under Causes and Solutions section", () => {
    createKnowledge.allSelectedSymptomsOrCausesInSymptomOrCauseAndSolutionSectionVisible()
    console.log(printTimestamp(), 'All  selected causes from multiple pages added under Causes and Solutions section')
});

And("Name of Cause should remain same as displayed in Select Cause pop up", () => {
    createKnowledge.allSelectedSymptomsOrCausesInSymptomOrCauseAndSolutionSectionVisible()
    console.log(printTimestamp(), 'Name of Cause remain same as displayed in Select Cause pop up')
});

And("Selected cause should be displayed in read only  mode", () => {
    // createKnowledge.symptomsOrCauseWithoutEditOption()
    console.log(printTimestamp(), 'Selected cause displayed in read only mode')
});

And("Where tags and parts data should be displayed in token", () => {
    createKnowledge.allTagsInTokenVisible()
    console.log(printTimestamp(), ' tags and parts data displayed in token')
});
// Edit button is not coming for added cause
// And("Causes added from Add Cause should contain edit option but causes added from Select Cause should not contain edit option", () => {
//     // createKnowledge.selectedCauseWithEditOptionVisible()
//     createKnowledge.symptomsOrCauseWithoutEditOption()
//     console.log(printTimestamp(), 'Causes added from Add Cause contain edit option but causes added from Select Cause not contain edit option')
// });

And("Close DAW  application", () => {
    cy.reload()
    cy.wait(5000)
    cy.DeleteWorkflow()
    cy.log('Test case executed successfully')
    console.log(printTimestamp(), 'Test case executed successfully')
});

