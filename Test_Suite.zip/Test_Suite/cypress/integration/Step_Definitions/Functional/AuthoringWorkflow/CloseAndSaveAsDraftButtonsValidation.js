/// <reference types="Cypress" />
/// <reference types='cypress-tags' />

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();
import ApplyMetadata from "../../../../support/pageObjects/pages/PatternAuthoring/applyMetadata";
const applyMetadata = new ApplyMetadata();
When("User Clicks on My Patterns and Clicks on Create Pattern", () => {
    createPattern.patternTabThreeDotsClick()
    createPattern.createPatternButtonClick()
    console.log(printTimestamp(), ' Clicked on My Patterns and Clicks on Create Pattern')
});

Then("Verifies buttons available in create pattern", () => { 
    createPattern.buttonsVerification()
    console.log(printTimestamp(), ' Verified buttons available in create pattern')
});

When("User Enters existing Pattern Name in pattern name field", () => {
    createPattern.patternNameTextBoxInvalidNameType()
    console.log(printTimestamp(), ' Entered existing Pattern Name in pattern name field')
});

Then("Verifies validation message for existing pattern name", () => {
    createPattern.invalidPatternNameEnteredValidationMessageVerification()
    console.log(printTimestamp(), ' Verified validation message for existing pattern name')
});

When("User Enters unique Pattern Name in pattern name field", () => {
    createPattern.patternNameDetailsCleartext()
    createPattern.patternNameTypeInPatternInformationSection()
    console.log(printTimestamp(), ' Enters unique Pattern Name in pattern name field')
});

Then("Verifies buttons when pattern name validation is successful", () => {
    createPattern.buttonsVerificationAfterCorrectPatternDetails()
    console.log(printTimestamp(), ' Verified buttons when pattern name validation is successful')
});

When("User Click on Import Data Model and Selects any Data Model from drop down option", () => {
    createPattern.importDataModelAction()
    console.log(printTimestamp(), ' Clicked on Import Data Model and Selects any Data Model from drop down option')
});

Then("Add any Condition or Expression", () => {
    createPattern.addConditionInPattern()
    cy.wait(2000)
    console.log(printTimestamp(), ' Condition Added')
});

When("Relaunches the application", () => {
    cy.reload()
    console.log(printTimestamp(), ' Application relaunched')
});

Then("Clicks on close button and verifies confirmation pop up", () => {
    createPattern.closeButtonClick()
    createPattern.popUpTitleVisible()
    console.log(printTimestamp(), ' Clicked on close button and verifies confirmation pop up')
});

And("Verifies message in close confirmation pop up", () => {
    createPattern.popUpDialogueVisible()
    createPattern.deleteButtonInDeleteWFPopupVisible()
    createPattern.cancelButtonInDeleteWFPopupVisible()
    console.log(printTimestamp(), ' Verified message in close confirmation pop up')
});

And("User clicks on Cancel button and verifies same page", () => {
    createPattern.cancelButtonInDeleteWFPopupClick()
    createPattern.patternInformationVisible()
    console.log(printTimestamp(), ' Clicked on Cancel button and verifies same page')
});

Then("User repeats above steps and click on OK button", () => {
    createPattern.breadcumbLastValueCapture()
    createPattern.closeButtonClick()
    createPattern.okButtonClick()
    console.log(printTimestamp(), ' Above steps repeated and clicked on OK button')
});

And("Verifies user should navigated to Dashboard under my pattern", () => {
    createPattern.breadcumbLastValueAsDashboardVisible()
    console.log(printTimestamp(), ' Verified user should navigated to Dashboard under my pattern')
});

And("Verifies content which are not saved while closing Authoring Workflow", () => {
    createPattern.patternInformationNotVisible()
    console.log(printTimestamp(), ' Verifies content which are not saved while closing Authoring Workflow')
});

And("Enter contents in remaining fields", () => {
    createPattern.newlyCreatedPatternNavigation()
    cy.wait(2000)
    createPattern.createPatternPageInformationSubmission()
    console.log(printTimestamp(), ' Contents entered in remaining fields')
});

Then("Click on save as draft button", () => {
    createPattern.clicksOnPopUpOkButton()
    cy.wait(2000)
    console.log(printTimestamp(), ' Clicked on save as draft button')
});

Then("After saving as draft verify Save as Draft button that should be disabled", () => {
    createPattern.saveAsDraftButtonAsDisabled()
    console.log(printTimestamp(), ' After saving as draft verified button that was disabled')
});

Then("Verifies saved details should be displayed", () => {
    createPattern.patternInformationVisible()
    console.log(printTimestamp(), ' Verified saved details displayed')
});

Then("Repeat above steps by filling data in any order for each fields and verify close functionality", () => {
    createPattern.removeActionForceClick()
    createPattern.removeActionForceClick()
    createPattern.okButtonClick()
    createPattern.importDataModelAction()
    createPattern.addAction()
    createPattern.addConditionInPattern()
    createPattern.closeButtonClick()
    createPattern.popUpTitleVisible()
    createPattern.popUpDialogueVisible()
    createPattern.deleteButtonInDeleteWFPopupVisible()
    createPattern.cancelButtonInDeleteWFPopupVisible()
    createPattern.cancelButtonInDeleteWFPopupClick()
    createPattern.clicksOnPopUpOkButton()
    console.log(printTimestamp(), ' Above steps Repeated by filling data in any order for each fields and verified close functionality')
});

Then("Repeat above steps in apply Metadata Page and verify functionality of Close and Save as Draft", () => {
    createPattern.nextButtonClick()
    cy.wait(2000)
    createPattern.buttonsVerificationAfterCorrectPatternDetails()
    applyMetadata.addCommnetInCommentBoxType()
    createPattern.closeButtonClick()
    createPattern.popUpTitleVisible()
    createPattern.popUpDialogueVisible()
    createPattern.deleteButtonInDeleteWFPopupVisible() 
    createPattern.cancelButtonInDeleteWFPopupVisible()
    createPattern.cancelButtonInDeleteWFPopupClick()
    createPattern.closeButtonClick()
    createPattern.okButtonClick()
    createPattern.breadcumbLastValueAsDashboardVisible()
    cy.DeleteDynamicPattern()
    console.log(printTimestamp(), ' Above steps Repeated in apply Metadata Page and verified functionality of Close and Save as Draft')
});