import "../../../../support/index";
import { Then, When} from "cypress-cucumber-preprocessor/steps";
import PatternDashboard from "../../../../support/pageObjects/pages/Dashboard/PatternDashboard";
const patternDashboard = new PatternDashboard();
import KnowledgeDashboard from "../../../../support/pageObjects/pages/Knowledge_Dashboard/KnowledgeDashboard";
const knowledgeDashboard = new KnowledgeDashboard();
import {printTimestamp} from '../../../../support/commands';
import AssertionConstants from "../../../../support/pageObjects/pages/AssertionConstants";
const assertionConstants = new AssertionConstants()

When("User clicks on 3 dots of knowledge available", () => {
    knowledgeDashboard.firstKnowledgeRecordThreeDotsClick()
    console.log(printTimestamp(), ' 3 dots clicked for knowledge')
});

When("User select all the columns in the select options", () => {
    patternDashboard.patternDropdownVisible();
    patternDashboard.patternDropdownClick();
    patternDashboard.selectdropdownValues();
    patternDashboard.patternDropdownWithAdditionOfColumnVisible();
    console.log(printTimestamp(), ' Selected all the columns from the select options')

});

When("By default pattern dashboard page is displayed", () => {
    patternDashboard.dashboardButtonVisible();
    console.log(printTimestamp(), ' Pattern dashboard page displayed')
});
Then("Click on My Pattern Dashboard", () => {
    patternDashboard.myPatternClick();
    patternDashboard.myPatternDashboardButtonVisible();
    patternDashboard.myPatternDashboardButtonClick();
    console.log(printTimestamp(), ' Clicked on My Pattern Dashboard')
});
Then("Validate breadcrumbs", () => {
    patternDashboard.breadcrumbVisible();
    console.log(printTimestamp(), ' breadcrumbs Validated')
});
Then(
    "Pattern Dashboard should contain patterns title, Delete Withdraw button",
    () => {
        patternDashboard.patternTitleVisible();
        patternDashboard.deletePatternButtonVisible();
        patternDashboard.withdrawPatternButtonVisible();
        console.log(printTimestamp(), ' Verified Pattern Dashboard with patterns title and Delete Withdraw button')
    }
);
Then(
    "Advance filter hyperlink,Column Configuration dropdown as 9 columns selected should be present",
    () => {
        knowledgeDashboard.navigationPanelVerification()
        knowledgeDashboard.entriesPerPageVisible()
        knowledgeDashboard.showingResultsVisible()
        knowledgeDashboard.modalityOptionClick()
        knowledgeDashboard.modalityOptionClick()
        patternDashboard.checkboxesAtColumnLevelValidation()
        patternDashboard.advanceFilterHyperlinkVisible()
        patternDashboard.patternDropdownVisible();
        cy.wait(2000)
        patternDashboard.patternDropdownClick();
        cy.wait(2000)
        patternDashboard.dropdownResultVerification()
        patternDashboard.patternNameColumnClick();
        console.log(printTimestamp(), ' Verified 9 columns selected in Column Configuration dropdown')
    }
);
Then("no of displayed pattern vs total records found should be present", () => {
    patternDashboard.recordsVisible();
    console.log(printTimestamp(), ' Verified no of displayed pattern vs total records found')
});
Then("Clear All filter button should be present", () => {
    patternDashboard.clearFiltersVisible();
    patternDashboard.clearFiltersClick();
    console.log(printTimestamp(), ' Verified Clear All filter button was displayed')
});
Then(
    "Entries per page as 15 to be selected and page count should be displayed",
    () => {
        patternDashboard.entriesPerPageVisible();
        patternDashboard.entriesPerPageCountVerification();
        console.log(printTimestamp(), ' Verified Entries per page and page count')
    }
);
Then("All the required columns should be displayed", () => {
    patternDashboard.patternNameColumnVisible();
    patternDashboard.patternStateColumnVisible();
    patternDashboard.versionColumnVisible();
    patternDashboard.modifiedbyColumnVisible();
    patternDashboard.modifiedonColumnVisible();
    patternDashboard.modalityColumnVisible();
    patternDashboard.patterntypeColumnVisible();
    patternDashboard.sercicecontextColumnVisible();
    patternDashboard.severityColumnColumnVisible();
    console.log(printTimestamp(), ' Verified All the required columns was displayed')
});
When("User selects all the columns in the select options", () => {
    patternDashboard.patternDropdownVisible();
    patternDashboard.selectdropdownValues();
    patternDashboard.patternDropdownWithAdditionOfColumnVisible();
    console.log(printTimestamp(), ' Selected all the columns from select options')
});
Then("All the datagrid column values should be present", () => {
    patternDashboard.CreatedOnFilterClick();
    patternDashboard.CreatedByFilterClick();
    patternDashboard.PublishedOnFilterClick();
    patternDashboard.PublishedByFilterClick();
    patternDashboard.ReviewedByFilterClick();
    console.log(printTimestamp(), ' Verified All the datagrid column values')
});
When("User clicks on pattern Name", () => {
    patternDashboard.firstPatternClick();
    console.log(printTimestamp(), ' Clicked on pattern Name')
});
Then("Pattern details should be displayed in page", () => {
    patternDashboard.patternDiscriptionVisible();
    patternDashboard.patternGuidVisible();
    patternDashboard.closeButtonClick();
    console.log(printTimestamp(), ' Verified Pattern details')
});

Then("Similar Values should not be available in dropdown once its added by users in previous added tag", () => {
    knowledgeDashboard.addedTagNotAvailableInWithoutKeywordDropdownVerification()
    console.log(printTimestamp(), ' Same value verified as not present in dropdown')
})

Then("Verify that by default filter applied on modality column", () => {

    console.log(printTimestamp(), ' by default filter applied on modality column verified')
})

Then("Verify showing count available in dashboard", () => {
    knowledgeDashboard.showingResultsVisible()
    console.log(printTimestamp(), ' Verified showing count')
})

When("User clicks on > icon", () => {
    knowledgeDashboard.nextPageIconClick()
    console.log(printTimestamp(), ' clicked on > icon')
})

When("User clicks on < icon", () => {
    knowledgeDashboard.previousPageIconClick()
    console.log(printTimestamp(), ' clicked on < icon')
})

Then("User should navigated to next page", () => {
    knowledgeDashboard.nextPageMovedVerification()
    console.log(printTimestamp(), ' Navigated to next page')
})

Then("User should navigated to previous page", () => {
    knowledgeDashboard.previousPageMovedVerification()
    console.log(printTimestamp(), ' Navigated to previous page')
})

Then("Verify UI for Enteries per page", () => {
    knowledgeDashboard.entriesPerPageValidation()
    console.log(printTimestamp(), ' Verified UI for Enteries per page')
})

Then("User selects different number from dropdown and verify total results available in page", () => {
    knowledgeDashboard.differentValueSelectionFromEnterPerPageDropdown()
    console.log(printTimestamp(), ' User selected different number from dropdown')
})