/// <reference types="Cypress" />
/// <reference types = 'cypress-tags' />   

import "../../../../support/index"
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import NavigationPanel from "../../../../support/pageObjects/pages/Dashboard/NavigationPanel";
const navigationPanel = new NavigationPanel();
import CreateKnowledge from "../../../../support/pageObjects/pages/KnowledgeAuthoring/CreateKnowledge";
const createKnowledge = new CreateKnowledge();
import { printTimestamp } from '../../../../support/commands';


When("User Create knowledge", () => {
    createKnowledge.knowledgeOptionArrowClick()
    createKnowledge.addKnowledgeWorkflowButtonClick()
    cy.wait(5000)
    console.log(printTimestamp(), 'Created knowledge')
});

Then("There should be three stages , Create, View and review. Create stage should be highlighted in blue and other stages should be disabled", () => {
    createKnowledge.createStageVisibleAndHighlighted()
    createKnowledge.viewStageVisibleAndDisabled()
    createKnowledge.reviewRequeStageVisibleAndDisabled()
    console.log(printTimestamp(), 'There is thress stages , Create, View and review. Create stage highlighted in blue and other stages disabled')
});

When("User Enter all the mandatory and  save knowledge details", () => {
    cy.CreateMyKnowledge()
    console.log(printTimestamp(), 'Entered all the mandatory and  saved knowledge details')
});

And("Click on Next", () => {
    createKnowledge.nextButtonOnCreatePageClick()
    console.log(printTimestamp(), 'Clicked on Next')
});

Then("User Should be navigated to View Step and view stage should be highlighted and create step"
    + " should be highlighted in blue with tick mark instead of Number 1 written, review stage should be disabled", () => {
        createKnowledge.viewStageVisibleAndHighlighted()
        createKnowledge.createStageWithTickMark()
        createKnowledge.reviewRequeStageVisibleAndDisabled()
        console.log(printTimestamp(), "User navigated to View Step and view stage highlighted and create step"
            + " highlighted in blue with tick mark instead of Number 1 written, review stage disabled")
    });

And("Added Rich text contents added in cause solution and symptom should appear when navigated from one stage to another", () => {
    createKnowledge.symptomOneTextInViewStepVisible()
    createKnowledge.causeOneTextInViewStepVisible()
    createKnowledge.solutionOnetextInViewStepVisible()
    console.log(printTimestamp(), 'Added Rich text contents added in cause solution and symptom appear when navigated from one stage to another')
});

And("User should be able to see unique tags", () => {

    console.log(printTimestamp(), 'User see unique tags')
});

And("Tooltip to be shown for the tags associated  with cause-solution-symptom with  cause-solution-symptom name to which its associated", () => {

    console.log(printTimestamp(), 'Tooltip shown for the tags associated  with cause-solution-symptom with  cause-solution-symptom name to which its associated')
});

And("For knowledge level tags, tooltip will not be shown  knowledge level tag is also associated with any cause-solution-symptom then only cause-solution-symptom details to be shown in tooltip", () => {

    console.log(printTimestamp(), 'For knowledge level tags, tooltip will not shown  knowledge level tag is also associated with any cause-solution-symptom then only cause-solution-symptom details shown in tooltip')
});

And("For newly created knowledge the version should be in draft stage and this section should  not be available in the create section", () => {
    createKnowledge.versionIndraftStageVisible()
    createKnowledge.previousButtonClickInKnowledge()
    createKnowledge.versionIndraftStageNotExist()
    createKnowledge.nextButtonOnCreatePageClick()
    console.log(printTimestamp(), 'For newly created knowledge the version in draft stage and this section not be available in the create section')
});

When("User click on full screen button", () => {
    createKnowledge.fullScreenViewButtonClick()
    console.log(printTimestamp(), 'clicked on full screen button')
});

Then("User should be able to view knowledge details in Full screen with navigation section  should also collapsed", () => {
    createKnowledge.knowledgeDetailsInFulllScreen()
    navigationPanel.leftPanelNotVisible()
    navigationPanel.navigationPanelLable()
    console.log(printTimestamp(), 'User able to view knowledge details in Full screen with navigation section also collapsed')
});

And("The next button should be enabled and user should be able to navigate to the next section of knowledge", () => {
    createKnowledge.fullScreenViewButtonClick()
    createKnowledge.nextButtonOnCreatePageEnabled()
    createKnowledge.nextButtonOnCreatePageClick()
    console.log(printTimestamp(), 'The next button enabled and user able to navigate to the next secton of knowledge')
});

When("User Click on the previous button", () => {
    createKnowledge.previousButtonClickInKnowledge()
    createKnowledge.previousButtonClickInKnowledge()
    console.log(printTimestamp(), 'Clicked on the previous button')
});

Then("Clicking on previos button should take user to the create Section", () => {
    createKnowledge.userOnCreateSection()
    console.log(printTimestamp(), 'Clicking on previos button take user to the create Section')
});

When("Click on Next", () => {
    createKnowledge.nextButtonOnCreatePageClick()
    console.log(printTimestamp(), 'Clicked on Next')
});


Then("Clicking on next button should take user to the view stage", () => {
    createKnowledge.viewStageVisibleAndHighlighted()
    console.log(printTimestamp(), 'Clicking on next button take user to the view stage')
});

And("All the knowledge Details should be already expanded", () => {
    createKnowledge.knowledgeDescriptionDetailsExpanded()
    createKnowledge.knowledgeSymptomDetailsExpanded()
    createKnowledge.knowledgeCausesAndSolutionsknowledgeCauseDetailsExpanded()
    createKnowledge.knowledgeTagsDetailsExpanded()
    console.log(printTimestamp(), 'All the knowledge Details already expanded')
});

When("User Collapse one of the section", () => {
    createKnowledge.KnowledgeDescriptionDetailsCollapseAndExpandButtonClick()
    console.log(printTimestamp(), 'Collapsed one of the section')
});

And("navigate from previous-Next Section to current section", () => {
    createKnowledge.previousButtonClickInKnowledge()
    createKnowledge.nextButtonOnCreatePageClick()
    console.log(printTimestamp(), 'navigated from previous-Next Section to current section')
});

Then("collapsed section again expanded", () => {
    createKnowledge.knowledgeDescriptionDetailsExpanded()
    console.log(printTimestamp(), 'collapsed section again expanded')
});

And("Close DAW application", () => {
    cy.DeleteWorkflow()
    cy.log('Test case executed successfully')
    console.log(printTimestamp(), 'Test case executed successfully')
});