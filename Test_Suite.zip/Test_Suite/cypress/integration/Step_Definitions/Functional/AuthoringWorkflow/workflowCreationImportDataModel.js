/// <reference types="Cypress" />
/// <reference types='cypress-tags' />

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';

import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();
var arr = [];

When("By default , Dashboard page under Patterns should be displayed", () => {
    createPattern.dashboardButtonVisible()
    console.log(printTimestamp(), ' Dashboard page under Patterns displayed')
});

Then("User should able to click on My Patterns three dots and able to see create pattern option", () => {
    createPattern.myPatternThreeDotsClick()
    createPattern.createPatternVisible()
    console.log(printTimestamp(), ' Clicked on My Patterns three dots')
});

And("clicks on create pattern button", () => {
    createPattern.createPatternClick()
    cy.wait(3000)
    createPattern.breadcumbLastValueCapture()
    console.log(printTimestamp(), ' Clicked on create pattern button')

});

And("Verify new workflow created with three dots available against its name", () => {
    createPattern.newlyCreatedWFAndItsThreeDotsVisible()
    console.log(printTimestamp(), ' New workflow created with three dots available against its name')
});

When("User clicks on Import Data Model", () => {
    createPattern.importdatamodelTabClick()
    console.log(printTimestamp(), ' Clicked on Import Data Model')
});

Then("Note with Select the data models you want to import and Dropdown section should be displayed", () => {
    createPattern.noteInImportDataModelVisible()
    createPattern.importdatamodelDrpdownVisible()
    console.log(printTimestamp(), ' Note and Dropdown displayed')
});

And("User able to click on dropdown section and verifies list of options available in it", () => {
    createPattern.importdatamodelDrpdownClick()
    createPattern.importdatamodelDrpdownValueTextVerification()
    createPattern.importdatamodelDrpdownValueCapture().invoke("text").as('commonDataModel')
    console.log(printTimestamp(), ' clicked on dropdown button and verified list of options')
});

When("User clicks on modality and it should get expanded with Data Models displayed in it", () => {
    createPattern.importdatamodelDrpdownCommonSelection()
    createPattern.importdatamodelDrpdownValueTextVerification()
    console.log(printTimestamp(), ' Modality clicked and Data Models displayed')
});

Then("Modality and Data Models should be available in dropdown option as per the user having access for a modality", () => {
    createPattern.importdatamodelDrpdownValueTextVerification()
    console.log(printTimestamp(), ' Modality and Data Models displayed')
});

And("User hovers on data model then files, Modality and Attribute details should be displayed", () => {
    createPattern.dataModelsHoverVisible()
    console.log(printTimestamp(), ' files, Modality and Attribute details displayed')
});

And("User selects one data model from dropdown and verifies user should select multiple models from list", () => {
    createPattern.importdatamodelDrpdownMRSelection()
    console.log(printTimestamp(), ' Selected one data model from dropdown')
});

And("User collapses other section then Data Model name should be displayed as a tag with remove option", () => {
    createPattern.addConditionTabClick()
    createPattern.importdatamodelDrpdownValueCapturedVisible()
    createPattern.importdatamodelDrpdownValueCapturedRemoveMarkVisible()
    console.log(printTimestamp(), '  Data Model name displayed as a tag with remove option')
});

And("User hovers on data model then files, Modality and Attribute details should be displayedd", () => {
    console.log(printTimestamp(), ' files, Modality and Attribute details displayed')
});

And("User clicks on Remove option and verifies Removed data model should not be available in tags", () => {
    createPattern.importdatamodelDrpdownValueCapturedRemoveMarkClick()
    createPattern.okButtonClick();
    console.log(printTimestamp(), ' Clicked on Remove option and verified Removed data model not available in tags')
});

And("Clicks on import data model and verifies Removed Data Model should not be available as selected", () => {
    createPattern.importdatamodelTabClick()
    createPattern.importdatamodelDrpdownClick()
    createPattern.checkBoxNotCheckedVerification()
    console.log(printTimestamp(), ' Clicked on import data model and and verified Removed Data Model not available as selected')
});

And("Verify user should able to remove all selected data models from tags", () => {
    createPattern.checkboxUnClick()
    createPattern.importdatamodelDrpdownClick()
    createPattern.checkBoxNotCheckedVerification()
    console.log(printTimestamp(), ' Removed all selected data models from tags')
});
