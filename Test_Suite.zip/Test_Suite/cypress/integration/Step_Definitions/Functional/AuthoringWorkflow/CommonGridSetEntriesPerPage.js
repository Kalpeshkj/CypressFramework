/// <reference types="Cypress" />
/// <reference types='cypress-tags' /> 
import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();

When("User Create Authoring Workflow", () => {
    createPattern.myPatternThreeDotsClick()
    createPattern.createPatternClick()
    console.log(printTimestamp(), 'Createed Authoring Workflow')
});

And("Click on + Add Condition and Click on From Rule Pattern", () => {
    createPattern.addConditionTabClick()
    createPattern.dropDownOptionUnderAddConditionClick()
    createPattern.fromRulePatternOpotionClick()
    console.log(printTimestamp(), 'Clicked on + Add Condition and Clicked on From Rule Pattern')
});

Then("By default Entries per Page should be available as 10", () => {
    createPattern.tenEntriesPerPageDropDownText()
    console.log(printTimestamp(), 'By default Entries per Page available as 10')
});

And("Max 10 records should be available per page For Pattern and My Pattern Dashboard By default entries per page should be available as 15", () => {
    createPattern.tenRecordsPerPgae()
    console.log(printTimestamp(), 'Max 10 records available per page For Pattern and My Pattern Dashboard By default entries per page available as 15')
});

When("Click on drop down of entries per page", () => {
    createPattern.entriesPerPageDropDownClick()
    console.log(printTimestamp(), 'Clicked on drop down of entries per page')
});

Then("5,10,20,50,100 values should be available in drop down of entries per page For"
    + " Pattern My Pattern Dashboard Grid User should be able to click on drop down 10,15,20,50,100,500 values should be available", () => {
        createPattern.entriesPerPageOptionsVerification()
        console.log(printTimestamp(), "5,10,20,50,100 values available in drop down of entries per page For"
            + " Pattern My Pattern Dashboard Grid User able to clicked on drop down 10,15,20,50,100,500 values available")
    });

When("Change value from drop down of entries per page", () => {
    createPattern.fiveEntriesPerPageOptionClick()
    console.log(printTimestamp(), 'Changed value from drop down of entries per page')
});

Then("As per value available in entries per page Number of records should get updated in page", () => {
    createPattern.fiveRecordsPerPgae()
    console.log(printTimestamp(), 'As per value available in entries per page Number of records gets updated in page')
});

And("value for showing current page of total page should get updated", () => {
    createPattern.currentPageOfTotalPageText()
    console.log(printTimestamp(), 'value for showing current page of total page gets updated')
});

When("User Search any pattern", () => {
    createPattern.searchByKeywordOptionType()
    createPattern.searchIconClicked()
    console.log(printTimestamp(), 'Searched any pattern')
});

Then("Max Number of records should be available as per selected value in drop down of entries per page", () => {
    createPattern.fiveRecordsPerPgae()
    console.log(printTimestamp(), 'Max Number of records available as per selected value in drop down of entries per page')
});

When("User Apply filter on any all column", () => {
    createPattern.nameFilterType()
    createPattern.searchIconOfNameFilterClick()
    console.log(printTimestamp(), 'Applied filter on any all column')
});

Then("Max Number of records should be available as per value selected in dropdown of entries per page", () => {
    createPattern.fiveRecordsPerPgae()
    console.log(printTimestamp(), 'Max Number of records available as per value selected in dropdown of entries per page')
});

When("Navigate to next page", () => {
    createPattern.arrowToNevigateToNextpageClick()
    console.log(printTimestamp(), 'Navigated to next page')
});

Then("In each page number of records should be displayed based on value selected in drop down of entries per page", () => {
    createPattern.fiveRecordsPerPgae()
    console.log(printTimestamp(), 'In each page number of records displayed based on value selected in drop down of entries per page')
});

When("User Click on cancel", () => {
    createPattern.cancelButtonClick()
    console.log(printTimestamp(), 'Clicked on cancel')
});

Then("Import condition pop up should get close", () => {
    createPattern.importConditionPopUpNotExist()
    console.log(printTimestamp(), 'Import conditions pop up gets close')
});

When("Click on + Add Condition and Click on From Rule Pattern", () => {
    createPattern.addConditionTabClick()
    createPattern.dropDownOptionUnderAddConditionClick()
    createPattern.fromRulePatternOpotionClick()
    console.log(printTimestamp(), 'Clicked on + Add Condition and Clicked on From Rule Pattern')
});

And("select Show All", () => {
    createPattern.showAllCheckBoxchecked()
    cy.wait(2000)
    console.log(printTimestamp(), 'selects Show All')
});

Then("By default Entries per Page should be available as 10 Max 10 records should be available per page", () => {
    createPattern.tenRecordsPerPgae()
    createPattern.tenEntriesPerPageDropDownText()
    console.log(printTimestamp(), 'By default Entries per Page available as 10 Max 10 records available per page')
});

When("User Update entries per page", () => {
    createPattern.entriesPerPageDropDownClick()
    createPattern.fiveEntriesPerPageOptionClick()
    console.log(printTimestamp(), 'Updated entries per page')
});

And("Navigate to any page from pagination and click on Cancel", () => {
    createPattern.arrowToNevigateToNextpageClick()
    createPattern.cancelButtonClick()
    console.log(printTimestamp(), 'Navigated to any page from pagination and clicked on Cancel')
});

Then("Import condition pop up should be closed", () => {
    createPattern.importConditionPopUpNotExist()
    console.log(printTimestamp(), 'Import condition pop up closed')
});

When("User Click on + Add Condition and Click on From Rule Pattern", () => {
    createPattern.addConditionTabClick()
    createPattern.dropDownOptionUnderAddConditionClick()
    createPattern.fromRulePatternOpotionClick()
    console.log(printTimestamp(), 'User Clicked on + Add Condition and Clicked on From Rule Pattern')
});

Then("By default showing 1 of total number of page should be displayed", () => {
    createPattern.currentPageOfTotalPageTextVisible()
    console.log(printTimestamp(), 'By default showing 1 of total number of page displayed')
});

And("By default Entries per Page should be available as 10 Max 10 records should be available per page", () => {
    createPattern.tenRecordsPerPgae()
    createPattern.tenEntriesPerPageDropDownText()
    console.log(printTimestamp(), 'By default Entries per Page available as 10 Max 10 records available per page')
});

And("Repeat above steps in Pattern and My Pattern Dashboard", () => {
    createPattern.cancelButtonClick({ force: true })
    cy.DeleteWorkflow()
    createPattern.patternDashboardClick()
    cy.wait(3000)
    createPattern.fifteenEntriesPerPageDropDownText()
    createPattern.fifteenRecordsInPatternDashBoard()
    createPattern.entriesPerPageDropDownClick()
    createPattern.entriesPerPageOptionsVerificationInMyPatternDashboard()
    createPattern.tenEntriesPerPageOptionInDashBoardClick()
    cy.wait(1000)
    createPattern.tenRecordsInPatternDashBoard()
    createPattern.currentPageOfTotalPageTextInDashBoard()
    createPattern.patternNameSearchOptionInDashBoardType()
    createPattern.searchIconClick()
    cy.wait(1000)
    createPattern.tenRecordsInPatternDashBoard()
    createPattern.arrowToNevigateToNextpageClick()
    cy.wait(1000)
    createPattern.tenRecordsInPatternDashBoard()
    createPattern.myPatternDashboardClick()
    cy.wait(1000)
    createPattern.fifteenEntriesPerPageDropDownText()
    createPattern.fifteenRecordsInPatternDashBoard()
    createPattern.entriesPerPageDropDownClick()
    createPattern.entriesPerPageOptionsVerificationInMyPatternDashboard()
    createPattern.tenEntriesPerPageOptionInDashBoardClick()
    cy.wait(1000)
    createPattern.tenRecordsInPatternDashBoard()
    createPattern.currentPageOfTotalPageTextInDashBoard()
    createPattern.patternNameSearchOptionInDashBoardType()
    createPattern.searchIconClick()
    cy.wait(1000)
    createPattern.tenRecordsInPatternDashBoard()
    createPattern.arrowToNevigateToNextpageClick()
    cy.wait(1000)
    createPattern.tenRecordsInPatternDashBoard()
    console.log(printTimestamp(), 'Repeats above steps in Pattern and My Pattern Dashboard')
});

And("close DAW  application", () => {
    cy.log('Test case executed successfully')
    console.log(printTimestamp(), 'Closed DAW application')
});
