/// <reference types="Cypress" />
/// <reference types='cypress-tags' />  

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();
import CreateKnowledge from "../../../../support/pageObjects/pages/KnowledgeAuthoring/CreateKnowledge";
const createKnowledge = new CreateKnowledge();


Then("Navigated to Knowledge dashboard", () => {
    createKnowledge.knowledgeClick()
    cy.CreateMyKnowledge()
    createKnowledge.saveAsDraftClick()
    cy.wait(5000)
    cy.visit(Cypress.env("DAWAutomationURL"));
    cy.wait(5000)
    createKnowledge.knowledgeCollapseClick()
    createPattern.myPatternDashboardClick()
    cy.wait(3000)
    console.log(printTimestamp(), ' User Navigates to Knowledge Dashboard')
});

When("User Clicks on a knowledge in published state", () => {
    createPattern.clearAllFiltersButtonClick()
    createKnowledge.patternNameTypeInKnowledgeSearchFilter()
    createKnowledge.selectAllCheckBoxBesidesNameClick()
    createKnowledge.publishKnowledgeClick()
    createKnowledge.popUpOkButtonClick()
    createKnowledge.firstKnowledgeOpen()
    console.log(printTimestamp(), ' Clicked on a knowledge in published state')
});

Then("Verifies buttons on the bottom right corner of the page", () => {
    createKnowledge.publishButtonInsideKnowledgeVisible()
    createKnowledge.deleteButtonInsideKnowledgeVisible()
    createKnowledge.editButtonInsideKnowledgeVisible()
    createKnowledge.closeButtonInsideKnowledgeVisible()
    console.log(printTimestamp(), ' Verified buttons on the bottom right corner of the page')
});

Then("User Clicks on edit button", () => {
    createKnowledge.editButtonInsideKnowledgeClick()
    console.log(printTimestamp(), ' Clicked edit button')
});

Then("Navigates to Knowledge dashboard", () => {
    createPattern.myPatternDashboardClick()
    createPattern.clearAllFiltersButtonClick()
    createKnowledge.patternNameTypeInKnowledgeSearch()
    console.log(printTimestamp(), ' User Navigates to Knowledge Dashboard')
});

And("Performs any changes in content or name of the knowledge and clicks on save", () => {
    createKnowledge.removeIconForBoltspartInTokenClick()
    createKnowledge.popUpOkButtonClick()
    createKnowledge.saveAsDraftClick()
    cy.wait(3000)
    console.log(printTimestamp(), ' Performed any changes in content or name of the knowledge and clicked on save')
});

Then("Edit the knowledge associated with a pattern by modifying the metadata tags", () => {
    console.log(printTimestamp(), ' Edited Knowledge associated with a pattern by modifying the metadata tags')
});

Then("Edit the knowledge associated with another knowledge by modifying the metadata tags", () => {
    console.log(printTimestamp(), " Edited knowledge associated with another knowledge by modifying the metadata tags")
});

And("Verifies status and version of the modified knowledge in knowledge dashboard", () => {
    createKnowledge.editknowledgeStatusVisible()
    createKnowledge.editknowledgeVersionVisible()
    console.log(printTimestamp(), ' Verified status and version of the modified knowledge in knowledge dashboard')
});

And("Verifies the modified by and modified date on the edited knowledge", () => {
    createKnowledge.editknowledgeVersionVisible()
    console.log(printTimestamp(), ' Verified the modified by and modified date on the edited knowledge')
});

And("Verifies a new workflow is created", () => {
    createKnowledge.NewPatternCreatedVisible()
    createKnowledge.selectAllCheckBoxBesidesNameClick()
    createKnowledge.publishKnowledgeClick()
    createKnowledge.popUpOkButtonClick()
    console.log(printTimestamp(), ' Verified a new workflow is created')
});

When("User Clicks on the knowledge and navigate to include knowledge", () => {
    cy.visit(Cypress.env("URL"));
    cy.createPattern()
    createPattern.nextButtonClick()
    cy.ApplyMetaDetaPageCompletion()
    createPattern.nextButtonClick()
    createPattern.ShowCheckboxClick()
    createKnowledge.patternNameTypeInKnowledgeSearchFilter()
    createKnowledge.editedknowledgeVisible()
    cy.DeleteDynamicPattern()
    cy.visit(Cypress.env("DAWAutomationURL"));
    cy.wait(5000)
    createKnowledge.knowledgeCollapseClick()
    createPattern.myPatternDashboardClick()
    cy.wait(3000)
    console.log(printTimestamp(), ' Clicked on the knowledge and navigate to include knowledge')
});

When("User Clicks on the knowledge and navigate to Add cause", () => {
    cy.wait(3000)
    createKnowledge.firstKnowledgeopen()
    cy.wait(2000)
    createKnowledge.editButtonInsideKnowledgeClick()
    createKnowledge.causeAndSolutionSectionButtonClick()
    createPattern.causeAndSolutionsDataVisible()
    console.log(printTimestamp(), ' Clicked on the knowledge and navigated to Add cause')
});

When("User Clicks on the knowledge and navigate to Add symptom", () => {
    cy.wait(3000)
    createKnowledge.firstKnowledgeopen()
    cy.wait(2000)
    createKnowledge.editButtonInsideKnowledgeClick()
    createKnowledge.symptomsSectionButtonClick()
    createPattern.symptomsDataVisible()
    console.log(printTimestamp(), ' Clicked on the knowledge and navigated to Add symptom')
});

Then("Verifies the Dashboard for changes made in knowledge", () => {
    createPattern.myPatternDashboardClick()
    createPattern.clearAllFiltersButtonClick()
    createKnowledge.patternNameTypeInKnowledgeSearch()
    cy.wait(3000)
    createPattern.selectAllRecordClickInDashboard()
    cy.wait(2000)
    createKnowledge.deleteKnowledgeClick()
    cy.wait(3000)
    createPattern.selectAllRecordClickInDashboard()
    cy.wait(2000)
    createKnowledge.deleteKnowledgeClick()
    console.log(printTimestamp(), ' Verified the Dashboard for changes made in knowledge')
});

Then("Repeats above steps for My Knowledge Dashboard", () => {
    cy.visit(Cypress.env("URL"));
    createKnowledge.knowledgeClick()
    cy.CreateMyKnowledge()
    createKnowledge.saveAsDraftClick()
    cy.wait(5000)
    cy.visit(Cypress.env("DAWAutomationURL"));
    cy.wait(5000)
    createPattern.patternSectionCollapseClick()
    createKnowledge.knowledgeCollapseClick()
    createKnowledge.myKnowledgeDahboardClick()
    createPattern.myPatternDashboardClick()
    cy.wait(3000)
    createPattern.clearAllFiltersButtonClick()
    createKnowledge.patternNameTypeInKnowledgeSearchFilter()
    createKnowledge.selectAllCheckBoxBesidesNameClick()
    createKnowledge.publishKnowledgeClick()
    createKnowledge.popUpOkButtonClick()
    createKnowledge.firstKnowledgeOpen()
    createKnowledge.publishButtonInsideKnowledgeVisible()
    createKnowledge.deleteButtonInsideKnowledgeVisible()
    createKnowledge.editButtonInsideKnowledgeVisible()
    createKnowledge.closeButtonInsideKnowledgeVisible()
    createKnowledge.editButtonInsideKnowledgeClick()
    createKnowledge.removeIconForBoltspartInTokenClick()
    createKnowledge.popUpOkButtonClick()
    createKnowledge.saveAsDraftClick()
    cy.wait(3000)
    createPattern.myPatternDashboardClick()
    createPattern.clearAllFiltersButtonClick()
    createKnowledge.patternNameTypeInKnowledgeSearch()
    createKnowledge.editknowledgeStatusVisible()
    createKnowledge.editknowledgeVersionVisible()
    createKnowledge.NewPatternCreatedVisible()
    createKnowledge.selectAllCheckBoxBesidesNameClick()
    createKnowledge.publishKnowledgeClick()
    createKnowledge.popUpOkButtonClick()
    createPattern.myPatternDashboardClick()
    createPattern.clearAllFiltersButtonClick()
    createKnowledge.patternNameTypeInKnowledgeSearch()
    cy.wait(3000)
    createPattern.selectAllRecordClickInDashboard()
    cy.wait(2000)
    createKnowledge.deleteKnowledgeClick()
    cy.wait(3000)
    console.log(printTimestamp(), ' Steps repeated for My Knowledge Dashboard')
});