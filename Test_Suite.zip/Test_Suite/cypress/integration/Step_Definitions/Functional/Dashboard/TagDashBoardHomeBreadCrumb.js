/// <reference types="Cypress" />
/// <reference types = 'cypress-tags' />    

import "../../../../support/index"
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
var commonData = {};
import PatternDashboard from "../../../../support/pageObjects/pages/Dashboard/PatternDashboard";
const patternDashboard = new PatternDashboard();
import TagDashboard from "../../../../support/pageObjects/pages/Dashboard/TagDashboard";
const tagDashboard = new TagDashboard();

Then("By default , Pattern Dashboard page should be displayed", () => {
    patternDashboard.patternDashboardTitleVisible()
    patternDashboard.patternDashboardBreadCrumVisible()
    console.log(printTimestamp(), 'Pattern Dashboard page displayed')
});

When("User Click on caret present beside the user name", () => {
    tagDashboard.caretBesideNameClick()
    console.log(printTimestamp(), 'Clicked on caret present beside the user name')
});

Then("settings button should be present", () => {
    tagDashboard.settingButtonVisible()
    console.log(printTimestamp(), 'settings button present')
});

When("User Click on settings button", () => {
    tagDashboard.settingButtonClick()
    console.log(printTimestamp(), 'Clicked on settings button')
});

Then("User should be navigaed to the tag dashboard page", () => {
    tagDashboard.tagsPageVisible()
    console.log(printTimestamp(), 'User navigated to the tag dashboard page')
});

When("User Click on home breadcrumb", () => {
    tagDashboard.homeOptionInbreadcrumbClick()
    console.log(printTimestamp(), 'Clicked on home breadcrumb')
});

Then("User should be navigated to the dashboard for which it has access as per content type in privilege table", () => {


    console.log(printTimestamp(), 'User navigated to the dashboard for which it has access as per content type in privilege table')
});

When("User Click on caret present beside the user name", () => {
    tagDashboard.caretBesideNameClick()
    console.log(printTimestamp(), 'Clicked on caret present beside the user name')
});

Then("settings button should be present", () => {
    tagDashboard.settingButtonVisible()
    console.log(printTimestamp(), 'settings button present')
});

When("User Click on settings button", () => {
    tagDashboard.settingButtonClick()
    console.log(printTimestamp(), 'Clicked on settings button')
});

Then("User should be navigaed to the tag dashboard page", () => {
    tagDashboard.tagsPageVisible()
    console.log(printTimestamp(), 'User navigated to the tag dashboard page')
});

And("User should be able to map user to a group having content category as Knowledge", () => {

    console.log(printTimestamp(), 'User able to map user to a group having content category as Knowledge')
});

When("Click on home breadcrumb", () => {
    tagDashboard.homeOptionInbreadcrumbClick()
    console.log(printTimestamp(), 'Clicked on home breadcrumb')
});

Then("User should be navigated to the knowledge dashboard", () => {
    tagDashboard.knowledgeDashboardSelected()
    console.log(printTimestamp(), 'User navigated to the knowledge dashboard')
});

