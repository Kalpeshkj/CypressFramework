/// <reference types="Cypress" />
/// <reference types='cypress-tags' />  

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import PatternDashboard from "../../../../support/pageObjects/pages/Dashboard/PatternDashboard";
const patternDashboard = new PatternDashboard();

Then("By default , Pattern Dashboard page should be displayed", () => {
    patternDashboard.patternDashboardTitleVisible()
    patternDashboard.patternDashboardBreadCrumVisible()
    cy.wait(3000)
    console.log(printTimestamp(), 'Pattern Dashboard displayed')
});

When("User Click on any pattern", () => {
    patternDashboard.patternClick()
    console.log(printTimestamp(), 'Clicked on any pattern')
});

Then("Pattern details should be available in read only mode", () => {
    patternDashboard.readOnlyModeExist()
    console.log(printTimestamp(), 'Pattern details available in read only mode')
});

And("To view full screen icon should be available at top right corner", () => {
    patternDashboard.fullscreenViewButtonvisible()
    console.log(printTimestamp(), ' view full screen icon available at top right corner')
});

When("User click on full screen view", () => {
    patternDashboard.fullscreenViewButtonClick()
    console.log(printTimestamp(), 'clicked on full screen view')
});

Then("Full screen without left pane and header with pattern details including buttons at bottom should be displayed", () => {
    patternDashboard.fullScreenVisible()
    patternDashboard.patternHeaderWithPatternDetailsVisible()
    patternDashboard.buttonsAtBottomVisible()
    console.log(printTimestamp(), ' Full screen without left pane and header with pattern details including buttons at bottom displayed')

});

When("User Click on icon of full screen view again", () => {
    patternDashboard.fullscreenViewButtonClick()
    console.log(printTimestamp(), 'Clicked on icon of full screen view')
});

Then("Full screen with left pane and header with pattern details including buttons at bottom should be displayed", () => {
    patternDashboard.leftPaneDashboardBoxVisible()
    patternDashboard.patternHeaderWithPatternDetailsVisible()
    patternDashboard.buttonsAtBottomVisible()
    console.log(printTimestamp(), 'Full screen with left pane and header with pattern details including buttons at bottom displayed')
});

When("User Click on back < icon available beside pattern name", () => {
    patternDashboard.backArrowClick()
    console.log(printTimestamp(), ' Clicked on back < icon available beside pattern name')
});

Then("User navigate to Dashboard page", () => {
    patternDashboard.patternDashboardTitleVisible()
    patternDashboard.patternDashboardBreadCrumVisible()
    console.log(printTimestamp(), 'User navigate to Dashboard page')
});

When("User Click on icon of full screen view", () => {
    patternDashboard.fullscreenViewButtonClick()
    console.log(printTimestamp(), 'Clicked on icon of full screen view')
});

Then("Full screen without left pane and header with pattern details including buttons at bottom should be displayed", () => {
    patternDashboard.fullScreenVisible()
    patternDashboard.patternHeaderWithPatternDetailsVisible()
    patternDashboard.buttonsAtBottomVisible()
    console.log(printTimestamp(), 'Full screen without left pane and header with pattern details including buttons at bottom displayed')
});

When("User Refresh application", () => {
    cy.reload()
    cy.wait(3000)
    console.log(printTimestamp(), 'User Refresh application')
});

Then("Full screen view should not retained", () => {
    patternDashboard.fullScreenNotExist()
    console.log(printTimestamp(), 'Full screen view not retained')
});

And("Dashboard with all pattern datils should be displayed", () => {
    patternDashboard.dashboardWithPattrensVisible()
    console.log(printTimestamp(), 'Dashboard with all pattern datails displayed')
});

When("User Relaunch application", () => {
    cy.reload()
    cy.wait(3000)
    console.log(printTimestamp(), 'User Relaunch application')
});

Then("Full screen view should not retained", () => {
    patternDashboard.fullScreenNotExist()
    console.log(printTimestamp(), 'Full screen view not retained')
});

And("User Repeat above steps for My Pattern Dashboard", () => {
    patternDashboard.myPatternArrowClick()
    patternDashboard.myPattrenDashboardClick()
    cy.wait(1000)
    patternDashboard.patternClick()
    cy.wait(1000)
    patternDashboard.readOnlyModeExist()
    patternDashboard.fullscreenViewButtonvisible()
    patternDashboard.fullscreenViewButtonClick()
    patternDashboard.fullScreenVisible()
    patternDashboard.patternHeaderWithPatternDetailsVisible()
    patternDashboard.buttonsAtBottomVisible()
    patternDashboard.fullscreenViewButtonClick()
    patternDashboard.toggleIconVisible()
    patternDashboard.leftPaneDashboardBoxVisible()
    patternDashboard.patternHeaderWithPatternDetailsVisible()
    patternDashboard.buttonsAtBottomVisible()
    patternDashboard.backArrowClick()
    patternDashboard.patternDashboardTitleVisible()
    patternDashboard.mypatternDashboardBreadCrumVisible()
    patternDashboard.patternClick()
    cy.wait(1000)
    patternDashboard.readOnlyModeExist()
    patternDashboard.fullscreenViewButtonClick()
    patternDashboard.fullScreenVisible()
    patternDashboard.patternHeaderWithPatternDetailsVisible()
    patternDashboard.buttonsAtBottomVisible()
    cy.reload()
    cy.wait(3000)
    patternDashboard.fullScreenNotExist()
    patternDashboard.dashboardWithPattrensVisible()
    patternDashboard.patternClick()
    cy.wait(1000)
    patternDashboard.readOnlyModeExist()
    cy.reload()
    cy.wait(3000)
    patternDashboard.fullScreenNotExist()
    patternDashboard.dashboardWithPattrensVisible()
    patternDashboard.patternClick()
    cy.wait(2000)
    patternDashboard.readOnlyModeExist()
    cy.reload()
    cy.wait(2000)
    patternDashboard.fullScreenNotExist()
    console.log(printTimestamp(), 'Repeats above steps for My Pattern Dashboard')
});

And("close the DAW application", () => {
    cy.log("Test case executed successfully");
    console.log(printTimestamp(), ' Test case executed successfully')
});
