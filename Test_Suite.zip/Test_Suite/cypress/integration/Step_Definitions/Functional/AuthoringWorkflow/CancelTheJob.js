/// <reference types="Cypress" />
/// <reference types='cypress-tags' /> 
import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();
import ValidationPage from "../../../../support/pageObjects/pages/PatternAuthoring/ValidatePage";
const validationPage = new ValidationPage();
When("User Create Pattern and Navigate to Validate Step", () => {
	cy.createPattern()
    createPattern.nextButtonClick()
    cy.wait(2000)
    cy.ApplyMetaDetaPageCompletionForPatternCreation()
    createPattern.nextButtonClick()
    cy.wait(2000)
    createPattern.showAllCheckboxClick()
    createPattern.recordSelectionInIncludeKnowledge()
    createPattern.nextButtonClick()
    cy.wait(2000)
    console.log(printTimestamp() ,'User Create edPattern and Navigated to Validate Step')
});

And("Enter Validation Criteria", () => {
	validationPage.validationIdDropdownClick()
    validationPage.selectFirstId()
    validationPage.selectButtonClick()
    validationPage.calenderOptionClick()
    validationPage.datePrevIconClick()
    validationPage.dateRangeSlection()
    validationPage.taskLimitInputBoxTypeOne()
    console.log(printTimestamp() ,'Entered Validation Criteria')
});

And("Click on Validate button", () => {
	validationPage.validateButtonClick()
    console.log(printTimestamp() ,'Clicked on Validate button')
});

Then("job validation should get started. Job status should be displayed as 'In Progress'", () => {
	validationPage.validationStatusBoxWithInprocessStatus()
    console.log(printTimestamp() ,'job validation gets started. Job status displayed as In Progress')
});

When("user click on X icon", () => {
	validationPage.inprogressCrossIconClick()
    console.log(printTimestamp() ,'user clicked on X icon')
});

Then("job should get cancelled and status should be displayed as Cancelled.", () => {
	validationPage.validationStatusBoxWithCancelledStatus()
    console.log(printTimestamp() ,'job gets cancelled and status displayed as Cancelled.')
});

And("Verify toaster message if validation is cancelled.Right tick mark with Success."
+" Pattern Validation is cancelled for the pattern Pattern Name", () => {
	validationPage.jobValidationCancelMessageVisible()
    console.log(printTimestamp() ,"Verified toaster message if validation is cancelled.Right tick mark with Success."
    +" Pattern Validation is cancelled for the pattern Pattern Name")
});

When("Click on Save as Draft", () => {
	validationPage.saveAsDraftButtonClick()
    cy.wait(3000)
    console.log(printTimestamp() ,'Clicked on Save as Draft')
});

And("Navigate to other workflow or dashboard , come back to saved workflow and verify job result", () => {
    cy.ExistingWorkFlowText()
    createPattern.patternDashboardClick()
    cy.wait(2000)
    cy.ExistingWFClick()
    console.log(printTimestamp() ,'Navigated to other workflow or dashboard , come back to saved workflow and verify job result')
});

Then("Job status with 'Completed' only should be displayed in validation result", () => {
	validationPage.validationStatusBoxWithCompletedStatus()
    console.log(printTimestamp() ,'Job status with Completed only displayed in validation result')
});

When("User Update Validation Criteria , Click on Validate button and Click on X icon", () => {
    validationPage.validationIdDropdownClick()
    validationPage.selectFirstId()
    validationPage.selectSecondId()
    validationPage.selectButtonClick()
	validationPage.validateButtonClick()
    validationPage.inprogressCrossIconClick()
    console.log(printTimestamp() ,'User Updated Validation Criteria , Clicked on Validate button and Clicked on X icon')
});

Then("Job should get Cancelled", () => {
	validationPage.validationStatusBoxWithCancelledStatus()
    validationPage.jobValidationCancelMessageVisible()
    console.log(printTimestamp() ,'Job gets Cancelled')
});

When("Navigate to next or previous workflow step , come back to validate step", () => {
	validationPage.previousButtonClick()
    cy.wait(2000)
    createPattern.nextButtonClick()
    cy.wait(2000)
    console.log(printTimestamp() ,'Navigated to next or previous workflow step , come back to validate step')
});

Then("cancelled job results should not be displayed.Within session it should be displayed", () => {
	validationPage.validationStatusBoxWithOutCancelledStatus()
    console.log(printTimestamp() ,'cancelled job results not be displayed.Within session it displayed')
});


