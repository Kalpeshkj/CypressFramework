/// <reference types="Cypress" />
/// <reference types='cypress-tags' />

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';

import PatternDashboard from "../../../../support/pageObjects/pages/Dashboard/PatternDashboard";
const patternDashboard = new PatternDashboard();
import KnowledgeDashboard from "../../../../support/pageObjects/pages/Knowledge_Dashboard/KnowledgeDashboard";
const knowledgeDashboard = new KnowledgeDashboard();

When("User Navigates to Knowledge dashboard", () => {
    knowledgeDashboard.knowledgeClick();
    knowledgeDashboard.knowledgeDashboardClick();
    console.log(printTimestamp(), '  Navigated to Knowledge dashboard')
});

Then('Verifies by default sorting available for "Modified On" column', () => {
    patternDashboard.byDefaultModifiedOnColumnSortedVerification();
    console.log(printTimestamp(), ' Verified by default sorting available for "Modified On" column')
});

And("By default DESC sorting should be available", () => {
    patternDashboard.modifiedOnColumnSortedVerification();
    console.log(printTimestamp(), ' By default DESC sorting available')
});

When("Verifies sorting icon on Modified On column", () => {
    patternDashboard.modifiedOnColumnSortedIconVerificationDESC();
    console.log(printTimestamp(), ' Verified sorting icon on Modified On column')
});

Then("For DESC sorting , downward facing triangle should be available", () => {
    patternDashboard.modifiedOnColumnDESCSortedVerification();
    console.log(printTimestamp(), ' For DESC sorting , downward facing triangle displayed')
});

When('User clicks on "Modified On" column', () => {
    patternDashboard.modifiedonColumnClickk();
    console.log(printTimestamp(), ' modified on column clicked')
});

Then("Data should be displayed in Ascending order", () => {
    patternDashboard.sortedDataVerificationForKnowledge();
    console.log(printTimestamp(), ' Data displayed in ASC order')
});

When("Verifies Sorting icon in Modified On column", () => {
    patternDashboard.modifiedonColumnClickk();
    patternDashboard.modifiedOnColumnSortedVerificationForASC();
    console.log(printTimestamp(), ' Verified sorting icon on Modified On column')
});

Then("For ASC sorting ,upward facing triangle should be available", () => {
    patternDashboard.modifiedOnColumnASCSortedVerificationInKnowledgeDashboard();
    console.log(printTimestamp(), ' For ASC sorting , upward facing triangle displayed')
});

And("Performs sorting operation on all the columns present bydefault", () => {
    patternDashboard.knowledgeNameColumnClickAndSortedDataVerification();
    patternDashboard.noOfAssociationColumnClickAndSortedDataVerification();
    patternDashboard.versionColumnClickAndSortingOfDataVerification();
    patternDashboard.knowledgeStateColumnClickAndSortedDataVerification();
    patternDashboard.modifiedbyColumnClickInKnowledgeAndSortingOfDataVerification();
    patternDashboard.modifiedonColumnClickInKnowledgeAndSortingOfDataVerification();
    console.log(printTimestamp(), ' sorting operation performed on all columns')
});

When("User Adds additional column and repeats the above steps", () => {
    patternDashboard.knowledgeDropdownClick();
    patternDashboard.selectDropdownValues();
    patternDashboard.knowledgeNameColumnClickAndSortedDataVerification();
    patternDashboard.noOfAssociationColumnClickAndSortedDataVerification();
    patternDashboard.versionColumnClickAndSortingOfDataVerification();
    patternDashboard.knowledgeStateColumnClickAndSortedDataVerification();
    patternDashboard.modifiedbyColumnClickInKnowledgeAndSortingOfDataVerification();
    patternDashboard.modifiedonColumnClickInKnowledgeAndSortingOfDataVerification();
    patternDashboard.createdbyColumnClickAndSortingOfDataVerification();
    patternDashboard.createdOnColumnClickAndSortingOfDataVerification();
    console.log(printTimestamp(), ' Additional columns added and sorting operation performed')

});

Then("Repeat all the above steps for my knowledge Dashboard", () => {
    knowledgeDashboard.myKnowledgeClick();
    knowledgeDashboard.myKnowledgeDashboardClick();
    patternDashboard.byDefaultModifiedOnColumnSortedVerification();
    patternDashboard.modifiedOnColumnSortedVerification();
    patternDashboard.modifiedOnColumnSortedIconVerificationDESC();
    patternDashboard.modifiedOnColumnDESCSortedVerification();
    patternDashboard.sortedDataVerificationForKnowledge();
    patternDashboard.modifiedonColumnClickk();
    patternDashboard.modifiedOnColumnSortVerificationForASC();
    patternDashboard.modifiedOnColumnASCSortedVerificationInKnowledgeDashboard();
    patternDashboard.knowledgeDropdownClick();
    patternDashboard.selectDropdownValues();
    patternDashboard.knowledgeNameColumnClickAndSortedDataVerification();
    patternDashboard.versionColumnClickAndSortingOfDataVerification();
    patternDashboard.knowledgeStateColumnClickAndSortedDataVerification();
    patternDashboard.modifiedbyColumnClickInKnowledgeAndSortingOfDataVerification();
    patternDashboard.modifiedonColumnClickInKnowledgeAndSortingOfDataVerification();
    patternDashboard.createdbyColumnClickAndSortingOfDataVerification();
    patternDashboard.createdOnColumnClickAndSortingOfDataVerification();
    console.log(printTimestamp(), ' All steps repeated in my knowledge dashboard')
});
