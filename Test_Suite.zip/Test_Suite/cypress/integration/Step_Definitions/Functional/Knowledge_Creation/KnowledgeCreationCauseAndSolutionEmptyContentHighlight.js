
/// <reference types="Cypress" />
/// <reference types = 'cypress-tags' />    
import "../../../../support/index"
import {When, Then,And } from "cypress-cucumber-preprocessor/steps";
import CreateKnowledge from "../../../../support/pageObjects/pages/KnowledgeAuthoring/CreateKnowledge";
const createKnowledge = new CreateKnowledge();
import {printTimestamp} from '../../../../support/commands'; 

When("User Create knowledge", () => {
	createKnowledge.knowledgeOptionArrowClick()
    createKnowledge.addKnowledgeWorkflowButtonClick() 
    cy.wait(3000)
    console.log(printTimestamp() ,'Create knowledge')
});

Then("Enter all the mandatory details and save knowledge details", () => {
    cy.CreateMyKnowledge()
    console.log(printTimestamp() ,'Enterered all the mandatory details and saved knowledge details')
});

When("User Remove Content from rich text section", () => {
	createKnowledge.causeAndSolutionSectionClick()
    createKnowledge.solutionOneInputBoxCleartext()
    console.log(printTimestamp() ,'Removed Content from rich text section')
});

Then("whole section should be highlighted indicating user that the content has to be filled for user to proceed", () => {
	createKnowledge.contentMissedMessageVisible()
    console.log(printTimestamp() ,'whole section highlighted indicating user that the content has to be filled for user to proceed')
});

When("Click on the save and draft button", () => {
	createKnowledge.saveAsDraftClick()
    cy.wait(2000)
    console.log(printTimestamp() ,'Clicked on the save and draft button')
});

Then("Toaster should get displayed saying the save as Draft failed", () => {
	createKnowledge.toasterMessageVisible()
    console.log(printTimestamp() ,'Toaster gets displayed saying the save as Draft failed')
});

When("Enter some values in the rich text section", () => {
	createKnowledge.solutionOneInputBoxType()
    console.log(printTimestamp() ,'Entered some values in the rich text section')
});

Then("highlight should go", () => {
	createKnowledge.contentMissedMessageNotExist()
    console.log(printTimestamp() ,'highlighted should go')
});

When("Remove content of rich text description section while tag values and Parts values are present", () => {
	createKnowledge.PartsIconClick()
    createKnowledge.twelveNCTextBoxTypeSdd()
    createKnowledge.descriptionTextBoxTypebdd()
    createKnowledge.doneButtonClickInPopUpClick()
    createKnowledge.tagIconUnderSolutionClick()
    createKnowledge.selectTagDropdownClick()
    createKnowledge.awsTagsOptionsClick()
    createKnowledge.plusIconInAddTagsClick()
    createKnowledge.doneButtonClickInPopUpClick()
    createKnowledge.solutionOneInputBoxCleartext()
    console.log(printTimestamp() ,'Removed content of rich text description section while tag values and Parts values are present')
});

Then("Highlight should appear and the user should not be allowed to proceed with save as draft Toaster message should be displayed", () => {
	createKnowledge.contentMissedMessageVisible()
	createKnowledge.saveAsDraftClick()
    cy.wait(2000)
    createKnowledge.toasterMessageVisible()
    console.log(printTimestamp() ,'Highlight appear and the user not be allowed to proceed with save as draft Toaster message displayed')
});

When("Repeat All the steps for multiple solution", () => {
    createKnowledge.solutionOneInputBoxType()
	createKnowledge.addSolutionClick()
    createKnowledge.solutionOneInputBoxType()
    cy.wait(1000)
    createKnowledge.solutionOneInputBoxCleartext()
    console.log(printTimestamp() ,'Repeated All the steps for multiple solution')
});

Then("All the corresponding expected results should pass", () => {
    createKnowledge.contentMissedMessageVisible()
	createKnowledge.saveAsDraftClick()
    cy.wait(2000)
    createKnowledge.toasterMessageVisible()
    createKnowledge.solutionOneInputBoxType()
    console.log(printTimestamp() ,'All the corresponding expected results passed')
});

When("User Create new Cause-solution", () => {
	createKnowledge.addCausesButtonClick()
    createKnowledge.causeTwoInputTextBoxType()
    createKnowledge.addSolutionClick()
    createKnowledge.solutionOneInputBoxType()
    cy.wait(1000)
    console.log(printTimestamp() ,'Creates new Cause-solution')
});

And("Click on the rich text description and click outside after the form is dirty", () => {
    createKnowledge.solutionOneInputBoxCleartext()
    console.log(printTimestamp() ,'Clicked on the rich text description and clicked outside after the form is dirty')
});

Then("The Section should get highlighted", () => {
    createKnowledge.contentMissedMessageVisible()
    createKnowledge.solutionOneInputBoxType()
    cy.wait(1000)
    console.log(printTimestamp() ,'The Section gets highlighted')
});

When("Remove a content in rich text description and add a space", () => {
	createKnowledge.solutionOneInputBoxCleartext()
    cy.wait(1000)
    createKnowledge.solutionOneInputBoxAddSpace()
    console.log(printTimestamp() ,'Removed a content in rich text description and added a space')
});

Then("The rich text editor should remain highlighted", () => {
	createKnowledge.contentMissedMessageVisible()
    console.log(printTimestamp() ,'The rich text editor remained highlighted')
});

When("Add enter for the highlighted content", () => {
	createKnowledge.solutionOneInputBoxPressEnter()
    console.log(printTimestamp() ,'Added enter for the highlighted content')
});

Then("The rich text editor should remain highlighted", () => {
	createKnowledge.contentMissedMessageVisible()
    console.log(printTimestamp() ,'The rich text editor remained highlighted')
});

When("Add  picture without adding any text in the rich text content", () => {
	createKnowledge.insertImageOptionClick()
    cy.wait(2000)
    createKnowledge.browseImageOptionClickAndUploadImage()
    console.log(printTimestamp() ,'Adds  picture without adding any text in the rich text content')
});

Then("The picture should be added but the content should remain highligted", () => {
    createKnowledge.contentMissedMessageVisible()
    console.log(printTimestamp() ,'The picture added but the content should remained highligted')
});

When("Add invalid priority Set same priority for 2 sol", () => {
	createKnowledge.addSolutionClick()
    createKnowledge.priorityDropdownForCauseTwoSolutionTwoClick()
    createKnowledge.priorityOneOptionClick()
    console.log(printTimestamp() ,'Added invalid priority Sets same priority for 2 sol')
});

Then("Save as Draft should not be enabled and the invalid priority should be highlighted", () => {
    createKnowledge.PriorityDropdownsHighlighted()
	createKnowledge.saveAsDraftClick()
    cy.wait(2000)
    createKnowledge.toasterMessageVisible()
    console.log(printTimestamp() ,'Save as Draft not be enabled and the invalid priority highlighted')
});

When("Add invalid priority set Select for 1 sol", () => {
	createKnowledge.priorityDropdownForCauseTwoSolutionOneClick()
    createKnowledge.selectOptionUnderPriorityDropdownForSolutionOneClick()
    console.log(printTimestamp() ,'Added invalid priority set Select for 1 sol')
});


When("Add invalid priority Set Select for more than 1 sol", () => {
	createKnowledge.priorityDropdownForCauseTwoSolutionTwoClick()
    createKnowledge.selectOptionUnderPriorityDropdownForSolutionTwoClick()
    console.log(printTimestamp() ,'Added invalid priority Sets Select for more than 1 sol')
});


When("Skip adding priority for 1 of many Soln", () => {
    createKnowledge.addSolutionClick()
	createKnowledge.priorityDropdownForCauseTwoSolutionTwoClick()
    createKnowledge.priorityTwoOptionUnderCauseTwoSolutionTWoClick()
    console.log(printTimestamp() ,'Skiped adding priority for 1 of many Soln')
});


