/// <reference types="Cypress" />
/// <reference types='cypress-tags' />  

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';

import NavigationPanel from "../../../../support/pageObjects/pages/Dashboard/NavigationPanel";
const navigationPanel = new NavigationPanel();
import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();

When("User Clicks on three dots of my pattern", () => {
    createPattern.myPatternThreeDotsClick()
    console.log(printTimestamp(), ' Clicked on three dots of my pattern')
});

Then("Create Pattern option is displayed", () => {
    navigationPanel.createPatternButtonVisible()
    console.log(printTimestamp(), 'Create Pattern option is displayed')
});

When("User click on Import Data Model", () => {
    createPattern.createPatternButtonClick()
    cy.wait(2000)
    createPattern.patternNameType()
    createPattern.descriptionType()
    createPattern.orderOfExecutionType()
    createPattern.importDataModelClick()
    console.log(printTimestamp(), 'User clicked on Import Data Model')
});

And("Select any Data Model from drop down options", () => {
    createPattern.dataModelDropArrowClick()
    createPattern.dataModelCommonOptionDropArrowClick()
    createPattern.eventLogDataModelClick()
    createPattern.dataModelDropArrowClick()
    console.log(printTimestamp(), 'Selected any Data Model from drop down options')
});

And("User clicks on Add Condition and Add Condition gets expanded", () => {
    createPattern.addConditionTabClick()
    createPattern.expandedAddConditionSectionVerification()
    console.log(printTimestamp(), 'clicked on Add Condition and Add Condition expanded')
});

When("User Click on + drop down", () => {
    createPattern.addConditionPlusIconClick()
    cy.wait(2000)
    console.log(printTimestamp(), 'Clicked on + drop down')
});

Then("From Data Model From Rule-Pattern From Variable option should be displayed", () => {
    createPattern.fromdataModelVisible()
    createPattern.fromrulePatternVisible()
    createPattern.fromVariableVisible()
    console.log(printTimestamp(), 'From Data Model From Rule-Pattern From Variable option displayed')
});

When("User Add condition from data model -pattern- rule", () => {
    createPattern.formDataModelClick()
    cy.wait(1000)
    createPattern.eventLogAttributeClick()
    createPattern.additionalInfoAttributeClick()
    createPattern.operatorForEventOneClick()
    createPattern.equaltoOperatorClick()
    createPattern.ValueForTestOneType()
    createPattern.addConditionPlusIconClick()
    cy.wait(1000)
    createPattern.formDataModelClick()
    cy.wait(1000)
    createPattern.importedEventLogModelClick()
    createPattern.dataModelAdditionalInfoAttributeClick()
    createPattern.opeartorDropDownForEvent3ConditionOneClick()
    createPattern.equaltoOperatorClick()
    createPattern.valueForFirstConditionInThridEventType()
    console.log(printTimestamp(), 'Adds condition from data model -pattern- rule')
});

Then("From Variable option should be in enabled", () => {
    createPattern.addConditionPlusIconClick()
    cy.wait(2000)
    createPattern.fromVariableOptionEnabled()
    console.log(printTimestamp(), 'From Variable option in enabled')
});

When("User Hover on From Variables and verify list of created events", () => {
    createPattern.fromVariableOptionClick()
    console.log(printTimestamp(), 'Hovered on From Variables and verified list of created events')
});

Then("All created events should be available under From Variable", () => {
    createPattern.eventOneUnderFromvariableVisible()
    createPattern.eventTwoUnderFromvariableVisible()
    console.log(printTimestamp(), 'All created events available under From Variable')
});

When("User Hover on any event", () => {
    createPattern.eventOneUnderFromvariableClick()
    console.log(printTimestamp(), 'Hovered on any event')
});

Then("As a Clone option for each event displayed", () => {
    createPattern.asACloneOptionVisible()
    createPattern.eventTwoUnderFromvariableClick()
    createPattern.asACloneOptionVisible()
    createPattern.eventOneUnderFromvariableClick()
    console.log(printTimestamp(), 'As a Clone option for each event displayed')
});

When("User Click on As is option from any of created event e.g Logevent1", () => {
    createPattern.asIsOptionClick()
    console.log(printTimestamp(), 'Clicked on As is option from any of created event e.g Logevent1')
});

Then("Event name including operator between event,attribute,value,operator should be added as part of add"
    + " condition read-only in copied state Operator between event should not get copied when first event added From Variable As is", () => {
        createPattern.copiedEventNameVisible()
        createPattern.operatorBetweenEvent()
        console.log(printTimestamp(), "Event name including operator between event,attribute,value,operator added as part of add"
            + " condition read-only in copied state Operator between event not get copied when first event added From Variable As is")
    });

And("“X” enabled displayed", () => {
    createPattern.crossIconEnabledAndVisible()
    console.log(printTimestamp(), '"“X” enabled displayed')

});

When("Select Operator for that event", () => {
    createPattern.operatorDropDownForCopiedEventClick()
    createPattern.andOperatorClick()
    console.log(printTimestamp(), 'Selects Operator for that event')
});

Then("Logical expression for event should be updated in add condition", () => {
    createPattern.updatedLogicalExpresssionUnderAddConditionVisible()
    console.log(printTimestamp(), 'Logical expression for event updated in add condition')
});

And("Add conditions expressions in actual  event e.g Logevent1", () => {
    createPattern.addConditionButtonForeventOneClick()
    createPattern.attributeForSecondConditionInFirstEventClick()
    createPattern.attributeForSecondConditionClick()
    createPattern.operatorDropDownForSecondConditionClick()
    createPattern.equalToOperatorForSecondConditonClick()
    createPattern.valueForSecondConditionFirstEventType()
    console.log(printTimestamp(), 'Add conditions expressions in actual  event e.g Logevent1')
});

When("User Group conditions within actual event", () => {
    createPattern.operatorAtConditionTwoEventOneClick()
    createPattern.andOperatorAtConditionTwoEventOne()
    createPattern.conditonOneInEventOneCheckBox()
    createPattern.conditonTwoInEventOneCheckBox()
    createPattern.groupButtonAtConditonClick()
    console.log(printTimestamp(), 'User Grouped conditions within actual event')

});

Then("Tooltip should get updated for copied event block should be available to depict grouping of condition", () => {

    createPattern.ungroupOptionForConditionsVisible()
    console.log(printTimestamp(), 'Tooltip gets updated for copied event block available to depict grouping of condition')
});

When("User Select events", () => {
    createPattern.copiedEventCheckBoxClick()
    createPattern.EventTwoCheckBoxClick()
    console.log(printTimestamp(), 'Selects events')
});

Then("Group option should be enabled when events are selected", () => {
    createPattern.groupButtonAtEventEnabled()
    console.log(printTimestamp(), 'Group option enabled when events are selected')
});

When("click on group option", () => {
    createPattern.groupButtonAtEventClick()
    console.log(printTimestamp(), 'clicked on group option')
});

Then("Logical expression should be updated as per grouped events", () => {
    createPattern.updatedLogicalExpresssionUnderAddConditionAfterAddingGroup()
    console.log(printTimestamp(), 'Logical expression updated as per grouped events')

});

And("For grouped events “Ungroup” option should be available in enabled state", () => {
    createPattern.ungroupOptionForEventEnabled()
    console.log(printTimestamp(), 'For grouped events “Ungroup” option available in enabled state')
});

When("User Click on Ungroup option", () => {
    createPattern.ungroupOptionForEventClick()
    console.log(printTimestamp(), 'User Clicked on Ungroup option')
});

Then("grouped events should get ungrouped", () => {
    createPattern.groupButtonforEventTwo()
    console.log(printTimestamp(), 'grouped events gets ungrouped')
});

And("Logical expression should get updated as per ungrouped events For events “Group” option should be available in disabled state", () => {
    createPattern.updatedLogicalExpresssionUnderAddConditionVisible()
    createPattern.updatedLogicalExpresssionUnderAddConditionAfterUngrouping()
    createPattern.groupButtonforEvent()
    console.log(printTimestamp(), 'Logical expression gets updated as per ungrouped events For events “Group” option available in disabled state')
});

When("Click on “X” option available at event level actual event", () => {
    createPattern.crossIconAtEventlevelClick()
    console.log(printTimestamp(), 'Clicked on “X” option available at event level actual event')
});

Then("Confirmation pop should be displayed while removing event", () => {
    createPattern.confirmationPopUpVisible()
    console.log(printTimestamp(), 'Confirmation pop displayed while removing event')
});

When("Click on Cancel", () => {
    createPattern.cancelButtonClick()
    console.log(printTimestamp(), 'Clicked on Cancel')
});

Then("Event should not get deleted", () => {
    createPattern.eventVisible()
    console.log(printTimestamp(), 'Event not get deleted')
});

When("Click on Delete button", () => {
    createPattern.crossIconAtEventlevelClick()
    createPattern.deleteButtonClick()
    console.log(printTimestamp(), 'Clicked on Delete button')
});

Then("Event actual and copied as is should get deleted", () => {
    createPattern.eventNotVisible()
    console.log(printTimestamp(), 'Event actual and copied as is gets deleted')
});

When("Click on “X” option available at event level event added from variable as is option", () => {
    createPattern.addConditionPlusIconClick()
    cy.wait(2000)
    createPattern.formDataModelClick()
    cy.wait(1000)
    createPattern.eventLogAttributeClick()
    createPattern.additionalInfoAttributeClick()
    createPattern.operatorDropDownForSecondEventFirstConditionClick()
    createPattern.equaltoOperatorClick()
    createPattern.valueForConditionTwoInEvenmtwoType()
    createPattern.addConditionPlusIconClick()
    cy.wait(1000)
    createPattern.formDataModelClick()
    cy.wait(1000)
    createPattern.importedEventLogModelClick()
    createPattern.additionalInfoAttributeClick()
    createPattern.opeartorDropDownForEvent3ConditionOneClick()
    createPattern.equaltoOperatorClick()
    createPattern.valueForFirstConditionInThridEventType()
    createPattern.addConditionPlusIconClick()
    cy.wait(1000)
    createPattern.fromVariableOptionClick()
    cy.wait(1000)
    createPattern.eventOneUnderFromvariableClick()
    createPattern.asIsOptionClick()
    createPattern.crossIconAtEventAddedFromAsIsOptionClick()
    console.log(printTimestamp(), 'Clicked on “X” option available at event level event added from variable as is option')
});

Then("Event should get deleted None of confirmation should be displayed", () => {
    createPattern.eventAddedFromAsIsOptionNotExist()
    createPattern.confirmationPopUpNotExist()
    console.log(printTimestamp(), 'Event gets deleted None of confirmation displayed')
});

When("Group all events and click on “X” option available at event level", () => {
    createPattern.eventThreeEventLevelCheckboxClick()
    createPattern.eventFourEventLevelCheckboxClick()
    createPattern.groupButtonAtEventClick()
    createPattern.crossIconAtGroupedEventLevelClick()
    console.log(printTimestamp(), 'Grouped all events and clicked on “X” option available at event level')
});

Then("confirmation pop up should be displayed", () => {
    createPattern.confirmationPopUpVisible()
    console.log(printTimestamp(), 'confirmation pop up displayed')
});

When("Click on Cancel", () => {
    createPattern.cancelButtonClick()
    console.log(printTimestamp(), 'Clicked on Cancel')
});

Then("Grouped Event should not get deleted", () => {
    createPattern.groupedEventsVisible()
    console.log(printTimestamp(), 'Grouped Event not deleted')
});

When("Click on Delete  button", () => {
    createPattern.crossIconAtGroupedEventLevelClick()
    createPattern.deleteButtonClick()
    console.log(printTimestamp(), 'Clicked on Delete button')
});

Then("Grouped Event actual and copied as is should get deleted", () => {
    createPattern.groupedEventsNotExist()
    console.log(printTimestamp(), 'Grouped Event actual and copied as is gets deleted')
});

When("Fill all mandatory fields in Create Pattern page and click on Save", () => {
    createPattern.addActionClick()
    createPattern.addActionPlusIconClick()
    createPattern.raiseAlertOptionClick()
    createPattern.saveAsDraftBButtonClick()
    cy.wait(1000)
    createPattern.messageVisible()
    console.log(printTimestamp(), 'Filelled all mandatory fields in Create Pattern page and clicked on Save')
});

When("User  Relaunch application", () => {
    cy.reload()
    cy.wait(5000)
    console.log(printTimestamp(), 'User  Relaunched application')
});

Then("Previously saved events should be available Copy As is functionality should work as expected for saved wf", () => {
    createPattern.savedEventVisible()
    console.log(printTimestamp(), 'Previously saved events available Copy As is functionality work as expected for saved wf')
});

And("Repeat above steps after importing conditions from Pattern", () => {
    createPattern.addConditionTabClick()
    cy.wait(1000)
    createPattern.addConditionPlusIconClick()
    cy.wait(1000)
    createPattern.rulePatternOptionClick()
    createPattern.ShowCheckboxClick()
    cy.wait(2000)
    createPattern.patternTwoClick()
    createPattern.importButtonClick()
    createPattern.operatorDropDownBetweenAddedEventsClick()
    createPattern.operatorOptionsClick()
    createPattern.addConditionPlusIconClick({ force: true })
    cy.wait(1000)
    createPattern.fromVariableOptionClick()
    createPattern.eventTwoUnderFromVariableForRulePatternVisible()
    createPattern.eventThreeUnderFromVariableForRulePatternVisible()
    createPattern.eventFourUnderFromVariableForRulePatternVisible()
    createPattern.eventTwoUnderFromVariableForRulePatternClick()
    createPattern.asACloneOptionVisible()
    createPattern.eventThreeUnderFromVariableForRulePatternClick()
    createPattern.asACloneOptionVisible()
    createPattern.eventFourUnderFromVariableForRulePatternClick()
    createPattern.asACloneOptionVisible()
    createPattern.eventThreeUnderFromVariableForRulePatternClick()
    createPattern.asIsOptionClick()
    createPattern.copiedEventFromRulePattenNameVisible()
    createPattern.operatorDropDownForCopiedEventVisible()
    createPattern.crossIconForCopiedEventFromRulePatternEnabledAndVisible()
    createPattern.operatorDropDownForCopiedEventClick()
    createPattern.andOperatorForCopiedEventClick()
    // createPattern.updatedLogicalExpresssionUnderAddConditionForRulePatternVisible()
    createPattern.addConditionButtonForEventTwoClick()
    createPattern.attributeDropDownForEventTwoConditionFourClick()
    createPattern.componentAttributeOptionsForEventTwoConditionFourClick()
    createPattern.operatorDropDownBetweenAttrAndValueForEventTwoConditonfourClick()
    createPattern.equalToOperatorsOptionsForEventTwoConditionFourClick()
    createPattern.valueOptionForEventTwoConditionFourType()
    createPattern.operatorDropDownForEventTwoConditionFourClick()
    createPattern.andOperatorsOptionsForEventTwoConditionFourClick()
    createPattern.checkBoxForConditionOneEventwoClick()
    createPattern.checkBoxForConditionTwoEventwoClick()
    createPattern.checkBoxForConditionThreeEventwoClick()
    createPattern.checkBoxForConditionFoutEventwoClick()
    createPattern.groupButtonForEventTwoConditionsClick()
    createPattern.ungroupOptionForGroupedConditionsVisible()
    createPattern.checkBoxForCopiedEventClick()
    createPattern.checkBoxForEventThreeClick()
    createPattern.groupButtonAtEventEnabled()
    createPattern.groupButtonAtEventClick()
    createPattern.updatedLogicalExpresssionUnderAddConditionAfterAddingGroupForRulePattern()
    createPattern.ungroupOptionForGroupedConditionsEnabled()
    createPattern.ungroupOptionForGroupedConditionsClick()
    createPattern.groupButtonforEventTwo()
    createPattern.updatedLogicalExpresssionUnderAddConditionForRulePatternVisible()
    createPattern.updatedLogicalExpresssionUnderAddConditionAfterUngrouping()
    createPattern.crossIconAtEventTwoClick()
    createPattern.confirmationPopUpVisible()
    createPattern.cancelButtonClick()
    createPattern.createdEventVisible()
    createPattern.crossIconAtEventTwoClick()
    createPattern.deleteButtonClick()
    createPattern.createdEventNotExist()
    createPattern.addConditionIconClick() 
    cy.wait(1000)
    createPattern.rulePatternOptionClick()
    createPattern.ShowCheckboxClick()
    cy.wait(2000)
    createPattern.patternTwoClick()
    createPattern.importButtonClick()
    createPattern.operatorDropDownBetweenAddedEventsFromRulePaternClick()
    createPattern.operatorOptionsBetweenFifthAndSixthEventClick()
    createPattern.addConditionIconClick()
    cy.wait(1000)
    createPattern.fromVariableOptionClick()
    createPattern.eventFourOptionUnderFormVariableOptionClick()
    createPattern.asIsOptionClick()
    createPattern.crossIconAtEventAddedFromAsIsOptionClick()
    createPattern.eventAddedFromAsIsOptionInRulepatternNotExist()
    createPattern.confirmationPopUpNotExist()
    createPattern.eventFiveCheckBoxClick()
    createPattern.eventTwoCheckBoxClick()
    // createPattern.groupButtonAtEventClick()
    createPattern.crossIconAtGroupedEventLevelClick()
    createPattern.confirmationPopUpVisible()
    createPattern.cancelButtonClick()
    createPattern.groupedEventsInRulePaternVisible()
    createPattern.crossIconAtGroupedEventLevelClick()
    createPattern.deleteButtonClick()
    createPattern.groupedEventsInRulePaternNotExist()
    createPattern.saveAsDraftBButtonClick()
    cy.wait(1000)
    createPattern.messageVisible()
    cy.reload()
    cy.wait(5000)
    createPattern.savedEventVisible()
    console.log(printTimestamp(), ' Repeats above steps after importing conditions from Pattern')
});


