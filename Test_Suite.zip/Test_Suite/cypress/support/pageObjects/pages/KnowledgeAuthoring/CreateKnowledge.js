import "../../../index"
import AssertionConstants from "../../../../support/pageObjects/pages/AssertionConstants"
const assertionConstants = new AssertionConstants();
import { userID_Alpha_Numeric } from '../../../../support/commands';

let [latestSelecteCauseArrey, latestSelectedKnowledgeArrey, knowledgeAndSymptomTextArrey, knowledgeText,knowledgeAssociationNameArrey,knowledgeNames] = [[], [], [], [], [], []]
let [tagValuesList] = [[]]
let patternNames = []
const knowledgeDescriptionDetails = 'knowledgeDescription'
const knowledgeSymptomDetails = 'AddedSymptomOne'
const knowledgeTagsDetails = 'AWS'
const knowledgeSolutionnDetails = 'solutionOne'
const DAPCollimeterTag = 'DAP/Collimator'
const DicomRisPacsTag = 'DICOM/RIS/PACS'
const testname = "KnowledgeAssociation"

const MyknowledgeArrow = 'button[class="p-ripple p-element p-tree-toggler p-link"]'
const filePath = 'cypress/fixtures/patternNameCreation.json'
const attachFile = 'input[name="file"]'
const uploadedFile = 'a[class="fr-file"]'
const priorityDropdown = '#priority-3'
const priorityDropdownValue = '#dropdown-menu-priority-3 li'
const causeNameAndRemoveIcon = 'ul>li>span'
const crossIconInSelectSymptoms = "button[class='pt-clear-button']>.icon-dls-cross-circle.pt-icon"
const searchIconInSelectSymptom = "dls-icon[class='icon-dls-search pt-icon']"
const cause1TextBox = "#Cause1 div>p"
const knowledge = "div[aria-label='Knowledge']>button";
const addKnowledge = "#nav-add-btn";
const addKnowledgeWorkflowButton = '[id="nav-add-btn"]'
const knowledgeInformationAccordian = 'Knowledge Information '
const symptomAccordian = 'Symptoms '
const tagsAccordian = 'Tags '
const descriptionTextOnCreatePage = ' Description '
const causeAndSolutionText = 'Causes and Solutions '

const popUpOkButton = "#ok-btn"; 
const causesAndSolutionSectionInKnowledge = "//span[contains(text(),'Causes and Solutions')]"
const addCauseButton = "#add-cause"
const solutionTextType = 'div[class="fr-element fr-view fr-element-scroll-visible"]'
const addSolutionButton = "#add-solution"
const confirmationPopup = '#dialog-title'
const dialogBodyInCause = '#dialog-body'
const cancelButtonInCausePopup = '#cancel-btn'
const symptoms = "//span[contains(text(),'Symptoms')]"
const addSymptoms = '#add-Symptom'
const TetxBox = '[class="fr-element fr-view fr-element-scroll-visible"]'
const priorityForSolution1UnderCause1 = '[id="priority-2"]'
const tickMark = '[id="edit-done-btn"]'
const editMode = '[class="cause-wrapper ng-touched ng-dirty ng-valid pt-1"]'
const causeAndSolutionContainer = 'div[class="preview-section"]'
const cause2Text = 'Cause2'
const priorityText = '[class="priority ng-star-inserted"]'
const editIcon = '[id="edit-btn"]'
const cause3Solution1PriorityDropdown = 'button[data-cmd="priority"]'
const priority1Option = '[title="1"]'
const priority2Option = '[title="2"]'
const causeInReadMode = '[class="preview-section"]'
const Workflow = '.p-treenode.p-treenode-leaf.ng-star-inserted'
const updatedDetails = '[class="content-body fr-view ng-star-inserted"]'
const inputBox = '[dir="auto"]'
const knowledgeCauseDetails = 'causeOne'
const message = 'Workflow Saved Successfully'
const knowledgeNameTextBox = 'input[id="labelName"]'
const descriptionFiledTextBox = 'textarea[id="description"]'
const cause1InputBox = '[class="fr-wrapper show-placeholder"]'
const addedSolution = 'Solution1'
const PartsIcon = '[id="parts"]'
const twelveNCTextBox = '[id="partName"]'
const descriptionTextBox = '[id="description"]'
const confirmationPopUp = '[id="undefined"]'
const addConditionButton = '[id="cond-add-btn"]'
const cancelButton = "Cancel"
const savedEvent = '[class="token-container ng-star-inserted"]'
const crosssMarkOfdataModel = '[class="pt-close-icon icon-dls-cross-circle close-icon ng-star-inserted"]'
const doneButton = "Done"
const crossMarkAtConditionLevel = '[id="cond-remove-btn"]'
const solution = '[class="pl-3"]'
const description = "#description"
const patternName = "#labelName"
const fullScreenViewButtonInSymptom = '[class="pt-quiet-default pt-icon-only pt-button ng-star-inserted"]'
const symptomSectionInFullScreen = '[id="symptoms"]'
const fullScreenButtonInExpandedSection = '[class="pt-quiet-default pt-icon-only pt-button"]'
const importDataModelDetailInCreatePatternPage = '[class="pt-token-label"]'
const causeAndSolutionSection = "Causes and Solutions "
const selectCauseButton = '[id="select-cause"]'
const existingPublishedKnowledgesSymptom = 'tr[class="p-element p-selectable-row ng-star-inserted"]'
const Symptom = 'div[class="p-checkbox p-component"]'
const selectButton = 'button[class="pt-primary pt-button pt-auto-focus"]'
const removeSymptomButton = 'button[dlstooltip="Delete"]'
const symptomTagIcon = '[id="knowledge-tags"]'
const tagsInToken = '[class="pt-token-list pt-read-only-token-list"]'
const selectAllCheckBoxBesidesName = '[id="selectall_checkbox"]'
const nextPageButton = '[class="pt-icon icon-dls-navigation-right custom-right-icon"]'
const knowledgeTexts = '[class="p-element p-selectable-row ng-star-inserted"]'
const solutionsWithAllDetails = '[class="preview-section ng-star-inserted"]'
const detectorOptionInTagsDropDown = '[aria-label="Detector"]'
const applyButttonInSelectCauseTagsFilter = '[id="tags_applyBtn"]'
const allTagsInToken = '[class="token-container ng-star-inserted"]'
const valueOnDropDown = '[filterplaceholder="Filter Options"]'
const editOption = '[id="edit-btn"]'
const solutionDetails = '[class="content-body fr-view ng-star-inserted"]'
const importConditionPopUp = '[class="pt-dialog"]'
const addCause = '[id="add-cause"]'
const checkBox = '[class="pt-input"]'
const entriesPerPageDropDown = '[class="pt-quiet pt-dropdown ng-untouched ng-pristine ng-valid"]'
const Operator = '[class="pt-option ng-star-inserted"]'
const symptomsOrCauseWithoutEditOption = '[class="col-1 action-grp"]'
const patternNameTextBox = '[id="labelName"]'
const modalityDropdownInCreatePage = '.value-field.ng-star-inserted'
const ctModalityOption = '[class="pt-checkbox-icon"]'
const adsymptomOption = 'Add Symptom'
const addAction = '[class="accordian-header ng-star-inserted"]'
const addCauseOption = 'Add Cause'
const addSolution = ' Add Solution '
const addTagsOption = 'Add Tags'
const selectTagDropdown = '[placeholder="Select Tags"]'
const tagsOptions = '[class="pt-multiselect-option ng-star-inserted"]'
const plusIconInAddTags = '#add-select-tag'
const createStage = '[id="step-0"]'
const viewStage = '[id="step-1"]'
const reviewRequeStage = '[id="step-2"]'
const nextButtonOnCreatePage = '[id="knowledge-step-next"]'
const fullScreenViewButton = '[class="pt-quiet-default icon-fullscreen pl-0 pt-button"]'
const knowledgeDetailsInFulllScreen = '[id="authoring-knowledge-body"]'
const previousButton = '#pat-step-prev'
const versionIndraftStage = '[class="version-info"]'
const previousButtonInKnowledge = '#knowledge-step-prev'
const expandCollapseIconAtgroupLevel = '[viewBox="0 0 140 140"]'
const partsDoneButton = 'button[class="pt-primary pt-button pt-auto-focus"]'
const causesandSolutionDoneButton = '#edit-done-btn'
const firstRecordCheckbox = '//tbody/tr[1]/td[1]'
const crossMarkIcon = '#remove-cause'
const crossMarkIconAtKnowledge = 'img[id="remove-btn"]'
const editCauseButton = 'img[id="edit-btn"]'
const saveButton = "#knowledge-save"
const uploadFileButton = '#insertFile-1'
const showAllOption = 'input[class="pt-input"]';
const causeButton = "#select-cause"
const mandatorySection = 'section > span.accordian-header.ng-star-inserted>span[class="mandatory"]'
const knowledgeNameType = '#labelName'
const breadcumbCaptureValue = 'dls-breadcrumb ul li span'
const partsButton = "#parts"
const partNameType = "#partName"
const partDescriptionType = ".pt-layout-container > #description"
const tagsButton = 'img[id="tags"]'
const selectTagsDropdown = 'dls-multiselect[placeholder="Select Tags"]'
const recordFromtagsDropdown = 'input[type="checkbox"]'
const addRecordsFromDropdown = "#add-select-tag"
const tagsDoneButton = 'button[class="pt-primary pt-button"]'
const causeDropdown = 'dls-dropdown[role="listbox"]'
const causeDropdownOptions = 'dls-option[role="option"]'
const firstRecordClick = '//tbody/tr[1]/td[2]'
const tagsVerification = 'img[alt="Tags"]'
const knowledgeInfo = "//span[contains(text(),'Knowledge Information')]"
const selectSymptomsButtonInAddSymptomSection = "#select-symptom"
const symptomRecord = 'div[class="p-checkbox-box p-component"]'
const savedDetails = 'app-token-tooltip ul li'
const tagsColumn = "#Tags"
const disabledClass = 'opacity-05 pt-button ng-star-inserted'
const NextButtonInKnowledge = '#knowledge-step-next'
const selectClauseHeading = ".pt-dialog .pt-title"
const crossMark = "dls-searchbox .pt-clear-button"
const searchBoxTestVisible = "#search-field>dls-layout-container>input"
const cancelforCause = "//span[contains(text(),'Cancel')]"
const symptomNameColumnField = "#symptomName_searchIcon";
const attributeForCause = "section>dls-dropdown"
const dropdownValuesVerification = "dls-option-list>dls-option"
const keywordType = 'Testing{enter}'
const PriorityDropdown = '[class="fr-command fr-btn fr-dropdown fr-selection"]'
const prioritythreeOptionOfPriorityDropdown = '[title="3"]'
const priorityTwoOptionOfPriorityDropdown = 'a[data-param1="2"]'
const priorityOneOptionOfPriorityDropdown = '[data-param1="1"]'
const removeIconOfCauseThree = '[id="remove-btn"]'
const cause3Text = 'Cause3'
const cause4Text = 'Cause4'
const cause3 = '[class="cause-view-container ng-star-inserted"]'
const cause3Solution1RemoveIcon = 'button[data-cmd="close"]'
const solutionTwoText = 'Solution2'
const solutionThreeText = 'Solution3'
const causeTwoSolutionTwoPriorityDropDown = '[#priority-17]'
const solutionWithRedBorder = '.froala-container .fr-btn-grp button[data-cmd=priority'
const solutionWithOutRedBorder = '.froala-container .fr-btn-grp button[data-cmd=priority'
const tick = '[id="edit-done-btn"]'
const causes = '[class="col-11 pl-0"]'
const solutions = '[class="name"]'
const popUpTitle = '[id="dialog-title"]'
const popUpDialogue = '[id="dialog-body"]'
const selectSymptom = 'button[id="select-symptom"]'
const symptomOption = 'Symptoms '
const addSymptomButton = '[id="add-Symptom"]'
const tickAtSymptomOne = '[data-cmd="tick"]'
const deleteButton = "//dls-layout-container[contains(text(),'Delete')]"
const deletebutton = "#ok-btn"
const generatedCause1 = '[class="font-16 mb-0 font-sans-bold col-11"]'
const selectCause = '[id="select-cause"]'
const richTextEditorBox = '[class="froala-container ng-untouched ng-pristine ng-invalid"]'
const fullScreenIcon = '[alt="Expand"]'
const expandIcon = '[fill="none"]'
const asterisk = '[class="mandatory"]'
const TextBox = '[class="fr-element fr-view fr-element-scroll-visible"]'
const firstCause = '[role="checkbox"]'
const closeIconForSolution1 = '[data-cmd="close"]'
const sequentialCauseName = 'Cause2'
const sequencialSolutionNameUnderCause2 = 'Solution2'
const selectOptionUderPriorityDropdown = '[title="-- Select --"]'
const solution1 = '[class="pt-0 font-sans-bold font-16"]'
const selectPriorityText = '-- Select --'
const solutionOnePriority = '1'
const solutionTwoPriority = '2'
const selectSymptomsButton = "#select-symptom"
const removeMarkVerification = "ul>li>span[class='pt-close-icon icon-dls-cross-circle close-icon']"
const removeMarkVerificationInKnowledge = "ul>li>span[class='pt-close-icon icon-dls-cross-circle close-icon ng-star-inserted']"
const keywordDropdownVisibleInTagSection = "dls-dropdown[name='keyword']"
const operatorDropdownVisibleInTagSection = "dls-dropdown[name='operator']"
const valueDropdownVisibleInTagSection = "dls-dropdown[name='tagValue']"
const firstRecord = "p-tablecheckbox"
const addTagPlusIcon = '#pat-add'
const addTagsList = 'div[class="card-text w-100"] ul li'
const withoutKeywordSection = "Without Keyword"
const withKeywordSection = "With Keyword"
const addPartTitle = '[class="pt-title"]'
const twelveNCText = '[class="col-5 pb-1 bor-bottom"]'
const descriptionTextInAddTags = '[class="col-6 bor-bottom"]'
const CancelBUtton = '[class="pt-button"]'
const redColorInfoIcon = '[class="icon-dls-exclamation-circle pt-icon"]'
const partValidationMessage = '[class="pt-dialog-footer"]'
const ValidationMessageForDuplicateName = 'Part already added, please change.'
const selectCauseTitle = 'span[class="pt-title"]'
const messageBelowSelectCauseTitle = ' Search for a cause or click on "Show All" to view all available causes. '
const searchByKeywordtextBoxWithText = '[class="col-9 pt-textbox pt-searchbox"]'
const causeDetails = '[class="p-datatable-scrollable-body ng-star-inserted"]'
const entriesPerPageDropdown = '[class="pt-quiet pt-dropdown ng-untouched ng-pristine ng-valid"]'
const recordsCount = 'span[id="record-count"]'
const afterClickOnPreviousArrowEnriesPerPage = '[class="pt-quiet pt-dropdown ng-valid ng-touched ng-dirty"]'
const selectedEntriesOfRecords = '[class="p-element p-selectable-row ng-star-inserted"]'
const arrowSymbolTonavigateToNextPage = '[class="pt-icon icon-dls-navigation-right custom-right-icon"]'
const arrowSymbolTonavigateToPreviousPage = '[class="pt-quiet-default custom-button-left pt-button"]'
const causeOfGrid = '[id="-checkbox"]'
const resizedGrid = '[class="row select-cause"]'
const selectedCauseDetails = '[class="col-md-6 rightView ng-star-inserted"]'
const latestSelectedCauseDetails = 'ZRotation current errors'
const selectAllCkeckBox = '[id="selectall_checkbox"]'
const priority = 'Priority 1'
const solutionDescription = 'Check the motor voltage and also Tomo2 safety circuit PCB for any relay burnt contacts. '
const collapseDetailsIcon = '[id="knowledge-view-toggle-icon"]'
const causeSearchOption = 'input[placeholder="Search"]'
const selectSearchedKnowledge = '[class="p-checkbox-box p-component"]'
const causeName = 'Knowledge associated with withdrawn pattern - Knowledge Delete Verification.Cause1'
const solutionName = '[class="content-heading"]'
const partsDataForSolution = '[class="row parts ng-star-inserted"]'
const tagsDataForSolution = '[class="row tags ng-star-inserted"]'
const tagsDataForCause = '[class="row content-footer ng-star-inserted"]'
const associations = 'Associations'
const clearAllFilterButton = '[id="clear-all-filter"]'
const commonSearchTextBox = '[class="font-16 font-sans-book search-condition pt-dropdown ng-untouched ng-pristine ng-valid"]'
const pageCount = '[class="showing"]'
const valueForSecondConditionInSecondEvent = '[role="option"]'
const searchButton = '[class="icon-dls-search pt-icon"]'
const AddAuthoringWokFlowButton = "#nav-add-btn";
const workFlowMessage = "Workflow Created Successfully";
const recordsFoundText = 'records found'
const causeList = '[class="p-element p-datatable-tbody"]'
const entriesPerpageDropdown = '[role="listbox"]'
const selectSymptomsHeading = "//span[contains(text(),'Select Symptom')]"
const okBtton = "#nav-add-btn";
const totalRecordFoundCount = '//tbody/tr'
const entriesperpageTwenty = '//dls-option[contains(text(),"20")]'
const entriesperPage = 'section>.pt-entries-per-page'
const ButtonVisible = "dls-dialog-footer>button"
const entriesPerPage = " Entries per page: "
const totalCountOfPage = ".pt-navigation>.showing"
const patternNameSorted = "p-sorticon>i"
const changeEntriesPerPageCount = "dls-dropdown[role='listbox']"
const nextPageNavigation = ".pt-navigation dls-icon"
const rightSecton = "app-symptom-viewmode>section"
const symptomName = "app-symptom-viewmode h2 div"
const knowledgeViewIcon = "#knowledge-view-toggle-icon"
const collapsedDetails = "#knowledge-view-toggle-icon"
const symptomAssociation = 'section div[class="token-list"] ul>li'
const symptomDescription = 'app-symptom-viewmode div span'
const noDataVisibleInTable = "div>table>.p-datatable-tbody"
const showAllCheckboxVisible = "#es-show-all-checkbox"
const knowledgeSteps = "#steps-list"
const insertFileButton = "#insertFile-1"
const browseFileIcon = 'input[name="file"]'
const attachedFileHyperlink = 'a[class="fr-file"]'
const saveDetailsButton = '#edit-done-btn'
const editButton = '#edit-btn'
const knowledgeInformationTab = "//span[contains(text(),'Knowledge Information')]"
const showAllCheckbox = 'input[type="checkbox"]'
const resultSelection = 'div[role="checkbox"]>span'
const symptomsSection = "#symptoms span"
const causeVerification = 'li>span'
const selectedSymptomWithEditOption = '[class="symptom-view-container ng-star-inserted"]'
const newScrollElement = '[aria-label="Models"]'
const richTextEditorWindow = 'div[formcontrolname="richTextDescription"]';
const fullScreenViewButttonOfRichTextEditor = '[data-cmd="customFullScreen"]'
const richTextEditorInFullScreen = '[id="Cause1"]'
const leftPaneCollapse = '[class="dashboard_container"]'
const fullScreenViewButtonAtCauseLevel = 'button[class="pt-quiet-default pt-icon-only pt-button ng-star-inserted"]'
const fullScreenViewButtonAfterExpanding = 'button[data-cmd="customFullScreen"]'
const richTextEditorUnderCauseSectionInFullScreen = '[class="editor-container ng-star-inserted"]'
const fullScreenViewButtonAtCauseAndSolutionLavelAterExpanding = '[class="pt-quiet-default pt-icon-only pt-button"]'
const fontFamilyDropDown = 'button[data-cmd="fontFamily"]';
const paragraphFormatDropDown = 'button[id="paragraphFormat-1"]';
const bold = 'button[id="bold-1"]';
const italic = 'button[id="italic-1"]';
const underline = 'button[id="underline-1"]';
const moreText = 'button[id="moreText-1"]';
const alignLeft = 'button[id="alignLeft-1"]';
const alignCenter = 'button[id="alignCenter-1"]';
const alignJustify = 'button[id="alignJustify-1"]';
const alignRight = 'button[id="alignRight-1"]';
const moreParagraph = 'button[id="moreParagraph-1"]';
const insertLink = 'button[id="insertLink-1"]';
const insertImage = 'button[id="insertImage-1"]';
const insertFile = '[data-cmd="insertFile"]';
const insertTable = 'button[id="insertTable-1"]';
const insertHorizontalLine = 'button[id="insertHR-1"]';
const moreMisc = 'button[data-cmd="moreMisc"]';
const undo = 'button[title="Undo (Ctrl+Z)"]';
const redo = 'button[title="Redo (Ctrl+Shift+Z)"]';
const arial = "Arial";
const Georgia = "Georgia";
const impact = "Impact";
const tahoma = "Tahoma";
const timesNewRoman = "Times New Roman";
const Verdana = "Verdana";
const paragraphFormat = 'button[id="paragraphFormat-1"]';
const heading1 = "Heading 1";
const heading2 = "Heading 2";
const heading3 = "Heading 3";
const heading4 = "Heading 4";
const code = 'a[title="Code"]';
const Strikethrough = 'button[data-cmd="strikeThrough"]';
const subScript = 'button[data-cmd="subscript"]';
const superScript = 'button[data-cmd="superscript"]';
const fontSize = 'button[data-cmd="fontSize"]';
const textColor = 'button[data-cmd="textColor"]';
const fontSizeDropDown = 'ul[class="fr-dropdown-list"]';
const backgroundColor = 'button[data-cmd="backgroundColor"]';
const inlineClass = 'button[data-cmd="inlineClass"]';
const inlilneClasscode = 'a[title="Code"]';
const Highlighted = 'a[title="Highlighted"]';
const Transparent = 'a[title="Transparent"]';
const inlineStyle = 'button[data-cmd="inlineStyle"]';
const bigRed = 'a[title="Big Red"]';
const smallBlue = 'a[title="Small Blue"]';
const clearFormatting = 'button[data-cmd="clearFormatting"]';
const oplListWithDropDown = 'button[ id="formatOL-1"]';
const oplListWithDropDownButton = 'button[id="formatOLOptions-1"]'
const ulListWithDropDown = 'button[data-cmd="formatULOptions"]';
const paragraphStyle = 'button[data-cmd="paragraphStyle"]';
const lineHeight = 'button[data-cmd="lineHeight"]';
const lineHeightValueDefault = 'a[class="fr-command Default fr-active"]'
const lineHeightValueSingle = 'a[class="fr-command Single"]'
const lineHeightValue3rd = 'a[class="fr-command 1.15"]'
const lineHeightValue4th = 'a[class="fr-command 1.5"]'
const lineHeightValueDouble = 'a[class="fr-command Double"]'
const decreaseIndent = 'button[title="Decrease Indent (Ctrl+[)"]';
const increseIndent = '[data-cmd="indent"]';
const quote = 'button[data-cmd="quote"]';
const increaseOptionUnderQuotes = 'a[title="Increase"]'
const decreaseOptionUnderQuotes = 'a[title="Decrease"]'
const defaultOption = 'a[title="Default"]';
const lowerAlpha = 'a[title="Lower Alpha"]';
const lowerGreek = 'a[title="Lower Greek"]';
const lowerRoman = 'a[title="Lower Roman"]';
const upperAlpha = 'a[title="Upper Alpha"]';
const upperRoman = 'a[title="Upper Roman"]';
const unorderListDropDownButton = 'button[id="formatULOptions-1"]'
const unorderListDefaultOption = 'Default'
const unorderListCircleOption = 'Circle'
const unorderListDiscOption = 'Disc'
const unorderListSquareOption = 'Square'
const photoGraphStyle = 'button[data-cmd="paragraphStyle"]';
const gray = 'a[title="Gray"]';
const bordered = 'a[title="Bordered"]';
const Spaced = 'a[title="Spaced"]';
const upperCase = 'a[title="Uppercase"]';
const close = '[id="remove-cause"]'
const causeNameColumnType = "#causeName_searchIcon"
const cause1TextFillBox = 'div[class="fr-element fr-view fr-element-scroll-visible"]'
const contentMissedMessage = 'Description is missing, please either add description or remove this section.'
const toasterMessage = 'Workflow Save not allowed, please provide valid inputs.'
const tagIconUnderSolution = '[id="tags"]'
const insertImageOption = '#insertImage-6'
const browseImageOption = 'input[type="file"]'
const PriorityOneOption = '[title="1"]' 
const priorityDropdownOptions = 'button[data-cmd="priority"]'
const selectOptionUnderPriorityDropdown = '[title="-- Select --"]'
const priorityTwoOption = '[title="2"]'
const lastKnowledgeName = 'div[class="p-treenode-content p-treenode-selectable p-highlight"]>span a'
const patternDashboardBreadCrum = '[class="pt-breadcrumb"]'
const ptLayoutContainerClass = '[class="pt-layout-container"]'
const knowledgeNameSearchFilter = "#knowledgeName_searchIcon";
const insertTableOption = 'button[id="insertTable-1"]'
const matrixSelection = 'span[data-param2="2"]'
const tableAsSelectedMatrix = 'table[style="width: 100%;"]'
const firstCell = 'table[style="width: 100%;"] td'
const tableHeaderOption = 'button[data-cmd="tableHeader"]'
const removeTableOption = 'button[data-cmd="tableRemove"]'
const rowOption = 'button[data-cmd="tableRows"]'
const insertRowAboveOption = 'Insert row above'
const insertRowBelow = 'Insert row below'
const deleteRowOption = 'Delete row'
const columnOption = 'button[data-cmd="tableColumns"]'
const insertColumnBeforeOption = 'Insert column before'
const insertColumnAfterOption = 'Insert column after'
const deleteColumnOption = 'Delete column'
const tableStyleOption = 'button[data-cmd="tableStyle"]'
const dashedBordersOption  = 'Dashed Borders'
const alternateRowsOption = 'Alternate Rows'
const tableCellOption = 'button[data-cmd="tableCells"]'
const mergeCellOption = 'Merge cells'
const verticalSplitOption = 'Vertical split'
const horizontalSplitOption = 'Horizontal split'
const cellBackgroundOption = '[data-cmd="tableCellBackground"]'
const backButton = 'button[data-cmd="tableBack"]'
const colors = '[class="fr-color-set fr-table-colors"]'
const deleteButtonUnderCellBackGroundOption = '[data-param1="REMOVE"]'
const textBoxForHEXColors = 'input[id="fr-table-colors-hex-layer-text-1"]'
const okButtonUnderCelBackgroundOption = 'button[class="fr-command fr-submit"]'
const verticalAllignmentOption = 'button[data-cmd="tableCellVerticalAlign"]' 
const allignmentTopOption = 'Top'
const allignmentMiddleOption = 'Middle'
const allignmentBottomOption = 'Bottom'
const horizontalAllignOption = '[data-cmd="tableCellHorizontalAlign"]'
const allignLeftOption = 'a[data-param1="left"]'
const allignCenterOption = 'a[data-param1="center"]'
const allignRightOption = 'a[data-param1="right"]'
const allignJustifyOption = 'a[data-param1="justify"]'
const cellStyleOption = 'button[data-cmd="tableCellStyle"]'
const highlightedOption = '[data-param1="fr-highlighted"]'
const thickOption = 'Thick'
const tablewithDashedBordrs = 'table[style="width: 100%;"]'
const userSelectedColor = 'span[data-param1="#B8312F"]'
const colorPopUp = 'div[class="fr-popup fr-desktop fr-above fr-active"]'
const userTypedColorText = '#F7DA64'
const HEXcolorInputBox = 'input[class="fr-not-empty"]'
const fullScreenIconAtCauseAndSolutionLevel = 'button[id="expand-cause-icon"]'
const CellOneInColumnOne = '//tbody/tr[1]/td[1]'
const CellTwoInColumnOne = 'tbody > :nth-child(1) > :nth-child(1)'
const tableCellsAfterMerge = 'tbody > :nth-child(2) > td'
const tableCellAftetHorizontalSplit = 'tbody > :nth-child(1) > td'
const causeCollpaseIconAtCauseAndSolutionLevel = 'button[id="cause-collapse-icon"]'
const addConditionOption = 'span[class="accordian-header ng-star-inserted"]'
const modalityDropdownInApplyMetadata = 'dls-multiselect[role="listbox"]';




const searchOptionInPopUp = 'input[placeholder="Search by Keyword"]'
const searchedKnowledgeCheckBox  = 'span[class="p-checkbox-icon"]'
const selectKnowledgeOption = '.pt-primary.pt-button.pt-auto-focus'
const createdKnowledgeAssociationName = '.token-container.ng-star-inserted span'
const knowledgeSearchOption = '#filter-option input'
const nameOfNormalKnowledge = 'knowledgeNormal'
const nameOfSecondKnowledge = 'knowledgeTwo'
const knowledgeTable = '[class="knowledgegrid"]'
const knowledgeListTable = '[class="dashboard_right"]'

const tagSection = '[class="token-container ng-star-inserted"]'
const filterForKeyword = 'input[placeholder="Search by Keyword"]';
const clearButton = '[class="pt-clear-button"]'
const nextButtonOnIncludeKnowledgePage = '[id="pat-step-next"]'


const patternNameFilterTextField = '#knowledgeName_searchIcon'
const firstKnowledge = '[class="p-element p-datatable-tbody"] tr td '
const firstKnowledgeRecord = '//tbody/tr[1]/td[2]'
const editknowledgeButton = '#Edit'
const knowledgeStatusColumn = '#column_knowledgeStatus #multiselect-filter'
const knowledgeStatusOptions = 'p-multiselectitem>li'
const knowledgeStatusApplyButton = '#knowledgeStatus_applyBtn'
const firstRecordsStatusVerification = '//tbody/tr[1]/td[6]'
const firstRecordsVersionVerification = '//tbody/tr[1]/td[7]'
const publishButton = '#Publish'
const notificationClass = '.pt-notification-item-text-content';
const publishButtonInsideKnowledge = '#detail-knowledge-publish';
const deleteButtonInsideKnowledge = '#knowledge-delete';
const editButtonInsideKnowledge = '#knowledge-edit';
const closeButtonInsideKnowledge = '#knowledge-close';
const deleteKnowledge = '#delete-knowledge';
const knowledgeCollapse = 'div[aria-label="Knowledge"] span';
const publishKnowledge = '#publish-knowledge';
const causeAndSolutionSectionButton = '#cause';
const symptomsSectionButton = '#symptoms';
const myKnowledgeDahboard = 'div[aria-label="My Knowledge"]>button';




class CreateKnowledge {
    myKnowledgeDahboardClick() {
        cy.get(myKnowledgeDahboard).click()
    }
    symptomsSectionButtonClick() {
        cy.get(symptomsSectionButton).click()
    }
    causeAndSolutionSectionButtonClick() {
        cy.get(causeAndSolutionSectionButton).click()
    }
    firstKnowledgeopen() {
        return cy.get(firstKnowledge).eq(1).find('span').first().click()
    }
    publishKnowledgeClick() {
        cy.get(publishKnowledge).click()
    }
    knowledgeCollapseClick() {
        cy.get(knowledgeCollapse).eq(0).click()
    }
    patternNameTextBoxInvalidNameType() {
        let x = 'Authoring_WF_Test' + Math.floor((Math.random() * 1000) + 1);
        cy.writeFile(filePath, { name: x })
        cy.wait(2000)
        cy.readFile(filePath).then(function (result) {
          let PatternNames = result.name;
          cy.get(patternNameTextBox).type(PatternNames);
        });
      }
    deleteKnowledgeClick() {
        cy.get(deleteKnowledge).click()
        cy.get(popUpOkButton).click()
    }
    NewPatternCreatedVisible() {
        cy.readFile('cypress/fixtures/patternNameCreation.json').then(function (result) {
            let PatternName = result.name;
            cy.get(
                "#" + PatternName + " > #nav-dropdown-btn > .ng-star-inserted > #Layer_1"
              ).last().scrollIntoView().should(assertionConstants.beVisibleAssertion);
        });
      }
    editknowledgeVersionVisible() {
        cy.xpath(firstRecordsVersionVerification).should(assertionConstants.beVisibleAssertion)
    }
    editknowledgeStatusVisible() {
        cy.xpath(firstRecordsStatusVerification).should(assertionConstants.beVisibleAssertion)
    }
    editButtonInsideKnowledgeClick() {
        cy.get(editButtonInsideKnowledge).click()
    }
    editButtonInsideKnowledgeVisible() {
        cy.get(editButtonInsideKnowledge).should(assertionConstants.beVisibleAssertion)
    }
    closeButtonInsideKnowledgeVisible() {
        cy.get(closeButtonInsideKnowledge).should(assertionConstants.beVisibleAssertion)
    }
    deleteButtonInsideKnowledgeVisible() {
        cy.get(deleteButtonInsideKnowledge).should(assertionConstants.beVisibleAssertion)
    }
    publishButtonInsideKnowledgeVisible() {
        cy.get(publishButtonInsideKnowledge).scrollIntoView().should(assertionConstants.beVisibleAssertion)
    }
    firstKnowledgeOpen() {
        cy.get(notificationClass,{timeout: 70000}).should(assertionConstants.beVisibleAssertion).then(()=>{
            cy.wait(3000)
            return cy.get(firstKnowledge).eq(1).find('span').first().click()
        })
    }
    publishButtonClick() {
        return cy.get(publishButton).click()
    }
    editedknowledgeStatusVisible() {
        cy.xpath(firstRecordsStatusVerification).find('span').should(assertionConstants.beVisibleAssertion)
    }
    editedknowledgeVisible() {
     cy.xpath(firstRecordClick).find('span').should(assertionConstants.beVisibleAssertion)
    }
    withdrawnKnowledgeStatusSelection() {
        cy.get(knowledgeStatusColumn).scrollIntoView().click()
        cy.get(knowledgeStatusColumn).click()
        cy.get(knowledgeStatusOptions).eq(2).click()
        cy.get(knowledgeStatusApplyButton).click()
      }
    editknowledgeButtonClick() {
        return cy.get(editknowledgeButton).click()
    }
    firstKnowledgeRightClick() {
        cy.get(firstKnowledge).eq(0).scrollIntoView()
        cy.wait(2000)
        return cy.xpath(firstKnowledgeRecord).rightclick()
      }
    patternNameTypeInKnowledgeSearchFilter() {
        cy.readFile('cypress/fixtures/patternNameCreation.json').then(function (result) {
            let PatternName = result.name;
            cy.get(patternNameFilterTextField).type(PatternName).type('{enter}');
        });
    }
    patternNameTypeInKnowledgeSearch() {
        cy.get(patternNameFilterTextField).type('Authoring_WF_Test{enter}')

    }
    inputFieldInCauseSectionClickAndType() {
        return cy.get(cause1TextFillBox).type(' Testing')
    }
    cause1TextFillBox(){ 
        return cy.get(cause1TextFillBox).type('abc')
    }

    solution1TextBoxClickAndType() {
        cy.get(addSolutionButton).click()
        cy.get(TextBox).eq(1).click().type('testing')
    }
    tickMarkIconClick() {
        return cy.get(saveDetailsButton).click()
    }
    uploadedImageVerification() {
        cy.get(uploadedFile).should(assertionConstants.beVisibleAssertion)
    }
    browseFileIconClick() {
        return cy.get(browseFileIcon).click({ force: true })
    }
    addCauseButtonClick() {
        return cy.get(addCauseButton).click()
    }
    causeAndSolutionSectionClick() {
        return cy.xpath(causeAndSolutionSection).click()
    }
    knowledgeStepsVisible() {
        cy.get(knowledgeSteps).should(assertionConstants.beVisibleAssertion)
    }
    addKnowledgeClick() {
        return cy.get(addKnowledge).click()
    }
    knowledgeClick() {
        return cy.get(knowledge).click()
    }
    cause1TextBoxClickAndType() {
        cy.get(cause1TextBox).click().type(' testing')
    }
    crossIconInSelectSymptomClick() {
        cy.get(crossIconInSelectSymptoms).eq(1).click()
    }
    searchIconInSelectSymptomVisible() {
        cy.get(searchIconInSelectSymptom).eq(1).should(assertionConstants.beVisibleAssertion)
    }
    crossIconInSelectSymptomsVisible() {
        cy.get(crossIconInSelectSymptoms).should(assertionConstants.beVisibleAssertion)
    }
    notAbleToAddExcelFileInCauseAndSolutionSectionVerification() {
        cy.get(insertFile).click()
        cy.get(attachFile).attachFile('TestingExcelFile.xlsx')
        cy.get(uploadedFile).should(assertionConstants.notExistsAssertion)
    }
    notAbleToAddExcelFileInCauseAndSolutionTwoSectionVerification() {
        cy.get(insertFile).eq(0).click()
        cy.get(attachFile).attachFile('TestingExcelFile.xlsx')
        cy.get(uploadedFile).should(assertionConstants.notExistsAssertion)
    }

    priorityDropdownClickAndChangeValue() {
        cy.get(priorityDropdown).click()
        cy.get(priorityDropdownValue).eq(1).click()
    }

    causeNameOneRemoveIconClick() {
        cy.get(causeNameAndRemoveIcon).eq(1).click()
    }
    causeNameAndRemoveIconVisible() {
        cy.get(causeNameAndRemoveIcon).eq(0).should(assertionConstants.beVisibleAssertion)
        cy.get(causeNameAndRemoveIcon).eq(1).should(assertionConstants.beVisibleAssertion)
    }

    knowledgeOptionArrowClick() {
        cy.get(knowledge).click()
    }

    addKnowledgeWorkflowButtonClick() {
        cy.get(addKnowledgeWorkflowButton).then((button)=>{
            cy.get(button).click()
        })
    }

    saveAsDraftButtonClick() {
        return cy.xpath(saveAsDraft).click()
    }

    knowledgeInformationAccordianClick() {
        cy.contains(knowledgeInformationAccordian).click()
    }

    knowledgeInformationAccordianVisible() {
        cy.contains(knowledgeInformationAccordian).should(assertionConstants.beVisibleAssertion)
    }

    symptomAccordianVisible() {
        cy.contains(symptomAccordian).should(assertionConstants.beVisibleAssertion)
    }

    tagsAccordianVisible() {
        cy.contains(tagsAccordian).should(assertionConstants.beVisibleAssertion)
    }

    knowledgeInformationSectionExpandedVerification() {
        cy.contains(descriptionTextOnCreatePage).should(assertionConstants.beVisibleAssertion)
    }

    causesAndSolutionSectionClick() {
        cy.xpath(causesAndSolutionSectionInKnowledge).click()
    }

    addCausesButtonClick() {
        cy.get(addCauseButton).click()
    }

    richTextEditorSectionVisible() {
        return cy.get(solutionTextType).should(assertionConstants.beVisibleAssertion)
    }

    insertTextInCauseRichTextEditorSection() {
        cy.get(solutionTextType).type('Testing')
    }

    addSolutionButtonClick() {
        return cy.get(addSolutionButton).click()
    }

    solutionTextType() {
        return cy.get(solutionTextType).eq(1).type('Testing')
    }

    areYouSureToDeleteCauseTestVisble() {
        cy.get(confirmationPopup).should(assertionConstants.beVisibleAssertion)
    }

    dialogBodyInCauseTextVisble() {
        cy.get(dialogBodyInCause).should(assertionConstants.beVisibleAssertion)
    }

    buttonsVisibleInCauseRemovePopup() {
        cy.get(cancelButtonInCausePopup).should(assertionConstants.beVisibleAssertion)
        cy.get(popUpOkButton).should(assertionConstants.beVisibleAssertion)
    }

    cancelButtonClickInCause() {
        cy.get(cancelButtonInCausePopup).click()
    }

    popUpOkButtonClick() {
        return cy.get(popUpOkButton).click()
    }

    causeNameAndRemoveIconNotVisible() {
        cy.get(causeNameAndRemoveIcon).should(assertionConstants.notExistsAssertion)
    }

    symptomsClick() {
        return cy.xpath(symptoms).click()
    }

    addSymptomsButtonClick() {
        cy.get(addSymptoms).click()
    }

    causeAndSolutionOptionClick() {
        cy.contains(causeAndSolutionText).click()
    }

    addCauseButtonClick() {
        cy.get(addCauseButton).click()
    }

    causeOneInputBoxType() {
        cy.get(inputBox).last().type(knowledgeCauseDetails)
    }


    Solution1TetxBoxOfCause1Type() {
        cy.get(TetxBox).last().type('Solution one for Cause one')
    }

    priorityForSolution1UnderCause1Visible() {
        cy.get(priorityForSolution1UnderCause1).find('span').should(assertionConstants.haveTextAssertion, '1').and(assertionConstants.beVisibleAssertion)
    }

    tickMarkAtCause1LevelClick() {
        cy.get(tickMark).click()
    }

    causeAndSolutionWithOutRichTextEditor() {
        cy.get(causeAndSolutionContainer).should(assertionConstants.notContainAssertion, '[class="froala-container ng-untouched ng-pristine ng-invalid"]')
    }

    cause2TextBoxType() {
        cy.get(TetxBox).first().type('Cause two text')
    }

    cause2Solution1TextBoxType() {
        cy.get(TetxBox).last().type('solution one in Cause two')
    }

    cause2TextVisible() {
        cy.contains(cause2Text).should(assertionConstants.beVisibleAssertion)
    }

    priorityTextForSolution1UnderCause1Visible() {
        cy.get(priorityText).first().should(assertionConstants.haveTextAssertion, priority).and(assertionConstants.beVisibleAssertion)
    }

    priorityTextForSolution1UnderCause2Visible() {
        cy.get(priorityText).last().should(assertionConstants.haveTextAssertion, priority).and(assertionConstants.beVisibleAssertion)
    }

    editIconForCause1Disabled() {
        cy.get(editIcon).first().should(assertionConstants.notBeEnabledAssertion)
    }

    editIconForCause2Disabled() {
        cy.get(editIcon).last().should(assertionConstants.notBeEnabledAssertion)
    }

    Cause3TextBoxType() {
        cy.get(TetxBox).first().type('cause three text')
    }

    // addSolutionButtonClick() {
    //     cy.get(addSolutionButton).click()
    // }

    cause3Solution1TextBoxType() {
        cy.get(TetxBox).last().type('solution one of cause three')
    }

    editIconForCause1Enabled() {
        cy.get(editIcon).first().should(assertionConstants.notBeDisabledAssertion)
    }

    editIconForCause2Enabled() {
        cy.get(editIcon).last().should(assertionConstants.notBeDisabledAssertion)
    }

    editIconForCause2Click() {
        cy.get(editIcon).last().click()
    }

    cause2InEditMode() {
        cy.get(editMode).should(assertionConstants.beVisibleAssertion)
    }

    cause1InReadModeVisible() {
        cy.get(causeInReadMode).first().should(assertionConstants.beVisibleAssertion)
    }

    cause3InReadModeVisible() {
        cy.get(causeInReadMode).last().should(assertionConstants.beVisibleAssertion)
    }

    cause2TextBoxUpdateType() {
        cy.get(TetxBox).first().clear().type('Updated Cause text for cause two')
    }

    cause2Solution1TextBoxUpdatedType() {
        cy.get(TetxBox).last().clear().type('Updated solution one in Cause two')
    }

    cause3EditIconClick() {
        cy.get(editIcon).last().click()
    }

    cause3Solution2TextBoxType() {
        cy.get(TetxBox).last().type('Solution two for cause three')
    }

    cause3Solution2PriorityDropdownClick() {
        cy.get(cause3Solution1PriorityDropdown).last().click()
    }

    priority2OptionClick() {
        cy.get(priority1Option).last().click()
    }

    cause3Solution1PriorityDropdownClick() {
        cy.get(cause3Solution1PriorityDropdown).first().click()
    }

    priority1OptionClick() {
        cy.get(priority2Option).first().click({force: true})
    }

    messageVisible() {
        cy.contains(message).should(assertionConstants.beVisibleAssertion)
    }

    existingWorkflow() {
        cy.get(Workflow).eq(2).click()
    }

    newlyCreatedWokFlow() {
        cy.get(Workflow).last().click()
    }

    updatedDetailsOfCause2Visible() {
        cy.get(updatedDetails).eq(2).find('p').should(assertionConstants.haveTextAssertion, 'Updated Cause text for cause two').and(assertionConstants.beVisibleAssertion)
    }

    knowledgeNameTextBoxType() {
        cy.get(knowledgeNameTextBox).type('NewKnowlwdge')
    }

    descriptionFiledTextBoxType() {
        cy.get(descriptionFiledTextBox).type('KnowledgeWithCause')
    }

    addedSolutionVisible() {
        cy.contains(addedSolution).should(assertionConstants.beVisibleAssertion)
    }

    PartsIconClick() {
        cy.get(PartsIcon).click()
    }

    addPartPopUpVisible() {
        cy.get(confirmationPopUp).should(assertionConstants.beVisibleAssertion)
    }

    twelveNCTextBoxTypeSdd() {
        cy.get(twelveNCTextBox).type('spanner')
    }

    descriptionTextBoxTypebdd() {
        cy.get(descriptionTextBox).last().type('Two')
    }

    secondRowTwelveNCTextBoxVisible() {
        cy.get(twelveNCTextBox).last().should(assertionConstants.haveAttributeAssertion, 'placeholder', "Part Number").and(assertionConstants.beVisibleAssertion)
    }

    secondRowDescriptionTextBoxVisible() {
        cy.get(descriptionTextBox).last().should(assertionConstants.haveAttributeAssertion, 'placeholder', "Part Description").and(assertionConstants.beVisibleAssertion)
    }

    partsNameTextBoxSecondRowType() {
        cy.get(twelveNCTextBox).last().type('bolts')
    }

    descriptionBoxSecondRoqType() {
        cy.get(descriptionTextBox).eq(2).type('three')
    }

    doneButtonEnabled() {
        cy.contains(doneButton).should(assertionConstants.notBeDisabledAssertion)
    }

    cancelButtonClick() {
        return cy.contains(cancelButton).click()
    }

    addPartPopUpNotExist() {
        cy.get(confirmationPopUp).should(assertionConstants.notExistsAssertion)
    }

    partsInsolutionNotExist() {
        cy.get(solution).should(assertionConstants.notContainAssertion, 'spanner')
    }

    partsNameTextBoxFirstRowEmpty() {
        cy.get(twelveNCTextBox).should(assertionConstants.beEmptyAssertion);
    }

    addPlusIconClick() {
        cy.get(addConditionButton).last().click()
    }

    partsNameTextBoxThirdRowType() {
        cy.get(twelveNCTextBox).last().type('screws')
    }

    descriptionBoxThirdRowType() {
        cy.get(descriptionTextBox).eq(3).type('two')
    }

    partsNameTextBoxFourthRowType() {
        cy.get(twelveNCTextBox).last().type('nut')
    }

    descriptionBoxFourthRowType() {
        cy.get(descriptionTextBox).eq(4).type('two')
    }

    removeIconFourthClick() {
        cy.get(crossMarkAtConditionLevel).last().click()
    }

    removeIconThirdClick() {
        cy.get(crossMarkAtConditionLevel).eq(2).click()
    }

    screwsRemovedFromAddPartPopUp() {
        cy.get(confirmationPopUp).should(assertionConstants.notContainAssertion, 'screws')
    }

    nutRemovedFromAddPartPopUp() {
        cy.get(confirmationPopUp).should(assertionConstants.notContainAssertion, 'nut')
    }

    doneButtonClickInPopUpClick() {
        cy.contains(doneButton).click()
    }

    firstAddedPartsAtSolutionLevelvisible() {
        cy.get(savedEvent).last().find('li').first().children().should(assertionConstants.haveTextAssertion, 'spanner').and(assertionConstants.beVisibleAssertion)
    }

    secondAddedPartsAtSolutionLevelvisible() {
        cy.get(savedEvent).last().find('li').last().children().should(assertionConstants.haveTextAssertion, 'bolts').and(assertionConstants.beVisibleAssertion)
    }

    removeIconForBoltspartInTokenClick() {
        cy.get(crosssMarkOfdataModel).last().click()
    }

    boltsPartInTokenNotExist() {
        cy.get(savedEvent).last().should(assertionConstants.notContainAssertion, 'bolts')
    }

    boltsPartInAddPartPopUpNotExist() {
        cy.get(confirmationPopUp).should(assertionConstants.notContainAssertion, 'bolts')
    }

    partsInPartsPopUp() {
        cy.get(twelveNCTextBox).should(assertionConstants.haveAttributeAssertion, 'class', "pt-input ng-untouched ng-pristine ng-valid")
    }

    description() {
        return cy.get(description)
    }

    patternName() {
        return cy.get(patternName)
    }

    knowledgeNameVisible() {
        cy.get(importDataModelDetailInCreatePatternPage).invoke('text').should(assertionConstants.beExistAssertion)
    }

    causeAndSolutionAcordianVisible() {
        cy.contains(causeAndSolutionText).should(assertionConstants.beVisibleAssertion)
    }

    symptomSectionClick() {
        cy.contains(symptomAccordian).click()
    }

    fullScreenViewButtonInSymptomSectionVisible() {
        cy.get(fullScreenViewButtonInSymptom).should(assertionConstants.beVisibleAssertion)
    }

    fullScreenViewButtonInSymptomSectionClick() {
        cy.get(fullScreenViewButtonInSymptom).click()
    }

    sypmtomSectionInFullScreen() {
        cy.get(symptomSectionInFullScreen).should(assertionConstants.notHaveClassAssertion, 'pt-expanded')
    }

    fullScreenButtonInExpandedSymptomSectionClick() {
        cy.get(fullScreenButtonInExpandedSection).click({ force: true })
    }

    causeAndSolutionSectionClick() {
        return cy.contains(causeAndSolutionSection).click()
    }

    fullScreenViewButtonInCauseAndSolutionSectionVisible() {
        cy.get(fullScreenViewButtonInSymptom).should(assertionConstants.beVisibleAssertion)
    }

    fullScreenViewButtonInCauseAndSolutionSectionClick() {
        cy.get(fullScreenViewButtonInSymptom).click()
    }

    fullScreenButtonInExpandedCauseAndSolutionSectionClick() {
        cy.get(fullScreenButtonInExpandedSection).click({ force: true })
    }

    selectCauseButtonClick() {
        cy.get(selectCauseButton).click()
    }

    selectCausePopupVisible() {
        cy.get(confirmationPopUp).should(assertionConstants.beVisibleAssertion)
    }

    existingPublishedSymptomOrCausesVisible() {
        cy.get(existingPublishedKnowledgesSymptom).find('td').eq(3).should(assertionConstants.beVisibleAssertion)
    }

    tagsFilterOptionClick() {
        return cy.get(valueOnDropDown).last().click()
    }

    detectorOptionInTagsDropDownClick() {
        cy.get(detectorOptionInTagsDropDown).click()
    }

    applyButttonInSelectCauseTagsFilterClick() {
        cy.get(applyButttonInSelectCauseTagsFilter).click({ force: true })
    }

    firstSymptomOrCauseText() {
        cy.get(knowledgeTexts).eq(2).find('td').eq(1).children().first().invoke('text').then((elOne) => {
            knowledgeAndSymptomTextArrey.push(elOne.trim())
        })
    }

    firstSymptomOrCauseClick() {
        cy.get(Symptom).eq(3).click()
    }

    selectButtonClick() {
        cy.get(selectButton).click({ force: true })
    }

    firstSelectedSymptomOrCauseInSymptomOrCauseAndSolutionSectionVisible() {
        cy.get(causes).eq(0).should(assertionConstants.beVisibleAssertion)
    }

    selectedFirstSymptomOrCauseNameInSymptomSection() {
        cy.get(causes).eq(0).invoke('text').then((valueOne) => {
            knowledgeText.push(valueOne.trim())
            // expect(knowledgeAndSymptomTextArrey[0]).to.eq(knowledgeText[0])
            cy.log(knowledgeText)
        })
    }

    editOptionNOtExists() {
        cy.get(editOption).should(assertionConstants.notExistsAssertion)
    }

    removeSymptomOrCauseButtonVisible() {
        cy.get(removeSymptomButton).should(assertionConstants.beVisibleAssertion)
    }

    nameOfFirstSymptomOrCauseInSymptomOrCauseAndSolutionSectionVisible() {
        cy.get(causes).eq(0).should(assertionConstants.beExistAssertion)
    }

    symptomOrCauseDescriptionInSymptonOrCauseAndSolutionSectionVisible() {
        cy.get(solutionDetails).should(assertionConstants.beVisibleAssertion)
    }

    solutionsWithSolutionNameVisible() {
        cy.get(solutionsWithAllDetails).find('[class="name"]').invoke('text').then((solutionName1) => {
            cy.contains(solutionName1).should(assertionConstants.beVisibleAssertion)
        })
    }

    solutionsWithPriorityVisible() {
        cy.get(solutionsWithAllDetails).find('[class="priority ng-star-inserted"]').should(assertionConstants.beVisibleAssertion)
    }

    symptomOrCauseTagIconVisible() {
        cy.get(symptomTagIcon).should(assertionConstants.beVisibleAssertion)
    }

    tagsInTokenVisible() {
        cy.get(allTagsInToken).last().find('li').first().should(assertionConstants.beVisibleAssertion)
    }

    selectSymptomOrCausePopUpVisible() {
        cy.get(importConditionPopUp).should(assertionConstants.beVisibleAssertion)
    }

    showAllCheckboxClick() {
        cy.get(checkBox).click()
    }

    secondSymptomOrCauseText() {
        cy.get(knowledgeTexts).eq(1).find('td').eq(1).children().first().invoke('text').then((elTwo) => {
            knowledgeAndSymptomTextArrey.push(elTwo.trim())
        })
    }

    ThirdSymptomOrCauseText() {
        cy.get(knowledgeTexts).eq(0).find('td').eq(1).children().first().invoke('text').then((elThree) => {
            knowledgeAndSymptomTextArrey.push(elThree.trim())
            cy.log(knowledgeAndSymptomTextArrey)
        })
    }

    secondSymptomClick() {
        cy.get(Symptom).eq(3).click()
    }

    FoutrhSymptomOrCauseClick() {
        cy.get(Symptom).eq(4).click()
    }

    secondSelectedSymptomOrCauseInSymptomOrCauseAndSolutionSectionVisible() {
        cy.get(causes).eq(1).should(assertionConstants.beVisibleAssertion)
    }

    thirdSelectedSymptomOrCauseInSymptomOrCauseAndSolutionSectionVisible() {
        cy.get(causes).eq(2).scrollIntoView().should(assertionConstants.beVisibleAssertion)
    }

    selectedSecondSymptomOrCauseNameInSymptomOrCauseAndSolutionSection() {
        cy.get(causes).eq(1).invoke('text').then((valueTwo) => {
            knowledgeText.push(valueTwo.trim())
            cy.log(knowledgeText)
            expect(knowledgeAndSymptomTextArrey[2]).to.eq(knowledgeText[1])
        })
    }

    selectedThirdSymptomOrCauseNameInSymptomOrCauseAndSolutionSection() {
        cy.get(causes).eq(0).invoke('text').then((valueThree) => {
            knowledgeText.push(valueThree.trim())
            cy.log(knowledgeText)
            // expect(knowledgeAndSymptomTextArrey[1]).to.eq(knowledgeText[2])

        })
    }

    nameOfSecondSymptomOrCauseInSymptomOrCauseAndSolutionSectionVisible() {
        cy.get(causes).eq(1).should(assertionConstants.beExistAssertion)
    }
    nameOfThirdSymptomOrCauseInSymptomOrCauseAndSolutionSectionVisible() {
        cy.get(causes).eq(2).scrollIntoView().should(assertionConstants.beExistAssertion)
    }

    multipleTagsInTokenVisible() {
        cy.get(allTagsInToken).last().scrollIntoView().find('li').should(assertionConstants.haveAttributeAssertion, 'class', 'pt-token-only ng-star-inserted').and(assertionConstants.beVisibleAssertion)
    }

    addCauseClick() {
        return cy.get(addCause).click()
    }

    tickMarkAtAddedCauseClick() {
        cy.get(tickMark).first().click()
    }

    entriesPerPageDropDownClick() {
    cy.get(entriesPerPageDropDown).click({ force: true })
    }

    FiveEntriesPerPageSelect() {
        cy.get(Operator).eq(0).click()
    }

    selectAllCheckBoxBesidesNameClick() {
        cy.get(selectAllCheckBoxBesidesName).click()
    }

    nextPageButtonClick() {
        cy.get(nextPageButton).click()
    }

    allSelectedSymptomsOrCausesInSymptomOrCauseAndSolutionSectionVisible() {
        cy.get(causes).should(assertionConstants.beVisibleAssertion)
    }

    allTagsInTokenVisible() {
        cy.get(allTagsInToken).last().find('li').scrollIntoView().should(assertionConstants.haveAttributeAssertion, 'class', 'pt-token-only ng-star-inserted').and(assertionConstants.beVisibleAssertion)
    }

    solutionOneTextBoxType() {
        cy.get(cause1InputBox).type('FirstSolution')
    }

    symptomsOrCauseWithoutEditOption() {
        cy.get(symptomsOrCauseWithoutEditOption).each((el, index) => {
            if (index !== 3) {
                cy.wrap(el).children('button').should('have.length.gte', 1)
            }
        })
    }

    knowledgeNameInputBoxType() {
        cy.get(patternNameTextBox).type(userID_Alpha_Numeric())
    }

    decriptionFieldType() {
        cy.get(descriptionTextBox).type(knowledgeDescriptionDetails)
    }

    modalityDropdownInCreatePageClick() {
        cy.get(modalityDropdownInCreatePage).click()
    }


    ctModalityOptionClick() {
        cy.get(ctModalityOption).first().click({ force: true })
    }

    symptomsKnowledgeInfoOptionsClick() {
        cy.get(addAction).eq(1).click()
    }

    adsymptomOptionClick() {
        cy.contains(adsymptomOption).click()
    }

    symptomOneTextBoxType() {
        cy.get(inputBox).last().type(knowledgeSymptomDetails)
    }

    addCauseOptionClick() {
        cy.contains(addCauseOption).click()
    }

    addSolutionClick() {
        cy.contains(addSolution).click()
    }

    solutionOneInputBoxType() {
        cy.get(inputBox).last().type(knowledgeSolutionnDetails)
    }

    tagsknowledgeInfoOptionsClick() {
        cy.get(addAction).last().click()
    }

    addTagsOptionClick() {
        cy.contains(addTagsOption).click()
    }

    selectTagDropdownClick() {
        cy.get(selectTagDropdown).click()
    }

    awsTagsOptionsClick() {
        cy.get(tagsOptions).eq(0).click()
    }

    plusIconInAddTagsClick() {
        cy.get(plusIconInAddTags).click()
    }

    createStageVisibleAndHighlighted() {
        cy.get(createStage).should(assertionConstants.containAssertion, ' Create ').and(assertionConstants.beVisibleAssertion).and(assertionConstants.haveAttributeAssertion, 'class', 'active ng-star-inserted')
    }

    viewStageVisibleAndDisabled() {
        cy.get(viewStage).should(assertionConstants.containAssertion, ' View ').and(assertionConstants.beVisibleAssertion).and(assertionConstants.haveAttributeAssertion, 'class', 'ng-star-inserted')
    }

    reviewRequeStageVisibleAndDisabled() {
        cy.get(reviewRequeStage).should(assertionConstants.containAssertion, ' Review Request ').and(assertionConstants.beVisibleAssertion).and(assertionConstants.haveAttributeAssertion, 'class', 'ng-star-inserted')
    }

    nextButtonOnCreatePageClick() {
        cy.get(nextButtonOnCreatePage).click()
    }

    nextButtonOnCreatePageEnabled() {
        cy.get(nextButtonOnCreatePage).should(assertionConstants.notBeDisabledAssertion)
    }

    viewStageVisibleAndHighlighted() {
        cy.get(viewStage).should(assertionConstants.containAssertion, ' View ').and(assertionConstants.beVisibleAssertion).and(assertionConstants.haveAttributeAssertion, 'class', 'ng-star-inserted active')
    }

    createStageWithTickMark() {
        cy.get(createStage).should(assertionConstants.containAssertion, ' Create ').and(assertionConstants.beVisibleAssertion).and(assertionConstants.haveAttributeAssertion, 'class', 'ng-star-inserted completed')
    }

    symptomOneTextInViewStepVisible() {
        cy.contains(knowledgeSymptomDetails).should(assertionConstants.beVisibleAssertion)
    }

    causeOneTextInViewStepVisible() {
        cy.contains(knowledgeCauseDetails).should(assertionConstants.beVisibleAssertion)
    }

    solutionOnetextInViewStepVisible() {
        cy.contains(knowledgeSolutionnDetails).should(assertionConstants.beVisibleAssertion)
    }

    fullScreenViewButtonClick() {
        cy.get(fullScreenViewButton).click()
    }

    knowledgeDetailsInFulllScreen() {
        cy.get(knowledgeDetailsInFulllScreen).should(assertionConstants.haveAttributeAssertion, 'class', 'enable-fullscreen')
    }


    previousButtonClick() {
        cy.get(previousButton).click()
    }

    userOnCreateSection() {
        cy.get(createStage).should(assertionConstants.containAssertion, ' Create ').and(assertionConstants.beVisibleAssertion).and(assertionConstants.haveAttributeAssertion, 'class', 'ng-star-inserted active')
    }

    knowledgeDescriptionDetailsExpanded() {
        cy.contains(knowledgeDescriptionDetails).should(assertionConstants.beVisibleAssertion)
    }

    knowledgeSymptomDetailsExpanded() {
        cy.contains(knowledgeSymptomDetails).should(assertionConstants.beVisibleAssertion)
    }

    knowledgeCausesAndSolutionsknowledgeCauseDetailsExpanded() {
        cy.contains(knowledgeCauseDetails).should(assertionConstants.beVisibleAssertion)
    }

    knowledgeTagsDetailsExpanded() {
        cy.contains(knowledgeTagsDetails).should(assertionConstants.beVisibleAssertion)
    }

    KnowledgeDescriptionDetailsCollapseAndExpandButtonClick() {
        cy.get(expandCollapseIconAtgroupLevel).first().click()
    }

    versionIndraftStageVisible() {
        cy.get(versionIndraftStage).should(assertionConstants.haveTextAssertion, 'Draft').and(assertionConstants.beVisibleAssertion)
    }

    versionIndraftStageNotExist() {
        cy.get(versionIndraftStage).should(assertionConstants.notExistsAssertion)
    }

    previousButtonClickInKnowledge() {
        cy.get(previousButtonInKnowledge).click()
    }

    ImportCausesAndSolutionInKnowledge() {
        cy.xpath(causesAndSolutionSectionInKnowledge).click()
        cy.get(causeButton).click()
        cy.get(showAllOption).click()
        cy.xpath(firstRecordCheckbox).click()
        cy.get(partsDoneButton).click()
    }

    fileUploadIconClick() {
        cy.get(uploadFileButton).click({ force: true })
    }

    saveAsDraftClick() {
        cy.get(saveButton).click()
    }

    crossMarkIconClick() {
        cy.get(crossMarkIcon).click()
    }

    confirmationPopupClick() {
        cy.get(confirmationPopup).should(assertionConstants.beVisibleAssertion)
        cy.get(confirmationPopup).click()
        cy.get(popUpOkButton).click()
    }

    deleteCause() {
        cy.get(crossMarkIconAtKnowledge).should(assertionConstants.beVisibleAssertion)
        cy.get(crossMarkIconAtKnowledge).click()
        cy.get(popUpOkButton).click()
    }

    ImportCausesAndSolutionByAddCauseSection() {
        cy.get(addCauseButton).click()
        cy.get(solutionTextType).type('Testing')
        cy.get(addSolutionButton).click()
        cy.get(solutionTextType).eq(1).type('Testing')
        cy.get(causesandSolutionDoneButton).click()
        cy.wait(3000)
    }

    editCausesAndSolution() {
        cy.get(editCauseButton).click()
        cy.get(solutionTextType).eq(0).clear().type('TestingText2')
        cy.get(solutionTextType).eq(1).clear().type('TestingText2')
        cy.get(causesandSolutionDoneButton).click()
        cy.wait(3000)
    }

    addedCauseAreEditableVerification() {
        cy.get(editCauseButton).then(($el) => {
            cy.wrap($el).should(assertionConstants.beVisibleAssertion)
        })
    }

    mandatorySectionVisible() {
        return cy.get(mandatorySection).then(($el) => {
            cy.wrap($el).should(assertionConstants.beVisibleAssertion)
            cy.wrap($el).prev().should(assertionConstants.beVisibleAssertion)
        })
    }

    saveButtonVisibleAsDisbled() {
        return cy.get(saveButton).should(assertionConstants.beVisibleAssertion).and(assertionConstants.haveAttributeAssertion, 'class', disabledClass)
    }

    breadcumbCaptureValue() {
        return cy.get(breadcumbCaptureValue).last().invoke('text').then((value) => {
            cy.writeFile(filePath, { name: value })
        })
    }

    knowledgeNameType() {
        return cy.get(knowledgeNameType)
    }

    saveButtonVisibleAsEnabled() {
        return cy.get(saveButton).should(assertionConstants.beVisibleAssertion).and(assertionConstants.haveNotAttributeAssertion, 'class', disabledClass)
    }

    causesAndSolutionSectionInKnowledgeClick() {
        cy.xpath(causesAndSolutionSectionInKnowledge).click({ force: true })
        cy.get(addCauseButton).click()
        cy.get(uploadFileButton).click({ force: true })
    }

    partsAddition() {
        cy.get(partsButton).click()
        cy.get(partNameType).type('Testing')
        cy.get(partDescriptionType).click({ force: true }).type('Testing')
        cy.get(partsDoneButton).click()
    }

    tagsAddition() {
        cy.get(tagsButton).click()
        cy.get(selectTagsDropdown).click()
        cy.get(recordFromtagsDropdown).eq(0).click({ force: true })
        cy.get(addRecordsFromDropdown).click()
        cy.get(tagsDoneButton).click()
        cy.wait(2000)
        cy.get(causesandSolutionDoneButton).click()
    }

    plusIconInAddtagsClick() {
        cy.get(addRecordsFromDropdown).click()
    }

    causeButtonClick() {
        return cy.get(causeButton).click()
    }

    importExistingCauses() {
        cy.get(recordFromtagsDropdown).click()
        cy.get(causeDropdown).click()
        cy.get(causeDropdownOptions).last().click()
        cy.get(tagsColumn).click()
        cy.wait(2000)
        cy.get(tagsColumn).click()
        cy.wait(2000)
        cy.xpath(firstRecordClick).click()
        cy.get(tagsVerification).then(($el) => {
            cy.wrap($el).should(assertionConstants.beVisibleAssertion)
        })
    }

    additionOfMandatoryDetails() {
        cy.xpath(knowledgeInfo).click()
        cy.get(description).type('Testing')
        cy.xpath(symptoms).click()
        cy.get(selectSymptomsButtonInAddSymptomSection).click()
        cy.get(recordFromtagsDropdown).click()
        cy.get(symptomRecord).eq(2).click()
        cy.get(partsDoneButton).click()
        cy.wait(2000)
    }

    savedDetailsVerificationInKnowledge() {
        cy.get(savedDetails).then(($el) => {
            cy.wrap($el).should(assertionConstants.beVisibleAssertion)
        })
    }

    nextButtonDisabledInKnowledge() {
        cy.get(NextButtonInKnowledge).should(assertionConstants.beVisibleAssertion)
        return cy.get(NextButtonInKnowledge).should(assertionConstants.haveAttributeAssertion, 'class', 'pt-primary pt-button ng-star-inserted')
    }

    causeButtonVisible() {
        return cy.get(causeButton).should(assertionConstants.beVisibleAssertion)
    }

    selectClauseHeadingVisible() {
        return cy.get(selectClauseHeading).should(assertionConstants.beVisibleAssertion)
    }

    crossMarkClick() {
        return cy.get(crossMark).eq(0).click()
    }

    searchBoxTestVisible() {
        return cy.get(searchBoxTestVisible).should(assertionConstants.haveAttributeAssertion, 'placeholder', 'Search by Keyword')
    }

    cancelButtonClickForClaus() {
        return cy.xpath(cancelforCause).click()
    }

    symptomsVisible() {
        return cy.xpath(symptoms).should(assertionConstants.beVisibleAssertion)
    }

    symptomNameColumnType() {
        return cy.get(symptomNameColumnField).type('Test{enter}')
    }

    dropdownValuesVerification() {
        cy.get(attributeForCause).eq(0).click()
        cy.get(dropdownValuesVerification).each(($el) => {
            cy.wrap($el).should(assertionConstants.beVisibleAssertion)
        })
    }

    clearSearchBoxType() {
        return cy.get(searchBoxTestVisible).clear()
    }

    searchBoxType() {
        return cy.get(searchBoxTestVisible).type(keywordType)
    }

    causeOneSolutionOneInputTextBoxType() {
        cy.get(cause1InputBox).type('causeonesolutionone')
    }

    causeOneSolutionTwoInputTextBoxType() {
        cy.get(cause1InputBox).type('causeonesolutionTwo')
    }

    causeOneSolutionThreeInputTextBoxType() {
        cy.get(cause1InputBox).type('causeonesolutionThree')
    }

    causeTwoInputTextBoxType() {
        cy.get(cause1InputBox).type('caustwo')
    }

    causeTwoSolutionOneInputTextBoxType() {
        cy.get(cause1InputBox).type('causetwosolutionone')
    }

    causeTwoSolutionTwoInputTextBoxType() {
        cy.get(cause1InputBox).type('causetwosolutiontwo')
    }

    causeTwoSolutionThreeInputTextBoxType() {
        cy.get(cause1InputBox).type('causetwosolutionthree')
    }

    causeThreeInputTextBoxType() {
        cy.get(cause1InputBox).type('causethree')
    }

    causeThreeSolutionOneInputTextBoxType() {
        cy.get(cause1InputBox).type('causethreesolutionone')
    }

    causeThreeSolutionTwoInputTextBoxType() {
        cy.get(cause1InputBox).type('causethreesolutiontwo')
    }

    causeThreeSolutionThreeInputTextBoxType() {
        cy.get(cause1InputBox).type('causethreesolutionthree')
    }

    causeFourInputTextBoxType() {
        cy.get(cause1InputBox).type('causefour')
    }

    causeFourSolutionOneInputTextBoxType() {
        cy.get(cause1InputBox).type('causefoursolutionone')
    }

    causeFourSolutionTwoInputTextBoxType() {
        cy.get(cause1InputBox).type('causefoursolutiontwo')
    }

    causeFourSolutionThreeInputTextBoxType() {
        cy.get(cause1InputBox).type('causefoursolutionthree')
    }

    editOptionAtCauseTwoClick() {
        cy.get(editOption).eq(1).click({ force: true })
    }

    causeTwoSolutionOnePriorityDropdownClick() {
        cy.get(PriorityDropdown).eq(5).click()
    }

    prioritythreeOptionOfPriorityDropdownclick() {
        cy.get(prioritythreeOptionOfPriorityDropdown).first().click({ force: true })
    }

    causeTwoSolutionTwoPriorityDropdownClick() {
        cy.get(PriorityDropdown).eq(9).click({ force: true })
    }

    priorityTwoOptionOfPriorityDropdownclick() {
        cy.get(priorityTwoOptionOfPriorityDropdown).eq(3).click({ force: true })
    }

    causeTwoSolutionThreePriorityDropdownClick() {
        cy.get(PriorityDropdown).eq(12).click()
    }

    priorityOneOptionOfPriorityDropdownclick() {
        cy.get(priorityOneOptionOfPriorityDropdown).eq(5).click({ force: true })
    }

    removeIconOfCauseThreeClick() {
        cy.get(removeIconOfCauseThree).eq(2).click()
    }

    popUpVisible() {
        cy.get(confirmationPopUp).should(assertionConstants.beVisibleAssertion)
    }

    popUpTextOneVisible() {
        cy.get(popUpTitle).should(assertionConstants.haveTextAssertion, 'Are you sure you want to delete this cause?').and(assertionConstants.beVisibleAssertion)
    }

    causeNameInPopUp() {
        cy.get(popUpDialogue).should(assertionConstants.haveTextAssertion, ' "Cause3"  will be deleted ').and(assertionConstants.beVisibleAssertion)
    }

    cause3() {
        cy.contains(cause3Text).should(assertionConstants.beVisibleAssertion)
    }

    cause4TextNotExist() {
        cy.contains(cause4Text).should(assertionConstants.notExistsAssertion)
    }

    cause3NotExist() {
        cy.get(cause3).last().find(updatedDetails).first().find('p').first().should(assertionConstants.notHaveTextAssertion, 'cause3')
    }

    editOptionAtCauseThreeSolutionTwoClick() {
        cy.get(editOption).last().click()
    }

    cause2Solution2RemoveIconClick() {
        cy.get(cause3Solution1RemoveIcon).eq(1).click()
    }

    solutionPopUpTextOneVisible() {
        cy.get(popUpTitle).should(assertionConstants.haveTextAssertion, 'Are you sure you want to delete this solution?').and(assertionConstants.beVisibleAssertion)
    }

    solutionNameInPopUp() {
        cy.get(popUpDialogue).should(assertionConstants.haveTextAssertion, ' "Solution2"  will be deleted ').and(assertionConstants.beVisibleAssertion)
    }

    solutionTwoTextVisible() {
        cy.contains(solutionTwoText).should(assertionConstants.beVisibleAssertion)
    }

    solutionThreeTextNotExist() {
        cy.get(solutionThreeText).should(assertionConstants.notExistsAssertion)
    }

    causeTwoSolutionOnePriorityDropdownWithRedBorder() {
        cy.get(PriorityDropdown).eq(5).should(assertionConstants.haveClassAssertion, 'fr-command fr-btn fr-dropdown fr-selection')
    }

    causeTwoSolutionOnePriorityDropdownWithOutWithRedBorder() {
        cy.get(PriorityDropdown).eq(5).should(assertionConstants.notHaveClassAssertion, 'fr-command fr-btn fr-dropdown fr-selection')
    }

    priorityTwoOptionOfPriorityDropdownForSolution2Click() {
        cy.get(priorityTwoOptionOfPriorityDropdown).eq(3).click()
    }

    causeTwoSolutionTwoPriorityDropDownClick() {
        cy.get(causeTwoSolutionTwoPriorityDropDown).click()
    }

    Priority2OptionForSolution2Click() {
        cy.get(priorityTwoOptionOfPriorityDropdown).eq(3).click()
    }

    redBorderVisible() {
        cy.get(solutionWithRedBorder).eq(0).should('have.css', 'border-color')
    }

    redBorderNotExist() {
        cy.get(solutionWithOutRedBorder).eq(0).should('have.css', 'background')
    }

    priorityTwoOptionForCauseOneClick() {
        cy.get(priorityTwoOptionOfPriorityDropdown).eq(1).click()
    }

    priorityOneOptionForCauseOneClick() {
        cy.get(priorityOneOptionOfPriorityDropdown).eq(1).click()
    }

    tickAtCauseFourClick() {
        cy.get(tick).click()
    }

    // previousButtonClickInKnowledge() {
    //   cy.get(previousButtonInKnowledge).click()
    // }

    tickAtCauseOneClick() {
        cy.get(tick).click()
    }

    sequenceOfCausesAndSolutionsForCauseOne() {
        cy.get(causes).eq(1).should(assertionConstants.haveTextAssertion, 'Cause1')
        cy.get(solutions).eq(0).should(assertionConstants.haveTextAssertion, 'Solution1')
        cy.get(solutions).eq(1).should(assertionConstants.haveTextAssertion, 'Solution2')
    }

    sequenceOfCausesAndSolutionsForCauseTwo() {
        cy.get(causes).eq(2).should(assertionConstants.haveTextAssertion, 'Cause2')
        cy.get(solutions).eq(2).should(assertionConstants.haveTextAssertion, 'Solution1')
        cy.get(solutions).eq(3).should(assertionConstants.haveTextAssertion, 'Solution2')
        cy.get(solutions).eq(4).should(assertionConstants.haveTextAssertion, 'Solution3')
    }

    sequenceOfCausesAndSolutionsForCauseThree() {
        cy.get(causes).eq(3).should(assertionConstants.haveTextAssertion, 'Cause3')
        cy.get(solutions).eq(5).should(assertionConstants.haveTextAssertion, 'Solution1')
        cy.get(solutions).eq(6).should(assertionConstants.haveTextAssertion, 'Solution2')
        cy.get(solutions).eq(7).should(assertionConstants.haveTextAssertion, 'Solution3')
    }

    selectSymptomClick() {
        cy.get(selectSymptom).click()
    }

    showAllButtonClick() {
        cy.get(checkBox).click()
    }

    symptomOptionClick() {
        cy.contains(symptomOption).click()
    }

    addSymptomButtonClick() {
        cy.get(addSymptomButton).click()
    }

    tickAtSymptomOneClick() {
        cy.get(tickAtSymptomOne).click()
    }

    cancelButtonVisible() {
        return cy.contains(cancelButton).should(assertionConstants.beVisibleAssertion)
    }

    deleteButtonVisible() {
        return cy.xpath(deleteButton).should(assertionConstants.beVisibleAssertion)
    }

    deleteButtonClick() {
        return cy.xpath(deleteButton).click()
    }
    deletebuttonVisible() {
        return cy.get(deletebutton).should(assertionConstants.beVisibleAssertion)
    }

    deletebuttonClick() {
        return cy.get(deletebutton).click()
    }

    asteriskVisible() {
        cy.get(asterisk).eq(4).should(assertionConstants.beVisibleAssertion)
    }

    selectCauseVisible() {
        return cy.get(selectCause).should(assertionConstants.beVisibleAssertion)
    }

    addCauseVisible() {
        return cy.get(addCause).should(assertionConstants.beVisibleAssertion)
    }

    causeAndSolutionClick() {
        cy.get(addAction).eq(2).click()
    }

    fullScreenIconVisible() {
        cy.get(fullScreenIcon).should(assertionConstants.beVisibleAssertion)
    }

    expandIconVisible() {
        cy.get(expandIcon).eq(2).should(assertionConstants.beVisibleAssertion)
    }

    generatedCause1Visible() {
        cy.get(generatedCause1).should(assertionConstants.haveTextAssertion, 'Cause1').and(assertionConstants.beVisibleAssertion)
    }

    tickdisabled() {
        cy.get(tick).should(assertionConstants.notBeEnabledAssertion)
    }

    closeEnabled() {
        cy.get(close).should(assertionConstants.notBeDisabledAssertion)
    }

    richTextEditorVisible() {
        cy.get(richTextEditorBox).should(assertionConstants.beVisibleAssertion)
    }

    addSolutionDisabled() {
        cy.contains(addSolution).should(assertionConstants.notBeEnabledAssertion)
    }

    selectCauseDisabled() {
        cy.get(selectCause).should(assertionConstants.notBeEnabledAssertion)
    }

    addCauseDisabled() {
        cy.get(addCause).should(assertionConstants.notBeEnabledAssertion)
    }

    richTextEditorType() {
        cy.get(cause1InputBox).type('firstCause')
    }

    addSolutionEnabled() {
        cy.contains(addSolution).should(assertionConstants.notBeDisabledAssertion)
    }

    causeAndSolutionVisible() {
        cy.get(addAction).eq(2).should(assertionConstants.beVisibleAssertion)
    }

    cause1TextBoxType() {
        cy.get(TextBox).first().type('secondTextForCause')
    }

    solution1TextBoxType() {
        cy.get(TextBox).last().type('secondTextForSolution')
    }

    selectCauseClick() {
        cy.get(selectCause).click()
    }

    firstCauseClick() {
        cy.get(firstCause).eq(1).click()
    }

    sequentialCauseNameVisible() {
        cy.contains(sequentialCauseName).should(assertionConstants.beVisibleAssertion)
    }

    closeIconForSolution1() {
        cy.get(closeIconForSolution1).should(assertionConstants.beVisibleAssertion)
    }

    solution1UnderCause2TextBoxType() {
        cy.get(TextBox).eq(1).type('SolutionUnderCauseTwo')
    }

    sequencialSolutionNameUnderCause2Visible() {
        cy.contains(sequencialSolutionNameUnderCause2).should(assertionConstants.beVisibleAssertion)
    }

    priorityDropdownForSolutionOneVisible() {
        cy.get(cause3Solution1PriorityDropdown).first().find('span').should(assertionConstants.haveTextAssertion, solutionOnePriority).and(assertionConstants.beVisibleAssertion)
    }

    priorityDropdownForSolutionTwoVisible() {
        cy.get(cause3Solution1PriorityDropdown).last().find('span').should(assertionConstants.haveTextAssertion, solutionTwoPriority).and(assertionConstants.beVisibleAssertion)
    }

    priorityDropdownForSolutionTwoClick() {
        cy.get(cause3Solution1PriorityDropdown).last().click()
    }

    selectOptionUderSolution2PriorityDropdownVisible() {
        cy.get(selectOptionUderPriorityDropdown).last().should(assertionConstants.haveTextAssertion, selectPriorityText).should(assertionConstants.beVisibleAssertion)
    }

    updatedDetailsOfCause2Solution1Visible() {
        cy.get(updatedDetails).eq(3).find('p').should(assertionConstants.haveTextAssertion, 'Updated solution one in Cause two').and(assertionConstants.beVisibleAssertion)
    }

    solution1Visible() {
        cy.get(solution1).should(assertionConstants.beVisibleAssertion)
    }

    richTextEditorForSolution1Visible() {
        cy.get(richTextEditorBox).last().should(assertionConstants.beVisibleAssertion)
    }

    priorityDropdownForSolutionOneClick() {
        cy.get(cause3Solution1PriorityDropdown).first().click()
    }

    selectOptionUderSolution1PriorityDropdownVisible() {
        cy.get(selectOptionUderPriorityDropdown).first().should(assertionConstants.haveTextAssertion, selectPriorityText).should(assertionConstants.beVisibleAssertion)
    }

    tickEnabled() {
        cy.get(tick).should(assertionConstants.notBeDisabledAssertion)
    }

    selectCauseEnabled() {
        cy.get(selectCause).should(assertionConstants.notBeDisabledAssertion)
    }

    addCauseEnabled() {
        cy.get(addCause).should(assertionConstants.notBeDisabledAssertion)
    }

    selectSymptomsButtonClick() {
        return cy.get(selectSymptomsButton).click({ force: true })
    }

    firstRecordClick() {
        return cy.get(firstRecord).eq(0).click()
    }

    causesAndSolutionsClick() {
        return cy.contains(causeAndSolutionText).click()
    }

    removeMarkVerificationInKnowledge() {
        return cy.get(removeMarkVerificationInKnowledge).should(assertionConstants.beVisibleAssertion)
    }

    withKeywordClick() {
        return cy.contains(withKeywordSection).click()
    }

    keywordDropdownClick() {
        cy.get(keywordDropdownVisibleInTagSection).click()
        cy.get(dropdownValuesVerification).eq(0).click()
    }

    operatorDropdownClick() {
        cy.get(operatorDropdownVisibleInTagSection).click()
        cy.get(dropdownValuesVerification).eq(0).click()
    }

    valueDropdownClick() {
        cy.get(valueDropdownVisibleInTagSection).click()
        cy.get(dropdownValuesVerification).eq(0).invoke('text').then((value) => {
            tagValuesList.push(value)
        })
        cy.get(dropdownValuesVerification).eq(0).click()
        cy.log(tagValuesList)
    }

    addTagPlusIconClick() {
        return cy.get(addTagPlusIcon).click()
    }

    removeMarkVerification() {
        return cy.get(removeMarkVerification).should(assertionConstants.beVisibleAssertion)
    }

    keywordDropdownVisibleInTagSection() {
        return cy.get(keywordDropdownVisibleInTagSection).should(assertionConstants.beVisibleAssertion)
    }

    operatorDropdownVisibleInTagSection() {
        return cy.get(operatorDropdownVisibleInTagSection).should(assertionConstants.beVisibleAssertion)
    }
    valueDropdownVisibleInTagSection() {
        return cy.get(valueDropdownVisibleInTagSection).should(assertionConstants.beVisibleAssertion)
    }

    addedTagVisible() {
        return cy.get(addTagsList).should(assertionConstants.beVisibleAssertion)
    }

    withoutKeywordClick() {
        return cy.contains(withoutKeywordSection).click()
    }

    withKeywordSectionVisible() {
        cy.contains(withKeywordSection).should(assertionConstants.beVisibleAssertion)
    }

    PartsIconVisible() {
        cy.get(PartsIcon).should(assertionConstants.beVisibleAssertion)
    }

    addPartTitleVisible() {
        cy.get(addPartTitle).should(assertionConstants.haveTextAssertion, 'Add Part').and(assertionConstants.beVisibleAssertion)
    }

    twelveNCTextVisible() {
        cy.get(twelveNCText).should(assertionConstants.haveTextAssertion, '12NC').and(assertionConstants.beVisibleAssertion)
    }

    twelveNCTextBoxVisible() {
        cy.get(twelveNCTextBox).should(assertionConstants.haveAttributeAssertion, 'placeholder', "Part Number")
    }

    descriptionTextVisible() {
        cy.get(descriptionTextInAddTags).should(assertionConstants.containAssertion, 'Description').and(assertionConstants.beVisibleAssertion)
    }

    descriptionTextBoxVisible() {
        cy.get(descriptionTextBox).last().should(assertionConstants.haveAttributeAssertion, 'placeholder', "Part Description")
    }

    removeXIconDisabled() {
        cy.get(crossMarkAtConditionLevel).should(assertionConstants.notBeDisabledAssertion)
    }

    addPlusIconEnabled() {
        cy.get(addConditionButton).should(assertionConstants.notBeDisabledAssertion)
    }

    cancelButtonEnabled() {
        cy.get(CancelBUtton).last().should(assertionConstants.notBeDisabledAssertion)
    }

    doneButtonDisabled() {
        cy.contains(doneButton).should(assertionConstants.notBeEnabledAssertion)
    }

    redColorInfoIconVisible() {
        cy.get(redColorInfoIcon).should(assertionConstants.beVisibleAssertion)
    }

    partValidationMessageVisible() {
        cy.get(partValidationMessage).find('[class="ng-star-inserted"]').should(assertionConstants.haveTextAssertion, 'Validate the part information before proceeding.').and(assertionConstants.beVisibleAssertion)
    }

    twelveNCTextBoxWithMaxTwelveCharacters() {
        cy.get(twelveNCTextBox).should(assertionConstants.haveAttributeAssertion, 'maxlength', '12')
    }

    descriptionTextBoxWithMaxThousandCharacters() {
        cy.get(descriptionTextBox).last().should(assertionConstants.haveAttributeAssertion, 'maxlength', '1000')
    }

    secondTwelveNCTextBoxType() {
        cy.get(twelveNCTextBox).last().type('spanner')
    }

    secondDescriptionTextBoxClick() {
        cy.get(descriptionTextBox).last().click()
    }

    secondTwelveNCTextBoxInRedColor() {
        cy.get(twelveNCTextBox).last().should(assertionConstants.haveAttributeAssertion, 'class', "pt-input ng-dirty ng-touched ng-invalid")
    }

    redColorInfoIconWithValidationMessageVisible() {
        cy.get(redColorInfoIcon).first().should(assertionConstants.beVisibleAssertion)
    }

    ValidationMessageForDuplicateNameVisible() {
        cy.contains(ValidationMessageForDuplicateName).should(assertionConstants.beVisibleAssertion)
    }

    secondTwelveNCTextBoxCleared() {
        cy.get(twelveNCTextBox).last().clear()
    }

    addPlusIconToAddRoClick() {
        cy.get(addConditionButton).last().click()
    }

    removeXIconEnabled() {
        cy.get(crossMarkAtConditionLevel).should(assertionConstants.notBeDisabledAssertion)
    }

    secondRowtwelveNCTextBoxForType() {
        cy.get(twelveNCTextBox).eq(1).type('Motor')
    }

    thirdRowTwelveNCTextBoxForType() {
        cy.get(twelveNCTextBox).eq(2).type('screws')
    }

    fourthRowTwelveNCTextBoxForType() {
        cy.get(twelveNCTextBox).eq(3).type('bolts')
    }

    secondRowDescriptionTextBoxType() {
        cy.get(descriptionTextBox).eq(2).type('Switches')
    }

    thirdRowDescriptionTextBoxType() {
        cy.get(descriptionTextBox).eq(3).type('PowerSupply')
    }

    fourthRowDescriptionTextBoxType() {
        cy.get(descriptionTextBox).eq(4).type('CanNode')
    }

    causeDetailsNotVisible() {
        cy.get(causeDetails).should(assertionConstants.notExistsAssertion)
    }


    selectCauseTitleVisible() {
        cy.get(selectCauseTitle).should(assertionConstants.haveTextAssertion, 'Select Cause').and(assertionConstants.beVisibleAssertion)
    }

    messageBelowSelectCauseTitleVisible() {
        cy.contains(messageBelowSelectCauseTitle).should(assertionConstants.beVisibleAssertion)
    }

    dropdownWithAllSelectedVisible() {
        cy.get(commonSearchTextBox).find('span').should(assertionConstants.haveTextAssertion, 'All').and(assertionConstants.beVisibleAssertion)
    }

    searchByKeywordtextBoxWithText() {
        cy.get(searchByKeywordtextBoxWithText).find('input').should(assertionConstants.haveAttributeAssertion, 'placeholder', 'Search by Keyword')
    }

    selectAllCkeckBoxVisible() {
        cy.get(selectAllCkeckBox).should(assertionConstants.beVisibleAssertion)
    }
    recordsCountVisible() {
        cy.get(recordsCount).should(assertionConstants.containAssertion, recordsFoundText).and(assertionConstants.beVisibleAssertion)
    }

    // causeDetailsNotVisible() {
    //   cy.get(causeDetails).should(assertionConstants.notExistsAssertion)
    // }

    selectButtonVisible() {
        cy.get(selectButton).should(assertionConstants.beVisibleAssertion)
    }

    entriesPerPageDropdownVisible() {
        cy.get(entriesPerPageDropdown).should(assertionConstants.beVisibleAssertion)
    }

    entriesPerPageDropdownTextVisible() {
        cy.get(entriesPerPageDropdown).find('span').should(assertionConstants.haveTextAssertion, '10').and(assertionConstants.beVisibleAssertion)
    }

    currentPageNoText() {
        cy.get(pageCount).should(assertionConstants.containAssertion, ' Showing 1 of').and(assertionConstants.beVisibleAssertion)
    }

    entriesPerPageDropdownClick() {
        cy.get(entriesPerPageDropdown).last().click()
    }

    fiveEntriesPerpageOptionClick() {
        cy.get(valueForSecondConditionInSecondEvent).eq(0).click()
    }

    selectedEntriesOfRecordsVisible() {
        cy.get(selectedEntriesOfRecords).should(assertionConstants.havelengthAssertion, '5').and(assertionConstants.beVisibleAssertion)
    }

    arrowSymbolTonavigateToNextPageClick() {
        cy.get(arrowSymbolTonavigateToNextPage).click()
    }

    nextPage() {
        cy.get(pageCount).should(assertionConstants.containAssertion, ' Showing 2 of')
    }

    nextPageNoVisible() {
        cy.get(pageCount).should(assertionConstants.containAssertion, '2').and(assertionConstants.beVisibleAssertion)
    }

    nextPagePatternDetailsVisible() {
        cy.get(selectedEntriesOfRecords).should(assertionConstants.beVisibleAssertion)
    }

    arrowSymbolTonavigateToPreviousPageClick() {
        cy.get(arrowSymbolTonavigateToPreviousPage).click()
    }

    PreviousPage() {
        cy.get(pageCount).should(assertionConstants.containAssertion, ' Showing 1 of')
    }

    PreviousPageNoVisible() {
        cy.get(pageCount).should(assertionConstants.containAssertion, '1').and(assertionConstants.beVisibleAssertion)
    }

    PreviousPagePatternDetailsVisible() {
        cy.get(selectedEntriesOfRecords).should(assertionConstants.beVisibleAssertion)
    }

    arrowSymbolTonavigateToPreviousPageDisabled() {
        cy.get(arrowSymbolTonavigateToPreviousPage).should(assertionConstants.notBeEnabledAssertion)
    }

    TenEntriesPerpageOptionClick() {
        cy.get(Operator).eq(0).click()
    }

    afterClickOnPreviousArrowEnriesPerPageClick() {
        cy.get(afterClickOnPreviousArrowEnriesPerPage).click()
    }

    selectCausePopupNotExist() {
        cy.get(confirmationPopUp).should(assertionConstants.notExistsAssertion)
    }

    fiveEntriesPerpageOptionVisible() {
        cy.get(Operator).eq(0).should(assertionConstants.haveTextAssertion, '5')
    }

    twentyEntriesOptionVisible() {
        cy.get(Operator).eq(1).should(assertionConstants.haveTextAssertion, '20')
    }

    fiftyEntriesOptionVisible() {
        cy.get(Operator).eq(2).should(assertionConstants.haveTextAssertion, '50')
    }

    hundredEntriesOptionVisible() {
        cy.get(Operator).eq(3).should(assertionConstants.haveTextAssertion, '100')
    }

    selectButtonDisabled() {
        cy.get(selectButton).should(assertionConstants.notBeEnabledAssertion)
    }

    resizedGrid() {
        cy.get(resizedGrid).find('div').first().should(assertionConstants.haveAttributeAssertion, 'class', 'leftView pl-4 col-md-6')
    }

    selectedCauseDetailsVisible() {
        cy.get(selectedCauseDetails).should(assertionConstants.beVisibleAssertion)
    }

    selectButtonEnabled() {
        cy.get(selectButton).should(assertionConstants.notBeDisabledAssertion)
    }

    firstCauseSelected() {
        cy.get(causeOfGrid).first().click()
    }

    secondCauseSelected() {
        cy.get(causeOfGrid).eq(1).click()
    }

    thirdCauseSelected() {
        cy.get(causeOfGrid).eq(2).click()
    }

    latestSelectedCauseDetailsVisible() {
        cy.contains(latestSelectedCauseDetails).should(assertionConstants.beVisibleAssertion)
    }

    allCausesSelected() {
        cy.get(causeOfGrid).click({ multiple: true })
    }

    priorityVisible() {
        cy.contains(priority).should(assertionConstants.beVisibleAssertion)
    }

    solutionDescriptionVisible() {
        cy.contains(solutionDescription).should(assertionConstants.beVisibleAssertion)
    }

    selectAllCkeckBoxClick() {
        cy.get(selectAllCkeckBox).click()
    }

    collapseDetailsIconVisible() {
        cy.get(collapseDetailsIcon).should(assertionConstants.beVisibleAssertion)
    }

    causeSearchOptionType() {
        cy.get(causeSearchOption).type('Knowledge associated with withdrawn pattern - Knowledge Delete Verification.Cause1')
    }

    causeSearchButtonClick() {
        cy.get(searchButton).last().click()
    }

    selectSearchedKnowledgeClick() {
        cy.get(selectSearchedKnowledge).click()
    }

    causeNameVisible() {
        cy.contains(causeName).should(assertionConstants.beVisibleAssertion)
    }

    descriptionOfCauseVisible() {
        cy.get(solutionDetails).first().should(assertionConstants.beVisibleAssertion)
    }

    solutionNameVisible() {
        cy.get(solutionName).first().should(assertionConstants.beVisibleAssertion)
    }

    priorityTextVisible() {
        cy.contains(priority).should(assertionConstants.beVisibleAssertion)
    }

    descriptionOfSolutionVisible() {
        cy.get(updatedDetails).eq(1).should(assertionConstants.beVisibleAssertion)
    }

    partsDataForSolutionVisibel() {
        cy.get(partsDataForSolution).should(assertionConstants.beVisibleAssertion)
    }

    tagsDataForSolutionVisible() {
        cy.get(tagsDataForSolution).should(assertionConstants.beVisibleAssertion)
    }

    tagsDataForCauseVisible() {
        cy.get(tagsDataForCause).should(assertionConstants.beVisibleAssertion)
    }

    associationsVisible() {
        cy.contains(associations).should(assertionConstants.beVisibleAssertion)
    }

    tagsDataForSolutionWithTokenVisible() {
        cy.get(tagsDataForSolution).find('div').eq(1).should(assertionConstants.haveAttributeAssertion, 'class', 'token-list')
    }

    tagsDataForCauseWithTokenVisible() {
        cy.get(tagsDataForCause).find('div').eq(1).should(assertionConstants.haveAttributeAssertion, 'class', 'token-list')
    }

    clearAllFilterButtonClick() {
        cy.get(clearAllFilterButton).click()
    }

    lastestSelectedCasueText() {
        cy.get(causeList).last().find('tr').eq(0).find('td').eq(1).find('span').first().invoke('text').then((value) => {
            latestSelecteCauseArrey.push(value.trim())
            cy.log(latestSelecteCauseArrey)

        })
    }
    lastestSelectedKnowledgeInRightSection() {
        cy.get(causes).invoke('text').then((el) => {
            latestSelectedKnowledgeArrey.push(el.trim())
            expect(latestSelecteCauseArrey[0]).to.eq(latestSelectedKnowledgeArrey[0])
        })
    }

    FirstSelectedKnowledgeInRightSection() {
        cy.get(causes).invoke('text').then((el) => {
            latestSelectedKnowledgeArrey.push(el.trim())
            expect(latestSelecteCauseArrey[0]).to.eq(latestSelectedKnowledgeArrey[0])
        })
    }

    AddAuthoringWokFlowButtonClick() {
        return cy.get(AddAuthoringWokFlowButton).click()
    }

    workFlowMessageVisible() {
        return cy.contains(workFlowMessage).should(assertionConstants.beVisibleAssertion)
    }

    entriesPerPageOptionsVerification() {
        cy.get(valueForSecondConditionInSecondEvent).eq(0).should(assertionConstants.containAssertion, '5').and(assertionConstants.beVisibleAssertion)
        cy.get(valueForSecondConditionInSecondEvent).eq(1).should(assertionConstants.containAssertion, '10').and(assertionConstants.beVisibleAssertion)
        cy.get(valueForSecondConditionInSecondEvent).eq(2).should(assertionConstants.containAssertion, '20').and(assertionConstants.beVisibleAssertion)
        cy.get(valueForSecondConditionInSecondEvent).eq(3).should(assertionConstants.containAssertion, '50').and(assertionConstants.beVisibleAssertion)
        cy.get(valueForSecondConditionInSecondEvent).eq(4).should(assertionConstants.containAssertion, '100').and(assertionConstants.beVisibleAssertion)
    }

    showAllCheckBoxUnchecked() {
        return cy.get(checkBox).should(assertionConstants.notBeCheckedAssertion)
    }

    knowledgeClick() {
        cy.get(knowledge).click()
        return cy.get(okBtton).click()
    }

    selectSymptomsHeadingVisible() {
        return cy.xpath(selectSymptomsHeading).should(assertionConstants.beVisibleAssertion)
    }

    totalrecordsPerPageVerificationforTen() {
        return cy.xpath(totalRecordFoundCount).should(assertionConstants.havelengthAssertion, 10)
    }

    entriesPerPageVisible() {
        return cy.contains(entriesPerPage).should(assertionConstants.beVisibleAssertion)
    }

    patternNameASCOrderSortedVisible() {
        return cy.get(patternNameSorted).eq(0).should(assertionConstants.haveAttributeAssertion, 'class', 'p-sortable-column-icon pi pi-fw pi-sort-amount-up-alt')
    }

    changeEntriesPerPageCountSize() {
        cy.get(changeEntriesPerPageCount).eq(1).click()
        cy.xpath(entriesperpageTwenty).click()
    }

    totalrecordsPerPageVerificationforTwenty() {
        return cy.xpath(totalRecordFoundCount).should(assertionConstants.havelengthAssertion, 20)
    }


    nextPageNavigationClickandVerification() {
        cy.get(nextPageNavigation).eq(1).click()
        return cy.get(totalCountOfPage).invoke('text').should('include', ' Showing 2')
    }


    previousPageNavigationClickandVerification() {
        cy.get(nextPageNavigation).eq(0).click()
        return cy.get(totalCountOfPage).invoke('text').should('include', ' Showing 1')
    }

    cancelClick() {
        return cy.get(ButtonVisible).eq(0).click()
    }

    entriesPrPageVisible() {
        return cy.get(entriesperPage).should(assertionConstants.beVisibleAssertion)
    }

    selectButtonDisabledVerification() {
        return cy.get(ButtonVisible).eq(1).should(assertionConstants.haveAttributeAssertion, 'disabled')
    }

    rightsideSectionVisible() {
        return cy.get(rightSecton).should(assertionConstants.beVisibleAssertion)
    }

    textVerificationFromRightSideSection() {
        return cy.get(symptomName).eq(0).invoke('text').should('have.length.at.least', 2)
    }

    selectButtonEnabledVerification() {
        return cy.get(ButtonVisible).eq(1).should(assertionConstants.haveNotAttributeAssertion, 'disabled')
    }

    collapseDetailsVerification() {
        cy.get(knowledgeViewIcon).should(assertionConstants.beVisibleAssertion)
        cy.get(knowledgeViewIcon).click()
        cy.get(collapsedDetails).should(assertionConstants.beVisibleAssertion)
    }

    collapseIconClick() {
        return cy.get(knowledgeViewIcon).click()
    }

    symptomAssociationsVisible() {
        return cy.get(symptomAssociation).eq(1).should(assertionConstants.beVisibleAssertion)
    }

    symptomTagsVisible() {
        return cy.get(symptomAssociation).eq(0).should(assertionConstants.beVisibleAssertion)
    }

    symptomDescriptionVisible() {
        return cy.get(symptomDescription).eq(0).should(assertionConstants.beVisibleAssertion)
    }

    symptomNameVisible() {
        return cy.get(symptomName).eq(0).should(assertionConstants.beVisibleAssertion)
    }

    noDataVisibleInTable() {
        return cy.get(noDataVisibleInTable).should('not.exist')
    }

    selectSymptomsButtonVisible() {
        return cy.get(selectSymptomsButton).should(assertionConstants.beVisibleAssertion)
    }


    showAllCheckboxVisible() {
        return cy.get(showAllCheckboxVisible).should(assertionConstants.beVisibleAssertion)
    }

    searchBoxVisible() {
        return cy.get(searchBoxTestVisible).should(assertionConstants.beVisibleAssertion)
    }

    CancelButtonVisible() {
        return cy.get(ButtonVisible).eq(0).should(assertionConstants.beVisibleAssertion)
    }

    knowledgeStepsVisible() {
        cy.get(knowledgeSteps).should(assertionConstants.beVisibleAssertion)
    }


    insertFileButtonClick() {
        return cy.get(insertFileButton).click()
    }

    browseFileIconClick() {
        return cy.get(browseFileIcon).click({ force: true })
    }

    uploadedImageVerification() {
        cy.get(attachedFileHyperlink).should(assertionConstants.beVisibleAssertion)
    }

    solutionTextTypeClickAndType() {
        return cy.get(solutionTextType).type(' Testing')
    }

    inputFieldInSolutionSectionClickAndType() {
        return cy.get(solutionTextType).eq(1).type('Testing')
    }

    tickMarkIconClick() {
        return cy.get(saveDetailsButton).click()
    }

    DetailsSavedVerification() {
        cy.get(editButton).should(assertionConstants.beVisibleAssertion)
        cy.get(attachedFileHyperlink).should(assertionConstants.beVisibleAssertion)
    }

    mandatoryDetailsAddition() {
        cy.xpath(knowledgeInformationTab).click()
        cy.PatternCreation()
        cy.readFile('cypress/fixtures/patternNameCreation.json').then(function (result) {
            let PatternName = result.name;
            cy.get(knowledgeNameType).type(PatternName);
        });
        cy.get(description).type('Testing')
        cy.get(symptomsSection).eq(1).click()
        cy.get(selectSymptomsButtonInAddSymptomSection).click()
        cy.get(showAllCheckbox).click()
        cy.get(resultSelection).eq(2).click()
        cy.get(selectButton).click()
    }

    causeVerification() {
        return cy.get(causeVerification).eq(0).should(assertionConstants.beVisibleAssertion)
    }

    thirdSymptomClick() {
        cy.get(Symptom).eq(1).click()
    }

    symtomsOrCausesOnCurrentPageSelected() {
        cy.get(causeList).last().find('tr').should(assertionConstants.haveAttributeAssertion, 'class', 'p-element p-selectable-row ng-star-inserted row-hightlight-with-border p-highlight')
    }

    selectedSymptomOrCauseWithEditOptionVisible() {
        cy.get(selectedSymptomWithEditOption).eq(2).find('[dlstooltip="Edit"]').and(assertionConstants.beVisibleAssertion)
    }

    scrollElement() {
        cy.get(newScrollElement).scrollIntoView()
    }

    MyknowledgeArrowClick() {
        cy.get(MyknowledgeArrow).eq(4).click()
    }

    richTextEditorWindowVisible() {
        return cy.get(richTextEditorWindow).should(assertionConstants.beVisibleAssertion)
    }

    fullScreenViewButttonOfRichTextEditorClick() {
        cy.get(fullScreenViewButttonOfRichTextEditor).click({ force: true })
    }

    richTextEditorTillBredcrumb() {
        cy.get(richTextEditorInFullScreen).should(assertionConstants.haveClassAssertion, "enable-fullscreen")
    }

    leftPaneCollapse() {
        cy.get(leftPaneCollapse).find('div').first().should(assertionConstants.haveClassAssertion, 'dashboard_left active')
    }

    fullScreenViewButtonAfterExpandingClick() {
        cy.get(fullScreenViewButtonAfterExpanding).click({ force: true })
    }

    leftPaneExpanded() {
        cy.get(leftPaneCollapse).find('div').first().should(assertionConstants.haveClassAssertion, 'dashboard_left')
    }

    fullScreenViewButtonAtCauseLevelClick() {
        cy.get(fullScreenViewButtonAtCauseLevel).click()
    }

    causeAndSolutionTextVisible() {
        cy.contains(causeAndSolutionText).should(assertionConstants.beVisibleAssertion)
    }

    richTextEditorUnderCauseSectionInFullScreenVisible() {
        cy.get(richTextEditorUnderCauseSectionInFullScreen).should(assertionConstants.beVisibleAssertion)
    }

    fullScreenViewButtonAtCauseAndSolutionLavelAterExpandingClick() {
        cy.get(fullScreenViewButtonAtCauseAndSolutionLavelAterExpanding).click({ force: true })
    }

    fontFamilyDropDownVisible() {
        return cy.get(fontFamilyDropDown).should(assertionConstants.beVisibleAssertion)
    }

    paragraphFormatDropDownVisible() {
        return cy.get(paragraphFormatDropDown).should(assertionConstants.beVisibleAssertion)
    }

    boldVisible() {
        return cy.get(bold).should(assertionConstants.beVisibleAssertion)
    }

    italicVisible() {
        return cy.get(italic).should(assertionConstants.beVisibleAssertion)
    }

    underlineVisible() {
        return cy.get(underline).should(assertionConstants.beVisibleAssertion)
    }

    moreTextVisible() {
        return cy.get(moreText).should(assertionConstants.beVisibleAssertion)
    }

    alignLeftVisible() {
        return cy.get(alignLeft).should(assertionConstants.beVisibleAssertion)
    }

    alignCenterVisible() {
        return cy.get(alignCenter).should(assertionConstants.beVisibleAssertion)
    }

    alignJustifyVisible() {
        return cy.get(alignJustify).should(assertionConstants.beVisibleAssertion)
    }

    alignRightVisible() {
        return cy.get(alignRight).should(assertionConstants.beVisibleAssertion)
    }

    moreParagraphVisible() {
        return cy.get(moreParagraph).should(assertionConstants.beVisibleAssertion)
    }

    insertLinkVisible() {
        return cy.get(insertLink).should(assertionConstants.beVisibleAssertion)
    }

    insertImageVisible() {
        return cy.get(insertImage).should(assertionConstants.beVisibleAssertion)
    }

    insertFileVisible() {
        return cy.get(insertFile).should(assertionConstants.beVisibleAssertion)
    }

    insertTableVisible() {
        return cy.get(insertTable).should(assertionConstants.beVisibleAssertion)
    }

    insertHorizontalLineVisible() {
        return cy.get(insertHorizontalLine).should(assertionConstants.beVisibleAssertion)
    }

    moreMiscVisible() {
        return cy.get(moreMisc).should(assertionConstants.beVisibleAssertion)
    }

    moreMiscClick() {
        return cy.get(moreMisc).click()
    }

    undoVisible() {
        return cy.get(undo).should(assertionConstants.beVisibleAssertion)
    }

    redoVisible() {
        return cy.get(redo).should(assertionConstants.beVisibleAssertion)
    }

    tickVisible() {
        return cy.get(tick).should(assertionConstants.beVisibleAssertion)
    }

    closeVisible() {
        return cy.get(close).should(assertionConstants.beVisibleAssertion)
    }

    moreMiscUnderSolution1Visible() {
        return cy.get(moreMisc).last().should(assertionConstants.beVisibleAssertion)
    }

    moreMiscUnderSolution1Click() {
        return cy.get(moreMisc).last().click()
    }

    undoUnderSolution1Visible() {
        return cy.get(undo).last().should(assertionConstants.beVisibleAssertion)
    }

    redoUnderSolution1Visible() {
        return cy.get(redo).last().should(assertionConstants.beVisibleAssertion)
    }

    closeUnderSolution1Visible() {
        return cy.get(close).last().should(assertionConstants.beVisibleAssertion)
    }

    priorityDropDownVisible() {
        return cy.get(cause3Solution1PriorityDropdown).should(assertionConstants.beVisibleAssertion)
    }

    fontFamilyDropDownClick() {
        return cy.get(fontFamilyDropDown).first().click()
    }

    arialVisible() {
        return cy.contains(arial).should(assertionConstants.beVisibleAssertion)
    }

    GeorgiaVisible() {
        return cy.contains(Georgia).should(assertionConstants.beVisibleAssertion)
    }

    impactVisible() {
        return cy.contains(impact).should(assertionConstants.beVisibleAssertion)
    }

    tahomaVisible() {
        return cy.contains(tahoma).should(assertionConstants.beVisibleAssertion)
    }

    timesNewRomanVisible() {
        return cy.contains(timesNewRoman).should(assertionConstants.beVisibleAssertion)
    }

    VerdanaVisible() {
        return cy.contains(Verdana).should(assertionConstants.beVisibleAssertion)
    }

    paragraphFormatClick() {
        return cy.get(paragraphFormat).click()
    }

    heading1Visible() {
        return cy.contains(heading1).should(assertionConstants.beVisibleAssertion)
    }

    heading2Visible() {
        return cy.contains(heading2).should(assertionConstants.beVisibleAssertion)
    }

    heading3Visible() {
        return cy.contains(heading3).should(assertionConstants.beVisibleAssertion)
    }

    heading4Visible() {
        return cy.contains(heading4).should(assertionConstants.beVisibleAssertion)
    }

    codeVisible() {
        return cy.get(code).should(assertionConstants.beVisibleAssertion)
    }

    moreTextClick() {
        return cy.get(moreText).click()
    }

    StrikethroughVisible() {
        return cy.get(Strikethrough).should(assertionConstants.beVisibleAssertion)
    }

    subScriptVisible() {
        return cy.get(subScript).should(assertionConstants.beVisibleAssertion)
    }

    superScriptVisible() {
        return cy.get(superScript).should(assertionConstants.beVisibleAssertion)
    }

    fontSizeVisible() {
        return cy.get(fontSize).should(assertionConstants.beVisibleAssertion)
    }

    textColorVisible() {
        return cy.get(textColor).should(assertionConstants.beVisibleAssertion)
    }

    fontSizeDropDown() {
        return cy.get(fontSizeDropDown).eq(2).find('li').find('a').each((el, ind, arr) => {
            if ((ind === 0)) {
                cy.wrap(el).should(assertionConstants.haveTextAssertion, '8')
            }
            if ((ind === (arr.length - 1))) {
                cy.wrap(el).should(assertionConstants.haveTextAssertion, '96')
            }
        })
    }

    backgroundColorVisible() {
        return cy.get(backgroundColor).should(assertionConstants.beVisibleAssertion)
    }

    inlineClassVisible() {
        return cy.get(inlineClass).should(assertionConstants.beVisibleAssertion)
    }

    inlineClassClick() {
        return cy.get(inlineClass).first().click({ force: true })
    }

    inlilneClasscodeVisible() {
        return cy.get(inlilneClasscode);
    }

    HighlightedVisible() {
        return cy.get(Highlighted).should(assertionConstants.beVisibleAssertion)
    }

    TransparentVisible() {
        return cy.get(Transparent).should(assertionConstants.beVisibleAssertion)
    }

    inlineStyleVisible() {
        return cy.get(inlineStyle).should(assertionConstants.beVisibleAssertion)
    }

    inlineStyleClick() {
        return cy.get(inlineStyle).first().click()
    }

    bigRedVisible() {
        return cy.get(bigRed).should(assertionConstants.beVisibleAssertion)
    }

    smallBlueVisible() {
        return cy.get(smallBlue).should(assertionConstants.beVisibleAssertion)
    }

    clearFormattingVisible() {
        return cy.get(clearFormatting).should(assertionConstants.beVisibleAssertion)
    }

    moreParagraphClick() {
        return cy.get(moreParagraph).click()
    }

    oplListWithDropDownVisible() {
        return cy.get(oplListWithDropDown).first().should(assertionConstants.beVisibleAssertion)
    }

    oplListWithDropDownButtonClick() {
        return cy.get(oplListWithDropDownButton).click()
    }

    ulListWithDropDownVisible() {
        return cy.get(ulListWithDropDown).should(assertionConstants.beVisibleAssertion)
    }

    paragraphStyleVisible() {
        return cy.get(paragraphStyle).should(assertionConstants.beVisibleAssertion)
    }

    lineHeightVisible() {
        return cy.get(lineHeight).should(assertionConstants.beVisibleAssertion)
    }

    lineHeightClick() {
        return cy.get(lineHeight).first().click()
    }

    lineHeightValueDefaultVisible() {
        return cy.get(lineHeightValueDefault).should(assertionConstants.beVisibleAssertion)
    }

    lineHeightValueSingleVisible() {
        return cy.get(lineHeightValueSingle).should(assertionConstants.beVisibleAssertion)
    }

    lineHeightValue3rdVisible() {
        return cy.get(lineHeightValue3rd).should(assertionConstants.beVisibleAssertion)
    }

    lineHeightValue4thVisible() {
        return cy.get(lineHeightValue4th).should(assertionConstants.beVisibleAssertion)
    }

    lineHeightValueDoubleVisible() {
        return cy.get(lineHeightValueDouble).should(assertionConstants.beVisibleAssertion)
    }

    decreaseIndentVisible() {
        return cy.get(decreaseIndent).eq(0).should(assertionConstants.haveAttributeAssertion, 'aria-disabled', 'true').and(assertionConstants.beVisibleAssertion)
    }

    increaseIndentVisible() {
        return cy.get(increseIndent).should(assertionConstants.beVisibleAssertion)
    }

    quoteVisible() {
        return cy.get(quote).should(assertionConstants.beVisibleAssertion)
    }

    quoteClick() {
        return cy.get(quote).first().click()
    }

    increaseOptionUnderQuotes() {
        return cy.get(increaseOptionUnderQuotes).should(assertionConstants.beVisibleAssertion).and(assertionConstants.containAssertion, 'Increase').and(assertionConstants.containAssertion, "Ctrl+'")
    }

    decreaseOptionUnderQuotes() {
        return cy.get(decreaseOptionUnderQuotes).should(assertionConstants.beVisibleAssertion).and(assertionConstants.containAssertion, 'Decrease',).and(assertionConstants.containAssertion, "Ctrl+Shift+'")
    }

    defaultOptionVisible() {
        return cy.get(defaultOption).should(assertionConstants.beVisibleAssertion)
    }

    lowerAlphaVisible() {
        return cy.get(lowerAlpha).should(assertionConstants.beVisibleAssertion)
    }

    lowerGreekVisible() {
        return cy.get(lowerGreek).should(assertionConstants.beVisibleAssertion)
    }

    lowerRomanVisible() { 
        return cy.get(lowerRoman).should(assertionConstants.beVisibleAssertion)
    }

    upperAlphaVisible() {
        return cy.get(upperAlpha).should(assertionConstants.beVisibleAssertion)
    }

    upperRomanVisible() {
        return cy.get(upperRoman).should(assertionConstants.beVisibleAssertion)
    }

    unorderListDropDownButtonClick() {
        return cy.get(unorderListDropDownButton).click()
    }

    unorderListDefaultOptionVisible() {
        return cy.contains(unorderListDefaultOption).should(assertionConstants.beVisibleAssertion)
    }

    unorderListCircleOptionVisible() {
        return cy.contains(unorderListCircleOption).should(assertionConstants.beVisibleAssertion)
    }

    unorderListDiscOptionVisible() {
        return cy.contains(unorderListDiscOption).should(assertionConstants.beVisibleAssertion)
    }

    unorderListSquareOptionVisible() {
        return cy.contains(unorderListSquareOption).should(assertionConstants.beVisibleAssertion)
    }

    photoGraphStyleVisible() {
        return cy.get(photoGraphStyle).first().should(assertionConstants.beVisibleAssertion)
    }

    photoGraphStyleClick() {
        return cy.get(photoGraphStyle).first().click()
    }

    grayVisible() {
        return cy.get(gray).should(assertionConstants.beVisibleAssertion)
    }

    borderedVisible() {
        return cy.get(bordered).should(assertionConstants.beVisibleAssertion)
    }

    SpacedVisible() {
        return cy.get(Spaced).should(assertionConstants.beVisibleAssertion)
    }

    upperCaseVisible() {
        return cy.get(upperCase).should(assertionConstants.beVisibleAssertion)
    }

    causesAndSolutionsVisible() {
        return cy.contains(causeAndSolutionText).should(assertionConstants.beVisibleAssertion)
    }

    attributeClickForClaus() {
        cy.get(attributeForCause).eq(0).click()
        cy.get(dropdownValuesVerification).eq(2).click()
    }

    causeNameColumnType() {
        return cy.get(causeNameColumnType).type(keywordType)
    }

    solutionOneInputBoxCleartext(){
        cy.get(inputBox).last().clear()
    }



    contentMissedMessageVisible(){
        cy.contains(contentMissedMessage).should(assertionConstants.beVisibleAssertion)
    }
    
    toasterMessageVisible(){
        cy.contains(toasterMessage).should(assertionConstants.beVisibleAssertion)
    }
    
    contentMissedMessageNotExist(){
        cy.contains(contentMissedMessage).should(assertionConstants.notExistsAssertion)
    }
    
    tagIconUnderSolutionClick(){
        cy.get(tagIconUnderSolution).last().click()
    }
    
    solutionOneInputBoxAddSpace(){
        cy.get(inputBox).last().type(' ')
    }
    
    solutionOneInputBoxPressEnter(){
        cy.get(inputBox).last().type('{enter}')
    }
    
    insertImageOptionClick(){
        cy.get(insertImageOption).last().click()
    }
    
    browseImageOptionClickAndUploadImage(){
        cy.get(browseImageOption).click({force:true}).attachFile('image.png') 
    }
    
    priorityDropdownForCauseTwoSolutionTwoClick(){
        cy.get(priorityDropdownOptions).eq(1).click()
    }
    
    priorityOneOptionClick(){
        cy.get(PriorityOneOption).last().click()
    }
    
    PriorityDropdownsHighlighted(){
        cy.get(priorityDropdownOptions).should(assertionConstants.haveCssAssertion, 'border-color', 'rgb(230, 88, 0)')
    }
    
    priorityDropdownForCauseTwoSolutionOneClick(){
        cy.get(priorityDropdownOptions).first().click()
    }
    
    selectOptionUnderPriorityDropdownForSolutionOneClick(){
        cy.get(selectOptionUnderPriorityDropdown).first().click()
    }
    
    selectOptionUnderPriorityDropdownForSolutionTwoClick(){
        cy.get(selectOptionUnderPriorityDropdown).eq(1).click()
    }
    
    priorityTwoOptionUnderCauseTwoSolutionTWoClick(){
       cy.get(priorityTwoOption).first().click()
    }

    getKnowledgeName() {
        cy.get(patternDashboardBreadCrum).find(ptLayoutContainerClass).find('ul').children('li').last().find('a').find('span').invoke('text').then((Name) => {
          knowledgeNames.push(Name.trim())
          cy.wait(3000)
          cy.log(knowledgeNames)
        })
      }

  
    workflowAndKnowledgeNameTextVerification(){
        cy.get(lastKnowledgeName).invoke('text').then((knowledgeName)=>{
        expect(knowledgeName.trim()).to.eql(patternNames[0])
        })
    }

    commonFilterClickAndTypePublishedKnowledge() {
        cy.get(filterForKeyword).type(patternNames[0])
    }

    tagsButtonAtCauselevelClick(){
    cy.get(tagsButton).eq(1).click()
    }

    selectTagsDropDownClick(){
        cy.get(selectTagsDropdown).click()
    }

    DAPCollimeterTagsOptionsClick() {
        cy.get(tagsOptions).eq(1).click()
    }
 
    detectorTagsOptionsClick() {
        cy.get(tagsOptions).eq(2).click()
    }
 
    uniqueTagsInIncludeKnowledgeSection(){
        cy.contains(DAPCollimeterTag).should(assertionConstants.havelengthAssertion,'1')
        cy.contains(DicomRisPacsTag ).should(assertionConstants.havelengthAssertion,'1')

    }

    symptomOneTextBoxForRichTextEditorType() {
        cy.get(inputBox).first().type(knowledgeSymptomDetails)
    }







    insertTableOptionClick(){
        cy.get(insertTableOption).click({force:true})
      }
    
      matrixClick(){
        cy.get(matrixSelection).eq(0).click({force:true})
      }
    
      addedTableVisible(){
        cy.get(tableAsSelectedMatrix).should(assertionConstants.beVisibleAssertion)
      }
    
      firstCellClick(){
        cy.get(firstCell).eq(0).click({force:true})
      }
    
      tableHeaderOptionVisible(){
        cy.get(tableHeaderOption).should(assertionConstants.beVisibleAssertion)
      }
    
      tableHeaderOptionClick(){
        cy.get(tableHeaderOption).click({force:true})
      }
    
      removeTableOptionVisible(){
        cy.get(removeTableOption).should(assertionConstants.beVisibleAssertion)
      }
    
      removeTableOptionClick(){
        cy.get(removeTableOption).click({force:true})
      }
    
    
      rowOptionVisible(){
        cy.get(rowOption).should(assertionConstants.beVisibleAssertion)
      }
    
      rowOptionClick(){
        cy.get(rowOption).click()
      }
    
      insertRowAboveOptionVisible(){
        cy.contains(insertRowAboveOption).should(assertionConstants.beVisibleAssertion)
      }
    
      insertRowBelowOptionVisible(){
        cy.contains(insertRowBelow).should(assertionConstants.beVisibleAssertion)
      }
    
      deleteRowOptionVisible(){
        cy.contains(deleteRowOption).should(assertionConstants.beVisibleAssertion)
      }
    
      columnOptionVisible(){
        cy.get(columnOption).should(assertionConstants.beVisibleAssertion)
      }
    
      columnOptionClick(){
        cy.get(columnOption).click()
      }
    
      insertColumnBeforeOptionVisible(){
        cy.contains(insertColumnBeforeOption).should(assertionConstants.beVisibleAssertion)
      }
    
      insertColumnAfterOptionVisible(){
        cy.contains(insertColumnAfterOption).should(assertionConstants.beVisibleAssertion)
      }
    
      deleteColumnOptionVisible(){
        cy.contains(deleteColumnOption).should(assertionConstants.beVisibleAssertion)
      }
    
      tableStyleOptionVisible(){
        cy.get(tableStyleOption).should(assertionConstants.beVisibleAssertion)
      }
    
      tableStyleOptionClick(){
        cy.get(tableStyleOption).click()
      }
    
      dashedBordersOptionVisible(){
        cy.contains(dashedBordersOption).should(assertionConstants.beVisibleAssertion)
      }
    
      alternateRowsOptionVisible(){
        cy.contains(alternateRowsOption).should(assertionConstants.beVisibleAssertion)
      }
    
      tableCellOptionVisible(){
        cy.get(tableCellOption).should(assertionConstants.beVisibleAssertion)
      }
    
      tableCellOptionClick(){
        cy.get(tableCellOption).click()
      }
    
      mergeCellOptionVisible(){
        cy.contains(mergeCellOption).should(assertionConstants.beVisibleAssertion)
      }
    
      verticalSplitOptionVisible(){
        cy.contains(verticalSplitOption).should(assertionConstants.beVisibleAssertion)
      }
    
      horizontalSplitOptionVisible(){
        cy.contains(horizontalSplitOption).should(assertionConstants.beVisibleAssertion)
      }
    
      cellBackgroundOptionVisible(){
        cy.get(cellBackgroundOption).should(assertionConstants.beVisibleAssertion)
      }
    
      cellBackgroundOptionClick(){
        cy.get(cellBackgroundOption).click()
      }
    
      backButtonVisible(){
        cy.get(backButton).last().should(assertionConstants.beVisibleAssertion)
      }
    
      backButtonClick(){
        cy.get(backButton).last().click()
      }
    
      colorsVisible(){
        cy.get(colors).should(assertionConstants.beVisibleAssertion)
      }
    
      deleteButtonUnderCellBackGroundOptionVisible(){
        cy.get(deleteButtonUnderCellBackGroundOption).should(assertionConstants.beVisibleAssertion)
      }
    
      textBoxForHEXColorsVisible(){
        cy.get(textBoxForHEXColors).should(assertionConstants.beVisibleAssertion)
      }
    
      okButtonUnderCelBackgroundOptionVisible(){
        cy.get(okButtonUnderCelBackgroundOption).should(assertionConstants.beVisibleAssertion)
      }
    
      verticalAllignmentOptionVisible(){
        cy.get(verticalAllignmentOption).should(assertionConstants.beVisibleAssertion)
      }
    
      verticalAllignmentOptionClick(){
        cy.get(verticalAllignmentOption).click()
      }
    
      allignmentTopOptionVisible(){
        cy.contains(allignmentTopOption).should(assertionConstants.beVisibleAssertion)
      }
    
      allignmentMiddleOptionVisible(){
        cy.contains(allignmentMiddleOption).should(assertionConstants.beVisibleAssertion)
      }
    
      allignmentBottomOptionVisible(){
        cy.contains(allignmentBottomOption).should(assertionConstants.beVisibleAssertion)
      }
    
      horizontalAllignOptionVisible(){
        cy.get(horizontalAllignOption).should(assertionConstants.beVisibleAssertion)
      }
    
      horizontalAllignOptionClick(){
        cy.get(horizontalAllignOption).first().click()
      }
    
      allignLeftOptionVisible(){
        cy.get(allignLeftOption).should(assertionConstants.beVisibleAssertion)
      }
    
      allignCenterOptionVisible(){
        cy.get(allignCenterOption).should(assertionConstants.beVisibleAssertion)
      }
    
    
      allignRightOptionVisible(){
        cy.get(allignRightOption).should(assertionConstants.beVisibleAssertion)
      }
    
      allignJustifyOptionVisible(){
        cy.get(allignJustifyOption).should(assertionConstants.beVisibleAssertion)
      }
    
      cellStyleOptionVisible(){
        cy.get(cellStyleOption).should(assertionConstants.beVisibleAssertion)
      }
    
      cellStyleOptionClick(){
        cy.get(cellStyleOption).click()
      }
    
      highlightedOptionVisible(){
        cy.get(highlightedOption).should(assertionConstants.beVisibleAssertion)
      }
    
      thickOptionVisible(){
        cy.contains(thickOption).should(assertionConstants.beVisibleAssertion)
      }
    
      addedTableHeaderVisible(){
        cy.get(tableAsSelectedMatrix).find('thead').should(assertionConstants.beVisibleAssertion)
      }
    
      addedTableHeaderRemoved(){
        cy.get(tableAsSelectedMatrix).find('thead').should(assertionConstants.notExistsAssertion)
      }
    
      firstCellNotExist(){
        cy.get(tableAsSelectedMatrix).should(assertionConstants.notExistsAssertion)
      }
    
      insertRowAboveOptionClick(){
        cy.contains(insertRowAboveOption).click()
      }
    
      addedTableRowAbove(){
        cy.get(tableAsSelectedMatrix).find('tr').should(assertionConstants.havelengthAssertion,2)
      }
    
      insertRowBelowOptionClick(){
      cy.contains(insertRowBelow).click()
      }
    
      addedTableRowBelow(){
        cy.get(tableAsSelectedMatrix).find('tr').should(assertionConstants.havelengthAssertion,3)
      }
    
    
      deleteRowOptionClick(){
        cy.contains(deleteRowOption).click()
      }
    
      tableWithTwoRows(){
        cy.get(tableAsSelectedMatrix).find('tr').should(assertionConstants.havelengthAssertion,2)
      }
    
      insertColumnBeforeOptionClick(){
        cy.contains(insertColumnBeforeOption).click()
      }
    
    
      tableWithThreeColumns(){
        cy.get(tableAsSelectedMatrix).find('tr').first().find('td').should(assertionConstants.havelengthAssertion,3)
      }
    
      insertColumnAfterOptionClick(){
        cy.contains(insertColumnAfterOption).click()
      }
    
      tableWithFourColumns(){
        cy.get(tableAsSelectedMatrix).find('tr').first().find('td').should(assertionConstants.havelengthAssertion,4)
      }
    
      deleteColumnOptionClick(){
        cy.contains(deleteColumnOption).click()
      }
    
      tableCellAfterAddingColumnClick(){
        cy.get(tableAsSelectedMatrix).find('tr').first().find('td').first().click({force: true})
      }
    
      dashedBordersOptionClick(){
        cy.contains(dashedBordersOption).click()
      }
    
      tablewithDashedBordrs(){
        cy.get(tablewithDashedBordrs).should(assertionConstants.haveAttributeAssertion,'class','fr-dashed-borders')
      }
    
      alternateRowsOptionClick(){
        cy.contains(alternateRowsOption).click()
      }
    
      tablewithRowsWithGreyColor(){
        cy.get(tablewithDashedBordrs).should(assertionConstants.haveAttributeAssertion,'class','fr-dashed-borders fr-alternate-rows')
      }
    
    
      verticalSplitOptionClick(){
        cy.contains(verticalSplitOption).click()
      }
    
      tableCellAfterVerticalSplit(){
        cy.get(tableAsSelectedMatrix).find('tr').first().find('td').should(assertionConstants.havelengthAssertion,4)
        cy.get(tableAsSelectedMatrix).find('tr').first().find('td').first().should(assertionConstants.haveAttributeAssertion,'style','width: 16.6667%;')
      }
    
    
      horizontalSplitOptionSplit(){
        cy.contains(horizontalSplitOption).click()
      }
    
      tableCellAfterHorizontalSplit(){
        cy.get(tablewithDashedBordrs).find('tr').should(assertionConstants.havelengthAssertion,'3')
      }
    
      cellBackgroundOptionClick(){
        cy.get(cellBackgroundOption).click()
      }
    
    
      colorPopUpNotExist(){
        cy.get(colorPopUp).should(assertionConstants.notExistsAssertion)
      }
    
      userColorClick(){
        cy.get(userSelectedColor).click()
      }
    
      tabelCellAfterColorSelection(){
        cy.get(tableAsSelectedMatrix).find('tr').first().find('td').first().should(assertionConstants.haveAttributeAssertion,'style','width: 16.6667%; background-color: rgb(184, 49, 47);')
      }
    
      HEXcolorInputBoxType(){
        cy.get(HEXcolorInputBox).clear().type(userTypedColorText)
      }
    
      okButtonUnderCelBackgroundOptionClick(){
        cy.get(okButtonUnderCelBackgroundOption).click()
      }
    
      tableCellAfterHEXColorSelection(){
        cy.get(tableAsSelectedMatrix).find('tr').first().find('td').first().should(assertionConstants.haveAttributeAssertion,'style','width: 16.6667%; background-color: rgb(247, 218, 100);')
        
      }
    
      deleteButtonUnderCellBackGroundOptionClick(){
        cy.get(deleteButtonUnderCellBackGroundOption).click()
      }
    
      tableCellWithRemovedColor(){
        cy.get(tableAsSelectedMatrix).find('tr').first().find('td').first().should(assertionConstants.haveNotAttributeAssertion,'style','width: 16.6667%; background-color: rgb(247, 218, 100);')
      }
    
      allignmentTopOptionClick(){
        cy.contains(allignmentTopOption).click()
      }
    
      dataAllignedTop(){
        cy.get(tableAsSelectedMatrix).find('tr').first().find('td').first().should(assertionConstants.haveNotAttributeAssertion,'style','width: 33.2779%; vertical-align: top;')
      }
    
      allignmentMiddleOptionClick(){
        cy.contains(allignmentMiddleOption).click()
      }
    
    
      dataAllignedMiddle(){
        cy.get(tableAsSelectedMatrix).find('tr').first().find('td').first().should(assertionConstants.haveAttributeAssertion,'style','width: 16.6889%; vertical-align: middle;')
      }
    
      allignmentBottomOptionClick(){
        cy.contains(allignmentBottomOption).click()
      }
    
      dataAllignedBottom(){
        cy.get(tableAsSelectedMatrix).find('tr').first().find('td').first().should(assertionConstants.haveAttributeAssertion,'style','width: 16.6889%; vertical-align: bottom;')
      }
    
      allignCenterOptionClick(){
        cy.get(allignCenterOption).click()
      }
    
      firstCellWithAlignCenter(){
        cy.get(tableAsSelectedMatrix).find('tr').first().find('td').first().should(assertionConstants.haveAttributeAssertion,'style','width: 16.6889%; vertical-align: bottom; text-align: center;')
      }
    
    
      allignRightOptionClick(){
        cy.get(allignRightOption).click()
      }
    
      firstCellWithAlignRight(){
        cy.get(tableAsSelectedMatrix).find('tr').first().find('td').first().should(assertionConstants.haveAttributeAssertion,'style','width: 16.6889%; vertical-align: bottom; text-align: right;')
      }
    
      allignJustifyOptionClick(){
        cy.get(allignJustifyOption).click()
      }
    
      firstCellWithAlignJustify(){
        cy.get(tableAsSelectedMatrix).find('tr').first().find('td').first().should(assertionConstants.haveAttributeAssertion,'style','width: 16.6889%; vertical-align: bottom; text-align: justify;')
      }
    
      highlightedOptionClick(){
        cy.get(highlightedOption).click()
      }
    
      firstCellWithHighlightedRedBorder(){
        cy.get(tableAsSelectedMatrix).find('tr').first().find('td').first().should(assertionConstants.haveAttributeAssertion,'class','fr-highlighted fr-selected-cell')
      }
    
      thickOptionClick(){
        cy.contains(thickOption).click()
      }
    
      firstCellbordered(){
        cy.get(tableAsSelectedMatrix).find('tr').first().find('td').first().should(assertionConstants.haveAttributeAssertion,'class','fr-highlighted  fr-thick fr-selected-cell')
      }
    
      firstCellUndobordered(){
        cy.get(tableAsSelectedMatrix).find('tr').first().find('td').first().should(assertionConstants.haveNotAttributeAssertion,'class','fr-highlighted  fr-thick fr-selected-cell')
      }
    
      firstCellWitUndoHighlightedRedBorder(){
        cy.get(tableAsSelectedMatrix).find('tr').first().find('td').first().should(assertionConstants.haveNotAttributeAssertion,'class','fr-highlighted fr-selected-cell')
      }
    
      fullScreenIconAtCauseAndSolutionLevelClick(){
        cy.get(fullScreenIconAtCauseAndSolutionLevel).click()
      }
    
      selectingTwoCell(){
        cy.xpath(CellOneInColumnOne).click({force: true})
        cy.get(CellTwoInColumnOne).type('{shift}{downarrow}')
      }
    
      mergeCellOptionEnabled(){
        cy.contains(mergeCellOption).should(assertionConstants.notBeDisabledAssertion)
      }
    
      mergeCellOptionClick(){
        cy.contains(mergeCellOption).click()
      }
    
      tableCellsAfterMerge(){
        cy.get(tableCellsAfterMerge).should(assertionConstants.havelengthAssertion,'2')
      }
    
      tableCellAftetHorizontalSplit(){
        cy.get(tableCellAftetHorizontalSplit).should(assertionConstants.havelengthAssertion,'4')
      }
    
      addingDataInCell(){
      cy.get(CellTwoInColumnOne).type('daw',{ force: true })
      }
    
      allignLeftOptionSelected(){
        cy.get(allignLeftOption).should(assertionConstants.haveAttributeAssertion,'aria-selected','true')
      }
     
      knowledgeInformationOptionClick() {
        return cy.get(addConditionOption).eq(0).click({ force: true })
      }
      
      causeCollpaseIconAtCauseAndSolutionLevelClick(){
        cy.get(causeCollpaseIconAtCauseAndSolutionLevel).click({force: true})
      }
    
      causeAndSolutionOptionClick() {
        cy.contains(causeAndSolutionText).click()
      }
    
      tableWithAppliedFunctionalityVisible(){
        cy.get(tableAsSelectedMatrix).find('tr').first().find('td').first().should(assertionConstants.haveAttributeAssertion,'class','fr-highlighted fr-thick')
        cy.get(tableAsSelectedMatrix).find('tr').first().find('td').first().should(assertionConstants.haveTextAssertion,'daw')
      }
    
    
      tableCellAfterVerticalSplitInFullScreen(){
        cy.get(tableAsSelectedMatrix).find('tr').first().find('td').should(assertionConstants.havelengthAssertion,4)
        cy.get(tableAsSelectedMatrix).find('tr').first().find('td').first().should(assertionConstants.haveAttributeAssertion,'style','width: 16.6573%;')
    
      }
    
      tabelCellAfterColorSelectionInFullScreen(){
        cy.get(tableAsSelectedMatrix).find('tr').first().find('td').first().should(assertionConstants.haveAttributeAssertion,'style','width: 16.6573%; background-color: rgb(184, 49, 47);')
      }
    
      tableCellAfterHEXColorSelectionInFullScreen(){
        cy.get(tableAsSelectedMatrix).find('tr').first().find('td').first().should(assertionConstants.haveAttributeAssertion,'style','width: 16.6573%; background-color: rgb(247, 218, 100);')
        
      }

      getPatternName(){
        cy.get(patternDashboardBreadCrum).find('[class="pt-layout-container"]').find('ul').children('li').last().find('a').find('span').invoke('text').then((Name)=>{
          patternNames.push(Name)
          cy.wait(3000) 
          cy.log(patternNames)
        })
        cy.log(patternNames)
      }

      knowledgeNameSearchValueType() {
        cy.get(knowledgeNameSearchFilter).click().type(patternNames[0])
      }

      knowledgeNameSearchValueTypeAfterEditing(){
        cy.get(knowledgeNameSearchFilter).click().type(patternNames[1])
      }

      modalityDropdownInApplyMetadata() {
        cy.get(modalityDropdownInApplyMetadata).click()
      }

      dcpModalityOptionClick() {
        cy.get(ctModalityOption).eq(1).click({ force: true })
      }
    
    knowledgeNameInputBoxTypeForSecondKnowledge() {
        cy.get(patternNameTextBox).type(nameOfSecondKnowledge)
    }
    
    firstKnowledgeSearch(){
        cy.get(knowledgeSearchOption).first().type(patternNames)
    }

    secondKnowledgeSearch(){
        return cy.get(knowledgeNameSearchFilter).then((secondknowledgeName)=>{
            cy.wrap(secondknowledgeName).type(patternNames[1])
        })
    }

    knowledgeTableWithOutDraftKnowledge(){
        cy.get(knowledgeTable).should(assertionConstants.notContainAssertion,patternNames[1,0])
    }


    knowledgeSearchOptionKnowledgeAsscociationType(){
    cy.get(knowledgeSearchOption).first().then((KnowledgeNameSearchOption)=>{
        cy.wrap(KnowledgeNameSearchOption).type(patternNames[3])
       })
    }

   knowledgeNameInputBoxTypeForNormalKnowledge() {
    cy.get(patternNameTextBox).type(userID_Alpha_Numeric())
    }

    secondKnowledgeSearchInIncludeKnowledgePopUp(){
        return cy.get(searchOptionInPopUp).then((secondknowledgeName)=>{
            cy.wrap(secondknowledgeName).type(patternNames[0])
        })
    }

    secondKnowledgeSearchInIncludeKnowledgeInMyPatternPopUp(){
        return cy.get(searchOptionInPopUp).then((secondknowledgeName)=>{
            cy.wrap(secondknowledgeName).type(patternNames[2])
        })
    }


    searchIconToSearchKnowledgeNameClick(){
    cy.get(searchButton).first().click()
    }

    searchedKnowledgeCheckBoxClick(){
    cy.get(searchedKnowledgeCheckBox).last().click({force: true})
    }

    selectKnowledgeOptionClick(){
    cy.get(selectKnowledgeOption).click()
    }

    knowledgeNameSearch() {
        return cy.get(knowledgeNameSearchFilter).then((knowledgeName)=>{
            cy.wrap(knowledgeName).type(patternNames[0])
        })
    }

    knowledgeNameInMyPatternSearch() {
        return cy.get(knowledgeNameSearchFilter).then((knowledgeName)=>{
            cy.wrap(knowledgeName).type(patternNames[2])
        })
    }


    publishedKnowledgeVisible(){
        cy.get(knowledgeListTable).then((list)=>{
          expect(list).to.contain(patternNames[1])
        })
    }

    patternNameTypeInPatternInformationSection() {
    let x = 'Authoring_WF_Test' + Math.floor((Math.random() * 1000) + 1);
    cy.writeFile(filePath, { name: x })
    cy.wait(2000)
    cy.readFile(filePath).then(function (result) {
      let PatternNames = result.name;
      cy.get(patternName).type(PatternNames);
    });
      
    }

    knowledgeSearchType(){
        return cy.get(knowledgeNameSearchFilter).then((secondknowledgeName)=>{
            cy.wrap(secondknowledgeName).type(patternNames[4])
        })
    }

    knowledgeSearchFourthKnowledgeType(){
        return cy.get(knowledgeNameSearchFilter).then((secondknowledgeName)=>{
            cy.wrap(secondknowledgeName).type(patternNames[5])
        })
    }

    knowledgeNameSearchInMyKnowledge() {
        return cy.get(knowledgeNameSearchFilter).then((knowledgeName)=>{
            cy.wrap(knowledgeName).type(patternNames[6])
        })
    }

    secondKnowledgeInMyKnowledgeSearch(){
        return cy.get(knowledgeNameSearchFilter).then((secondknowledgeName)=>{
            cy.wrap(secondknowledgeName).type(patternNames[7])
        })
    }


    publishedKnowledgeInMyKnowldgeVisible(){
        cy.get(knowledgeListTable).then((list)=>{
          expect(list).to.contain(patternNames[7])
        })
    }

    publishedKnowledgeNotExist(){
        cy.get(knowledgeListTable).then((list)=>{
          expect(list).to.not.contain(patternNames[1])
        })
    }


    publishedKnowledgeNotExistAfterDeletingFromThreeDots(){
        cy.get(knowledgeListTable).then((list)=>{
          expect(list).to.not.contain(patternNames[4])
        })
    }

    publishedKnowledgeNotExistAfterDeletingName(){
        cy.get(knowledgeListTable).then((list)=>{
          expect(list).to.not.contain(patternNames[5])
        })
    }

    publishedKnowledgeInMyKnowldgeNotExist(){
        cy.get(knowledgeListTable).then((list)=>{
          expect(list).to.not.contain(patternNames[7])
        })
    }

    knowledgeSearchInMyPatternType(){
        return cy.get(knowledgeNameSearchFilter).then((secondknowledgeName)=>{
            cy.wrap(secondknowledgeName).type(patternNames[10])
        })
    }

    publishedKnowledgeNotExistInMyPattern(){
        cy.get(knowledgeListTable).then((list)=>{
          expect(list).to.not.contain(patternNames[10])
        })
    }

    knowledgeSearchFourthKnowledgeInMyPatternType(){
        return cy.get(knowledgeNameSearchFilter).then((secondknowledgeName)=>{
            cy.wrap(secondknowledgeName).type(patternNames[11])
        })
    }

    publishedKnowledgeNotExistAfterDeletingNameInMyPattern(){
        cy.get(knowledgeListTable).then((list)=>{
          expect(list).to.not.contain(patternNames[11])
        })
    }



    tagButtonClick(){
    cy.get(tagsButton).eq(0).click()
    }

    tagsAddedUnderTagsSectionVerification(){
    cy.get(tagSection).last().find('li').children().should(assertionConstants.containAssertion,'DAP/Collimator').and(assertionConstants.haveClassAssertion,'pt-token-label')
    cy.get(tagSection).last().find('li').children().should(assertionConstants.containAssertion,'Detector').and(assertionConstants.haveClassAssertion,'pt-token-label')
    cy.get(tagSection).last().find('li').children().should(assertionConstants.containAssertion,'AWS').and(assertionConstants.haveClassAssertion,'pt-token-label')
    }

    tagsAsRemovableToken(){
    cy.get(tagSection).last().find('li').find('span').last().should(assertionConstants.haveClassAssertion,'pt-close-icon icon-dls-cross-circle close-icon ng-star-inserted')
    }

    hoverOnDAPTag(){
    cy.get(tagSection).last().find('li').eq(0).trigger('mouseover')

    }

    tagSectionWithUniqueTags(){
    cy.get(symptomTagIcon).should(assertionConstants.containAssertion,'DICOM/RIS/PACS').and(assertionConstants.havelengthAssertion,'1')
    }

    filterForKeywordTypeKnowledgeName() {
        cy.get(filterForKeyword).type(patternNames[0])
    }

    clearButtonClick(){
        cy.get(clearButton).click()
    }

    firstRecordCheckboxClick(){
        cy.xpath(firstRecordCheckbox).click()
    }

    nextButtonOnIncludeKnowledgePageClick(){
        cy.get(nextButtonOnIncludeKnowledgePage).click()
    }

   




}

export default CreateKnowledge;