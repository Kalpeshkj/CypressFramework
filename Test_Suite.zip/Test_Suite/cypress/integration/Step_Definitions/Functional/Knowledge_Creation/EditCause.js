/// <reference types="Cypress" /> 
/// <reference types = 'cypress-tags' />  

import "../../../../support/index"
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import CreateKnowledge from "../../../../support/pageObjects/pages/KnowledgeAuthoring/CreateKnowledge";
const createKnowledge = new CreateKnowledge();

When("User navigate to newly created knowledge workflow", () => {
    createKnowledge.knowledgeOptionArrowClick()
    createKnowledge.addKnowledgeWorkflowButtonClick()
    console.log(printTimestamp(), 'Navigated to newly created knowledge workflow')
});

And("Add details in Knowledge Information section", () => {
    cy.PatternCreation()
    cy.readFile('cypress/fixtures/patternNameCreation.json').then(function (result) {
        var PatternName = result.name;
        createKnowledge.patternName().type(PatternName);
    });
    createKnowledge.description().type(Cypress.env("PatternDescription"));
    console.log(printTimestamp(), 'Added details in Knowledge Information section')
});

When("User Expand Causes and Solution", () => {
    createKnowledge.causeAndSolutionOptionClick()
    console.log(printTimestamp(), 'Expands cause and solution')
});

And("click on Add cause", () => {
    createKnowledge.addCauseButtonClick()
    console.log(printTimestamp(), ' Add cause Clicked')
});

And("add content in rich text editor", () => {
    createKnowledge.causeOneInputBoxType()
    console.log(printTimestamp(), 'Added content in rich text editor')
});

And("User should be able to add solution with content and priority", () => {
    createKnowledge.addSolutionButtonClick()
    createKnowledge.Solution1TetxBoxOfCause1Type()
    createKnowledge.priorityForSolution1UnderCause1Visible()
    console.log(printTimestamp(), 'added solution with content and priority')
});

When("User Click on tick mark available at cause level", () => {
    createKnowledge.tickMarkAtCause1LevelClick()
    console.log(printTimestamp(), 'Clicked on tick mark')
});

Then("Cause and solution should be displayed in read only mode", () => {
    createKnowledge.causeAndSolutionWithOutRichTextEditor()
    console.log(printTimestamp(), 'cause and solution displayed in read only mode')
});

When("User Add other cause", () => {
    createKnowledge.addCauseButtonClick()
    createKnowledge.cause2TextBoxType()
    createKnowledge.addSolutionButtonClick()
    createKnowledge.cause2Solution1TextBoxType()
    createKnowledge.tickMarkAtCause1LevelClick()
    createKnowledge.addCauseButtonClick()
    console.log(printTimestamp(), 'Added other cause')
});

Then("Cause should get created Previously added cause including solution should be available in read only mode", () => {
    createKnowledge.cause2TextVisible()
    createKnowledge.causeAndSolutionWithOutRichTextEditor()

    console.log(printTimestamp(), 'cause added and previous cause and solution is in read only mode')
});

And("Priority for each solution should be displayed at right corner in rich text editor e.g Priority 1", () => {
    createKnowledge.priorityTextForSolution1UnderCause1Visible()
    createKnowledge.priorityTextForSolution1UnderCause2Visible()
    console.log(printTimestamp(), 'Priority for solutiion displayed in right corner')

});

And("Edit icon beside remove icon should be available in disabled state", () => {
    createKnowledge.editIconForCause1Disabled()
    createKnowledge.editIconForCause2Disabled()
    console.log(printTimestamp(), 'edit icon is available in disabled state')
});

And("User should be able to add solutions with content and priority", () => {
    createKnowledge.Cause3TextBoxType()
    createKnowledge.addSolutionButtonClick()
    createKnowledge.cause3Solution1TextBoxType()
    createKnowledge.tickMarkAtCause1LevelClick()
    console.log(printTimestamp(), 'user added solution content and priority')
});

And("Edit icon should be available in enabled state", () => {
    createKnowledge.editIconForCause1Enabled()
    createKnowledge.editIconForCause2Enabled()
    console.log(printTimestamp(), 'edit icon available in enabled state')
});

When("User Click on edit icon of previously added cause", () => {
    createKnowledge.editIconForCause2Click()
    console.log(printTimestamp(), 'Clicked on edit icon of previous cause')
});

Then("Rich text editor for cause and solution should be available in edit mode", () => {
    createKnowledge.cause2InEditMode()
    console.log(printTimestamp(), ' Rich text editor available in edit mode')
});

And("Other added cause including solution should be available in read mode Note : At a time only one cause can be editable", () => {
    createKnowledge.cause1InReadModeVisible()
    createKnowledge.cause3InReadModeVisible()
    console.log(printTimestamp(), 'other causes available in read mode')
});

And("User should be able to update add content in rich text editor of cause and solution", () => {
    createKnowledge.cause2TextBoxUpdateType()
    createKnowledge.cause2Solution1TextBoxUpdatedType()
    createKnowledge.tickMarkAtCause1LevelClick()
    console.log(printTimestamp(), 'User update and add content in rich etxt editor of cause and solution')
});

And("User should be able to update value of priority for solution", () => {
    createKnowledge.cause3EditIconClick()
    createKnowledge.addSolutionButtonClick()
    createKnowledge.cause3Solution2TextBoxType()
    createKnowledge.cause3Solution2PriorityDropdownClick()
    createKnowledge.priority2OptionClick()
    createKnowledge.cause3Solution1PriorityDropdownClick()
    createKnowledge.priority1OptionClick()
    console.log(printTimestamp(), 'User update the value of priority for solution')

});

When("User Click on Save as draft", () => {
    createKnowledge.saveAsDraftClick()
    cy.wait(2000)
    console.log(printTimestamp(), 'Clicked on save as draft')
});

Then("All added data should get saved for knowledge workflow", () => {
    createKnowledge.messageVisible()
    console.log(printTimestamp(), 'Added data gets saved in knowledge workflow')
});

When("User Relaunch application", () => {
    cy.reload()
    console.log(printTimestamp(), 'Application relaunched')
});

And("navigate back to knowledge workflow from other workflow", () => {
    createKnowledge.existingWorkflow()
    createKnowledge.newlyCreatedWokFlow()
    cy.wait(2000)
    console.log(printTimestamp(), 'navigated to knowledge workflow from other workflow')
});

Then("All updated details should be displayed in knowledge workflow", () => {
    createKnowledge.causeAndSolutionOptionClick()
    createKnowledge.updatedDetailsOfCause2Visible()
    console.log(printTimestamp(), 'All updated details displayed in knowledge workflow')

});

And("Close DAW application", () => {
    cy.DeleteWorkflow()
    cy.log('Test case executed successfully')
    console.log(printTimestamp(), 'Test case executed successfully')
});
