/// <reference types="Cypress" />
/// <reference types='cypress-tags' />  
import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';


import NavigationPanel from "../../../../support/pageObjects/pages/Dashboard/NavigationPanel";
const navigationPanel = new NavigationPanel();
import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();

When("User Clicks on three dots of my pattern", () => {
    createPattern.myPatternThreeDotsClick()
    console.log(printTimestamp(), 'Clicked on three dots of my pattern')
});

Then("Create Pattern option displayed", () => {
    navigationPanel.createPatternButtonVisible()
    createPattern.createPatternButtonClick()
    cy.wait(3000)
    console.log(printTimestamp(), 'Create Pattern option is displayed')
});

When("Click on Import Data  Model", () => {
    createPattern.patternNameType()
    createPattern.descriptionType()
    createPattern.orderOfExecutionType()
    createPattern.addActionClick()
    createPattern.addActionPlusIconClick()
    createPattern.raiseAlertOptionClick()
    createPattern.importDataModelClick()
    console.log(printTimestamp(), 'Clicked on Import Data Model')
});

Then("Select any data Model from drop down option", () => {
    createPattern.dataModelDropArrowClick()
    createPattern.dataModelCommonOptionDropArrowClick()
    createPattern.eventLogDataModelClick()
    createPattern.dataModelDropArrowClick()
    console.log(printTimestamp(), 'Selected any Data Model from drop down option')
});

When("User Click on Add Condition", () => {
    createPattern.addConditionTabClick()
    console.log(printTimestamp(), 'User Clicked on Add Condition')
});

Then("Add Condition should get expanded", () => {
    createPattern.expandedAddConditionSectionVerification()
    console.log(printTimestamp(), 'Add Condition gets expanded')
});

When("User Click on + drop down", () => {
    createPattern.addConditionPlusIconClick()
    cy.wait(2000)
    console.log(printTimestamp(), 'Clicked on + drop down')
});

Then("From Data Model,From Rule Pattern,From Variable Options displayed", () => {
    createPattern.fromdataModelVisible()
    createPattern.fromrulePatternVisible()
    createPattern.fromVariableVisible()
    console.log(printTimestamp(), 'From Data Model,From Rule Pattern,From Variable Options displayed')
});

When("Add multiple events with multiple conditions", () => {
    createPattern.formDataModelClick()
    cy.wait(1000)
    createPattern.eventLogAttributeClick()
    createPattern.additionalInfoAttributeClick()
    createPattern.operatorForEventOneClick()
    createPattern.equaltoOperatorClick()
    createPattern.ValueForTestOneType()
    createPattern.addConditionPlusIconClick()
    cy.wait(2000)
    createPattern.formDataModelClick()
    cy.wait(1000)
    createPattern.eventLogAttributeClick()
    createPattern.additionalInfoAttributeClick()
    createPattern.operatorForEventTwoClick()
    createPattern.equaltoOperatorClick()
    createPattern.ValueForEventTwoType()
    console.log(printTimestamp(), 'Added multiple events with multiple conditions')
});

And("Select Operator from drop down option between events", () => {
    createPattern.operatorOneDropdownForEventTwoClick()
    createPattern.andOperatorForEventClick()
    console.log(printTimestamp(), 'Selected Operator from drop down option between events')
});

When("User Select “Add Expression” from drop down option of attribute", () => {
    createPattern.addedCondtionAttributeDropdownClick()
    createPattern.addCondtionOptionForTestOneClick()
    console.log(printTimestamp(), 'Selected “Add Expression” from drop down option of attribute')
});

Then("Pop up for Add Expression should be displayed", () => {
    createPattern.addConditionPopUpVisible()
    console.log(printTimestamp(), 'Pop up for Add Expression displayed')
});

And("title Add Expression,Operator dropdown,Attribute 1 dropdown,Operator dropdown,Attribute 2 or"
    + " Number dropdown or textbox,Done button Disabled,Close to close pop up", () => {
        createPattern.addExpressionsTitleVisible()
        createPattern.operatorInAddExpressinPopUp()
        createPattern.attributeOneInAddExpressinPopUpVisible()
        createPattern.operatorTwoInAddExpressionPopUpVisible()
        createPattern.attributeTwoInAddExpressionPopUpVisible()
        createPattern.doneButtonInPopUpVisible()
        createPattern.closeButtonInPopUpVisible()
        console.log(printTimestamp(), 'All Optiions displayed')
    });

And("All auto generated events for respective data model should be available in drop down option for Attribute1 and Attribute2 displayed", () => {
    createPattern.attributeOneDropDownArrowForTestOneClick()
    createPattern.eventLogOneUnderAttributeVisible()
    createPattern.eventLogTwoUnderAttributeVisible()
    createPattern.attributetwoArrowForTestOneClick()
    createPattern.eventLogOneUnderAttributeVisible()
    createPattern.eventLogTwoUnderAttributeVisible()
    console.log(printTimestamp(), 'All auto generated events for respective data model should be available in drop down option for Attribute1 and Attribute2 displayed')
});

When("User Select operators and attributes in Add Expression and Click on Close button", () => {
    createPattern.operatorOneDropdownFortetsOneClick()
    createPattern.absOperatorforTestOneClick()
    createPattern.attributeOneDropDownArrowForTestOneClick()
    createPattern.eventLogOneUnderAttributeclick()
    createPattern.OperatorForeventLog1UnderAtribute1Click()
    createPattern.operatorTwoFortetsOneClick()
    createPattern.starOperatorforTestOneClick()
    createPattern.attributetwoArrowForTestOneClick()
    createPattern.eventLogOneUnderAttributeclick()
    createPattern.OperatorForeventLog1UnderAtribute2Click()
    createPattern.closeButtonInPopUpClick()
    console.log(printTimestamp(), 'User Select operators and attributes in Add Expression and Clicked on Close button')
});

Then("add expression pop up should be closed, Added expression should not get added into condition within event", () => {
    createPattern.addConditionPopUpNotExist()
    createPattern.operatorTextBoxTextWithOutAddedExpression()
    console.log(printTimestamp(), 'add expression pop up closed, Added expression not get added into condition within event')
});

When("User Repeat above step except click on Close Button", () => {
    createPattern.addedCondtionAttributeDropdownClick()
    createPattern.addCondtionOptionForTestOneClick()
    createPattern.addConditionPopUpVisible()
    createPattern.operatorOneDropdownFortetsOneClick()
    createPattern.absOperatorforTestOneClick()
    createPattern.attributeOneDropDownArrowForTestOneClick()
    createPattern.eventLogOneUnderAttributeclick()
    createPattern.OperatorForeventLog1UnderAtribute1Click()
    createPattern.operatorTwoFortetsOneClick()
    createPattern.starOperatorforTestOneClick()
    createPattern.attributetwoArrowForTestOneClick()
    createPattern.eventLogOneUnderAttributeclick()
    createPattern.OperatorForeventLog1UnderAtribute2Click()
    console.log(printTimestamp(), 'Repeats above step except click on Close Button')
});

Then("Done button is enabled", () => {
    createPattern.doneButtonEnabled()
    console.log(printTimestamp(), 'Done button is enabled')
});

When("User Click on Done", () => {
    createPattern.doneButtonClickInPopUpClick()
    console.log(printTimestamp(), 'User Clicked on Done')
});

Then("pop of Add Expression should be closed", () => {
    createPattern.addConditionPopUpNotExist()
    console.log(printTimestamp(), 'pop of Add Expression closed')
});

And("Added expression should be displayed as part of condition in attribute within event", () => {
    createPattern.operatorTextBoxTextWithAddedExpression()
    console.log(printTimestamp(), 'Added expression displayed as part of condition in attribute within event')
});

When("User Select operator and enter value for added expression", () => {
    createPattern.operatorForEventLastClick()
    createPattern.equaltoOperatorClick()
    createPattern.ValueForEventOneType()
    createPattern.unitDropdownClick()
    createPattern.msUnitClick()
    console.log(printTimestamp(), 'Selects operator and enter value for added expression')
});

And("Click on Save as Draft", () => {
    createPattern.saveAsDraftButtonClick()
    cy.wait(2000)
    console.log(printTimestamp(), 'Clicked on Save as Draft')
});

When("User Relaunch DAW application", () => {
    cy.reload()
    cy.wait(3000)
    console.log(printTimestamp(), 'Relaunched DAW application')
});

Then("All saved details should be available in wf", () => {
    createPattern.savedDetailsVisible()
    console.log(printTimestamp(), 'All saved details available in wf')
});

When("Remove any autogenerated event", () => {
    createPattern.addConditionTabClick()
    createPattern.removeEventButtonClick()
    createPattern.deleteButtonClick()
    console.log(printTimestamp(), 'Removed any autogenerated event')
});

Then("All events-conditions should be displayed with red color border when dependant event removed", () => {
    createPattern.eventsAndConditionInredColor()
    console.log(printTimestamp(), 'All events-conditions displayed with red color border when dependant event removed')
});

And("removed event should not be available in list of attribute1 and attribute2 in Add Expression pop up", () => {
    createPattern.addConditionPlusIconClick()
    cy.wait(2000)
    createPattern.formDataModelClick()
    cy.wait(1000)
    createPattern.eventLogAttributeClick()
    createPattern.additionalInfoAttributeClick()
    createPattern.operatorForEventTwoClick()
    createPattern.equaltoOperatorClick()
    createPattern.ValueForEventTwoType()
    createPattern.addedCondtionAttributeDropdownForLog2Click()
    createPattern.addExpressionOptionForEventTwoClick()
    createPattern.attributeOneDropDownArrowForTestOneClick()
    createPattern.eventLogOneUnderAttributeOneNotVisible()
    createPattern.attributetwoArrowForTestOneClick()
    createPattern.eventLogOneUnderAttributeTwoNotVisible()
    createPattern.closeButtonInPopUpClick()
    cy.DeleteWorkflow()
    console.log(printTimestamp(), 'removed event not available in list of attribute1 and attribute2 in Add Expression pop up')
});

And("User Repeat above steps by adding condition from  Pattern", () => {
    createPattern.myPatternThreeDotsClick()
    createPattern.createPatternButtonClick()
    cy.wait(3000)
    createPattern.patternNameType()
    createPattern.descriptionType()
    createPattern.orderOfExecutionType()
    createPattern.addActionClick()
    createPattern.addActionPlusIconClick()
    createPattern.raiseAlertOptionClick()
    createPattern.importDataModelClick()
    createPattern.dataModelDropArrowClick()
    createPattern.dataModelCommonOptionDropArrowClick()
    createPattern.eventLogDataModelClick()
    createPattern.dataModelDropArrowClick()
    createPattern.addConditionTabClick()
    createPattern.addConditionPlusIconClick()
    createPattern.rulePatternClick()
    createPattern.showAllButtonClick()
    cy.wait(1000)
    createPattern.firstKnowledgeClick()
    createPattern.importButtonClick()

    createPattern.addedCondtionAttributeDropdownForEventTwoInRulepatternClick()
    createPattern.addCondtionOptionForTestOneClick()
    createPattern.addConditionPopUpVisible()
    createPattern.addExpressionsTitleVisible()
    createPattern.operatorInAddExpressinPopUp()
    createPattern.attributeOneInAddExpressinPopUpVisible()
    createPattern.operatorTwoInAddExpressionPopUpVisible()
    createPattern.attributeTwoInAddExpressionPopUpVisible()
    createPattern.doneButtonInPopUpVisible()
    createPattern.closeButtonInPopUpVisible()
    createPattern.attributeOneDropDownArrowForTestOneClick()
    createPattern.eventLogOneUnderAttributeVisible()
    createPattern.attributetwoArrowForTestOneClick()
    createPattern.eventLogOneUnderAttributeVisible()
    createPattern.operatorOneDropdownFortetsOneClick()
    createPattern.absOperatorforTestOneClick()
    createPattern.attributeOneDropDownArrowForTestOneClick()
    createPattern.eventLogOneUnderAttributeclick()
    createPattern.OperatorForeventLog1UnderAtribute1Click()
    createPattern.operatorTwoFortetsOneClick()
    createPattern.starOperatorforTestOneClick()
    createPattern.attributetwoArrowForTestOneClick()
    createPattern.eventLogOneUnderAttributeclick()
    createPattern.OperatorForeventLog1UnderAtribute2Click()
    createPattern.closeButtonInPopUpClick()
    createPattern.operatorTextBoxTextWithOutAddedExpressionForRulePattern()
    createPattern.addedCondtionAttributeDropdownForEventTwoInRulepatternClick()

    createPattern.addCondtionOptionForTestOneClick()
    createPattern.addConditionPopUpVisible()
    createPattern.operatorOneDropdownFortetsOneClick()
    createPattern.absOperatorforTestOneClick()
    createPattern.attributeOneDropDownArrowForTestOneClick()
    createPattern.eventLogOneUnderAttributeclick()
    createPattern.OperatorForeventLog1UnderAtribute1Click()
    createPattern.operatorTwoFortetsOneClick()
    createPattern.starOperatorforTestOneClick()
    createPattern.attributetwoArrowForTestOneClick()
    createPattern.eventLogOneUnderAttributeclick()
    createPattern.OperatorForeventLog1UnderAttribute2Click()
    createPattern.doneButtonClickInPopUpClick()
    createPattern.addConditionPopUpNotExist()
    createPattern.operatorForEventTwoInRulePatternClick()
    createPattern.equaltoOperatorClick()
    createPattern.ValueForEventTwoInRulePatternType()
    createPattern.unitDropdownForEventTwoInRulePatternClick()
    createPattern.msUnitForRulePatternClick()
    createPattern.saveAsDraftButtonClick()
    cy.wait(2000)
    cy.reload()
    cy.wait(3000)
    createPattern.savedDetailsVisible()
    createPattern.addConditionTabClick()
    createPattern.removeEventButtonClick()
    createPattern.deleteButtonClick()
    createPattern.addConditionPlusIconClick()
    cy.wait(2000)
    createPattern.formDataModelClick()
    cy.wait(1000)
    createPattern.eventLogAttributeClick()
    createPattern.additionalInfoAttributeClick()
    createPattern.operatorForEventTwoClick()
    createPattern.equaltoOperatorClick()
    createPattern.ValueForEventTwoType()
    createPattern.addedCondtionAttributeDropdownForLog2Click()
    createPattern.addExpressionOptionForEventTwoClick()
    createPattern.attributeOneDropDownArrowForTestOneClick()
    createPattern.closeButtonInPopUpClick()
    console.log(printTimestamp(), 'Repeats above steps by adding condition from  Pattern')
});