/// <reference types="Cypress" />

/// <reference types = 'cypress-tags' />

import "../../../support/index";
import { When, Then } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../support/commands';
import IncludeKnowlegePage from "../../../support/pageObjects/pages/PatternAuthoring/includeKnowledgepageObj";
const includeKnowlegePage = new IncludeKnowlegePage();
import KnowledgeDashboard from "../../../support/pageObjects/pages/Knowledge_Dashboard/KnowledgeDashboard";
const knowledgeDashboard = new KnowledgeDashboard();
import CreateKnowledge from "../../../support/pageObjects/pages/KnowledgeAuthoring/CreateKnowledge";
const createKnowledge = new CreateKnowledge();

Then("User Expands My Knowledge section and clicks on the '+'  section", () => {
    createKnowledge.knowledgeClick() 
    console.log(printTimestamp(), ' My knowledge section expanded and + icon clicked')
});

Then("Verifies Name, Description and Modality section should be displayed in expanded state", () => {
    includeKnowlegePage.nameAndDescriptionExpandedVerification()
    console.log(printTimestamp(), ' Details verified')
});

When("User Enters all the mandatory details in knowledge information section", () => {
    cy.PatternCreation()
    includeKnowlegePage.knowledgeNameTypeInKnowledgeDetails()
    includeKnowlegePage.knowledgeInfoTabClick()
    createKnowledge.additionOfMandatoryDetails()
    console.log(printTimestamp(), ' All mandatory details added')
});

When("User Expands Symptom section and select symptom", () => {
    // includeKnowlegePage.symptomsClick()
    createKnowledge.selectSymptomsButtonClick()
    console.log(printTimestamp(), ' Expanded Symptom section')
});

Then("Select Symptom pop up should appear", () => {
    createKnowledge.selectSymptomsHeadingVisible()
    console.log(printTimestamp(), ' Select Symptom pop up appeared')
});

When("User clicks on show all", () => {
    createKnowledge.showAllCheckboxClick()
    console.log(printTimestamp(), ' Show All checkbox clicked')
});

Then("Grid should be populated with already created knowledges", () => {
    includeKnowlegePage.knowledgeDetailsVerification()
    console.log(printTimestamp(), ' Verified Grid populated with already created knowledges')
});

When("User Enters any filter in the text boxes in the select Symptom pop up", () => {
    createKnowledge.symptomNameColumnType();
    console.log(printTimestamp(), ' User Entered any filter in the text boxes in the select Symptom pop up')
});

Then("User should be able to view filtered related data in the grid", () => {
    includeKnowlegePage.nameColumnSortingOfDataVerification()
    console.log(printTimestamp(), ' User viewed filtered related data in the grid')
});

When("User clicks on the Clear all Filter", () => {
    createKnowledge.clearAllFilterButtonClick();
    console.log(printTimestamp(), ' Clicked on Clear all Filter')
});

Then("filters should be removed and the data should restore to default values", () => {
    includeKnowlegePage.recordsCheckboxCountVerification()
    console.log(printTimestamp(), ' filtered removed')
});

When("User clicks on the checkbox and click on select button", () => {
    includeKnowlegePage.firstRecordsCheckboxClick();
    console.log(printTimestamp(), ' Clicked on the checkbox')
});

Then("Selected Symptom should be added to the symptom section", () => {
    includeKnowlegePage.selectedSymptomsPreviewSectionVerification()
    console.log(printTimestamp(), ' Selected Symptom added')
});

When("User clicks on the Add Symptom option", () => {
    createKnowledge.addSymptomsButtonClick();
    console.log(printTimestamp(), ' Clicked on the Add Symptom option')
});

Then("Rich text box should be available and user should be able to add rich text content with pictures", () => {
    includeKnowlegePage.richTextEditorSectionVerification()
    createKnowledge.insertFileButtonClick()
    createKnowledge.browseFileIconClick().attachFile('SampleFile.pdf')
    console.log(printTimestamp(), ' Rich text box available')
});

When("User clicks on the tick button present on top of symptom rich text", () => {
    includeKnowlegePage.tickButtonClick();
    console.log(printTimestamp(), ' User clicked on the tick button')
});

Then("The symptom should be selected", () => {
    includeKnowlegePage.addedSymptomsPreviewSectionVerification()
    console.log(printTimestamp(), ' Symtoms selected')
});

Then("Repeat step for addition of cause and solution as same as addition of symptom for both select and add function", () => {
    createKnowledge.ImportCausesAndSolutionInKnowledge();
    createKnowledge.ImportCausesAndSolutionByAddCauseSection();
    console.log(printTimestamp(), ' Steps repeated')
});

When("User Deletes one of cause , solution or symptom", () => {
    includeKnowlegePage.deleteCauseFromListClick();
    console.log(printTimestamp(), ' Deleted one cause')
});

When("User Clicks on next button", () => {
    includeKnowlegePage.nextButtonClick();
    console.log(printTimestamp(), ' Next button clicked')
});

Then("User should be navigated to the knowledge View stage", () => {
    includeKnowlegePage.viewDetailsTabActiveVerification()
    console.log(printTimestamp(), ' Navigated to the knowledge View stage')
});

Then("relaunches the application and navigates to newly created workflow", () => {
    console.log(printTimestamp(), ' User relaunched application')
});

And("Close The Application and delete newly created workflow", () => {
    cy.DeleteWorkflow()
    cy.log("Test Case Executed Successfully")
    console.log(printTimestamp(), ' Test Case Executed Successfully')
});