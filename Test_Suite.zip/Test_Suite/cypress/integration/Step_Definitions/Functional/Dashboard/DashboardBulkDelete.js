/// <reference types="Cypress" />
/// <reference types='cypress-tags' />  

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();

And("at least two to three published status and some patterns present in draft status" +
    " should be present and should be selectable", () => {
        // createPattern.draftPatternCountVerification()
        createPattern.publishedPatternCountVerification()
        console.log(printTimestamp(), "at least two to three published status and some patterns present in draft status" +
            " present and selectable")
    });

When("Select entries per page as 50", () => {
    createPattern.changeEntriesPerPageCountSizeInPatternDashboard()
    console.log(printTimestamp(), 'Selected entries per page as 50')
});

Then("Max 50 patterns should be displayed in a page", () => {
    createPattern.recordsAvailableInDashboardVerification()
    console.log(printTimestamp(), 'Max 500 patterns displayed in a page')
});

When("Apply filter on Pattern state i.e published and withdraw", () => {
    // createPattern.publishedAndWithdrawnPatternStatusSelection()
    console.log(printTimestamp(), 'Apply filter on Pattern state i.e published and withdraw')
});

Then("All Published and withdraw patterns should be available", () => {
    createPattern.publishedPatternCountVerification()
    // createPattern.withdrawnPatternCountVerification()
    console.log(printTimestamp(), 'All Published and withdraw patterns available')
});

When("Select five patterns available in current page", () => {
    cy.wait(2000)
    createPattern.firstFiveRecordClickInDashboard()
    console.log(printTimestamp(), 'Selects five patterns available in current page')
});

Then("Based on selected number of patterns 5 patterns selected should be displayed beside Advance Search", () => {
    createPattern.fiveRecordsSelectedVerification()
    console.log(printTimestamp(), 'Based on selected number of patterns 5 patterns selected displayed beside Advance Search')
});

When("click on delete button from top right corner", () => {
    createPattern.deletePatternButtonInDashboardClick()
    console.log(printTimestamp(), 'clicked on delete button from top right corner')
});

Then("pop up should be displayed", () => {
    createPattern.deletePopUpVisible() 
    console.log(printTimestamp(), 'pop up displayed')
});

And("Confirmation message should be displayed as below Delete icon - Are you sure you want to delete" +
    " the following 5 pattern all Pattern Names Cancel and Delete buttons", () => {
        createPattern.popUpTitleVisible()
        createPattern.cancelButtonInDeleteWFPopupVisible()
        createPattern.deleteButtonInDeleteWFPopupVisible()
        console.log(printTimestamp(), "Confirmation message displayed as below Delete icon - Are you sure you want to delete" +
            " the following 9 pattern all Pattern Names Cancel and Delete buttons")
    });

When("Click on Cancel button", () => {
    createPattern.cancelButtonInDeleteWFPopupClick()
    console.log(printTimestamp(), 'Clicked on Cancel button')
});

Then("Pattern should not get deleted", () => {
    createPattern.fiveRecordsSelectedVerification()
    console.log(printTimestamp(), 'Pattern not deleted')
});

When("Select more than 10 e.g selected 50 Published-Withdraw state of pattern,click on delete button" +
    " from top right corner and verify confirmation pop up", () => {
        createPattern.nextFiveRecordsClickInDashboard()
        createPattern.deletePatternButtonInDashboardClick()
        createPattern.deletePopUpVisible()
        console.log(printTimestamp(), "Select more than 10 e.g selected 500Published-Withdraw state of  pattern,clicked on delete button" +
            " from top right corner and verified confirmation pop up")
    });

And("Based on selected number of patterns 10 patterns selected should be displayed beside Advance Search", () => {
    createPattern.tenRecordsSelectedVerification()
    console.log(printTimestamp(), 'Based on selected number of patterns 500 patterns selected displayed beside Advance Search')
});

Then("Delete icon - Are you sure you want to delete following 10 pattern All 10 Pattern Name +1 more Cancel and Delete buttons", () => {
    createPattern.popUpTitleVisible()
    createPattern.cancelButtonInDeleteWFPopupVisible()
    createPattern.deleteButtonInDeleteWFPopupVisible()
    console.log(printTimestamp(), 'Delete icon - Are you sure you want to delete following 500 pattern All 10 Pattern Name +490 more Cancel and Delete buttons')
});

When("Click on Cancel button", () => {
    createPattern.cancelButtonInDeleteWFPopupClick()
    console.log(printTimestamp(), 'Clicked on Cancel button')
});

Then("Pattern should not get removed", () => {
    createPattern.tenRecordsSelectedVerification()
    console.log(printTimestamp(), 'Pattern should not deleted')
});

When("Click on the Delete button and click on Delete button from pop up", () => {
    cy.CreatePatternsTillValidateStageCompletion(5)
    cy.wait(3000)
    createPattern.patternDashboardClick()
    cy.wait(2000)
    createPattern.servicecontextColumnClickAndFSESelection()
    createPattern.modalityColumnClickAndCT_DCPSelection()
    createPattern.firstThreeRecordsClickAndPublish()
    cy.wait(5000)
    cy.reload()
    createPattern.servicecontextColumnClickAndFSESelection()
    createPattern.modalityColumnClickAndCT_DCPSelection()
    createPattern.firstFiveRecordsClickInDashboard()
    createPattern.deletePatternButtonInDashboardClick()
    createPattern.okButtonClick()
    console.log(printTimestamp(), 'Clicked on the Delete button and clicked on Delete button from pop up')
});

Then("After clicking on Delete button from pop up Patterns including all version should get deleted from UI", () => {
    createPattern.patternsDeletedNotVisible()
    console.log(printTimestamp(), 'After clicking on Delete button from pop up Patterns including all version get deleted from UI')
});

And("All versions of deleted patterns is_deleted flag should get updated to True Modified" +
    " by user id and Modified on current utc should get updated in Db", () => {

        console.log(printTimestamp(), "All versions of deleted patterns is_deleted flag should get updated to True Modified" +
            " by user id and Modified on current utc gets updated in Db")
    });

And("Deleted pattern should not be displayed in UI", () => {
    createPattern.patternsDeletedNotVisible()
    console.log(printTimestamp(), 'Deleted pattern not be displayed in UI')
});

When("Click on Clear All Filter", () => {
    createPattern.clearAllFiltersButtonClick()
    console.log(printTimestamp(), 'Clicked on Clear All Filter')
});

Then("Filtered data should get removed", () => {
    createPattern.filtersClearedVerification()
    console.log(printTimestamp(), 'Filtered data gets removed')
});

When("Apply filter on pattern state Other than Published Withdraw", () => {
    createPattern.draftPatternStatusSelection()
    console.log(printTimestamp(), 'Apply filter on pattern state Other than Published Withdraw')
});

Then("Published Withdraw state of patterns should not be displayed", () => {
    createPattern.publishedPatternNotExistVerification()
    console.log(printTimestamp(), 'Published Withdraw state of patterns not displayed')
});

When("click on delete button available at top right corner", () => {
    createPattern.firstFiveRecordsClickInDashboard()
    createPattern.deletePatternButtonInDashboardClick()
    console.log(printTimestamp(), 'clicked on delete button available at top right corner')
});

Then("pop up should be displayed", () => {
    createPattern.deletePopUpVisible()
    console.log(printTimestamp(), 'pop up displayed')
});

And("'Are you sure you want to delete following 1 pattern' Pattern Name Cancel and Delete buttons", () => {
    createPattern.popUpTitleVisible()
    createPattern.cancelButtonInDeleteWFPopupVisible()
    createPattern.deleteButtonInDeleteWFPopupVisible()
    console.log(printTimestamp(), 'Are you sure you want to delete following 1 pattern” Pattern Name Cancel and Delete buttons')
});

When("Click on Cancel button", () => {
    createPattern.cancelButtonInDeleteWFPopupClick()
    console.log(printTimestamp(), 'Clicked on Cancel button')
});

Then("Patterns should not get deleted", () => {
    createPattern.fiveRecordsSelectedVisible()
    console.log(printTimestamp(), 'Pattern should get deleted')
});

When("Clicks on the Delete button and click on Delete button from pop up", () => {
    createPattern.deletePatternButtonInDashboardClick()
    createPattern.okButtonClick()
    console.log(printTimestamp(), 'Clicked on the Delete button and clicked on Delete button from pop up')
});

Then("After  clicking on Delete button from pop up Pattern should get deleted from UI", () => {

    console.log(printTimestamp(), 'After  clicking on Delete button from pop up Pattern get deleted from UI')
});

And("In  Pattern table,For latest version of patterns is_deleted flag should get updated to True," +
    " Modified by user id and Modified on current utc should get updated", () => {

        console.log(printTimestamp(), "In  Pattern table,For latest version of patterns is_deleted flag gets updated to True," +
            " Modified by user id and Modified on current utc gets updated")
    });

And("In Workflow table,Deleted patterns id itemid workflow is_deleted flag should get updated to true ,Modified" +
    " by user id and modified on current utc should get updated", () => {

        console.log(printTimestamp(), "In Workflow table,Deleted patterns id itemid workflow is_deleted flag gets updated to true ,Modified" +
            " by user id and modified on current utc get updated")
    });

And("Deleted pattern latest version should not be displayed in UI Other version of that pattern should get displayed in UI", () => {
    createPattern.patternsDeletedNotVisible()
    console.log(printTimestamp(), 'Deleted pattern latest version not be displayed in UI Other version of that pattern gets displayed in UI')
});

When("Select combination of Published Withdraw and other state of patterns and Click on Delete button", () => {
    cy.reload()
    cy.wait(3000)
    createPattern.firstFiveRecordsClickInDashboard()
    createPattern.deletePatternButtonInDashboardClick()
    createPattern.cancelButtonInDeleteWFPopupClick()
    console.log(printTimestamp(), 'Select combination of Published Withdraw and other state of patterns and Clicked on Delete button')
});

Then("Depending on which state of pattern deleted , details should be updated in UI and db as mentioned in above steps", () => {

    console.log(printTimestamp(), 'Depending on which state of pattern deleted , details updated in UI and db as mentioned in above steps')
});

When("Click on three dot of any pattern and delete pattern", () => {
    cy.reload()
    cy.wait(4000)
    createPattern.threeDotsGridButtonClickAndDelete()
    console.log(printTimestamp(), 'Clicked on three dot of any pattern and delete pattern')
});

Then("Based on which states pattern deleted details should get updated in db and UI as mentioned in above steps", () => {
    console.log(printTimestamp(), 'Based on which states pattern deleted details gets updated in db and UI as mentioned in above steps')
});

When("Click on pattern name and delete pattern", () => {
    cy.reload()
    createPattern.firstRecordsNaviagationLinkClick()
    createPattern.deletePatternButtonClickFromInsideOFPattern()
    createPattern.okButtonClick()
    console.log(printTimestamp(), 'Clicked on pattern name and delete pattern')
});

Then("Based on which states pattern deleted details should get updated in db and UI as mentioned in above steps", () => {

    console.log(printTimestamp(), 'Based on which states pattern deleted details gets updated in db and UI as mentioned in above steps')
});

And("Repeat above steps in My pattern dashboard", () => {
    createPattern.myPatternsSectionCollapseIconClick()
    createPattern.myPatternDashboardClick()
    createPattern.publishedPatternCountVerification()
    createPattern.publishedAndWithdrawnPatternStatusSelection()
    createPattern.publishedPatternCountVerification()
    createPattern.withdrawnPatternCountVerification()
    cy.reload()
    cy.wait(4000)
    createPattern.firstFiveRecordClickInDashboard()
    createPattern.fiveRecordsSelectedVerification()
    createPattern.deletePatternButtonInDashboardClick()
    createPattern.deletePopUpVisible()
    createPattern.popUpTitleVisible()
    createPattern.cancelButtonInDeleteWFPopupVisible()
    createPattern.deleteButtonInDeleteWFPopupVisible()
    createPattern.cancelButtonInDeleteWFPopupClick()
    createPattern.fiveRecordsSelectedVerification()
    createPattern.nextFiveRecordsClickInDashboard()
    createPattern.deletePatternButtonInDashboardClick()
    createPattern.deletePopUpVisible()
    createPattern.tenRecordsSelectedVerification()
    createPattern.popUpTitleVisible()
    createPattern.cancelButtonInDeleteWFPopupVisible()
    createPattern.deleteButtonInDeleteWFPopupVisible()
    createPattern.cancelButtonInDeleteWFPopupClick()
    createPattern.tenRecordsSelectedVerification()
    cy.reload()
    cy.CreatePatternsTillValidateStageCompletion(5)
    cy.wait(3000)
    createPattern.myPatternDashboardClick()
    cy.wait(2000)
    createPattern.servicecontextColumnClickAndFSESelection()
    cy.wait(3000)
    // createPattern.modalityColumnClickAndCT_DCPSelection()
    createPattern.firstFiveRecordClickInDashboard()
    createPattern.deletePatternButtonInDashboardClick()
    createPattern.okButtonClick()
    createPattern.patternsDeletedNotVisible()
    createPattern.clearAllFiltersButtonClick()
    createPattern.filtersClearedVerification()
    createPattern.publishedPatternNotExistVerification()
    cy.wait(3000)
    createPattern.firstFiveRecordClickInDashboard()
    createPattern.deletePatternButtonInDashboardClick()
    createPattern.cancelButtonInDeleteWFPopupClick()  
    console.log(printTimestamp(), 'Repeats above steps in My Pattern Dashboard')
});
