import "../../../index";
import '../../../commands';

import AssertionConstants from "../../../../support/pageObjects/pages/AssertionConstants"
const assertionConstants = new AssertionConstants();
const filePath = 'cypress/fixtures/patternNameCreation.json'
var patternNames = []
const knowledgee = "div[aria-label='Knowledge']>button";
const myKnowledgeTab = "div[aria-label='My Knowledge']>button";
const knowledgeDashboard = "section>#Dashboard";
const knowledgeColumnsDropdown = "Knowledge Name ... +7 more";
const knowledgeUnselectedColumns = "dls-multiselect-option[class='pt-multiselect-option ng-star-inserted']";
const knowledgeOutsideClickToGetResults = "//dls-label[contains(text(),'Knowledge')]";
const knowledgeNameSearchFilter = "#knowledgeName_searchIcon";
const noOfAssociationsSearchFilter = "#noOfAssociations_searchIcon";
const dropdownFilterColumns = "p-multiselect[filterplaceholder='Filter Options']";
const filteredDataVerification = '[style="width: 500px;"] > .btn-link';
const crossIcon = '[id="knowledge-sidebar-close"]';
const allDataPresentInTableVerification = "tbody>tr";
const modalityColumn = "#multiselect-filter";
const modalityDropdownValueSelection = "p-multiselectitem>li .ng-star-inserted";
const modifiedOnColumn = "p-calendar[name='calendar']";
const calenderDateSelection = 'table tr td span[draggable="false"]';
const clearAllFilters = "#clear-all-filter";
const addKnowledge = "#nav-add-btn";
const firstRecord = "#-checkbox";
const ButtonVisible = "dls-dialog-footer>button"
const selectCause = "#select-cause"
const tagSection = "//span[contains(text(),'Tags')]"
const addTagsButton = "#add-tags"
const searchTextBox = "dls-multiselect[name='withoutKeyword']"
const addTagFromList = 'dls-multiselect-option[role="option"]';
const addTagOkButton = "#add-select-tag"
const keywordDropdownVisibleInTagSection = "dls-dropdown[name='keyword']"
const dropdownValuesVerification = "dls-option-list>dls-option"
const operatorDropdownVisibleInTagSection = "dls-dropdown[name='operator']"
const valueDropdownVisibleInTagSection = "dls-dropdown[name='tagValue']"
const addTag = 'div>ul>li>.pt-token-label'
const monthPicker = '.p-datepicker-month'
const datePicker = ".p-datepicker-prev-icon"
const descriptionSection = "//span[contains(text(),'Description')]"
const symptomsSection = "//span[contains(text(),'Symptoms')]"
const causeAndSolutionSection = "//span[contains(text(),'Causes and Solutions')]"
const AssociationSection = "//span[contains(text(),'Associations')]"
const knowledgeDetails = "div[id='knowledge-id-container']"
const knowledgeName = "#pat-name"
const versionDetails = "div[class='version-container']"
const draftIcon = "img[alt='Version']"
const screenExpandIcon = "img[alt='Expand']"
const deleteButton = "#knowledge-delete"
const closeButton = "#knowledge-close"
const descriptionValueValidation = "dls-layout-container section>p"
const descriptionIconValidation = "button[class]>svg"
const descriptionIconValidationForMyknowledge = "button>svg"
const symptomsValueValidation = "app-symptom-viewmode section div>p"
const symptomsIconValidation = "button[class]>svg"
const causesAndSolutionValueValidation = "div[class='preview-section']"
const causesAndSolutionIconValidation = 'button[class]>svg'
const tagsIconValidation = 'button>svg'
const descriptionDetails = "#knowledge-info-expander span"
const symptomName = "section h2>div"
const symptomTags = "div>ul"
const causeAndSolutionName = "section div h2 span"
const causeAndSolutionDescription = ':nth-child(3) > .preview-section > .content-body'
const descriptionCollapsedVerification = "dls-expander[id='knowledge-info-expander']"
const symptomCollapsedVerification = "#symptoms-expander"
const knowledgeDashboardNavigationVerification = "div>header[class='row p-3']"
const backArrow = 'button[id="back-arrow"]'
const tableFirstRecord = '//tbody/tr[1]/td[2]/span'
const navigationPanelIcon = '#side-nav-toggle-icon'
const navigationPanelText = 'div[class="collapse-label ng-star-inserted"]'
const deleteButtonInKnowledgeDashboard = 'button[id="delete-knowledge"]'
const advanceFilterHyperlink = '#advanced-filter-knowledge'
const selectedColumns = 'dls-multiselect-option[class="pt-multiselect-option pt-selected ng-star-inserted"]'
const unSelectedColumns = 'dls-multiselect-option[class="pt-multiselect-option ng-star-inserted"]'
const entriesPerPage = 'section[class="pt-entries-per-page"]'
const showingResults = 'section[class="showing"]'
const modifiedOnColumnDESC = 'th[aria-sort="descending"]'
const nextPageIcon = 'dls-icon[class="pt-icon icon-dls-navigation-right custom-right-icon"]'
const previousPageIcon = 'dls-icon[class="pt-icon icon-dls-navigation-left custom-left-icon"]'
const pageCount = 'dls-dropdown[role="listbox"]'
const entriesPerPagesCount = 'dls-option[role="option"]'
const firstKnowledgeRecordThreeDots = "td>#grid-dropdown-btn"
const publishButtonInRecord = "#publish-knowledge"
const deleteButtonInRecord = "#delete-knowledge"
const firstrecord = "//tbody/tr[1]/td[2]/span[1]"
const modifiedOnColumnn = "th[id='Modified On']"
const breadcumbLastValue = ".pt-layout-container > ul > li > a > span"
const addCauseButton = "#add-cause"
const addSolutionButton = '#add-solution'
const saveAsDraftButton = "#knowledge-save > .pt-layout-container"
const resultSelection = 'div[role="checkbox"]>span'
const textTypeInSearchBox = 'est'
const byDefaultModality = "//div[contains(text(),'DXR')]"
const gridColumns = "thead[class='p-datatable-thead']>tr>th[class='p-element p-sortable-column ng-star-inserted']"
const columnSelection = "dls-multiselect[role='listbox']"
const knowledgeResult = "span[class='btn-link ng-star-inserted']"
const FirstRecord = '//tbody/tr[1]/td[2]/span[1]'
const knowledgeNameInOverlay = '#pat-name'
const closeIconInOverlay = " #back-arrow"
const modalityInKnowledgeDashboard = "#Modality"
const dxrModality = 'DXR'
const changeEntriesPerPageCount = "dls-dropdown[role='listbox']"
const threeDotsOfKnowledgeRecords = "#nav-dropdown-btn #Layer_1"
const renameButtonInKnowledgeRecord = "#Rename"
const deleteButtonInKnowledgeRecord = "#Delete"
const crossButton = 'button[class="pt-clear-button"]'
const okButton = '#ok-btn'
const breadCumb = 'li[role="menuitem"] span'
const addKnowledgeHyperLink = 'span[class="btn-link"]'
const knowledgeNameColumn = "th[id='Knowledge Name']";
const modalityNameColumn = "th[id='Modality']";
const tagsColumn = "th[id='Tags']";
const noOfAssociationColumn = "th[id='# of Associations']";
const versionsColumn = "th[id='Version']";
const knowledgeStateColumn = "th[id='Knowledge State']";
const modifiedByColumn = "th[id='Modified By']";
const modifiedonColumn = "th[id='Modified On']";
const columnConfiurationDropdown = 'dls-multiselect[role="listbox"] span'
const selectedColumnsChekbox = 'dls-multiselect-option.pt-multiselect-option.pt-selected.ng-star-inserted'
const unSelectedColumnsChekbox = 'dls-multiselect-option[class="pt-multiselect-option ng-star-inserted"]'
const selectedColumnsText = 'dls-multiselect-option[class="pt-multiselect-option pt-selected ng-star-inserted"] span[class="pt-option-label"]'
const unSelectedColumnsText = 'dls-multiselect-option[class="pt-multiselect-option ng-star-inserted"] span[class="pt-option-label"]'
const newScrollElement = '[aria-label="Models"]'
let arr = []
let arr1 = []
let arr2 = []
let knowledgeNamesArrey = []
let filteredValue = ''
const knowledge = '[class="p-element p-datatable-tbody"]'
const editButton = '[id="knowledge-sidebar-edit"]'
const viewButton = '[id="knowledge-sidebar-view"]'
const knowledgeDetailsPage = '[class="h-100"]'
const searchIcon = 'dls-searchbox .icon-dls-search'
const knowledgeList = '.p-element.p-datatable-tbody td '
const checkBoxToSelectAllModalities = '.p-multiselect-header > .p-checkbox > .p-checkbox-box'
const publishButton =  'button[id="detail-knowledge-publish"]'
const threeDotsOfKnowledgeOnKnowledgeDashboard = '[id="grid-dropdown-btn"]'
const editButtonOnKnowledgeDashboardPage = '[id="Edit"]'
const editedKnowledge = '[class="p-element p-datatable-tbody"]>tr'
const editedKnowledgeInDraftState = '[class="p-element p-datatable-tbody"]>tr>td'
const editButtonOnKnowledgeDetailsPage = '[id="knowledge-edit"]'
const secondKnowledge = '.p-element.p-datatable-tbody tr td'
const publishButtonInThreeDots = '#Publish'
const lastRecordOpen = 'tr>td>span[class="btn-link ng-star-inserted"]'
const publishButtonInsideWF = '#detail-knowledge-publish'
const backPageClick = 'img[alt="Back"]'
const cancelButtonInPopUp = '#cancel-btn'
const symptomsDataInPopup = '.preview-section'
const knowledgeStatusColumn = 'th[id="column_knowledgeStatus"]'
const draftOption = 'li[aria-label="Draft"]'
const applyButtonInKnowledgeStatusColumn = '#knowledgeStatus_applyBtn'
const applyButtonInModalityColumn = "button[id='metadata.modality_applyBtn']"
const CTModalitySelection = 'div[class="p-checkbox-box"]'
const knowledgeSearchOption = '#filter-option input'
const searchIconForKnowledgeName = '.icon-dls-search.pt-icon'
const knowledgePublishOption =  '#detail-knowledge-publish'
const clearKnowledgeNameOption = '.pt-clear-button>dls-icon'
const rowLevelThreeDots = 'span[id="grid-dropdown-btn"]'
const checkBoxSelectingFirstKnowledge = 'span[class="p-checkbox-icon"]'
const deleteButtonWhenClickedOnlink = '#knowledge-delete'
const checkedFirstbox = '[class="p-checkbox-icon pi pi-check"]'
const deleteButtonUnderThreeDots = '[id="Delete"]'


const myPatternDropArrow = 'span[class="p-tree-toggler-icon pi pi-fw pi-chevron-right"]'
const recordsInKnowledgeDashBoard = '[class="p-element context-menu-area p-selectable-row ng-star-inserted"]'
const confirmationPopUpHeader = '[id="dialog-title"]'
const knowledgeNamesOnPopUp = '[role="listitem"] label'
const popUpcancelButton = '[id="cancel-btn"]'
const okButtonOnPopUp = '[id="ok-btn"]'
const knowledgelist = '[id="pr_id_3-table"]'
const knowledgeDeletedMessage = 'Deleted Knowledge Successfully'
const nameOfSecondKnowledge = 'knowledgeTwo'
const noResultsFoundInRelevanceMessage = " No records found "
const firstKnowledge = '[class="p-element p-datatable-tbody"] tr td '
const patternStateRecords2 = '//tbody/tr[2]/td[3]/span[1]'
const knowledgeNameOnRightSide = '[id="knowledge-name-field"]'
const KnowlegeDetailsSection = '[id="knowledge-overlay-container"]'
const knowledgeListTable = '[class="dashboard_right"]'
const modalityOption = '[id="multiselect-filter"]'
const symptomTag = 'dls-token ul'


class KnowledgeDashboard {
    symptomTagsVisible() {
        cy.get(symptomTags).should(assertionConstants.beVisibleAssertion)
      }
    modalitySelection() {
        cy.get(modalityColumn).eq(0).scrollIntoView().click()
        cy.get(modalityColumn).eq(0).scrollIntoView().click()
        cy.get(CTModalitySelection).eq(1).click()
        cy.get(applyButtonInModalityColumn).click()
    }
    firstKnowledgeRecordThreeDotClick() {
        cy.get(firstKnowledgeRecordThreeDots).last().scrollIntoView().click()
    }
    publishButtonInDashboardNotExist() {
        cy.get(publishButtonInThreeDots).should(assertionConstants.notExistsAssertion)
    }
    publishButtonClickFromDashboard(){
        cy.get(publishButtonInRecord).click()
    }
    deleteKnowledge(){
        cy.get(deleteButtonInRecord).click()
        cy.get(okButton).click()
    }
    knowledgeStatusColumnClickAndDraftSelection() {
        cy.get(knowledgeStatusColumn).click()
        cy.get(draftOption).click()
        cy.get(applyButtonInKnowledgeStatusColumn).click()
    }
    symptomsDataInPopupVisible() {
        cy.get(symptomsDataInPopup).eq(0).should(assertionConstants.beVisibleAssertion)
    }
    causeDataInPopupVisible() {
        cy.get(symptomsDataInPopup).eq(1).should(assertionConstants.beVisibleAssertion)
    }
    solutionsDataInPopupVisible() {
        cy.get(symptomsDataInPopup).eq(2).should(assertionConstants.beVisibleAssertion)
    }
    cancelButtonInPopUpClick() {
        cy.get(cancelButtonInPopUp).click()
    }
    firstRecordThreeDotsClick() {
        cy.get(firstKnowledgeRecordThreeDots).first().scrollIntoView().click()
    }
    LastCheckboxClickInKnowledgeRecord() {
        cy.get(resultSelection).last().click()
    }
    FirstCheckboxClickInKnowledgeRecord() {
        cy.get(resultSelection).eq(1).click()
    }
    multipleRecordsClickInKnowledgeRecord() {
        cy.get(resultSelection).eq(1).click()
        cy.get(resultSelection).eq(2).click()
    }
    publishButtonInsideWFVisibleAsDisabled() {
        cy.get(publishButtonInsideWF).should(assertionConstants.beVisibleAssertion)
        return cy.get(publishButtonInsideWF).should('have.attr','disabled')
    }
    publishButtonInsideWFVisibleAsEnabled() {
        cy.get(publishButtonInsideWF).should(assertionConstants.beVisibleAssertion)
        // return cy.get(publishButtonInsideWF).should('not.have.attr','disabled')
    }
    backPageClick() {
        cy.get(backPageClick).click()
    }
    firstRecordClickInDashboard() {
        cy.get(lastRecordOpen).first().click()
    }
    lastRecordClickInDashboard() {
        cy.get(lastRecordOpen).last().click()
    }
    publishButtonInThreeDotsVisibleAsDisabled() {
        cy.get(publishButtonInThreeDots).should(assertionConstants.beVisibleAssertion)
        return cy.get(publishButtonInThreeDots).should(assertionConstants.haveClassAssertion,'pt-menu-item pt-disabled ng-star-inserted')
    }
    publishButtonInThreeDotsVisibleAsEnabled() {
        cy.get(publishButtonInThreeDots).should(assertionConstants.beVisibleAssertion)
        return cy.get(publishButtonInThreeDots).should(assertionConstants.haveClassAssertion,'pt-menu-item ng-star-inserted')
    }
    publishButtonInThreeDotsClick() {
        cy.get(publishButtonInThreeDots).click()
    }
    publishButtonVisibleAsDisabled() {
        cy.get(publishButtonInRecord).should(assertionConstants.beVisibleAssertion)
        return cy.get(publishButtonInRecord).should('have.attr','disabled')
    }
    publishButtonVisibleAsEnabled() {
        cy.get(publishButtonInRecord).should(assertionConstants.beVisibleAssertion)
        return cy.get(publishButtonInRecord).should('not.have.attr','disabled')
    }
    checkboxesAvailableInEachKnowledgeRecord() {
        cy.get(resultSelection).each(($el) => {
            cy.wrap($el).should(assertionConstants.beVisibleAssertion)
        })
    }
    selectedColumnsTextCountVerification() {
        cy.get(selectedColumnsText).each(($el) => {
            cy.wrap($el).should(assertionConstants.beVisibleAssertion)
        })
        cy.get(selectedColumnsText).should(assertionConstants.havelengthAssertion, 8)
    }
    unSelectedColumnsTextCountVerification() {
        cy.get(unSelectedColumnsText).each(($el) => {
            cy.wrap($el).should(assertionConstants.beVisibleAssertion)
        })
        cy.get(unSelectedColumnsText).should(assertionConstants.havelengthAssertion, 2)
    }
    selectedColumnsChekboxCountVerification() {
        cy.get(selectedColumnsChekbox).should(assertionConstants.havelengthAssertion, 8)
    }
    unSelectedColumnsChekboxCountVerification() {
        cy.get(unSelectedColumnsChekbox).should(assertionConstants.havelengthAssertion, 2)
    }
    columnConfiurationDropdownTextVerification() {
        cy.get(columnConfiurationDropdown).invoke('text').should('eq', knowledgeColumnsDropdown)
    }
    dataGridInKnowledgeDashboardVerification() {
        cy.wait(3000)
        cy.get(knowledgeNameColumn).scrollIntoView().should(assertionConstants.beVisibleAssertion);
        cy.get(modalityNameColumn).scrollIntoView().should(assertionConstants.beVisibleAssertion);
        cy.get(tagsColumn).scrollIntoView().should(assertionConstants.beVisibleAssertion);
        cy.get(noOfAssociationColumn).scrollIntoView().should(assertionConstants.beVisibleAssertion);
        cy.get(versionsColumn).scrollIntoView().should(assertionConstants.beVisibleAssertion);
        cy.get(knowledgeStateColumn).scrollIntoView().should(assertionConstants.beVisibleAssertion);
        cy.get(modifiedByColumn).scrollIntoView().should(assertionConstants.beVisibleAssertion);
        cy.get(modifiedonColumn).click().should(assertionConstants.beVisibleAssertion);
    }
    deletePatternWF() {
        cy.readFile(filePath).then(function (result) {
            let PatternName = result.name;
            cy.get("#" + PatternName + " > #nav-dropdown-btn > .ng-star-inserted > #Layer_1").click()
            cy.get(deleteButtonInKnowledgeRecord).click({ force: true });
            cy.get(okButton).click()
        });
    }
    workflowSequencialNumberVerification() {
        cy.get(breadCumb).last().invoke('text').then((value) => {
            cy.wait(2000)
            arr1.length = 0
            arr1.push(value.slice(15, 17))
            cy.log(arr1[0] - 1)
            cy.get('section[id="Authoring_WF112' + (arr1[0] - 1) + '"] a').invoke('text').then((value2) => {
                arr2.length = 0
                cy.wait(2000)
                arr2.push(value2.slice(14, 16))
            });
            cy.log(arr1)
            cy.log(arr2)
            if (arr1 >= arr2) {
                cy.log("Workflow created properly with incremented WF number");
            }
            else {
                cy.log("Workflow not created properly");
            }
        });

    }
    newWFNavigationInKnowledgeVerification() {
        cy.get(breadCumb).eq(2).invoke('text').should('eq', 'My Knowledge')
    }
    addKnowledgeHyperLinkClick() {
        cy.get(addKnowledgeHyperLink).click()
    }
    dashboardNavigationVerification() {
        cy.get(breadCumb).last().invoke('text').should('eq', 'Dashboard')
    }
    crossButtonClickAndNameEnter() {
        cy.readFile(filePath).then( ()=> {
            cy.get(crossButton).click({force: true})
           
        });

    }
    deleteButtonClick() {
        cy.get(deleteButtonInKnowledgeRecord).click()
        cy.get(okButton).click()
    }
    renameButtonClick() {
        cy.get(renameButtonInKnowledgeRecord).click()
    }
    buttonsInRecordsThreeDotsVisible() {
        cy.get(renameButtonInKnowledgeRecord).should(assertionConstants.beVisibleAssertion)
        cy.get(deleteButtonInKnowledgeRecord).should(assertionConstants.beVisibleAssertion)
    }
    threeDotsOfKnowledgeLastRecordClick() {
        cy.get(threeDotsOfKnowledgeRecords).last().click()
    }
    threeDotsOfKnowledgeRecordsVisible() {
        cy.get(threeDotsOfKnowledgeRecords).each(($el) => {
            cy.wrap($el).should(assertionConstants.beVisibleAssertion)
        })
    }
    addKnowledgePlusIconVisible() {
        return cy.get(addKnowledge).should(assertionConstants.beVisibleAssertion)
    }
    changeEntriesPerPageCountVerification() {
        cy.get(changeEntriesPerPageCount).should(assertionConstants.beVisibleAssertion)
        cy.get(changeEntriesPerPageCount).click()
        cy.get(changeEntriesPerPageCount).click()
    }
    modalityInKnowledgeDashboardVerification() {
        cy.get(modalityInKnowledgeDashboard).should(assertionConstants.beVisibleAssertion)
    }
    knowledgeOverlayPopUpDetailsVerification() {
        cy.get(knowledgeNameInOverlay).should(assertionConstants.beVisibleAssertion)
    }
    closeIconInOverlayClick() {
        return cy.get(closeIconInOverlay).click()
    }
    FirstRecordClick() {
        return cy.xpath(FirstRecord).click()
    }
    knowledgeResultClick() {
        return cy.get(knowledgeResult).eq(0).scrollIntoView().click({ force: true })
    }
    columnSelection() {
        cy.get(columnSelection).click()
        cy.get(knowledgeUnselectedColumns).each(($el) => {
            cy.wrap($el).click()
        })
    }
    gridColumnsVerification() {
        cy.get(gridColumns).each(($el) => {
            cy.wrap($el).click().should(assertionConstants.beVisibleAssertion)
        })
    }
    byDefaultModalityVisible() {
        return cy.xpath(byDefaultModality).should(assertionConstants.beVisibleAssertion)
    }
    saveAsDraftButtonClick() {
        return cy.get(saveAsDraftButton).click({ force: true })
    }

    addSolutionButtonClick() {
        return cy.get(addSolutionButton).click()
    }

    addCauseButtonClick() {
        return cy.get(addCauseButton).click()
    }
    causeAndSolutionSectionClick() {
        return cy.xpath(causeAndSolutionSection).click()
    }
    breadcumbLastValue() {
        cy.get(breadcumbLastValue)
    }
    firstKnowledgeRecordClick() {
        cy.xpath(firstrecord).scrollIntoView().click({ force: true })
    }
    deleteButtonVerificationInRecords() {
        return cy.get(deleteButtonInRecord).should(assertionConstants.beVisibleAssertion)
    }
    buttonsVerificationInRecords() {
        cy.get(publishButtonInRecord).should(assertionConstants.beVisibleAssertion)
        return cy.get(deleteButtonInRecord).should(assertionConstants.beVisibleAssertion)
    }
    firstKnowledgeRecordThreeDotsClick() {
        cy.get(firstKnowledgeRecordThreeDots).last().click({ force: true })
    }
    differentValueSelectionFromEnterPerPageDropdown() {
        cy.get(entriesPerPagesCount).first().click()
    }
    entriesPerPageValidation() {
        cy.get(pageCount).click()
        cy.get(entriesPerPagesCount).each(($el) => {
            cy.wrap($el).should(assertionConstants.beVisibleAssertion)
        })
    }
    previousPageMovedVerification() {
        cy.get(showingResults).invoke('text').should('include', ' Showing 1 ')
    }
    previousPageIconClick() {
        return cy.get(previousPageIcon).click()
    }
    nextPageMovedVerification() {
        cy.get(showingResults).invoke('text').should('include', ' Showing 2 ')
    }
    previousPageIconVisible() {
        return cy.get(previousPageIcon).should(assertionConstants.beVisibleAssertion)
    }
    nextPageIconVisible() {
        return cy.get(nextPageIcon).should(assertionConstants.beVisibleAssertion)
    }
    nextPageIconClick() {
        return cy.get(nextPageIcon).click()
    }
    modifiedOnColumnDESCVisible() {
        cy.get(modifiedOnColumnn).click()
        cy.get(modifiedOnColumnn).click()
        return cy.get(modifiedOnColumnDESC).should(assertionConstants.beVisibleAssertion)
    }
    knowledgePreSelectedColumnsVerification() {
        cy.get(selectedColumns).each(($el) => {
            cy.wrap($el).should(assertionConstants.beVisibleAssertion)
        })
        cy.contains(knowledgeColumnsDropdown).click({ force: true })
    }
    showingResultsVisible() {
        return cy.get(showingResults).should(assertionConstants.beVisibleAssertion)
    }
    entriesPerPageVisible() {
        return cy.get(entriesPerPage).should(assertionConstants.beVisibleAssertion)
    }
    knowledgeColumnsDropdownVisible() {
        cy.contains(knowledgeColumnsDropdown).click({ force: true })
        cy.get(selectedColumns).each(($el) => {
            cy.wrap($el).should(assertionConstants.beVisibleAssertion)
        })
        cy.get(unSelectedColumns).each(($el) => {
            cy.wrap($el).should(assertionConstants.beVisibleAssertion)
        })
    }
    advanceFilterHyperlinkVisible() {
        return cy.get(advanceFilterHyperlink).should(assertionConstants.beVisibleAssertion)
    }
    deleteButtonInKnowledgeDashboardVisible() {
        return cy.get(deleteButtonInKnowledgeDashboard).should(assertionConstants.beVisibleAssertion)
    }
    navigationPanelVerification() {
        cy.get(navigationPanelIcon).click()
        cy.get(navigationPanelText).should(assertionConstants.beVisibleAssertion)
        cy.get(navigationPanelIcon).click()
    }
    knowledgedashboardHeadingVisible() {
        return cy.xpath(knowledgeOutsideClickToGetResults).should(assertionConstants.beVisibleAssertion)
    }
    tagsValueValidationForMyknowledge() {
        cy.get(descriptionIconValidationForMyknowledge).eq(3).should(assertionConstants.beVisibleAssertion)
    }
    causesAndSolutionValueValidationForMyknowledge() {
        cy.get(descriptionIconValidationForMyknowledge).eq(2).should(assertionConstants.beVisibleAssertion)
    }
    symptomIconValidationForMyknowledge() {
        cy.get(descriptionIconValidationForMyknowledge).eq(1).should(assertionConstants.beVisibleAssertion)
    }
    descriptionIconValidationForMyknowledge() {
        cy.get(descriptionIconValidationForMyknowledge).eq(0).should(assertionConstants.beVisibleAssertion)
        return cy.get(descriptionValueValidation).should(assertionConstants.beVisibleAssertion)
    }
    tableFirstRecordClick() {
        return cy.xpath(tableFirstRecord).eq(0).click({ force: true })
    }
    backArrowClick() {
        return cy.get(backArrow).click()
    }
    knowledgeDashboardNavigationVerification() {
        return cy.get(knowledgeDashboardNavigationVerification).should(assertionConstants.beVisibleAssertion)
    }
    closeButtonClick() {
        return cy.get(closeButton).click()
    }
    symptomsSectionClick() {
        return cy.xpath(symptomsSection).click()
    }
    symptomCollapsedVerification() {
        return cy.get(symptomCollapsedVerification).should('have.attr', 'class').should('not.include', 'pt-expanded')
    }
    descriptionCollapsedVerification() {
        return cy.get(descriptionCollapsedVerification).should('have.attr', 'class').should('not.include', 'pt-expanded')
    }
    descriptionSectionClick() {
        return cy.xpath(descriptionSection).click()
    }
    causeAndSolutionDescriptionVisible() {
        return cy.get(causeAndSolutionDescription).should(assertionConstants.beVisibleAssertion)
    }
    causeAndSolutionNameVisible() {
        return cy.get(causeAndSolutionName).eq(0).should(assertionConstants.beVisibleAssertion)
    }
    
    symptomDescriptionVisible() {
        return cy.get(symptomsValueValidation).should(assertionConstants.beVisibleAssertion)
    }
    symptomNameVisible() {
        return cy.get(symptomName).eq(0).should(assertionConstants.beVisibleAssertion)
    }
    descriptionDetailsVisible() {
        return cy.get(descriptionDetails).should(assertionConstants.beVisibleAssertion)
    }
    tagsValueValidation() {
        cy.get(tagsIconValidation).eq(3).should(assertionConstants.beVisibleAssertion)
    }
    causesAndSolutionValueValidation() {
        cy.get(causesAndSolutionIconValidation).eq(2).should(assertionConstants.beVisibleAssertion)
        return cy.get(causesAndSolutionValueValidation).first().should(assertionConstants.beVisibleAssertion)
    }
    symptomsIconAndValueValidation() {
        cy.get(symptomsIconValidation).eq(1).should(assertionConstants.beVisibleAssertion)
    }
    descriptionIconAndValueValidation() {
        cy.get(descriptionIconValidation).eq(0).should(assertionConstants.beVisibleAssertion)
        return cy.get(descriptionValueValidation).should(assertionConstants.beVisibleAssertion)
    }
    closeButtonVisibleAsEnabled() {
        return cy.get(closeButton).should(assertionConstants.beVisibleAssertion)
    }
    deleteButtonVisibleAsDisabled() {
        return cy.get(deleteButton).should(assertionConstants.beVisibleAssertion)
    }
    screenExpandIconVisible() {
        return cy.get(screenExpandIcon).should(assertionConstants.beVisibleAssertion)
    }
    draftIconVisible() {
        return cy.get(draftIcon).should(assertionConstants.beVisibleAssertion)
    }
    versionDetailsVisible() {
        return cy.get(versionDetails).should(assertionConstants.beVisibleAssertion)
    }
    knowledgeNameVisible() {
        return cy.get(knowledgeName).should(assertionConstants.beVisibleAssertion)
    }
    knowledgeDetailsVisible() {
        return cy.get(knowledgeDetails).should(assertionConstants.beVisibleAssertion)
    }
    tagSectionVisible() {
        return cy.xpath(tagSection).should(assertionConstants.beVisibleAssertion)
    }
    symptomsSectionVisible() {
        return cy.xpath(symptomsSection).should(assertionConstants.beVisibleAssertion)
    }
    causeAndSolutionSectionVisible() {
        return cy.xpath(causeAndSolutionSection).should(assertionConstants.beVisibleAssertion)
    }
    AssociationSectionVisible() {
        return cy.xpath(AssociationSection).should(assertionConstants.beVisibleAssertion)
    }
    descriptionSectionVisible() {
        return cy.xpath(descriptionSection).should(assertionConstants.beVisibleAssertion)
    }
    knowledgeRecordClick() {
        return cy.xpath(tableFirstRecord).eq(0).click()
    }
    addedTagNotAvailableInWithoutKeywordDropdownVerification() {
        cy.get(addTag).invoke('text').then((value) => {
            arr.push(value)
        })
        cy.get(keywordDropdownVisibleInTagSection).click()
        cy.get(dropdownValuesVerification).eq(0).click()
        cy.get(operatorDropdownVisibleInTagSection).click()
        cy.get(dropdownValuesVerification).eq(0).click()
        cy.get(valueDropdownVisibleInTagSection).click()
        cy.get(dropdownValuesVerification).each(($el) => {
            cy.wrap($el).should('not.include.text', arr[0])
        });
        cy.get(valueDropdownVisibleInTagSection).click()
    }
    addedTagNotAvailableInDropdownVerification() {
        cy.get(searchTextBox).click()
        cy.get(addTagFromList).eq(0).invoke('text').then((value) => {
            arr.push(value)
        })
        cy.get(addTagFromList).eq(0).click()
        cy.get(addTagOkButton).click()
        cy.get(searchTextBox).click()
        cy.log(arr)
        cy.get(addTagFromList).each(($el) => {
            cy.wrap($el).should('not.include.text', arr[0])
        });
        cy.get(searchTextBox).click()
    }
    addTagsButtonClick() {
        return cy.get(addTagsButton).click()
    }
    tagSectionClick() {
        return cy.xpath(tagSection).click()
    }
    selectCauseClick() {
        return cy.get(selectCause).click()
    }
    selectButtonClick() {
        return cy.get(ButtonVisible).eq(1).click()
    }
    firstRecordClick() {
        return cy.get(firstRecord).eq(0).click()
    }
    addKnowledgeClick() {
        return cy.get(addKnowledge).click()
    }
    myKnowledgeDashboardClick() {
        return cy.get(knowledgeDashboard).eq(2).click()
    }
    myKnowledgeClick() {
        return cy.get(myKnowledgeTab).click()
    }
    clearAllFiltersClick() {
        cy.get(clearAllFilters).click()
    }
    filteredDataVerificationForDate() {
        cy.get(modifiedOnColumn).eq(0).click()
        cy.get(monthPicker).invoke('text').then((value) => {
            arr.push(value)
        })
        cy.xpath(knowledgeOutsideClickToGetResults).click()
        filteredValue = arr.slice(0, 3)
        cy.get(allDataPresentInTableVerification).invoke('text').should('include', filteredValue)

    }
    calenderDateSelection() {
        cy.get(datePicker).click({ force: true })
        cy.get(calenderDateSelection).eq(8).click()
        cy.get(calenderDateSelection).eq(20).click()
        cy.xpath(knowledgeOutsideClickToGetResults).click()
    }
    modifiedOnColumnClick() {
        cy.get(modifiedOnColumn).eq(0).click()
    }
    crossIconClickInNoOfAssociationSearch() {
        return cy.get(crossIcon).eq(1).click({ force: true })
    }
    filteredDataVerificationInDropdownColumn() {
        return cy.get(allDataPresentInTableVerification).invoke('text').should('include', dxrModality)
    }
    applyFilterButtonClick() {
        return cy.contains('Apply').last().click()
    }
    modalityDropdownValueSelectionClick() {
        cy.get(modalityDropdownValueSelection).eq(0).invoke('text').as('valueName')
        cy.get(modalityDropdownValueSelection).eq(0).click()
        cy.get(modalityDropdownValueSelection).eq(1).click()
    }
    modalityColumnClick() {
        return cy.get(modalityColumn).eq(0).click()
    }
    noOfAssociationsSearchValueType() {
        return cy.get(noOfAssociationsSearchFilter).click().type('testing{enter}')
    }
    allDataPresentInTableVerification() {
        return cy.get(allDataPresentInTableVerification).should(assertionConstants.haveLengthGreaterThanAssertion, 1)
    }
    crossIconClick() {
        return cy.get(crossIcon).eq(0).click({ force: true })
    }
    filteredDataVerification() {
        return cy.get(filteredDataVerification).invoke('text').should('include', textTypeInSearchBox)
    }
    knowledgeNameSearchValueType() {
        return cy.get(knowledgeNameSearchFilter).click().type('Test{enter}')
    }
    dropdownFilterColumnsVisible() {
        cy.get(dropdownFilterColumns).each(($el) => {
            cy.wrap($el).click()
        })
    }
    noOfAssociationsSearchFilterVisible() {
        return cy.get(noOfAssociationsSearchFilter).should(assertionConstants.beVisibleAssertion)
    }
    knowledgeNameSearchFilterVisible() {
        return cy.get(knowledgeNameSearchFilter).should(assertionConstants.beVisibleAssertion)
    }
    knowledgeOutsideClickToGetResults() {
        return cy.xpath(knowledgeOutsideClickToGetResults).click()
    }
    knowledgeUnselectedColumnsClick() {
        cy.get(knowledgeUnselectedColumns).each(($el) => {
            cy.wrap($el).click()
        })
    }
    knowledgeClick() {
        return cy.get(knowledgee).click()
    }
    knowledgeDashboardClick() {
        return cy.get(knowledgeDashboard).eq(1).click()
    }
    knowledgeColumnsDropdownClick() {
        return cy.contains(knowledgeColumnsDropdown).click({ force: true })
    }

    scrollElement() {
        cy.get(newScrollElement).scrollIntoView()
    }

    knowledgeDashboardSelected(){
        cy.get(knowledgeDashboard).eq(1).find('div').first().should(assertionConstants.haveAttributeAssertion,'class',"p-treenode-content p-treenode-selectable p-highlight")
    }

    firstKnowledgeSelect(){
        cy.get(knowledge).last().find('tr').eq(0).find('td').eq(1).click()
    }

    crossIconVisible(){
        cy.get(crossIcon).should(assertionConstants.beVisibleAssertion)
    }

    editButtonVisible(){
        cy.get(editButton).should(assertionConstants.beVisibleAssertion)
    }

    viewButtonVisible(){
        cy.get(viewButton).should(assertionConstants.beVisibleAssertion)
    }

    viewButtonClick(){ 
        cy.get(viewButton).click() 
    }

    secondKnowledgeSelect(){
        cy.get(knowledge).last().find('tr').eq(1).find('td').eq(1).click()
    }

    knowledgeDetailsOnRightSideVisible(){
        cy.get(knowledgeNameOnRightSide).should(assertionConstants.beVisibleAssertion)
        cy.get(KnowlegeDetailsSection).should(assertionConstants.beVisibleAssertion)
    }

    knowledgeDetailsPageVisibel(){
        cy.get(knowledgeDetailsPage).should(assertionConstants.beVisibleAssertion)
    }

    KnowledgeDashboardSelect(){
        cy.get(knowledgeDashboard).eq(2).click()
    }

    searchIconClicked() {
        cy.get(searchIcon).first().click()
    }

    searchedSecondKnowledgeClick(){
        cy.get(secondKnowledge).eq(11).find('span').first().click() 
    
    }

    checkBoxToSelectAllModalitiesClick(){
        cy.get(checkBoxToSelectAllModalities).click()
    }

    publishButtonClick(){
        cy.get(publishButton).click()
    }

    popUpOkButtonClick(){
        cy.get(okButton).click()
    }

    threeDotsOfKnowledgeOnKnowledgeDashboardClick(){
        cy.get(threeDotsOfKnowledgeOnKnowledgeDashboard).eq(0).click()
    }

    editButtonOnKnowledgeDashboardPageVisible(){
        cy.get(editButtonOnKnowledgeDashboardPage).should(assertionConstants.beVisibleAssertion)
    }

    editButtonOnKnowledgeDashboardPageClick(){
        cy.get(editButtonOnKnowledgeDashboardPage).click()
    }

    editedKnowledgeInPatternDashboardPageVisible(){
        cy.get(editedKnowledge).should(assertionConstants.beVisibleAssertion)
    }

    editedKnowledgeInDraftState(){
        cy.get(editedKnowledgeInDraftState).eq(6).find('span').first().should(assertionConstants.haveTextAssertion,'Draft ')
    }

    editButtonOnKnowledgeDetailsPageClick(){
        cy.get(editButtonOnKnowledgeDetailsPage).click()
    }

    FirstRecordRightClick() {
        return cy.xpath(FirstRecord).rightclick()
    }

    selectingAllModalitiesAndApplyButtonClicked(){
        cy.get(modalityColumn).eq(0).click()
        cy.get(modalityColumn).eq(0).click()
        cy.get(checkBoxToSelectAllModalities).click()
        cy.contains('Apply').last().click()
        cy.wait(1000)
        cy.get(searchIcon).first().click()
        cy.wait(1000)
    }


    knowledgeSearchOptionType(){
        cy.get(knowledgeSearchOption).first().type('knowledgeNormal')
    }
    
    searchIconForKnowledgeNameClick(){
        cy.get(searchIconForKnowledgeName).first().click({force: true})
    }
    
    searchedKnowledgeClick(){
        cy.get(knowledgeList).eq(1).find('span').first().click() 
    
    }
    
    knowledgePublishOptionClick(){
        cy.get(knowledgePublishOption).click({force: true})
    }
    
    okButtonButtonInPopUpClick(){
        cy.get(okButton).click()
    }
    
    searchedKnowledgeNameRemoveOptionClick(){
    cy.get(clearKnowledgeNameOption).first().click()
    }
    
    //    knowledgesFirstRowRightClick(){
    //     cy.get(knowledgeList).eq(1).rightclick()
    //    }  
    
    rowLevelThreeDotsClick(){
    cy.get(rowLevelThreeDots).first().then((el)=>{
    cy.wrap(el).click({force: true})
    })
    }
    
    deleteOptionInsideSubMenuVisible(){
    cy.get(deleteButtonInRecord).should(assertionConstants.beVisibleAssertion)
    }
    
    checkBoxSelectingKnowledgeWithOutAssociationClick(){
    cy.get(checkBoxSelectingFirstKnowledge).eq(1).click()
    }
    
    
    deleteButtonInKnowledgeDashboardEnabled() {
    return cy.get(deleteButtonInKnowledgeDashboard).should(assertionConstants.notBeDisabledAssertion)
    }
    
    deleteOptionInsideSubMenuEnabled(){
    cy.get(deleteButtonInRecord).should(assertionConstants.notBeDisabledAssertion)
    }
    
    deleteButttonWhenClickedOnlinkEnabled(){
    cy.get(deleteButtonWhenClickedOnlink).should(assertionConstants.notBeDisabledAssertion)
    }
    
    
    unselectingFirstKnowledge(){
    cy.get(checkedFirstbox).click()
    }
    
    checkBoxSelectingKnowledgeHavingAssociationClick(){
    cy.get(checkBoxSelectingFirstKnowledge).eq(2).click()
    }
    
    deleteButtonInKnowledgeDashboardDisabled() {
    cy.get(deleteButtonInKnowledgeDashboard).should(assertionConstants.haveAttributeAssertion, 'class','topbtns pt-button ng-star-inserted opacity-05')
    }
    
    deleteOptionInsideSubMenuDisabled(){
    cy.get(deleteButtonInRecord).should(assertionConstants.notBeEnabledAssertion)
    }
    
    
    deleteButttonWhenClickedOnlinkDisabled(){
    cy.get(deleteButtonWhenClickedOnlink).should(assertionConstants.haveAttributeAssertion, 'class','ml-2 opacity-05 pt-button ng-star-inserted')
    }
    
    deleteButtonUnderThreeDotsDisabled(){
        cy.get(deleteButtonUnderThreeDots).should(assertionConstants.notBeEnabledAssertion)
    }

    deleteButtonUnderThreeDotsVisible(){
        cy.get(deleteButtonUnderThreeDots).should(assertionConstants.beVisibleAssertion)
    }

    deleteButtonUnderThreeDotsVisible(){
        cy.get(deleteButtonUnderThreeDots).should(assertionConstants.notBeDisabledAssertion)
    }

    rowLevelThreeDotsForAssociatedKnowledgeClick(){
        cy.get(rowLevelThreeDots).eq(1).then((el)=>{
        cy.wrap(el).click()
        })
    }


   
    selectingPublishedKnowledges(){
        cy.get(checkBoxSelectingFirstKnowledge).eq(3).click() 
    }

    cancelButtonClick() {
        cy.get(popUpcancelButton).click()
    }

    confirmationPopUpHeaderForDeletingPublishedJnowledgeVisible() {
        cy.get(confirmationPopUpHeader).should(assertionConstants.containAssertion, 'The below  1 knowledge(s) will be deleted. Are you sure you want to proceed?').and(assertionConstants.beVisibleAssertion)
    }

    publishedKnowledgeVisible(){
        cy.get(knowledgeListTable).then((list)=>{
          expect(list).to.contain(patternNames[0])
        })
    }

    // publishedKnowledgeNotExist(){
    //     cy.contains(nameOfSecondKnowledge).should(assertionConstants.notExistsAssertion)
    // }

    checkBoxSelectingDraftKnowledgeClick(){
        cy.get(checkBoxSelectingFirstKnowledge).eq(2).click()
    }

    deleteButtonUnderThreeDotsClick(){
        cy.get(deleteButtonUnderThreeDots).click()
    }

    deleteButttonWhenClickedOnlinkClick(){
        cy.get(deleteButtonWhenClickedOnlink).click()
    }

    noResultsFoundInRelevanceMessageVisible() {
        cy.contains(noResultsFoundInRelevanceMessage).scrollIntoView().should(assertionConstants.beVisibleAssertion);
    }

    firstKnowledgeRightClick() {
        return cy.get(firstKnowledge).eq(1).rightclick()
    }

    myPatternDropArrowClick() {
    return cy.get(myPatternDropArrow).eq(1).click()
    }

    pageCountDropArrowClick(){
    cy.get(pageCount).click()
    }

    tenRecordsInKnowledgenDashBoard() {
    cy.get(recordsInKnowledgeDashBoard).should(assertionConstants.havelengthAssertion, '10')
    }


    selectingFirstFiveKnowledges(){
    cy.get(checkBoxSelectingFirstKnowledge).eq(1).click()
    cy.get(checkBoxSelectingFirstKnowledge).eq(1).click()
    cy.get(checkBoxSelectingFirstKnowledge).eq(1).click()
    }
       
    deleteButtonInKnowledgeDashboardClick() {
    cy.get(deleteButtonInKnowledgeDashboard).click({force:true})
    }    

    confirmationPopUpHeaderVisible() {
    cy.get(confirmationPopUpHeader).should(assertionConstants.containAssertion, 'The below  3 knowledge(s) will be deleted. Are you sure you want to proceed?').and(assertionConstants.beVisibleAssertion)
    }

    knowledgeNamesOnPopUpVisible(){
    cy.get(knowledgeNamesOnPopUp).invoke('text').then((knowledgeNames)=>{
        knowledgeNamesArrey.push(knowledgeNames)
        expect(knowledgeNames).to.exist
       })
    }

    cancelButtonVisible() {
    cy.get(popUpcancelButton).should(assertionConstants.beVisibleAssertion)
    }

    deleteButtonOnPopUpVisible() {
    cy.get(okButtonOnPopUp).should(assertionConstants.beVisibleAssertion)
    }

    deleteButtonOnPopUpClick() {
    cy.get(okButtonOnPopUp).click()
    }

    knowledgesDeletedMessageVisible(){
    cy.contains(knowledgeDeletedMessage).should(assertionConstants.beVisibleAssertion)
    }

    patternDashboardColumnFirstRecordClick() {
        cy.xpath(patternStateRecords2).click();
    }

    deleteButtonUnderThreeDotsClick(){
        cy.get(deleteButtonUnderThreeDots).click({force: true})
    }

    modalityOptionClick(){
        cy.get(modalityOption).eq(3).click() 
    }
}

export default KnowledgeDashboard;
