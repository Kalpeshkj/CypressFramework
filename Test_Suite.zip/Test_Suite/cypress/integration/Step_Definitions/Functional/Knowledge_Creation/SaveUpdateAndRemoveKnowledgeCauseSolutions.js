/// <reference types="Cypress" /> 
/// <reference types='cypress-tags' />

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';

import KnowledgeDashboard from "../../../../support/pageObjects/pages/Knowledge_Dashboard/KnowledgeDashboard";
const knowledgeDashboard = new KnowledgeDashboard();
import CreateKnowledge from "../../../../support/pageObjects/pages/KnowledgeAuthoring/CreateKnowledge";
const createKnowledge = new CreateKnowledge();
const filePath = 'cypress/fixtures/patternNameCreation.json'

var arr = []

When("User expands knowledge and clicks on add knowledge", () => {
    knowledgeDashboard.knowledgeClick()
    knowledgeDashboard.addKnowledgeClick()
    console.log(printTimestamp(), ' Knowledge expanded and add knowledge clicked')
});

Then("User should be navigated to new workflow", () => {
    knowledgeDashboard.knowledgeStepsVisible()
    console.log(printTimestamp(), ' Navigated to new workflow')
});

When("User imports existing cause from Select Cause", () => {
    createKnowledge.ImportCausesAndSolutionInKnowledge()
    console.log(printTimestamp(), ' imported existing cause from Select Cause')
});

Then("User should be able to click on add causes", () => {
    createKnowledge.addCausesButtonClick()
    console.log(printTimestamp(), ' existing cause added')
});

When("User navigates under cause and solution section and clicks on upload file option", () => {
    createKnowledge.fileUploadIconClick()
    console.log(printTimestamp(), ' User navigated under cause and solution section and clicked on upload file option')
});

Then("User should be able to upload image or pdf file by drag and drop option", () => {
    createKnowledge.browseFileIconClick().attachFile('SampleFile.pdf')
    console.log(printTimestamp(), ' pdf file uploaded')
});

And("User click on save as draft button", () => {
    createKnowledge.saveAsDraftClick()
    console.log(printTimestamp(), ' Save as draft button clicked')
});

When("User clicks on the Remove X button available at the right top of the section", () => {
    createKnowledge.crossMarkIconClick()
    console.log(printTimestamp(), ' Remove X button clicked')
});

Then("Confirmation pop up of deletion should displayed and cause should be removed from UI", () => {
    createKnowledge.confirmationPopupClick()
    console.log(printTimestamp(), ' Confirmation pop up of deletion displayed')
});

And("User should add or update new cause", () => {
    createKnowledge.deleteCause()
    createKnowledge.ImportCausesAndSolutionByAddCauseSection()
    console.log(printTimestamp(), ' Added new cause')
});

When("User click on save as draft button", () => {
    createKnowledge.saveAsDraftClick()
    console.log(printTimestamp(), ' save as draft button clicked')
});

And("Edit an already added cause and Solution and change the description Content", () => {
    createKnowledge.editCausesAndSolution()
    console.log(printTimestamp(), ' already added cause and Solution edited')
});

When("User adds new cause and Solution", () => {
    createKnowledge.ImportCausesAndSolutionByAddCauseSection()
    console.log(printTimestamp(), ' New cause and Solution added')
});

Then("The cause and solution section should be in editable mode", () => {
    createKnowledge.addedCauseAreEditableVerification()
    console.log(printTimestamp(), '  cause and solution section was in editable mode')
});

When("User navigate to other workflow and come back to the current", () => {
    createKnowledge.saveAsDraftClick()
    cy.wait(3000)
    console.log(printTimestamp(), ' User navigated to other workflow and came back to the current')
});

And("User clicks on Workflow delete", () => {
    cy.DeleteWorkflow()
    console.log(printTimestamp(), ' Workflow deleted')
});