
import "../../../../support/index";
import { Given} from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();
import Constants from "../../../../support/pageObjects/pages/PatternAuthoring/constants";
const constants = new Constants();
var arr = [];

Given("DAW Application is available", () => {
    cy.visit(Cypress.env("URL"));
    console.log(printTimestamp(), constants.applicationLaunched)
});

Given("DAW Application Is Available", () => {
    cy.SSO_LOGIN();
    console.log(printTimestamp(), constants.applicationLaunched)
});

And("Close Application", () => {
    cy.log("Application closed successfully")
    console.log(printTimestamp(), constants.applicationLaunched)
});
And("Close DAW application", () => {
    cy.DeleteWorkflow()
    cy.log(constants.testCaseExecuted)
    console.log(printTimestamp(), constants.testCaseExecuted)
});

And("close DAW application", () => {
    createPattern.cancelButtonClick()
    cy.DeleteWorkflow()
    cy.log(constants.testCaseExecuted)
    console.log(printTimestamp(), constants.testCaseExecuted)
});