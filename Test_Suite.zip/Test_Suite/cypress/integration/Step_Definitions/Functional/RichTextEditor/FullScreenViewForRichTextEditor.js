/// <reference types="Cypress" /> 
/// <reference types = 'cypress-tags' />    
import "../../../../support/index"
import PatternDashboard from "../../../../support/pageObjects/pages/Dashboard/PatternDashboard";
const patternDashboard = new PatternDashboard();
import CreateKnowledge from "../../../../support/pageObjects/pages/KnowledgeAuthoring/CreateKnowledge";
const createKnowledge = new CreateKnowledge();
import { printTimestamp } from '../../../../support/commands';


Then("Pattern Dashboard page should be displayed", () => {
    patternDashboard.patternDashboardTitleVisible()
    cy.wait(2000)
    console.log(printTimestamp(), 'Pattern Dashboard page displayed')
});

And("User create new Authoring Workflow", () => {
    createKnowledge.knowledgeClick()
    // createKnowledge.MyknowledgeArrowClick()
    createKnowledge.AddAuthoringWokFlowButtonClick()
    cy.wait(3000)
    createKnowledge.workFlowMessageVisible()
    console.log(printTimestamp(), 'New Authoring Workflow Created')
});

When("Expand Cause and Solution section", () => {
    createKnowledge.causeAndSolutionSectionClick()
    console.log(printTimestamp(), 'Expanded Cause and Solution section')
});

And("Click on Add Cause", () => {
    createKnowledge.addCauseClick()
    console.log(printTimestamp(), 'Clicked on Add Cause')
});

Then("Rich Text Editor should appear", () => {
    createKnowledge.richTextEditorWindowVisible()
    console.log(printTimestamp(), 'Rich Text Editor appeared')
});

When("User Click on Full Screen", () => {
    createKnowledge.fullScreenViewButttonOfRichTextEditorClick()
    console.log(printTimestamp(), 'Clicked on Full Screen')
});

Then("Rich Text should get opened in full screen till breadcrumbs", () => {
    createKnowledge.richTextEditorTillBredcrumb()
    console.log(printTimestamp(), 'Rich Text opened in full screen till breadcrumbs')
});

And("Left pane should get collapsed", () => {
    createKnowledge.leftPaneCollapse()
    console.log(printTimestamp(), 'Left pane collapsed')
});

When("User Click on Full Screen expand left pane", () => {
    createKnowledge.fullScreenViewButtonAfterExpandingClick()
    cy.wait(1000)
    createKnowledge.leftPaneExpanded()
    console.log(printTimestamp(), 'Clicked on Full Screen expand left pane')
});

Then("Rich Text should get resized  in default  screen Left pane should get expanded", () => {
    createKnowledge.leftPaneExpanded()
    console.log(printTimestamp(), 'Rich Text resized in default  screen Left pane expanded')
});

When("User Click on Full Screen available at Cause and Solution level", () => {
    createKnowledge.fullScreenViewButtonAtCauseLevelClick()
    console.log(printTimestamp(), 'Clicked on Full Screen available at Cause and Solution level')
});

Then("Cause and Solution section should get displayed in full screen", () => {
    createKnowledge.causeAndSolutionTextVisible()
    createKnowledge.leftPaneCollapse()
    console.log(printTimestamp(), 'Cause and Solution section should get displayed in full screen')
});

And("Rich Text should get opened in full screen under Cause and Solution section", () => {
    createKnowledge.richTextEditorUnderCauseSectionInFullScreenVisible()
    console.log(printTimestamp(), 'Rich Text gets opened in full screen under Cause and Solution section')
});

When("User Click on Full Screen available at Rich text editor level", () => {
    createKnowledge.fullScreenViewButttonOfRichTextEditorClick()
    console.log(printTimestamp(), 'Clicked on Full Screen available at Rich text editor level')
});

Then("Rich Text should get opened in full screen till breadcrumbs", () => {
    createKnowledge.richTextEditorInFullScreen()
    console.log(printTimestamp(), 'Rich Text opened in full screen till breadcrumbs')
});

When("USer Click on Full Screen available at Rich text editor level", () => {
    createKnowledge.fullScreenViewButttonOfRichTextEditorClick()
    console.log(printTimestamp(), 'Clicked on Full Screen available at Rich text editor level')
});

Then("Causes and Solution section should get displayed in full screen under that Rich Text should get opened in full screen Left pane should get collapsed", () => {
    createKnowledge.causeAndSolutionTextVisible()
    createKnowledge.richTextEditorUnderCauseSectionInFullScreenVisible()
    createKnowledge.leftPaneCollapse()
    console.log(printTimestamp(), 'Causes and Solution section displayed in full screen under that Rich Text opened in full screen Left pane get collapsed')
})

When("User Click on Full Screen available at Causes and Solutions level or expand left pane", () => {
    createKnowledge.fullScreenViewButtonAtCauseAndSolutionLavelAterExpandingClick()
    console.log(printTimestamp(), 'Clicked on Full Screen available at Causes and Solutions level or expand left pane')
});

Then("Cause and Solution section should get resized in default screen", () => {
    createKnowledge.leftPaneExpanded()
    console.log(printTimestamp(), 'Cause and Solution section resized in default screen')
});

And("Rich Text should get resized  in default  screen", () => {
    createKnowledge.leftPaneExpanded()
    console.log(printTimestamp(), 'Rich Text resized  in default  screen')
});

And("Left pane should get expanded", () => {
    createKnowledge.leftPaneExpanded()
    console.log(printTimestamp(), 'Left pane expanded')
});

Then("close DAW Application", () => {
    cy.DeleteWorkflow()
    cy.log("Test Case Executed Successfully")
    console.log(printTimestamp(), ' Test Case Executed Successfully')
});
