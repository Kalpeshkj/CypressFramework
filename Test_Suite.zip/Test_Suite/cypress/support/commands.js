import 'cypress-file-upload';
import PatternDashboard from "../support/pageObjects/pages/Dashboard/PatternDashboard";
const patternDashboard = new PatternDashboard();
import CreatePattern from "../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();
import CreateKnowledge from "../support/pageObjects/pages/KnowledgeAuthoring/CreateKnowledge";
const createKnowledge = new CreateKnowledge();
import IncludeKnowledge from "../support/pageObjects/pages/PatternAuthoring/includeKnowledgepageObj";
const includeKnowledge = new IncludeKnowledge();
import KnowledgeDashboard from "../support/pageObjects/pages/Knowledge_Dashboard/KnowledgeDashboard";
const knowledgeDashboard = new KnowledgeDashboard();
import ValidationPage from "../support/pageObjects/pages/PatternAuthoring/ValidatePage";
const validationPage = new ValidationPage();
import ApplyMetadata from "../support/pageObjects/pages/PatternAuthoring/applyMetadata";
const applyMetadata = new ApplyMetadata();

const filePath = 'cypress/fixtures/patternNameCreation.json'
const addTagFromList = 'dls-multiselect-option[role="option"]'
let arr = []
Cypress.Commands.add('SSO_LOGIN', function () {

  const options = {
    username: Cypress.env('username'),
    password: Cypress.env('password'),
    loginUrl: Cypress.env('appUrl'),
    postLoginSelector: '#app-name',
    headless: true,
    logs: false
  }
  cy.task('AzureAdSingleSignOn', options).then(result => {
    cy.clearCookies()

    result.cookies.forEach(cookie => {
      cy.setCookie(cookie.name, cookie.value, {
        domain: cookie.domain,
        expiry: cookie.expires,
        httpOnly: cookie.httpOnly,
        path: cookie.path,
        secure: cookie.secure
      })
      Cypress.Cookies.preserveOnce(cookie.name)
    })
  })
  cy.visit(Cypress.env("appUrl"));
})


Cypress.Commands.add("PatternCreation", () => {
  let x = 'Authoring_WF_Test' + Math.floor((Math.random() * 1000) + 1);
  cy.wait(2000)
  cy.writeFile(filePath, { name: x })
});

Cypress.Commands.add("PatternNameWithInvalidLength", () => {
  let x = 'Authoring_WF_Test'
  for (let i = 0; i < 150; i++) {
    x = x + i
  }
  cy.wait(2000)
  cy.writeFile(filePath, { PatternNameWithInvalidLength: x })
});


Cypress.Commands.add("createPattern", () => {
  createPattern.myPatternThreeDots().eq(1).click();
  // cy.get(':nth-child(2) > .p-treenode > .p-treenode-content > .p-treenode-label > :nth-child(1) > .node-item > #nav-dropdown-btn > .ng-star-inserted > #Layer_1 > path').click()
  createPattern.createPattern().click({ force: true });
  cy.wait(1000)
  createPattern.patternName().click();
  let x = 'Authoring_WF_Test' + Math.floor((Math.random() * 1000) + 1);
  cy.writeFile(filePath, { name: x })
  cy.wait(2000)
  cy.readFile(filePath).then(function (result) {
    let PatternName = result.name;
    createPattern.patternName().type(PatternName);
  });
  createPattern.description().click();
  createPattern.description().type(Cypress.env("PatternDescription"));
  createPattern.importdatamodelTab().click();
  createPattern.importdatamodelDrpdownArrow().click();
  createPattern.importDataModelDrpdownCommon().click();
  createPattern.clickoutsidetoGetResult().click({ force: true });
  createPattern.adConditionTab().click();
  createPattern.addConditionPlusIcon().click({ force: true });
  cy.contains(" From Data Model ").click();
  createPattern.option1Click();
  cy.contains("AdditionalInfo").click({ force: true });
  createPattern.operatorsDropdownClick()
  cy.contains("==").click({ force: true });
  createPattern.valueInputField()
  createPattern.addActionTab().click();
  createPattern.addactionPlusIcon().should("be.visible");
  createPattern.addactionPlusIcon().click({ force: true });
  createPattern.raiseAlert().click({ force: true });
});

Cypress.Commands.add("DeleteDynamicPattern", () => {
  cy.readFile(filePath).then(function (result) {
    let PatternName = result.name;
    cy.get("#" + PatternName + " > #nav-dropdown-btn > .ng-star-inserted > #Layer_1").click({ force: true })
    createPattern.deleteOption().click({ force: true });
    createPattern.okButtonClick()
  });
});


Cypress.Commands.add("DeletePattern", () => {
  createPattern.deleteOption().click({ force: true });
  cy.wait(2000)
  createPattern.okButtonClick()
});


Cypress.Commands.add("DeleteWorkflow", () => {
  createPattern.breadcumbLastValue().last().invoke("text")
    .then((text1) => {
      cy.get(
        "#" + text1 + " > #nav-dropdown-btn > .ng-star-inserted > #Layer_1"
      ).last().click({ force: true })
      createPattern.deleteOption().click({ force: true });
      createPattern.okButtonClick()
    })
})

export const printTimestamp = function printTimestamp() {
  let now = new Date();
  let str = now.toLocaleString();
  let CurrentDate = str.slice();
  return CurrentDate
}

Cypress.Commands.add("DeleteLastPattern", () => {
      cy.get('[id="nav-dropdown-btn"]').last().click()
      createPattern.deleteOption().click({ force: true });
      createPattern.okButtonClick()
    })

export const userID_Alpha_Numeric = function userID_Alpha_Numeric() {
  let text = "";
  let possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  for (let i = 0; i < 10; i++) {
    text += possible.charAt(Math.floor(Math.random() * possible.length));
  }
  return text;
}


Cypress.Commands.add("createIncludeKnowledge", () => {
  createPattern.myPatternThreeDots().eq(1).click();
  createPattern.createPattern().click();
  createPattern.patternName().click();
  let x = 'Authoring_WF_Test' + Math.floor((Math.random() * 100) + 1);
  cy.writeFile(filePath, {name:x})
  cy.wait(2000) 
  cy.readFile(filePath).then(function (result) {
    let PatternName = result.name;
    createPattern.patternName().type(PatternName);
  });
  createPattern.description().click();
  createPattern.description().type(Cypress.env("PatternDescription"));
  createPattern.importdatamodelTab().click();
  createPattern.importdatamodelDrpdownArrow().click();
  createPattern.importDataModelDrpdownCommon().click();
  createPattern.clickoutsidetoGetResult().click({ force: true });
  createPattern.adConditionTab().click();
  createPattern.addConditionPlusIcon().click({ force: true });
  cy.contains(" From Data Model ").click();
  createPattern.option1Click();
  cy.contains("AdditionalInfo").click({ force: true });
  createPattern.operatorsDropdownClick()
  cy.contains("==").click({ force: true });
  createPattern.valueInputField()
  createPattern.addActionTab().click();
  createPattern.addactionPlusIcon().should("be.visible");
  createPattern.addactionPlusIcon().click({ force: true });
  createPattern.raiseAlert().click({ force: true });
  createPattern.nextButtonClick()
  cy.wait(4000)
  createPattern.modalityDropdownfield().eq(0).click({ force: true })
  createPattern.modalityDropdownInApplyMetadataOptionSelection()
  createPattern.dropdownValueClick()
  createPattern.patternTypeDropdown().eq(0).click()
  createPattern.relevanceCheckboxClick()
  createPattern.modalityDropdownfield().eq(2).click({ force: true })
  createPattern.serviceContextFields().eq(0).click();
  cy.wait(2000);
  createPattern.modalityDropdownfield().eq(2).click({ force: true })
  createPattern.modalityDropdownfield().last().click({ force: true })
  createPattern.severityFields().eq(0).click({ force: true })
  createPattern.commentBox().click({ force: true }).type('TestComment')
  createPattern.addTagButton().click();
  createPattern.cancelButton().click({ force: true });
  createPattern.addTagButton().click();
  createPattern.selectTag().click();
  createPattern.addTagFromList().eq(0).click();
  createPattern.addTagOkButton().eq(0).click();
  createPattern.doneButton().click({ force: true });
  createPattern.nextButtonClick()
  createPattern.addKnowledgeButtonClick()
  cy.readFile(filePath).then(function (result) {
    let PatternName = result.name;
    createPattern.patternName().type(PatternName);
  });
  includeKnowledge.saveAsDraftClick()
});

Cypress.Commands.add("ExistingWorkFlowText", () => {
  cy.get('.pt-layout-container > ul > li > a > span').last().invoke("text")
    .then((text1) => {
      arr.push(text1)
      cy.wait(2000)
    })
});


Cypress.Commands.add("ExistingWFClick", () => {
  cy.get('.node-item > #' + arr[0]).click()
})

Cypress.Commands.add("ApplyMetaDetaPageCompletion", () => {
  cy.wait(3000)
  createPattern.modalityDropdownfield().eq(0).click({ force: true })
  createPattern.modalityDropdownInApplyMetadataOptionSelection()
  createPattern.modalityDropdownfield().eq(1).click({ force: true })
  createPattern.patternTypeDropdown().eq(0).click()
  createPattern.relevanceField().eq(0).click();
  createPattern.relevanceCheckboxClick() 
  createPattern.modalityDropdownfield().eq(2).click({ force: true })
  createPattern.serviceContextFields().eq(0).click();
  cy.wait(2000);
  createPattern.modalityDropdownfield().eq(2).click({ force: true })
  createPattern.modalityDropdownfield().last().click({ force: true })
  createPattern.severityFields().eq(0).click({ force: true })
  createPattern.commentBox().click({ force: true }).type('TestComment')
  createPattern.addTagButton().click();
  createPattern.cancelButton().click({ force: true });
  createPattern.addTagButton().click();
  createPattern.selectTag().click();
  createPattern.addTagFromList().eq(0).click();
  createPattern.addTagOkButton().eq(0).click();
  createPattern.doneButton().click({force: true});
  createPattern.clicksOnPopUpOkButton()
  patternDashboard.dashboardButton().eq(0).click();
  createPattern.okButtonClick()
  cy.readFile(filePath).then(function (result) {
    let PatternName = result.name;
    cy.get('#' + PatternName).click()
 
  })
})

Cypress.Commands.add("CreatePatternsTillValidateStageCompletion", (InputValue) => {
  for(let i= 0; i<InputValue ; i++)
  {
    cy.createPattern()
    createPattern.nextButtonClick()
    cy.ApplyMetaDetaPageCompletion()
    createPattern.nextButtonClick()
    createPattern.ShowCheckboxClick()
    createPattern.firstRecordsClickInDashboard()
    createPattern.nextButtonClick()
    createPattern.systemIdSelection()
    createPattern.dateRangeSelectionInIncludeKnowledgeSection()
    cy.wait(3000)
    createPattern.clicksOnPopUpOkButton()
  }
});

Cypress.Commands.add("CreateMyKnowledge", () => {
  createKnowledge.patternNameTextBoxInvalidNameType()
  createKnowledge.decriptionFieldType()
  createPattern.modalityDropdownInApplyMetadata().click()
  createKnowledge.ctModalityOptionClick()
  createKnowledge.symptomsKnowledgeInfoOptionsClick()
  createKnowledge.adsymptomOptionClick()
  createKnowledge.symptomOneTextBoxType()
  createKnowledge.causeAndSolutionOptionClick()
  createKnowledge.addCauseOptionClick()
  createKnowledge.causeOneInputBoxType()
  createKnowledge.addSolutionClick()
  createKnowledge.solutionOneInputBoxType()
  createKnowledge.tagsknowledgeInfoOptionsClick()
  createKnowledge.addTagsOptionClick()
  createKnowledge.selectTagDropdownClick()
  createKnowledge.awsTagsOptionsClick()
  createKnowledge.plusIconInAddtagsClick()
  createKnowledge.doneButtonClickInPopUpClick()         
})

Cypress.Commands.add("AddRemoveExpandCollapseFromRulePattern", () => {
  createPattern.myPatternThreeDotsClick()
  createPattern.createPatternButtonClick()
  cy.wait(2000)
  createPattern.importDataModelClick()
  createPattern.dataModelDropArrowClick()
  createPattern.dataModelCommonOptionDropArrowClick()
  createPattern.eventLogDataModelClick()
  createPattern.dataModelDropArrowClick()
  createPattern.addConditionTabClick()
  createPattern.expandedAddConditionSectionVerification()
  createPattern.addConditionPlusIconClick()
  cy.wait(2000)
  createPattern.rulePatternOptionClick()
  createPattern.showAllCheckboxClick()
  cy.wait(2000)
  createPattern.patternClickForWFCreation()
  createPattern.importButtonClick()

  createPattern.addConditionPlusIconClick()
  cy.wait(2000)
  createPattern.rulePatternOptionClick()
  createPattern.ShowCheckboxClick()
  cy.wait(2000)
  createPattern.patternTwoClick()
  createPattern.importButtonClick()
  createPattern.scrollElement()
  cy.wait(1000)
  createPattern.addConditionPlusIconClick()
  cy.wait(2000)
  createPattern.rulePatternOptionClick()
  createPattern.ShowCheckboxClick()
  cy.wait(2000)
  createPattern.patternTwoClick()
  createPattern.importButtonClick()
  createPattern.scrollElement()
  cy.wait(1000)
  createPattern.addConditionPlusIconClick()
  cy.wait(2000)
  createPattern.rulePatternOptionClick()
  createPattern.ShowCheckboxClick()
  cy.wait(2000)
  createPattern.patternTwoClick()
  createPattern.importButtonClick()
  createPattern.scrollElement()
  cy.wait(1000)
  createPattern.addConditionPlusIconClick()
  cy.wait(2000)
  createPattern.fromVariableOptionClick()
  createPattern.eventOneUnderFromvariableClick()
  createPattern.asIsOptionClick()
  createPattern.operatorDropdownAtEventAndConditionBetweenEventTwoAndThreeForRulePattenClick()
  createPattern.andOperatorOptionsUnderDropdownClick()
  createPattern.operatorDropdownAtEventAndConditionBetweenEventThreeAndFourForRulePattenClick()
  createPattern.andOperatorOptionsUnderDropdownClick()
  createPattern.operatorOptionAboveCopiedEventForEventOneForRulePatternClick()
  createPattern.andOperatorForCopiedEventClick()
  createPattern.autoGeneratedFirstEventVisible()
  createPattern.AutoGeneratedFirstConditionVisible()
  createPattern.addConditionPlusIconVisible()
  createPattern.conditionRemoveButtonVisibleForFormRulePattern()
  createPattern.crossMarkAtEventOneVisible()
  createPattern.groupOptionAtEventDisabled()
  createPattern.saveAsRuleOptionDisabled()
  createPattern.addConditionPlusIconAtC3Click()
  createPattern.fourthConditionInFirstEventVisible()
  createPattern.addConditionPlusIconAtC3Click()
  createPattern.c3ConditionsNameForFirstConditionInRulePattern()
  createPattern.c5ConditionsNameForSecondConditionInRulePattern()
  createPattern.c4ConditionsNameForThirdConditionInRulePattern()
  createPattern.addConditionPlusIconAtC4InRulePatternClick()
  createPattern.c3ConditionsNameForFirstConditionInRulePattern()
  createPattern.c5ConditionsNameForSecondConditionInRulePattern()
  createPattern.c4ConditionsNameForThirdConditionInRulePattern()
  createPattern.c6ConditionsNameForSixthConditionInRulePattern()
  createPattern.conditionRemoveButtonAtConditionC4Click()
  createPattern.eventContainerWithOutConditionFour()
  createPattern.addConditionPlusIconAtC6Click()
  createPattern.c3ConditionsNameForFirstConditionInRulePattern()
  createPattern.c5ConditionsNameForSecondConditionInRulePattern()
  createPattern.c6ConditionsNameForSixthConditionInRulePatternAfterRemovingC4()
  createPattern.c7ConditionsNameForSeventhConditionInRulePattern()
  createPattern.operatorDropdownAtEventAndConditionForConditionFourClick()
  createPattern.orOperatorOptionsUnderDropdownForConditionTwoClick()
  createPattern.operatorDropdownAtEventAndConditionForConditionFiveClick()
  createPattern.andOperatorOptionsUnderDropdownForConditionThreeClick()
  createPattern.operatorDropdownAtEventAndConditionForConditionSixClick()
  createPattern.andOperatorOptionsUnderDropdownForConditionFourClick()
  createPattern.logicalExpressionForConditionVisible()
  createPattern.crossMarkAtEventOneClick()
  createPattern.popupVisible()
  createPattern.popUpTitleVisible()
  createPattern.popUpDialogueVisible()
  createPattern.cancelButtonClick()
  createPattern.eventOneVisible()
  createPattern.copiedEventFromEventOneExist()
  createPattern.crossMarkAtEventOneClick()
  createPattern.deleteButtonClick()
  createPattern.eventOneNotExist()
  createPattern.copiedEventFromEventOneNotExist()
  createPattern.scrollElement()
  cy.wait(1000)
  createPattern.addConditionPlusIconClick()
  cy.wait(2000)
  createPattern.fromVariableOptionClick()
  createPattern.eventTwoUnderFormVariableClick()
  createPattern.asIsOptionClick()
  createPattern.checkBoxAtEventOneClick()
  createPattern.checkBoxAtEventTwoInRulePatternClick()
  createPattern.groupOptionAtEventClick()
  createPattern.operatorOptionAboveCopiedEventForEventTwoForRulePatternClick()
  createPattern.operatorOptionsClick()
  createPattern.crossMarkAtGroupedEventsClick()
  createPattern.popupVisible()
  createPattern.popUpTitleForDeletingAllGroupedEventsVisible()
  createPattern.popUpDialogueForDeletingAllGroupedEventsVisible()
  createPattern.cancelButtonClick()
  createPattern.groupedAllEventsVisible()
  createPattern.copiedEventFromEventTwoExist()
  createPattern.crossMarkAtGroupedEventsClick()
  createPattern.deleteButtonClick()
  createPattern.groupedAllEventsNotExist()
  createPattern.copiedEventFromEventTwoNotExist()
  createPattern.addConditionPlusIconClick()
  cy.wait(2000)
  createPattern.fromVariableOptionClick()
  createPattern.eventTwoUnderFormVariableClick()
  createPattern.asIsOptionClick()
  createPattern.expandAndCollapseIconAtEventVisible()
  createPattern.copiedEventFormEVentFourWithoutCollapseAndExpandIcon()
  createPattern.expandAndCollapseIconAtEventClick()
  cy.wait(1000)
  createPattern.eventNameUnderEventVisible()
  createPattern.conditionTextUnderEventNotVisible()
  createPattern.expandAndCollapseIconAtEventClick()
  cy.wait(1000)
  createPattern.conditionTextUnderEventVisible()
})
     
Cypress.Commands.add("AddExpressionPopUpDataFilled", () => {
  createPattern.addExpressionPopUpFirstOperatorDropDownClick()
  createPattern.absOperatorsInOperatorDropDownClick()
  createPattern.attributeOneDropDownArrowForTestOneClick()
  createPattern.eventLogOneUnderAttributeclick()
  createPattern.firstOperatorInAttributeOneEventOneOperatorsClick() 
  createPattern.addExpressionPopUpSecondOperatorDropDownClick()
  createPattern.starOperatorsInOperatorDropDownClick()
  createPattern.attributetwoArrowForTestOneClick()
  createPattern.eventLogOneUnderAttributeclick()
  createPattern.firstOperatorInAttributeTwoEventOneOperatorsClick()
  createPattern.doneButtonClickInPopUpClick()
  });

  Cypress.Commands.add("AddExpressionPopUpDataFilledForEventTwo", () => {
  createPattern.addExpressionPopUpFirstOperatorDropDownClick()
  createPattern.absOperatorsInOperatorDropDownClick()
  createPattern.attributeOneDropDownArrowForTestOneClick()
  createPattern.eventLogOneUnderAttributeclick()
  createPattern.firstOperatorInAttributeOneEventOneOperatorsClick() 
  createPattern.addExpressionPopUpSecondOperatorDropDownClick()
  createPattern.starOperatorsInOperatorDropDownClick()
  createPattern.attributetwoArrowForTestOneClick()
  createPattern.eventLogOneUnderAttributeclick()
  createPattern.firstOperatorInAttributeTwoEventOneOperatorsInEventTwoClick()
  createPattern.doneButtonClickInPopUpClick()
  });


  Cypress.Commands.add("AddingNewEvent", () => {
  createPattern.addConditionPlusIconClick()
  cy.wait(2000)
  createPattern.formDataModelClick() 
  cy.wait(1000)
	createPattern.importedEventLogModelClick()
  createPattern.dataModelAdditionalInfoAttributeClick()
  });


  Cypress.Commands.add("ApplyMetaDetaPageCompletionForPatternCreation",() => {
    cy.wait(3000)
    createPattern.modalityDropdownfield().eq(0).click({force: true})
    createPattern.modalityDropdownInApplyMetadataOptionSelection()
    createPattern.modalityDropdownfield().eq(1).click({force: true})
    createPattern.patternTypeDropdown().eq(0).click()
    createPattern.relevanceField().eq(0).click();
    createPattern.relevanceCheckboxClick()
    createPattern.modalityDropdownfield().eq(2).click({force: true}) 
    createPattern.serviceContextFields().eq(0).click();
    cy.wait(2000);
    createPattern.modalityDropdownfield().eq(2).click({force: true})
    createPattern.modalityDropdownfield().last().click({force: true})
    createPattern.severityFields().eq(0).click({force: true})
    createPattern.commentBox().click({force: true}).type('TestComment')
    createPattern.addTagButton().click();
    createPattern.cancelButton().click({force: true});
    createPattern.addTagButton().click();
    createPattern.selectTag().click();
    createPattern.addTagFromList().eq(0).click();
    createPattern.addTagOkButton().eq(0).click();
    createPattern.doneButton().click({force: true});
  })

  Cypress.Commands.add("CreateMyKnowledgeForInsertTable", () => {
    createKnowledge.knowledgeNameInputBoxType()
    createKnowledge.decriptionFieldType()
    createKnowledge.modalityDropdownInCreatePageClick()
    createKnowledge.ctModalityOptionClick()
    createKnowledge.symptomsKnowledgeInfoOptionsClick()
    createKnowledge.adsymptomOptionClick()
    createKnowledge.symptomOneTextBoxForRichTextEditorType() 
    createKnowledge.tagsknowledgeInfoOptionsClick()
    createKnowledge.addTagsOptionClick()
    createKnowledge.selectTagDropdownClick()
    createKnowledge.awsTagsOptionsClick()
    createKnowledge.plusIconInAddTagsClick()
    createKnowledge.doneButtonClickInPopUpClick()
            
    })

    Cypress.Commands.add("CreateMyKnowledgeWithAllTags", () => {
      createKnowledge.knowledgeNameInputBoxType()
      createKnowledge.decriptionFieldType()
      createPattern.modalityDropdownInApplyMetadata().click()
      createKnowledge.ctModalityOptionClick()
      createKnowledge.symptomsKnowledgeInfoOptionsClick()
      createKnowledge.adsymptomOptionClick()
      createKnowledge.symptomOneTextBoxType()
      createKnowledge.causeAndSolutionOptionClick()
      createKnowledge.addCauseOptionClick()
      createKnowledge.causeOneInputBoxType()
      createKnowledge.tagsButtonAtCauselevelClick()
      createKnowledge.selectTagsDropDownClick()
      createKnowledge.DAPCollimeterTagsOptionsClick()
      createKnowledge.detectorTagsOptionsClick()
      createKnowledge.plusIconInAddtagsClick()
      createKnowledge.doneButtonClickInPopUpClick()     
      createKnowledge.addSolutionClick()
      createKnowledge.solutionOneInputBoxType()
      createKnowledge.tagsknowledgeInfoOptionsClick()
      createKnowledge.addTagsOptionClick()
      createKnowledge.selectTagDropdownClick()
      createKnowledge.DAPCollimeterTagsOptionsClick()
      createKnowledge.detectorTagsOptionsClick()
      createKnowledge.awsTagsOptionsClick()
      createKnowledge.plusIconInAddtagsClick()
      createKnowledge.doneButtonClickInPopUpClick()         
    })

   Cypress.Commands.add("RichTextEditorInsertTableFunctionality", () => {
    createKnowledge.tableCellAfterAddingColumnClick()
    createKnowledge.removeTableOptionClick()
    createKnowledge.insertTableOptionClick()
    createKnowledge.matrixClick()
    cy.wait(1000)
    createKnowledge.firstCellClick()
    createKnowledge.tableHeaderOptionVisible()
    createKnowledge.removeTableOptionVisible()
    createKnowledge.rowOptionVisible()
    createKnowledge.rowOptionClick()
    createKnowledge.insertRowAboveOptionVisible()
    createKnowledge.insertRowBelowOptionVisible()
    createKnowledge.deleteRowOptionVisible()
    createKnowledge.columnOptionVisible()
    createKnowledge.columnOptionClick()
    createKnowledge.insertColumnBeforeOptionVisible()
    createKnowledge.insertColumnAfterOptionVisible()
    createKnowledge.deleteColumnOptionVisible()
    createKnowledge.tableStyleOptionVisible()
    createKnowledge.tableStyleOptionClick()
    createKnowledge.dashedBordersOptionVisible()
    createKnowledge.alternateRowsOptionVisible()
    createKnowledge.tableCellOptionVisible()
    createKnowledge.tableCellOptionClick()
    createKnowledge.mergeCellOptionVisible()
    createKnowledge.verticalSplitOptionVisible()
    createKnowledge.horizontalSplitOptionVisible()
    createKnowledge.cellBackgroundOptionVisible()
    createKnowledge.cellBackgroundOptionClick()
    createKnowledge.backButtonVisible()
    createKnowledge.colorsVisible()
    createKnowledge.deleteButtonUnderCellBackGroundOptionVisible()
    createKnowledge.textBoxForHEXColorsVisible()
    createKnowledge.okButtonUnderCelBackgroundOptionVisible()
    createKnowledge.backButtonClick()
    createKnowledge.verticalAllignmentOptionVisible()
    createKnowledge.verticalAllignmentOptionClick()
    createKnowledge.allignmentTopOptionVisible()
    createKnowledge.allignmentMiddleOptionVisible()
    createKnowledge.allignmentBottomOptionVisible()
    createKnowledge.horizontalAllignOptionVisible()
    createKnowledge.horizontalAllignOptionClick()
    cy.get(1000)
    createKnowledge.allignLeftOptionVisible()
    createKnowledge.allignCenterOptionVisible()
    createKnowledge.allignRightOptionVisible()
    createKnowledge.allignJustifyOptionVisible()
    createKnowledge.cellStyleOptionVisible()
    createKnowledge.cellStyleOptionClick()
    createKnowledge.highlightedOptionVisible()
    createKnowledge.thickOptionVisible()
    createKnowledge.tableHeaderOptionClick()
    createKnowledge.tableHeaderOptionClick()
    createKnowledge.addedTableHeaderRemoved()
    createKnowledge.firstCellClick()
    createKnowledge.removeTableOptionClick()
    createKnowledge.firstCellNotExist()
    createKnowledge.insertTableOptionClick()
    createKnowledge.matrixClick()
    createKnowledge.firstCellClick()
    createKnowledge.rowOptionClick()
    createKnowledge.insertRowAboveOptionClick()
    createKnowledge.addedTableRowAbove()
    createKnowledge.rowOptionClick()
    createKnowledge.insertRowBelowOptionClick()
    createKnowledge.addedTableRowBelow()
    createKnowledge.firstCellClick()
    createKnowledge.rowOptionClick()
    createKnowledge.deleteRowOptionClick()
    createKnowledge.addedTableRowAbove()
    createKnowledge.firstCellClick()
    createKnowledge.columnOptionClick()
    createKnowledge.insertColumnBeforeOptionClick()
    createKnowledge.tableWithThreeColumns()
    createKnowledge.columnOptionClick()
    createKnowledge.insertColumnAfterOptionClick()
    createKnowledge.tableWithFourColumns()
    createKnowledge.columnOptionClick()
    createKnowledge.deleteColumnOptionClick()
    createKnowledge.tableWithThreeColumns()
    createKnowledge.tableCellAfterAddingColumnClick()
    createKnowledge.tableStyleOptionClick()
    createKnowledge.dashedBordersOptionClick()
    createKnowledge.tablewithDashedBordrs()
    createKnowledge.tableStyleOptionClick()
    createKnowledge.alternateRowsOptionClick()
    createKnowledge.tablewithRowsWithGreyColor()
    createKnowledge.tableCellAfterAddingColumnClick()
    createKnowledge.tableCellOptionClick()
    createKnowledge.verticalSplitOptionClick()
    createKnowledge.tableCellAfterVerticalSplitInFullScreen()
    createKnowledge.tableCellAfterAddingColumnClick()
    createKnowledge.tableCellOptionClick()
    createKnowledge.horizontalSplitOptionSplit()
    createKnowledge.tableCellAfterAddingColumnClick()
    createKnowledge.cellBackgroundOptionClick()
    createKnowledge.userColorClick()
    createKnowledge.colorPopUpNotExist()
    createKnowledge.tabelCellAfterColorSelectionInFullScreen()
    createKnowledge.cellBackgroundOptionClick()
    cy.wait(1000)
    createKnowledge.HEXcolorInputBoxType()
    cy.wait(1000)
    createKnowledge.okButtonUnderCelBackgroundOptionClick()
    createKnowledge.tableCellAfterHEXColorSelectionInFullScreen()
    createKnowledge.tableCellAfterAddingColumnClick()
    createKnowledge.cellBackgroundOptionClick()
    createKnowledge.deleteButtonUnderCellBackGroundOptionClick()
    createKnowledge.tableCellWithRemovedColor()
    createKnowledge.cellStyleOptionClick()
    createKnowledge.highlightedOptionClick()
    createKnowledge.firstCellWithHighlightedRedBorder()
    createKnowledge.cellStyleOptionClick()
    createKnowledge.thickOptionClick()
    createKnowledge.firstCellbordered()
    createKnowledge.cellStyleOptionClick()
    createKnowledge.thickOptionClick()
    createKnowledge.firstCellUndobordered()
    createKnowledge.cellStyleOptionClick()
    createKnowledge.highlightedOptionClick()
    createKnowledge.firstCellWitUndoHighlightedRedBorder()
    createKnowledge.cellStyleOptionClick()
    createKnowledge.highlightedOptionClick()
    createKnowledge.firstCellWithHighlightedRedBorder()
    createKnowledge.cellStyleOptionClick()
    createKnowledge.thickOptionClick() 
    createKnowledge.firstCellbordered()   
    createKnowledge.addingDataInCell() 
  })
  
  Cypress.Commands.add("CreateMyKnowledgeForBulkDelete", () => {
    createKnowledge.patternNameTypeInPatternInformationSection()
    createKnowledge.decriptionFieldType()
    createKnowledge.symptomsKnowledgeInfoOptionsClick()
    createKnowledge.adsymptomOptionClick()
    createKnowledge.symptomOneTextBoxType()
    createKnowledge.causeAndSolutionOptionClick()
    createKnowledge.addCauseOptionClick()
    createKnowledge.causeOneInputBoxType()
    createKnowledge.addSolutionClick()
    createKnowledge.solutionOneInputBoxType()
    createKnowledge.tagsknowledgeInfoOptionsClick()
    createKnowledge.addTagsOptionClick()
    createKnowledge.selectTagDropdownClick()
    createKnowledge.awsTagsOptionsClick()
    createKnowledge.plusIconInAddtagsClick()
    createKnowledge.doneButtonClickInPopUpClick()         
  })

  
  Cypress.Commands.add("CreateMultipleKnowledgeAsPerUserInput", (records1) => {
    for(let i= 0; i<=records1 ; i++){
    createKnowledge.addKnowledgeWorkflowButtonClick()
    cy.wait(3000)
    cy.CreateMyKnowledgeForBulkDelete()
    createKnowledge.saveAsDraftClick()
    cy.wait(3000)
    }
});

  Cypress.Commands.add("CreateMyKnowledgeNormal", () => {
    createKnowledge.patternNameTypeInPatternInformationSection()
    createKnowledge.decriptionFieldType()
    createKnowledge.modalityDropdownInCreatePageClick()
    createKnowledge.symptomsKnowledgeInfoOptionsClick()
    createKnowledge.adsymptomOptionClick()
    createKnowledge.symptomOneTextBoxType()
    createKnowledge.causeAndSolutionOptionClick()
    createKnowledge.addCauseOptionClick()
    createKnowledge.causeOneInputBoxType()
    createKnowledge.addSolutionClick()
    createKnowledge.solutionOneInputBoxType()
    createKnowledge.tagsknowledgeInfoOptionsClick()
    createKnowledge.addTagsOptionClick() 
    createKnowledge.selectTagDropdownClick()
    cy.wait(1000)
    createKnowledge.awsTagsOptionsClick()
    createKnowledge.plusIconInAddTagsClick()
    createKnowledge.doneButtonClickInPopUpClick()          
  })

  Cypress.Commands.add("knowledgeDeleteInMyPatternDashboard", () => {
    createKnowledge.addKnowledgeWorkflowButtonClick()
    cy.wait(2000)
    cy.CreateMyKnowledgeNormal()
    createKnowledge.saveAsDraftClick()
    cy.wait(3000) 
    createKnowledge.getPatternName()
    cy.wait(1000)
    knowledgeDashboard.knowledgeDashboardClick()
    cy.wait(1000)
    createKnowledge.knowledgeNameSearchInMyKnowledge()
    knowledgeDashboard.searchIconForKnowledgeNameClick()
    cy.wait(2000)
    knowledgeDashboard.searchedKnowledgeClick()
    knowledgeDashboard.knowledgePublishOptionClick()
    knowledgeDashboard.okButtonButtonInPopUpClick()
    createKnowledge.addKnowledgeWorkflowButtonClick()
    cy.wait(2000)
    cy.CreateMyKnowledgeNormal()
    createKnowledge.saveAsDraftClick()
    cy.wait(3000) 
    createKnowledge.getPatternName()
    cy.wait(1000)
    knowledgeDashboard.knowledgeDashboardClick()
    cy.wait(1000)
    createKnowledge.secondKnowledgeInMyKnowledgeSearch()
    knowledgeDashboard.searchIconForKnowledgeNameClick()
    cy.wait(2000)
    knowledgeDashboard.searchedKnowledgeClick()
    knowledgeDashboard.knowledgePublishOptionClick()
    knowledgeDashboard.okButtonButtonInPopUpClick()
    createKnowledge.addKnowledgeWorkflowButtonClick()
    cy.wait(3000)
    cy.CreateMyKnowledgeForBulkDelete()
    createKnowledge.saveAsDraftClick()
    cy.wait(3000) 
    createKnowledge.getPatternName()
    cy.wait(1000)
    createKnowledge.addKnowledgeWorkflowButtonClick()
    cy.wait(3000)
    cy.wait(2000)
    cy.CreateMyKnowledgeForBulkDelete()
    createKnowledge.saveAsDraftClick()
    cy.wait(3000) 
    createKnowledge.getPatternName()
    cy.wait(1000)
    knowledgeDashboard.myKnowledgeDashboardClick()
    cy.wait(3000)
	  knowledgeDashboard.deleteButtonInKnowledgeDashboardDisabled()
    knowledgeDashboard.selectingPublishedKnowledges()
    knowledgeDashboard.deleteButtonInKnowledgeDashboardEnabled()
    cy.wait(4000)
	  knowledgeDashboard.deleteButtonInKnowledgeDashboardClick()
    cy.wait(1000)
    knowledgeDashboard.confirmationPopUpHeaderForDeletingPublishedJnowledgeVisible()
    knowledgeDashboard.deleteButtonOnPopUpVisible()
    knowledgeDashboard.cancelButtonVisible()
    knowledgeDashboard.knowledgeNamesOnPopUpVisible()
    knowledgeDashboard.cancelButtonClick()
    createKnowledge.publishedKnowledgeInMyKnowldgeVisible()
    knowledgeDashboard.deleteButtonInKnowledgeDashboardClick()
    cy.wait(1000)
    knowledgeDashboard.deleteButtonOnPopUpClick()
    cy.wait(4000)
	  createKnowledge.publishedKnowledgeInMyKnowldgeNotExist()
    knowledgeDashboard.checkBoxSelectingDraftKnowledgeClick()
    cy.wait(2000)
    knowledgeDashboard.deleteButtonInKnowledgeDashboardClick()
    cy.wait(1000)
    knowledgeDashboard.deleteButtonOnPopUpClick()
    cy.wait(2000)
    createKnowledge.knowledgeTableWithOutDraftKnowledge()
    cy.wait(1000)
	  knowledgeDashboard.checkBoxSelectingDraftKnowledgeClick()
    knowledgeDashboard.checkBoxSelectingKnowledgeWithOutAssociationClick()
    knowledgeDashboard.deleteButtonInKnowledgeDashboardClick()
    cy.wait(1000)
    knowledgeDashboard.deleteButtonOnPopUpClick()
    cy.wait(2000)
    createKnowledge.addKnowledgeWorkflowButtonClick()
    cy.wait(2000)
    cy.CreateMyKnowledgeNormal()
    createKnowledge.saveAsDraftClick()
    cy.wait(3000) 
    createKnowledge.getPatternName()
    cy.wait(1000)
    knowledgeDashboard.myKnowledgeDashboardClick()
    cy.wait(1000)
    createKnowledge.knowledgeSearchInMyPatternType()
    knowledgeDashboard.searchIconForKnowledgeNameClick()
    cy.wait(2000)
    knowledgeDashboard.rowLevelThreeDotsClick()
    knowledgeDashboard.deleteButtonUnderThreeDotsClick()
    cy.wait(1000)
    knowledgeDashboard.deleteButtonOnPopUpClick()
    cy.wait(2000)
    createKnowledge.publishedKnowledgeNotExistInMyPattern()
    createKnowledge.secondKnowledgeSearch()
    knowledgeDashboard.searchIconForKnowledgeNameClick()
    cy.wait(2000)
    knowledgeDashboard.noResultsFoundInRelevanceMessageVisible()
    createKnowledge.addKnowledgeWorkflowButtonClick()
    cy.wait(2000)
    cy.CreateMyKnowledgeNormal()
    createKnowledge.saveAsDraftClick()
    cy.wait(3000) 
    createKnowledge.getPatternName()
    cy.wait(1000)
    knowledgeDashboard.myKnowledgeDashboardClick()
    cy.wait(1000)
    createKnowledge.knowledgeSearchFourthKnowledgeInMyPatternType()
    knowledgeDashboard.searchIconForKnowledgeNameClick()
    cy.wait(2000)
    knowledgeDashboard.searchedKnowledgeClick()
    cy.wait(2000)
    knowledgeDashboard.deleteButttonWhenClickedOnlinkEnabled()
    cy.wait(1000)
    knowledgeDashboard.deleteButttonWhenClickedOnlinkClick()
    knowledgeDashboard.deleteButtonOnPopUpClick()
    cy.wait(2000)
    knowledgeDashboard.crossIconClick()
    cy.wait(1000)
    createKnowledge.secondKnowledgeInMyKnowledgeSearch()
    knowledgeDashboard.searchIconForKnowledgeNameClick()
    cy.wait(2000)
    knowledgeDashboard.noResultsFoundInRelevanceMessageVisible()         
  })

  Cypress.Commands.add("CreateKnowledgeAssociation", () => {
    createKnowledge.patternNameTypeInPatternInformationSection()
    createKnowledge.decriptionFieldType()
    createKnowledge.modalityDropdownInCreatePageClick()
    createKnowledge.symptomsKnowledgeInfoOptionsClick()
    createKnowledge.selectSymptomClick()
    createKnowledge.showAllButtonClick()
    cy.wait(5000)
    createKnowledge.secondKnowledgeSearchInIncludeKnowledgePopUp()
    cy.wait(1000)
    createKnowledge.searchIconToSearchKnowledgeNameClick()
    cy.wait(2000)
    createKnowledge.searchedKnowledgeCheckBoxClick()
    createKnowledge.selectKnowledgeOptionClick()
    cy.wait(2000)
    createKnowledge.causeAndSolutionOptionClick()
    createKnowledge.addCauseOptionClick()
    createKnowledge.causeOneInputBoxType()
    createKnowledge.addSolutionClick()
    createKnowledge.solutionOneInputBoxType()
    createKnowledge.tagsknowledgeInfoOptionsClick()
    createKnowledge.addTagsOptionClick()
    createKnowledge.selectTagDropdownClick()
    cy.wait(1000)
    createKnowledge.awsTagsOptionsClick()
    createKnowledge.plusIconInAddTagsClick()
    createKnowledge.doneButtonClickInPopUpClick()
     
  })

  Cypress.Commands.add("CreateKnowledgeAssociationInMyPattern", () => {
    createKnowledge.patternNameTypeInPatternInformationSection()
    createKnowledge.decriptionFieldType()
    createKnowledge.modalityDropdownInCreatePageClick()
    createKnowledge.symptomsKnowledgeInfoOptionsClick()
    createKnowledge.selectSymptomClick()
    createKnowledge.showAllButtonClick()
    createKnowledge.secondKnowledgeSearchInIncludeKnowledgeInMyPatternPopUp()
    createKnowledge.searchIconToSearchKnowledgeNameClick()
    cy.wait(2000)
    createKnowledge.searchedKnowledgeCheckBoxClick()
    createKnowledge.selectKnowledgeOptionClick()
    cy.wait(2000)
    createKnowledge.causeAndSolutionOptionClick()
    createKnowledge.addCauseOptionClick()
    createKnowledge.causeOneInputBoxType()
    createKnowledge.addSolutionClick()
    createKnowledge.solutionOneInputBoxType()
    createKnowledge.tagsknowledgeInfoOptionsClick()
    createKnowledge.addTagsOptionClick()
    createKnowledge.selectTagDropdownClick()
    createKnowledge.awsTagsOptionsClick()
    createKnowledge.plusIconInAddTagsClick()
    createKnowledge.doneButtonClickInPopUpClick()
     
  })

  Cypress.Commands.add("CreateMultiplePatternsWithValidation", () => {
    cy.createPattern()
    cy.ExistingWorkFlowText()
    createPattern.nextButtonClick()
    cy.wait(2000)
    cy.ApplyMetaDetaPageCompletionForPatternCreation()
    createPattern.nextButtonClick()
    cy.wait(2000)
    createPattern.showAllCheckboxClick()
    createPattern.recordSelectionInIncludeKnowledge()
    createPattern.nextButtonClick()
    cy.wait(2000)
    validationPage.validationIdDropdownClick()
    validationPage.selectFirstId()
    validationPage.selectButtonClick()
    validationPage.calenderOptionClick()
    validationPage.datePrevIconClick()
    validationPage.dateRangeSlection()
    validationPage.taskLimitInputBoxTypeOne()
    validationPage.validateButtonClick()
    cy.wait(3000)
    validationPage.saveAsDraftButtonClick()
    cy.wait(3000)
    createPattern.getPatternName()
    cy.wait(1000)
    createPattern.patternDashboardClick()
    cy.wait(2000)
    patternDashboard.modalityDropdownColumnClick()
    cy.wait(1000)
    patternDashboard.selectAllCheckBoxClick()
    patternDashboard.modalityApplyButtonClick()
});


Cypress.Commands.add("CreateMultiplePatternsAsPerUserInput", (records1) => {
  for(let i= 0; i<=records1 ; i++){
 
    cy.createPattern()
    cy.ExistingWorkFlowText()
    createPattern.nextButtonClick()
    cy.wait(2000)
    cy.ApplyMetaDetaPageCompletionForPatternCreation()
    createPattern.nextButtonClick()
    cy.wait(2000)
    createPattern.showAllCheckboxClick()
    createPattern.recordSelectionInIncludeKnowledge()
    createPattern.nextButtonClick()
    cy.wait(2000)
    validationPage.validationIdDropdownClick()
    validationPage.selectFirstId()
    validationPage.selectButtonClick()
    validationPage.calenderOptionClick()
    validationPage.datePrevIconClick()
    validationPage.dateRangeSlection()
    // validationPage.taskLimitInputBoxTypeOne()
    validationPage.validateButtonClick()
    cy.wait(3000)
    validationPage.saveAsDraftButtonClick()
    cy.wait(5000)
    createPattern.getPatternName()
    cy.wait(1000)
  }
});


Cypress.Commands.add("ApplyMetaDetaPageCompletionWithUserProvidedModalities", (m1,m2) => {
  if(m1!=undefined && m2!=undefined){
  cy.wait(3000)
  createPattern.modalityDropdownfield().eq(0).click({ force: true })
  cy.get(addTagFromList).eq(0).click()
  }
  else if(m1!=undefined){
  cy.wait(3000)
  createPattern.modalityDropdownfield().eq(0).click({ force: true })
  }
  createPattern.modalityDropdownfield().eq(1).click({ force: true })
  createPattern.patternTypeDropdown().eq(0).click()
  createPattern.relevanceField().eq(0).click();
  createPattern.relevanceCheckboxClick() 
  createPattern.modalityDropdownfield().eq(2).click({ force: true })
  createPattern.serviceContextFields().eq(0).click();
  cy.wait(2000);
  createPattern.modalityDropdownfield().eq(2).click({ force: true })
  createPattern.modalityDropdownfield().last().click({ force: true })
  createPattern.severityFields().eq(0).click({ force: true })
  createPattern.commentBox().click({ force: true }).type('TestComment')
  createPattern.addTagButton().click();
  createPattern.cancelButton().click({ force: true });
  createPattern.addTagButton().click();
  createPattern.selectTag().click();
  createPattern.addTagFromList().eq(0).click();
  createPattern.addTagOkButton().eq(0).click();
  createPattern.doneButton().click({force: true});
  createPattern.clicksOnPopUpOkButton()
  patternDashboard.dashboardButton().eq(0).click();
  createPattern.okButtonClick()
  cy.readFile(filePath).then(function (result) {
    let PatternName = result.name;
    cy.get('#' + PatternName).click()
 
  })
})



Cypress.Commands.add("CreateMultiplePatternsAsPerUserInputWithIGTModality", (records1) => {
  for(let i= 0; i<=records1 ; i++){
 
    cy.createPattern()
    cy.ExistingWorkFlowText()
    createPattern.nextButtonClick()
    cy.wait(2000)
    cy.ApplyMetaDetaPageCompletionWithUserProvidedModalities(0)
    createPattern.nextButtonClick()
    cy.wait(2000)
    createPattern.showAllCheckboxClick()
    createPattern.recordSelectionInIncludeKnowledge()
    createPattern.nextButtonClick()
    cy.wait(2000)
    validationPage.validationIdDropdownClick()
    validationPage.selectFirstId()
    validationPage.selectButtonClick()
    validationPage.calenderOptionClick()
    validationPage.datePrevIconClick()
    validationPage.dateRangeSlection()
    validationPage.previousButtonClick()
    cy.wait(1000)
    validationPage.previousButtonClick()
    cy.wait(1000)
    applyMetadata.selectiongAllUnderRelevnceClick()
    applyMetadata.nextButtonClick()
    cy.wait(1000)
    applyMetadata.nextButtonClick()
    cy.wait(2000)
    validationPage.validateButtonClick()
    cy.wait(3000)
    validationPage.saveAsDraftButtonClick()
    cy.wait(3000)
    createPattern.getPatternName()
    cy.wait(1000)
    createPattern.patternDashboardClick()
    cy.wait(40000)
    patternDashboard.modalityDropdownColumnClick()
    cy.wait(1000)
    patternDashboard.IGTmodalitySelect()
    patternDashboard.modalityApplyButtonClick()

  }
});


