/// <reference types="Cypress" />
/// <reference types='cypress-tags' />
import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import CreateKnowledge from "../../../../support/pageObjects/pages/KnowledgeAuthoring/CreateKnowledge";
const createKnowledge = new CreateKnowledge();
var arr = [];

When("User creates new knowledge workflow", () => {
    createKnowledge.knowledgeClick()
    console.log(printTimestamp(), ' New knowledge workflow created')
});

Then("User should be able to add details in Knowledge Information section and User expands symptoms section", () => {
    createKnowledge.symptomsVisible()
    createKnowledge.symptomsClick()
    console.log(printTimestamp(), ' Details added in Knowledge Information section')
});

And("User clicks on Select symptom button", () => {
    createKnowledge.selectSymptomsButtonVisible()
    createKnowledge.selectSymptomsButtonClick()
    console.log(printTimestamp(), ' clicked on Select symptom button')
});

And("User verifies title, searchbox and show all checkbox present", () => {
    createKnowledge.showAllCheckboxVisible()
    createKnowledge.searchBoxVisible()
    createKnowledge.searchBoxTestVisible()
    createKnowledge.selectSymptomsHeadingVisible()
    console.log(printTimestamp(), ' Title, searchbox and show all checkbox present')
});

When("User Clicks on show all checkbox", () => {
    createKnowledge.showAllCheckboxClick()
    console.log(printTimestamp(), ' Clicks on show all checkbox and verifies details like total records, column level filter, cancel and select button and entries per page')
});

Then("Verifies details like total records, column level filter, cancel and select button and entries per page are present", () => {
    createKnowledge.totalrecordsPerPageVerificationforTen()
    createKnowledge.entriesPerPageVisible()
    createKnowledge.CancelButtonVisible()
    createKnowledge.selectButtonVisible()
    createKnowledge.dropdownValuesVerification()
    console.log(printTimestamp(), ' Clicks on show all checkbox and verifies details like total records, column level filter, cancel and select button and entries per page')
});

Then("By default symptom details should be displayed as per asc order of symptom name", () => {
    createKnowledge.patternNameASCOrderSortedVisible()
    console.log(printTimestamp(), ' By default symptom details displayed as per asc order of symptom name')
});

And("Based on selected value from drop down number of records should be displayed", () => {
    createKnowledge.changeEntriesPerPageCountSize()
    createKnowledge.totalrecordsPerPageVerificationforTwenty()
    console.log(printTimestamp(), ' Number of records displayed')
});

And("Navigates to next page by clicking on > icon", () => {
    createKnowledge.nextPageNavigationClickandVerification()
    console.log(printTimestamp(), ' Navigated to next page')
});

And("Navigates to previous page by clicking on < icon", () => {
    createKnowledge.previousPageNavigationClickandVerification()
    console.log(printTimestamp(), ' Navigated to previous page')
});

And("User should be able to Change number of entries per page and navigates to next page and Clicks on Cancel", () => {
    createKnowledge.changeEntriesPerPageCountSize()
    createKnowledge.totalrecordsPerPageVerificationforTwenty()
    createKnowledge.nextPageNavigationClickandVerification()
    createKnowledge.cancelClick()
    console.log(printTimestamp(), '  Verification of entries per page changes')
});

And("Open Select Symptom and verify number of entries per page", () => {
    createKnowledge.selectSymptomsButtonClick()
    createKnowledge.showAllCheckboxClick()
    createKnowledge.entriesPrPageVisible()
    cy.wait(2000)
    createKnowledge.totalrecordsPerPageVerificationforTen()
    console.log(printTimestamp(), ' Verified number of entries per page')
});

And("Select button should be disabled when none of symptom is selected", () => {
    createKnowledge.selectButtonDisabledVerification()
    console.log(printTimestamp(), ' Select button disabled')
});

When("Any symptom is selected Grid should be resized and symptom details should be displayed in right side", () => {
    createKnowledge.firstRecordClick()
    createKnowledge.rightsideSectionVisible()
    createKnowledge.textVerificationFromRightSideSection()
    console.log(printTimestamp(), ' Grid resized and verified right side section')
});

Then("Select button should be enabled when any symptom is selected", () => {
    createKnowledge.selectButtonEnabledVerification()
    console.log(printTimestamp(), ' Select btton enabled')
});

And("Verifies > Collapse Details available beside search box", () => {
    createKnowledge.collapseDetailsVerification()
    console.log(printTimestamp(), ' Verified Collapsed Details available beside search box')
});

And("Name, description, tags and associations of symptoms are present in right side section", () => {
    createKnowledge.collapseIconClick()
    createKnowledge.symptomNameVisible()
    createKnowledge.symptomDescriptionVisible()
    createKnowledge.symptomTagsVisible()
    // createKnowledge.symptomAssociationsVisible()
    console.log(printTimestamp(), ' Right side details verified')
});

And("User clicks on cancel button", () => {
    createKnowledge.cancelClick()
    console.log(printTimestamp(), ' Clicked on cancel button')
});

And("User again clicks on select symptoms button and verifies no any data present in table", () => {
    createKnowledge.selectSymptomsButtonClick()
    createKnowledge.noDataVisibleInTable()
    console.log(printTimestamp(), ' Reverified table details present or not')
});

And("Close DAW Application", () => {
    createKnowledge.cancelButtonClickForClaus()
    cy.DeleteWorkflow()
    cy.log("Test Case Executed Successfully")
    console.log(printTimestamp(), ' Test Case Executed Successfully')
});

