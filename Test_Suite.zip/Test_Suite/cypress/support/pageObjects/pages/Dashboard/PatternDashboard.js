import "../../../index";
import AssertionConstants from "../../../../support/pageObjects/pages/AssertionConstants"
const assertionConstants = new AssertionConstants();

const dashboardButton = 'a[id="Dashboard"]';
const patternDropdown = "Pattern Name ... +8 more";
const knowledgeDropdown = "Knowledge Name ... +7 more";
const patternDropdownWithAdditionOfColumn = "Pattern Name ... +14 more";
const dropdownResults = ".pt-option-label";
const patternNameField = ".pt-input";
const deletePatternButton = "#delete-pattern";
const withdrawPatternButton = "#withdraw-pattern";
const patternTitle = "//dls-label[contains(text(),'Patterns')]";
const patternNameColumn = "th[id='Pattern Name']";
const patternStateColumn = "th[id='Pattern State']";
const versionColumn = "th[id='Version']";
const modifiedbyColumn = "th[id='Modified By']";
const modifiedonColumn = "th[id='Modified On']";
const modalityColumn = "th[id='Modality']";
const patterntypeColumn = "th[id='Pattern Type']";
const serciceconextColumn = "th[id='Service Context']";
const severityColumn = "#Severity";
const sideClick = "//p-tableheadercheckbox/div[1]/div[2]/span[1]";
const reviewdBy = "th[id='Reviewed By']";
const publishedBy = "th[id='Published By']";
const publishedOn = "th[id='Published On']";
const createdBy = "th[id='Created By']";
const createdOn = "th[id='Created On']";
const tags = "th[id='Tags']";
const clearFilters = "Clear All Filters";
const entriesPerPage = " Entries per page: ";
const records = "#record-count";
const patternGuid = "//label[contains(text(),'Pattern GUID :')]";
const patternDiscription = "//label[contains(text(),'Description :')]";
const myPatternDashboardButton = "button[type='button']";
const tagsButton = "#Tags";
const breadcrumb = ".pt-breadcrumb >.pt-layout-container >ul";
const myPattern = "div[aria-label='My Patterns'] > button[type='button']";
const clearButton = "button[id='metadata.modality_clearBtn']";
const sortinIcon = 'th[id="Modified On"] p-sorticon>i';
const unselectedDropdownValues = 'dls-multiselect-option[class="pt-multiselect-option ng-star-inserted"]';
const firstRecordText = '//tbody/tr[2]/td[6]/span';
const secodRecordText = '//tbody/tr[3]/td[6]/span';
const modalityColumnDropdown = 'p-multiselect>div';
const firstRecordTextForKnowledge = '//tbody/tr[1]/td[9]/span[1]';
const knowledgeName = "th[id='Knowledge Name']";
const noOfAssociationColumn = "th[id='# of Associations']";
const knowledgeState = "th[id='Knowledge State']";
const firstPattern = ':nth-child(1) > [style="width: 500px;"] > .btn-link';
const entriesPerpage = ".pt-entries-per-page";
const valueToCompare = "dls-layout-container>span";
const tagValue = "//span[contains(text(),'AWS')]";
const upArrow = "p-sortable-column-icon pi pi-fw pi-sort-amount-up-alt";
const downArrow = 'p-sortable-column-icon pi pi-fw pi-sort-amount-down';
const recordsAvailable = "//tbody/tr";
const invokedTextOfFirstRecord = "//tbody/tr[1]/td[2]/span[1]";
const firstRecordThreeDot = '[id="grid-dropdown-btn"]';
const deleteOption = "//label[contains(text(),'Delete')]";
let PatternName = '';
const deleteButton = "Delete";
const okButton = "#ok-btn";
const patternNameCheckbox = 'span[class="p-checkbox-icon"]'
const invokeTextOfDeletingRecords = "dls-list-item>label";
const patternNameSearchField = "#patternName_searchIcon";
const myPatternDashboard = "section[id='Dashboard']";
const deleteButtonInsidePattern = "footer > .align-right > :nth-child(2)"
const naviagationToNewlyCreatedAuthWF = "span.btn-link.ng-star-inserted"
const record = "#record-count"
const columnFilters = 'p-multiselect[defaultlabel="All"]'
const filtersCheckboxes = 'p-multiselectitem div[class="p-checkbox-box"]'
const filtersCheckbox = ' p-multiselectitem div[class="p-checkbox p-component"]'
const filtersValues = 'p-multiselectitem li'
const searchTextBox = 'input[role="textbox"]'
const clearFilterButton = '#patternStatus_clearBtn'
const applyFilterButton = '#patternStatus_applyBtn'
const applyFilterButton2 = '#tagValue_applyBtn'
const versionClearButton = '#version_clearBtn'
const versionApplyButton = '#version_applyBtn'
const reviewerClearButton = '#reviewerName_clearBtn'
const TagsClearButton = '#tagValue_clearBtn'
const advanceFilter = '#advanced-filter'
const checkboxesAtColumnLevel = 'div[role="checkbox"]>span'
const patternNameRecords = 'tr>td>span[class="btn-link ng-star-inserted"]'
const patternStateRecords1 = '//tbody/tr[1]/td[3]/span[1]'
const patternStateRecords2 = '//tbody/tr[1]/td[5]/span[1]'
const versionRecords1 = '//tbody/tr[1]/td[4]/span[1]'
const versionRecords2 = '//tbody/tr[2]/td[4]/span[1]'
const modifiedByRecords1 = '//tbody/tr[2]/td[5]/span[1]'
const modifiedByRecords2 = '//tbody/tr[3]/td[5]/span[1]'
const modifiedOnRecords1 = '//tbody/tr[2]/td[6]/span[1]'
const modifiedOnRecords2 = '//tbody/tr[3]/td[6]/span[1]'
const modalityRecords1 = '//tbody/tr[2]/td[7]/span[1]'
const modalityRecords2 = '//tbody/tr[3]/td[7]/span[1]'
const patternTypeRecords1 = '//tbody/tr[2]/td[8]/span[1]'
const patternTypeRecords2 = '//tbody/tr[3]/td[8]/span[1]'
const serviceContextRecords2 = '//tbody/tr[3]/td[9]/span[1]'
const severityRecords1 = '//tbody/tr[2]/td[10]/span[1]'
const severityRecords2 = '//tbody/tr[3]/td[10]/span[1]'
const knowledgeNameRecords1 = '//tbody/tr[1]/td[2]/span[1]'
const knowledgeNameRecords2 = '//tbody/tr[2]/td[2]/span[1]'
const modalityRecordsInKnowledge1 = '//tbody/tr[1]/td[3]/span[1]'
const modalityRecordsInKnowledge2 = '//tbody/tr[2]/td[3]/span[1]'
const noOfAssociationRecords1 = '//tbody/tr[2]/td[5]/span[1]'
const noOfAssociationRecords2 = '//tbody/tr[3]/td[5]/span[1]'
const knowledgeStateRecords1 = '//tbody/tr[1]/td[7]/span[1]'
const knowledgeStateRecords2 = '//tbody/tr[2]/td[7]/span[1]'
const modifiedByColumnInKnowledgeRecords1 = '//tbody/tr[1]/td[8]/span[1]'
const modifiedByColumnInKnowledgeRecords2 = '//tbody/tr[2]/td[8]/span[1]'
const modifiedOnColumnInKnowledgeRecords2 = '//tbody/tr[2]/td[9]/span[1]'
const modifiedOnColumnInKnowledgeRecords1 = '//tbody/tr[1]/td[9]/span[1]'
const createdOnRecords1 = '//tbody/tr[1]/td[11]/span[1]'
const createdOnRecords2 = '//tbody/tr[2]/td[11]/span[1]'
const createdByRecords1 = '//tbody/tr[1]/td[10]/span[1]'
const createdByRecords2 = '//tbody/tr[2]/td[10]/span[1]'
const columnConfiurationDropdown = '#dynamic-column-selector span'
const selectedColumnsChekbox = 'dls-multiselect-option.pt-multiselect-option.pt-selected.ng-star-inserted'
const unSelectedColumnsChekbox = 'dls-multiselect-option[class="pt-multiselect-option ng-star-inserted"]'
const selectedColumnsText = 'dls-multiselect-option[class="pt-multiselect-option pt-selected ng-star-inserted"] span[class="pt-option-label"]'
const unSelectedColumnsText = 'dls-multiselect-option[class="pt-multiselect-option ng-star-inserted"] span[class="pt-option-label"]'
const nextPageIcon = 'dls-icon[class="pt-icon icon-dls-navigation-right custom-right-icon"]'
const previousPageIcon = 'dls-icon[class="pt-icon icon-dls-navigation-left custom-left-icon"]'
const singleColumn = 'th[role="columnheader"]'
const patternDashboardTitle = '[class="font-20 font-sans-bold col-4 pl-4 pt-label"]'
const patternDashboardBreadCrum = '[class="pt-breadcrumb"]'
const pattern = 'tbody[class="p-element p-datatable-tbody"]'
const fullscreenViewButton = '[class="pt-quiet-default icon-fullscreen pl-0 pt-button"]'
const fullScreen = '[class="content-items h-100 ng-star-inserted fullScreen"]'
const patternHeaderWithPatternDetails = '[class="accordian-header ng-star-inserted"]'
const buttonsAtBottom = '[class="align-right pad-10"]'
const backArrow = '[id="back-arrow"]'
const readOnlyMode = '[id="readonly-description"]'
const dashboardWithPattrens = '[class="p-element p-datatable-tbody"]'
const myPatternArrow = '[class="p-tree-toggler-icon pi pi-fw pi-chevron-right"]'
const toggleIcon = '[class="toggle-icon glyphicon"]'
const leftPaneDashboardBox = '[class="dashboard_box"]'
const myPattrenDashboard = '[aria-label="Dashboard"]'
const patternDetailsIngrid = '[class="details-container pad-10"]'
const patternName = '[id="pat-name"]'
const versionLable = '[class="version-info pt-label"]'
const versionValue = '[class="version-info"]'
const Icon = '[alt="Version"]'
const Icon2 = '[alt="Expand"]'
const MetadataInfo = '[id="metadataInfo"]'
const knowledgeInfo = '[id="knowledgeInfo"]'
const auditInfo = '[id="auditInfo"]'
const button = '[class="btnbox pt-button ng-star-inserted"]'
const editButton = '[id="pat-edit"]'
const closeButton = '[id="pat-close"]'
const expandAndCollapseIcon = '[viewBox="0 0 140 140"]'
const patternDetails = '[class="col-md-2"]'
const patternDetailsOption = '[class="accordian-header ng-star-inserted"]'
const metadataDetails = '[id="metadata.modality"]'
const patternGuideOption = 'Pattern GUID : '
const knowledgeNameText = 'Knowledge Name'
const paternTypeAndValue = '[id="metadata.pattern_type"]'
const serviceContextAndValue = '[id="metadata.service_context"]'
const timeSpanAndValue = '[class="col-md-9 font-sans-book ng-star-inserted"]'
const modalityTextAndValue = '[id="metadata.modality"]'
const relevanceText = '[id="metadata.relevance"]'
const myPatternDashboardBreadCrum = '[class="pt-breadcrumb"]'
const expandedProductfamily = '[class="p-treenode-children ng-star-inserted"]'
const comment = '[id="comment"]'
const severity = '[id="metadata.severity"]'
const tagsText = '[id="patternTags"] label'
const patterns = 'tbody[class="p-element p-datatable-tbody"]'
const patternsCheckbox = '[class="p-checkbox-icon"]'
const threeDots = '#grid-dropdown-btn > #Layer_1'
const cloneButton = '[id="Clone"]'
const KnowledgwSelectcheckBox = 'span[class="p-checkbox-icon"]'
const patternDashboardPage = ".font-20.font-sans-bold.col-4.pt-label";
const patternTabArrow = ".p-tree-toggler-icon.pi.pi-fw.pi-chevron-right";
const MyknowledgeArrow = 'button[class="p-tree-toggler p-link p-ripple"]';
const patternAndAutoringWorkFlowList = ".ng-star-inserted > div > span >span >section";
const AddAuthoringWokFlowButton = "#nav-add-btn";
const workFlowMessage = "Workflow Created Successfully";
const classNameForUnselectedCheckboxes = 'span[class="pt-option-label"]'
const noRecordsFoundText = "#no-record-message";
const modalityColumnText = "p-multiselect>div>div>div";
const ICAPOptionFromModalityDropdown = 'li[aria-label="ICAP"]';
const modalityApplyButton = "//button[@id='metadata.modality_applyBtn']";
const DraftOptionFromModalityDropdown = 'li[aria-label="Draft"]';
const patternStatusApplyButton = "#patternStatus_applyBtn";
const dateRangeColumn = 'p-calendar[name="calendar"]';
const datePicker = ".p-datepicker-prev-icon"
const calenderDateSelection = 'table tr td span[draggable="false"]';
const modifiedOnDateRangeApplyButton = '#modifiedOn_applyBtn';
const modifiedOnDateRangeClearButton = '#modifiedOn_clearBtn';
const datePickerNextMonthIcon = ".p-datepicker-next-icon"
const publishedOnDateRangeApplyButton = '#publishedOn_applyBtn';
const publishedOnDateRangeClearButton = '#publishedOn_clearBtn';
const patternStatusColumn = '#column_patternStatus';
const clearAllFilterButton = '#clear-all-filter';
const myPatternsExpandArrow = 'div[aria-label="My Patterns"] span';
const myPatternsDashboard = 'section[id="Dashboard"]';
const allcolumnsSelected = "dls-multiselect[role='listbox'] span"
const clearFilterIcon = 'button[class="pt-clear-button"]>dls-icon'
const patternDashboardNameColumnRecords1 = '//tbody/tr[1]/td[2]'
const patternDashboardNameColumnRecords2 = ' //tbody/tr[2]/td[2]'
const rightSideOverlaySection = 'dls-sidebar[sidebarposition="right"] div'
const relevanceExpandedIcon = 'section[id="metadata.relevance"] [aria-expanded="true"]'
const knowledgeExpanded = 'dls-expander'
const editButtonInPatternOverlayScreen = '#pat-edit'
const editButtonInPatternOverlay = 'button[class="pt-button ng-star-inserted"]'
const viewButtonInPatternOverlayScreen = 'button[class="mx-2 pt-primary view-btn pt-button"]'
const relevanceCollapsedIcon = 'div[aria-expanded="false"]'
const knowledgeSectionInOverlayScreen = 'label[class="font-sans-bold font-16 space-pre-wrap col-12"]'
const knowledgeNameInOverlayScreen = "header>section"
const knowledgeSectionExpandCollapseIcon = "dls-expander svg"
const tagsSectionInOverlay = "//label[contains(text(),'Tags')]"
const knowledgeDetails = "section>p"
const causeAndSolutionDetails = 'div[class="preview-section"]'
const severityClearButton = '#modifiedBy_clearBtn'
const modalityColumnValue = '#multiselect-filter div>div[class]'
const tagColumn = '#column_tagValue'
const tagColumnSearchBox = 'input[placeholder="Filter Options"]'
const tagColumnValues = 'ul[role="listbox"] span[class="ng-star-inserted"]'
const tagColumnSearchedValue = 'li[aria-label="DICOM/RIS/PACS"]'
const tagColumnSearchValue = 'li[aria-label="Dicom"]'
const tagColumnSelectedValue = 'li[aria-label="AWS"]'
const tagColumnSelectedValueAsCollimeter = 'li[aria-label="Collimeter"]'
const dashboardDropdownColumn = '#dynamic-column-selector'
const checkboxesAtColumn = '.p-multiselect-header > .p-checkbox > .p-checkbox-box'
const publishButton = '#publish-pattern'
const publishButtonFromRightClick = '#Publish'
const firstKnowledge = '[class="p-element p-datatable-tbody"] tr td '
const disabledClassForPublishButton = 'pt-menu-item pt-disabled ng-star-inserted'
const disabledClassForPublishButton1 = 'topbtns pt-button ng-star-inserted'
const threeDotsGridButton = '#grid-dropdown-btn'
const backButton = 'img[alt="Back"]'
const patternOpen = '//tbody/tr[7]/td[2]'
const withdrawButton = "#Withdraw"
const withdrawButtonInsidePattern = "footer > .align-right > :nth-child(3)"
const myPatternDashboardNavigation = 'div[aria-label="My Patterns"]>button'
const scrollingElement = '[id="calendar-filter"]'
const searchBox = '[id="filter-option"]'
const patternNameAtTop = '[id="pattern-name"]'
const selectAllCheckBox = 'div[role="checkbox"]'
const crossMarkInOverlaySection = '[class="pt-clear-button pt-quiet ng-tns-c5-29 pt-button ng-star-inserted"]'
const tagSectionInOverlaySection  = '[class="ml-3 token-list ng-star-inserted"]'
const tagsInDetailsPage = '[class="token-list knowledge-tags"]'
const FirstRecord = '//tbody/tr[1]/td[2]/span[1]'
const publishButtonInPatternDashboard = '[id="publish-pattern"]'
const cancelButtonInPopUp = '#cancel-btn'
const messageInPublishPopUp = '[id="dialog-title"]'
const patternNameInPopUP = '[role="listitem"]'
const publishButtonInPopUp = '[id="ok-btn"]'
const publishPatternPopUp = ' [id="undefined"]'
const PatternInDraft ='[class="p-element context-menu-area p-selectable-row ng-star-inserted"]'
const norecordText = ' No records found '
const crosssIcon = '[class="icon-dls-cross-circle pt-icon"]'
const publishButtonUnderThreeDots = '#Publish > label'
const publishButtonUnderThreeDotsOfFirstRecord = '[id="Publish"]'
const patternNameDropdown = '[id="dynamic-column-selector"]'
const patternNameSearchOption = '[placeholder="Search"]'
const patternNameSearchIcon = '[class="icon-dls-search pt-icon"]'
const myPatternTextScrollElement = '[aria-label="My Patterns"]'
const checkedCheckBox = '[class="p-checkbox-icon pi pi-check"]'
const deleteButtonIndashbaord = '[id="delete-pattern"]'
const modalitySelectOptions = '[class="p-ripple p-element p-multiselect-item"]'
const columnLevelThreeDots = '[id="grid-dropdown-btn"]'
const Dashboard = '[id="Dashboard"]'
const patternsInPublishedState = '[class="p-element green-text p-resizable-column ng-star-inserted"]'
const modifiedByOption = '[class="p-element p-resizable-column ng-star-inserted"]'
const patternDeleteMessage = 'Patterns Deleted Successfully'
const checkboxInDashboard = "div[role='checkbox']"
const patternWithdrawMessage = 'Patterns Withdrawn Successfully'


let a = ""
let arr1 = [""]
let arr2 = [""]
let myEpoch1 = 0
let myEpoch2 = 0

class PatternDashboard {
  tagsColumnFirstValuSelectedNotVisible() {
    cy.get(modalityColumnValue).eq(30).invoke('text').should('not.include','Dicom')
  }
  tagColumnAllValuSelectionClick() {
    cy.get(checkboxesAtColumn).first().click()
    cy.get(applyFilterButton2).click()
  }
  tagColumnSelectedValuVisible() {
    cy.get(tagColumnSelectedValueAsCollimeter).should(assertionConstants.haveAttributeAssertion,'class','p-ripple p-element p-multiselect-item');
  }
  tagsColumnFirstValuSelectedVerification() {
    cy.get(modalityColumnValue).eq(30).should(assertionConstants.beVisibleAssertion)
  }
  myPatternDashboardNavigationClick() {
    return cy.get(myPatternDashboardNavigation).click()
  }
  patternNameTypeInKnowledgeSearchFilter() {
    cy.readFile('cypress/fixtures/patternNameCreation.json').then(function (result) {
        PatternName = result.name;
        cy.get(patternNameSearchField).type(PatternName).type('{enter}');
        cy.wait(3000)

    });
  }
  firstPatternOpenClick() {
    return cy.get(patternNameRecords).first().click()
  }
  withdrawButtonClickFromPattern() {
    return cy.get(withdrawButtonInsidePattern).click()
  }
  withdrawButtonClick() {
    return cy.get(withdrawButton).click()
  }
  backButtonClick() {
    return cy.get(backButton).click()
  }
  threeDotsGridButtonClick() {
    cy.get(threeDotsGridButton).first().scrollIntoView()
    cy.wait(2000)
    cy.get(threeDotsGridButton).first().click({ force: true })
  }
  firstKnowledgeRightClick() {
    return cy.get(firstKnowledge).eq(1).rightclick()
  }
  secondKnowledgeRightClick() {
    cy.xpath(patternOpen).scrollIntoView()
    return cy.xpath(patternOpen).scrollIntoView().rightclick()
  }
  publishButtonByRightClickVisibleAsDisabled() {
    return cy.get(publishButtonFromRightClick).should(assertionConstants.beVisibleAssertion).should(assertionConstants.haveAttributeAssertion,'class', disabledClassForPublishButton)
  }
  publishButtonByRightClickVisibleAsDisable() {
    return cy.get(publishButton).should(assertionConstants.beVisibleAssertion)
  }
  publishButtonByRightClickVisibleAsEnabled() {
    cy.get(publishButtonFromRightClick).should(assertionConstants.beVisibleAssertion)
    // cy.get(publishButtonFromRightClick).should(assertionConstants.notHaveClassAssertion,disabledClassForPublishButton)
  }
  publishButtonVisibleAsDisabled() {
    return cy.get(publishButton).should(assertionConstants.beVisibleAssertion).should(assertionConstants.haveAttributeAssertion,'class', disabledClassForPublishButton1)
  }
  publishButtonVisibleAsEnabled() {
    return cy.get(publishButton).should(assertionConstants.beVisibleAssertion).should(assertionConstants.notHaveClassAssertion,disabledClassForPublishButton)
  }
  dashboardDropdownColumnClick() {
    return cy.get(dashboardDropdownColumn).click()
  }
  multipleTagsSelectionFromDropdown() {
    cy.get(tagColumnValues).eq(1).click();
    cy.get(tagColumnValues).eq(2).click()
    cy.get(applyFilterButton2).click()
  }
  tagColumnSelectedValueVisible() {
    cy.get(tagColumnSelectedValue).should(assertionConstants.haveAttributeAssertion,'class','p-ripple p-element p-multiselect-item p-highlight');
  }
  selectedTagsVisible() {
    return cy.xpath(createdOnRecords1).should(assertionConstants.beVisibleAssertion);
  }
  TagsColumnPopUpNotVisible() {
    return cy.get(TagsClearButton).should(assertionConstants.notExistsAssertion);
  }
  tagColumnSearchBoxType() {
    cy.get(tagColumnSearchBox).type('Dicom');
  }
  tagColumnSearchedValueVisible() {
    cy.get(tagColumnSearchedValue).should(assertionConstants.beVisibleAssertion);
  }
  tagColumnSearchValueVisible() {
    cy.get(tagColumnSearchValue).should(assertionConstants.beVisibleAssertion);
  }
  tagsColumnFirstValueSelectedVerification() {
    cy.get(modalityColumnValue).eq(30).invoke('text').should('include','AWS')
  }
  tagsColumnFirstValueSelectedNotVisible() {
    cy.get(modalityColumnValue).eq(30).invoke('text').should('not.include','Collimeter')
  }
  tagsColumnMultipleValueSelectedVerification() {
    cy.get(modalityColumnValue).eq(30).invoke('text').should('include','Collimeter')
  }
  tagColumnFirstValueClick() {
    cy.get(tagColumnValues).first().click();
    cy.get(applyFilterButton2).click()
  }
  tagColumnBesideTheBoxClick() {
    cy.get(applyFilterButton2).click()
  }
  tagColumnValuesSortedDataVerification() {
    cy.get(tagColumnValues).eq(0).invoke('text').then((value) => {
      cy.wait(2000)
      arr1.length = 0
      arr1.push(value.slice(0, 2))
    });
    cy.get(tagColumnValues).eq(1).invoke('text').then((value) => {
      cy.wait(2000)
      arr2.length = 0
      arr2.push(value.slice(0, 2))
    });
    cy.log(arr1)
    cy.log(arr2)
    this.sortedAscending()
  }
  TagsClearButtonVisible() {
    return cy.get(TagsClearButton).should(assertionConstants.beVisibleAssertion);
  }
  tagColumnAllValueSelectionCheckBoxVisible() {
    cy.get(checkboxesAtColumn).first().should(assertionConstants.beVisibleAssertion)
  }
  tagColumnAllValueSelectionClick() {
    cy.get(checkboxesAtColumn).first().scrollIntoView().click()
    cy.get(applyFilterButton2).click({force:true})
  }
  tagColumnSearchBoxVisible() {
    cy.get(tagColumnSearchBox).should(assertionConstants.beVisibleAssertion);
  }
  tagColumnClick() {
    cy.get(tagColumn).scrollIntoView()
    cy.get(tagColumn).scrollIntoView().click();
  }
  selectTagsDropdownValue() {
    cy.get(unselectedDropdownValues).last().click();
  }
  modalityColumnValueVerification() {
    cy.get(modalityColumnValue).eq(14).invoke('text').should('include','All')
  }
  severityClearButtonClick() {
    cy.get(severityClearButton).click()
  }
  causeAndSolutionDetailsVisible() {
    cy.get(causeAndSolutionDetails).scrollIntoView().should(assertionConstants.beVisibleAssertion)
  }
  knowledgeDetailsVisible() {
    cy.get(knowledgeDetails).should(assertionConstants.beExistAssertion)
  }
  tagsSectionInOverlayVisible() {
    cy.xpath(tagsSectionInOverlay).scrollIntoView().should(assertionConstants.beVisibleAssertion)
  }
  causeAndSolutionSectionInOverlayVisible() {
    cy.contains('Causes and Solutions').scrollIntoView().should(assertionConstants.beVisibleAssertion)
  }
  symptomsSectionInOverlayVisible() {
    cy.contains('Symptoms').scrollIntoView().should(assertionConstants.beVisibleAssertion)
  }
  knowledgeSectionExpandCollapseIconVisible() {
    cy.get(knowledgeSectionExpandCollapseIcon).should(assertionConstants.beVisibleAssertion)
  }
  knowledgeNameInOverlayScreenVisible() {
    cy.get(knowledgeNameInOverlayScreen).should(assertionConstants.beVisibleAssertion)
  }
  knowledgeSectionInOverlayScreenVisible() {
    cy.get(knowledgeSectionInOverlayScreen).scrollIntoView().should(assertionConstants.beVisibleAssertion)
  }
  viewButtonInPatternOverlayScreenVisible() {
    cy.get(viewButtonInPatternOverlayScreen).should(assertionConstants.beVisibleAssertion)
  }
  viewButtonInPatternOverlayScreenClick() {
    cy.get(viewButtonInPatternOverlayScreen).click()
  }
  editButtonInPatternOverlayScreenVisible() {
    cy.get(editButtonInPatternOverlayScreen).should(assertionConstants.beVisibleAssertion)
  }
  editButtonInPatternOverlayVisible() {
    cy.get(editButtonInPatternOverlay).last().should(assertionConstants.beVisibleAssertion)
  }
  editButtonInPatternOverlayScreenVisibleAsDisabled() {
    cy.get(editButtonInPatternOverlayScreen).should(assertionConstants.haveAttributeAssertion, 'class', 'btnbox pt-button ng-star-inserted')
  }
  knowledgeSectionExpandedVisible() {
    cy.get(knowledgeExpanded).should(assertionConstants.beVisibleAssertion)
  }
  relevanceExpandedIconVisible() {
    cy.get(relevanceExpandedIcon).should(assertionConstants.beVisibleAssertion)
  }
  relevanceCollapsedModalitiesVisible() {
    cy.wait(2000)
    cy.get(relevanceCollapsedIcon).first().should(assertionConstants.beVisibleAssertion)
  }
  rightSideOverlaySectionVisible() {
    cy.get(rightSideOverlaySection).eq(0).should(assertionConstants.beVisibleAssertion)
  }
  patternDashboardColumnFirstRecordClick() {
    cy.xpath(patternStateRecords1).click(); 
  }
  patternDashboardFirstRecordClick() {
    cy.xpath(patternDashboardNameColumnRecords1).click({ force: true });
  }
  patternDashboardColumnSecondRecordClick() {
    cy.xpath(patternDashboardNameColumnRecords2).click();
  }
  multipleColumnFilter() {
    cy.get(patternNameSearchField).type('Test{enter}')
    cy.get(patternStatusColumn).click()
    cy.get(DraftOptionFromModalityDropdown).click()
    cy.get(applyFilterButton).click()
  }
  clearAllFilterButtonClick() {
    cy.get(clearAllFilterButton).click();
  }
  myPatternDashboardNavigation() {
    cy.get(myPatternsExpandArrow).eq(0).click();
    cy.get(myPatternsDashboard).eq(1).click()
  }
  modifiedonColumnDateRangeClearButtonClick() {
    cy.get(modifiedOnDateRangeClearButton).click();
  }
  publishedonnColumnDateRangeClearButtonClick() {
    cy.get(publishedOnDateRangeClearButton).click();
  }
  calenderFutureDateSelection() {
    cy.get(datePickerNextMonthIcon).click({ force: true })
    cy.get(calenderDateSelection).eq(8).click()
    cy.get(calenderDateSelection).eq(20).click()
    cy.get(modifiedOnDateRangeApplyButton).click()
  }
  calenderDateSelectionForPublishedOnColumn() {
    cy.get(datePicker).click({ force: true })
    cy.get(calenderDateSelection).eq(8).click()
    cy.get(calenderDateSelection).eq(20).click()
    cy.get(publishedOnDateRangeApplyButton).click()
  }
  calenderDateSelection() {
    cy.get(datePicker).click({ force: true })
    cy.get(calenderDateSelection).eq(8).click()
    cy.get(calenderDateSelection).eq(20).click()
    cy.get(modifiedOnDateRangeApplyButton).click()
  }
  modifiedonColumnDateRangeClick() {
    cy.get(dateRangeColumn).eq(0).scrollIntoView().click();
  }
  publishedonColumnDateRangeClick() {
    cy.get(dateRangeColumn).eq(1).scrollIntoView().click();
  }
  dateRangeColumnsVisible() {
    cy.get(dateRangeColumn).eq(0).should(assertionConstants.beVisibleAssertion)
  }
  patternStateColumnClick() {
    return cy.get(modalityColumnDropdown).eq(0).click()
  }
  MultipleOptionSelectionFromModalityDropdown() {
    cy.get(ICAPOptionFromModalityDropdown).click()
    cy.xpath(modalityApplyButton).click()
  }
  allColumnsSelectedVerification() {
    cy.get(allcolumnsSelected).invoke('text').should('include', 'Pattern Name ... +14 more')
  }
  MultipleOptionSelectionFromPatternStateDropdown() {
    cy.get(DraftOptionFromModalityDropdown).click()
    cy.get(patternStatusApplyButton).click()
  }
  multipleFiltersAppliedRecordsTextVerification() {
    return cy.xpath(patternStateRecords1).invoke('text').should('include', 'Draft')
  }
  patternStateRecordsTextVerificationAfterFilterApply() {
    cy.wait(2000)
    return cy.xpath(patternStateRecords1).invoke('text').should('include', 'Draft')
  }
  patternStateColumnTextCapture() {
    return cy.get(modalityColumnText).eq(0).scrollIntoView().invoke('text').then((value) => {
      arr1.length = 0;
      arr1.push(value)
      cy.wait(2000)
    })
  }
  modalityColumnTextCapture() {
    return cy.get(modalityColumnText).eq(3).scrollIntoView().invoke('text').then((value) => {
      arr1.length = 0;
      arr1.push(value)
      cy.wait(2000)
    })
  }
  modalityRecordsTextVerificationAfterFilterApply() {
    return cy.xpath(modalityRecords1).invoke('text').should('include', arr1)
  }
  validPatternNameFilterTextVerification() {
    return cy.xpath(invokedTextOfFirstRecord).invoke('text').should('include', 'est')
  }
  noRecordsFoundTextValidation() {
    cy.get(noRecordsFoundText).scrollIntoView().should(assertionConstants.beVisibleAssertion)
  }
  patternNameSearchWithInvalidText() {
    cy.get(patternNameSearchField).click().type('ABCD{enter}');
    cy.wait(2000)
  }
  patternNameSearchWithValidText() {
    return cy.get(patternNameSearchField).clear().type('Test{enter}');
  }
  patternNameSearchClearText() {
    cy.get(clearFilterIcon).click({ force: true })
    cy.wait(2000)
  }
  patternNameTextVerificationAferClearFilter() {
    return cy.xpath(invokedTextOfFirstRecord).invoke('text').should('not.include', 'test')
  }
  singleColumnPresentVerification() {
    arr1 = []
    cy.get(singleColumn).should(assertionConstants.havelengthAssertion, 1)
    cy.get(singleColumn).invoke('text').then((value) => {
      arr1.push(value)
    })
  }
  pageNavigationClick() {
    cy.get(nextPageIcon).click()
    cy.wait(2000)
    cy.get(previousPageIcon).click()
    cy.wait(2000)
  }
  unSelectedSingleColumnsChekboxClick() {
    arr1 = [""]
    cy.get(unSelectedColumnsChekbox).eq(0).click()
      .find(classNameForUnselectedCheckboxes).invoke('text').then((value) => {
        arr1.push(value)
      })
  }
  unSelectedAllColumnsChekboxClickAndRemoveSelected() {
    arr1 = []
    cy.get(columnConfiurationDropdown).click({ force: true })
    cy.get(selectedColumnsChekbox).each(($el) => {
      cy.wrap($el).click()
    })
    cy.get(unSelectedColumnsChekbox).each(($el) => {
      cy.wrap($el).click().find(classNameForUnselectedCheckboxes).invoke('text').then((value) => {
        arr1.push(value)
      })
    })

  }
  unSelectedAllColumnsChekboxClick() {
    arr1 = []
    cy.get(columnConfiurationDropdown).click({ force: true })
    cy.get(unSelectedColumnsChekbox).each(($el) => {
      cy.wrap($el).click().find(classNameForUnselectedCheckboxes).invoke('text').then((value) => {
        arr1.push(value)
      })
    })
  }
  selectedAllColumnsChekboxClick() {
    cy.get(columnConfiurationDropdown).click({ force: true })
    cy.wait(2000)
    cy.get(selectedColumnsChekbox).each(($el) => {
      cy.wrap($el).click().find(classNameForUnselectedCheckboxes).invoke('text').then((value) => {
        arr1.push(value)
      })
    })
  }
  newlyAddedColumnsInDataGridVerify() {
    a = arr1.length
    cy.get(a).each(($el) => {
      cy.wrap($el).then(() => {
        cy.xpath("//th[@id='" + arr1[1] + "']").click().should(assertionConstants.beVisibleAssertion);
      })
    })
  }
  newlyAddedColumnsInDataGridVerification() {
    a = arr1.length
    cy.get(arr1).each((index) => {
      cy.xpath("//th[@id='" + index + "']").click().should(assertionConstants.beVisibleAssertion);

    })
  }
  newlyAddedColumnsInDataGridNotPresentVerification() {
    a = arr1.length
    cy.get(arr1).each((index) => {
      cy.xpath("//th[@id='" + index + "']").should('not.exist');
    })
  }
  selectedColumnsTextCountVerification() {
    cy.get(selectedColumnsText).each(($el) => {
      cy.wrap($el).should(assertionConstants.beVisibleAssertion)
    })
    cy.get(selectedColumnsText).should(assertionConstants.havelengthAssertion, 9)
  }
  unSelectedColumnsTextCountVerification() {
    cy.get(unSelectedColumnsText).each(($el) => {
      cy.wrap($el).should(assertionConstants.beVisibleAssertion)
    })
    cy.get(unSelectedColumnsText).should(assertionConstants.havelengthAssertion, 6)
  }
  selectedColumnsChekboxCountVerification() {
    cy.get(selectedColumnsChekbox).should(assertionConstants.havelengthAssertion, 9)
  }
  unSelectedColumnsChekboxCountVerification() {
    cy.get(unSelectedColumnsChekbox).should(assertionConstants.havelengthAssertion, 6)
  }
  columnConfigurationDropdownClick() {
    cy.get(columnConfiurationDropdown).click({ force: true })
  }
  columnConfiurationDropdownTextVerification() {
    cy.get(columnConfiurationDropdown).invoke('text').should('eq', patternDropdown)
  }
  dataGridInPatternDashboardVerification() {
    cy.get(patternNameColumn).scrollIntoView().should(assertionConstants.beVisibleAssertion);
    cy.get(patternStateColumn).scrollIntoView().should(assertionConstants.beVisibleAssertion);
    cy.get(versionColumn).scrollIntoView().should(assertionConstants.beVisibleAssertion);
    cy.get(modifiedbyColumn).scrollIntoView().should(assertionConstants.beVisibleAssertion);
    cy.get(modifiedonColumn).scrollIntoView().should(assertionConstants.beVisibleAssertion);
    cy.get(modalityColumn).scrollIntoView().should(assertionConstants.beVisibleAssertion);
    cy.get(patterntypeColumn).scrollIntoView().should(assertionConstants.beVisibleAssertion);
    cy.get(serciceconextColumn).click().should(assertionConstants.beVisibleAssertion);
    cy.get(severityColumn).click().should(assertionConstants.beVisibleAssertion);

  }
  severityColumnColumnVisible() {
    return cy.get(severityColumn).scrollIntoView().click({ force: true })
  }
  sercicecontextColumnVisible() {
    return cy.get(serciceconextColumn).scrollIntoView().click({ force: true })
  }
  checkboxesAtColumnLevelValidation() {
    cy.get(checkboxesAtColumn).each(($el) => {
      cy.wrap($el).scrollIntoView().should(assertionConstants.beVisibleAssertion)
    })
  }
  advanceFilterHyperlinkVisible() {
    return cy.get(advanceFilter).should(assertionConstants.beVisibleAssertion);
  }
  TagsClearButtonClick() {
    return cy.get(TagsClearButton).click();
  }
  metdataApplyButton() {
    return cy.get(metdataApplyButton)
  }
  metdataClearButton() {
    return cy.get(metdataClearButton)
  }
  versionApplyButton() {
    return cy.get(versionApplyButton)
  }
  versionClearButton() {
    return cy.get(versionClearButton)
  }
  anotherColumnSelectsMultipleCheckboxes() {
    cy.get(columnFilters).last().click()
    cy.get(filtersCheckboxes).eq(0).click()
    cy.get(filtersCheckboxes).eq(1).click()
    cy.get('button[id="#tagValue_applyBtn"]').scrollIntoView().click()
  }
  selectMultipleCheckboxes() {
    cy.get(columnFilters).last().click()
    cy.get(filtersCheckboxes).eq(0).click()
    cy.get(filtersCheckboxes).eq(1).click()
    cy.get(applyFilterButton2).click()
  }
  filtersCheckboxesVisible() {
    cy.get(filtersCheckboxes).should(assertionConstants.beVisibleAssertion)
  }
  searchTextBoxValidTextTypeinTagsColumn() {
    cy.get(columnFilters).last().click()
    cy.get(searchTextBox).type('AWS')
  }
  clearFilterButtonClick() {
    return cy.get(reviewerClearButton).click()
  }
  filtersCheckboxesNotExistVerification() {
    return cy.get(filtersCheckboxes).should('not.exist')
  }
  searchTextBoxInvalidTextType() {
    cy.get(columnFilters).eq(2).click()
    cy.wait(2000)
    cy.get('.p-multiselect-filter').click({ force: true }).type('Testing')
    cy.wait(2000)
  }
  applyFilterButton() {
    return cy.get(applyFilterButton)
  }
  clearFilterButton() {
    return cy.get(clearFilterButton)
  }
  clearfilterButtonClick() {
    return cy.get(clearFilterButton).click()
  }
  searchTextBox() {
    return cy.get(searchTextBox)
  }
  filtersValues() {
    return cy.get(filtersValues)
  }
  filtersCheckboxes() {
    return cy.get(filtersCheckboxes)
  }
  columnFilters() {
    return cy.get(columnFilters)
  }
  recordsVerificationBeforeClearFilter() {
    cy.get(record).invoke('text').then((value) => {
      arr1.push(value)
      cy.wait(3000)
    })
  }
  recordsVerificationAfterClearFilter() {
    cy.get(record).invoke('text').then((value) => {
      arr2.push(value)
      cy.wait(3000)
    })
    if (arr1[0] <= arr2) {
      cy.log("Verification Passed")
    }
    else {
      cy.log("Verification Failed")

    }
  }
  patternNameNotAvailableAssertion() {
    cy.get("#" + PatternName + " > #nav-dropdown-btn > .ng-star-inserted > #Layer_1").should('not.exist')
  }
  patternNameAvailableAssertion() {
    cy.contains(PatternName).should(assertionConstants.beVisibleAssertion)
  }
  naviagationToNewlyCreatedAuthWFCLick() {
    cy.get(naviagationToNewlyCreatedAuthWF).click({ force: true })
  }
  myPatternDashboardClick() {
    cy.get(myPatternDashboard).eq(1).click()
  }
  deleteButtonClick() {
    cy.get(deleteButtonInsidePattern).click()
  }
  patternNameSearchField() {
    return cy.get(patternNameSearchField);
  }
  myPatternDashboardButtonClick() {
    return cy.get(dashboardButton).eq(1).click();
  }
  invokeTextOfDeletingRecordsVerification() {
    cy.get(invokeTextOfDeletingRecords).eq(0).invoke('text').then((value) => {
      PatternName = value;
    });
  }
  deletePatternButtonFromDashboardClick() {
    return cy.get(deletePatternButton).click();
  }
  patternNamesCheckboxesClick() {
    cy.get(patternNameCheckbox).should(assertionConstants.beVisibleAssertion).then(()=>{
      cy.wait(5000)
      cy.get(patternNameCheckbox).eq(5).click()
      cy.get(patternNameCheckbox).eq(6).click()
    })
  }
  deleteRecordFromPatternDetailsPage() {
    cy.xpath(invokedTextOfFirstRecord).click()
    cy.get(deleteButtonInsidePattern).click()
    cy.get(okButton).click()
    cy.wait(3000)
  }
  invokedTextOfFirstRecord() {
    return cy.xpath(invokedTextOfFirstRecord).invoke('text').then((value) => {
      PatternName = value;
    });
  }
  deletedPatternNotVisible() {
    return cy.contains(PatternName).should('not.exist');
  }
  deleteOptionClick() {
    cy.xpath(deleteOption).click();
  }
  firstRecordThreeDotClick() {
    cy.get(firstRecordThreeDot).eq(0).scrollIntoView().then(() => {
      cy.wait(3000)
      cy.get(firstRecordThreeDot).eq(0).click({ force: true })
    })
  }
  recordsAvailable() {
    return cy.xpath(recordsAvailable).eq(0).should(assertionConstants.beVisibleAssertion)
  }
  tagValue() {
    return cy.xpath(tagValue); 
  }
  valueToCompare() {
    return cy.get(valueToCompare);
  }
  knowledgeDropdownClick() {
    return cy.contains(knowledgeDropdown).click({ force: true });
  }
  recordsTextInvokeFunction1(record1, textValue) {
    cy.xpath(record1).invoke('text').then((value) => {
      cy.wait(2000)
      arr1.length = 0
      arr1.push(value.slice(0, textValue))
    });
  }
  recordsTextInvokeFunction2(record2, textValue) {
    cy.xpath(record2).invoke('text').then((value) => {
      cy.wait(2000)
      arr2.length = 0
      arr2.push(value.slice(0, textValue))
    });
  }
  sortedAscending() {
    if (arr1 >= arr2) {
      cy.log("Data is sorted as ascending");
    }
    else {
      cy.log("Data is sorted as descending");
    }
  }
  sortedDescending() {
    if (arr1 >= arr2) {
      cy.log("Data is sorted as descending");
    }
    else {
      cy.log("Data is sorted as ascending");
    }
  }
  modifiedonColumnClickInKnowledgeAndSortingOfDataVerification() {
    cy.get(modifiedonColumn).click();
    this.recordsTextInvokeFunction1(modifiedOnColumnInKnowledgeRecords1, 2)
    this.recordsTextInvokeFunction2(modifiedOnColumnInKnowledgeRecords2, 2)
    cy.log(arr1)
    cy.log(arr2)
    this.sortedAscending()
    cy.get(modifiedonColumn).click();
    cy.wait(2000)
    this.recordsTextInvokeFunction1(modifiedOnColumnInKnowledgeRecords1, 2)
    this.recordsTextInvokeFunction2(modifiedOnColumnInKnowledgeRecords2, 2)
    cy.log(arr1)
    cy.log(arr2)
    this.sortedDescending()
  }
  modifiedbyColumnClickInKnowledgeAndSortingOfDataVerification() {
    cy.get(modifiedbyColumn).click();
    this.recordsTextInvokeFunction1(modifiedByColumnInKnowledgeRecords1, 1)
    this.recordsTextInvokeFunction2(modifiedByColumnInKnowledgeRecords2, 1)
    cy.log(arr1)
    cy.log(arr2)
    this.sortedDescending()
    cy.get(modifiedbyColumn).click();
    this.recordsTextInvokeFunction1(modifiedByColumnInKnowledgeRecords1, 1)
    this.recordsTextInvokeFunction2(modifiedByColumnInKnowledgeRecords2, 1)
    cy.log(arr1)
    cy.log(arr2)
    this.sortedAscending()
  }
  knowledgeStateColumnClickAndSortedDataVerification() {
    cy.get(knowledgeState).click();
    this.recordsTextInvokeFunction1(knowledgeStateRecords1, 5)
    this.recordsTextInvokeFunction2(knowledgeStateRecords2, 5)
    cy.log(arr1)
    cy.log(arr2)
    this.sortedAscending()
    cy.get(knowledgeState).click();
    cy.wait(2000)
    this.recordsTextInvokeFunction1(knowledgeStateRecords1, 5)
    this.recordsTextInvokeFunction2(knowledgeStateRecords2, 5)
    cy.log(arr1)
    cy.log(arr2)
    this.sortedDescending()
  }
  noOfAssociationColumnClickAndSortedDataVerification() {
    cy.get(noOfAssociationColumn).click();
    this.recordsTextInvokeFunction1(noOfAssociationRecords1, 1)
    this.recordsTextInvokeFunction2(noOfAssociationRecords2, 1)
    cy.log(arr1)
    cy.log(arr2)
    this.sortedAscending()
    cy.get(noOfAssociationColumn).click();
    cy.wait(2000)
    this.recordsTextInvokeFunction1(noOfAssociationRecords1, 1)
    this.recordsTextInvokeFunction2(noOfAssociationRecords2, 1)
    cy.log(arr1)
    cy.log(arr2)
    this.sortedDescending()
  }
  knowledgeNameColumnClickAndSortedDataVerification() {
    cy.get(knowledgeName).click();
    this.recordsTextInvokeFunction1(knowledgeNameRecords1, 3)
    this.recordsTextInvokeFunction2(knowledgeNameRecords2, 3)
    cy.log(arr1)
    cy.log(arr2)
    this.sortedAscending()
    cy.get(knowledgeName).click();
    cy.wait(2000)
    this.recordsTextInvokeFunction1(knowledgeNameRecords1, 3)
    this.recordsTextInvokeFunction2(knowledgeNameRecords2, 3)
    cy.log(arr1)
    cy.log(arr2)
    this.sortedDescending()
  }
  modalityColumnClickkInKnowledgeAndSortingOfDataVerification() {
    cy.get(modalityColumn).click();
    this.recordsTextInvokeFunction1(modalityRecordsInKnowledge1, 3)
    this.recordsTextInvokeFunction2(modalityRecordsInKnowledge2, 3)
    cy.log(arr1)
    cy.log(arr2)
    this.sortedAscending()
    cy.get(modalityColumn).click();
    cy.wait(2000)
    this.recordsTextInvokeFunction1(modalityRecordsInKnowledge1, 3)
    this.recordsTextInvokeFunction2(modalityRecordsInKnowledge2, 3)
    cy.log(arr1)
    cy.log(arr2)
    this.sortedDescending()
  }
  sortedDataVerificationForKnowledge() {
    cy.xpath(firstRecordTextForKnowledge).eq(0).invoke('text').then((value) => {
      cy.wait(2000)
      arr1.length = 0
      arr1.push(value.toString())
    });
    cy.xpath(modifiedOnColumnInKnowledgeRecords1).eq(0).invoke('text').then((value) => {
      cy.wait(2000)
      arr2.length = 0
      arr2.push(value.toString())
    });
    cy.log(arr1)
    cy.log(arr2)
    const myDate1 = new Date(arr1);
    cy.wait(2000)
    myEpoch1 = myDate1.getTime() / 1000;
    const myDate2 = new Date(arr2);
    cy.wait(2000)
    myEpoch2 = myDate2.getTime() / 1000;
    cy.log(myDate1)
    cy.log(myDate2)
    cy.log(myEpoch1)
    cy.log(myEpoch2)
    if (myEpoch1 <= myEpoch2) {
      cy.log("Data is sorted");
    }
    else {
      cy.log("Data not sorted");
    }
  }
  selectDropdownValues() {
    cy.get(patternNameDropdown).click()
    cy.get(unselectedDropdownValues).each((index) => {
      cy.wrap(index).click();
    });
  }
  selectdropdownValues() { 
    cy.get(patternNameDropdown).click()
    cy.get(unselectedDropdownValues).each((index) => {
      cy.wrap(index).click();
    });
  }
  patternNameColumnClick() {
    cy.get(patternNameColumn).click();
    return cy.get(patternNameColumn).click()
  }
  patternNameColumnClickAndSortingOfDataVerification() {
    cy.get(patternNameColumn).click();
    cy.get(patternNameRecords).eq(0).invoke('text').then((value) => {
      cy.wait(2000)
      arr1.length = 0
      arr1.push(value.toString())
    });
    cy.get(patternNameRecords).eq(1).invoke('text').then((value) => {
      cy.wait(2000)
      arr2.length = 0
      arr2.push(value.toString())
    });
    cy.log(arr1)
    cy.log(arr2)
    this.sortedAscending()
    cy.get(patternNameColumn).click();
    cy.wait(2000)
    cy.get(patternNameRecords).eq(0).invoke('text').then((value) => {
      cy.wait(2000)
      arr1.length = 0
      arr1.push(value.toString())
    });
    cy.get(patternNameRecords).eq(1).invoke('text').then((value) => {
      cy.wait(2000)
      arr2.length = 0
      arr2.push(value.toString())
    });
    cy.log(arr1)
    cy.log(arr2)
    this.sortedDescending()
  }
  patternStateColumnClickAndSortingOfDataVerification() {
    cy.get(patternStateColumn).click();
    this.recordsTextInvokeFunction1(patternStateRecords1, 3)
    this.recordsTextInvokeFunction2(patternStateRecords2, 3)
    cy.log(arr1)
    cy.log(arr2)
    this.sortedAscending()
    cy.get(patternStateColumn).click();
    cy.wait(2000)
    this.recordsTextInvokeFunction1(patternStateRecords1, 3)
    this.recordsTextInvokeFunction2(patternStateRecords2, 3)
    cy.log(arr1)
    cy.log(arr2)
    this.sortedDescending()
  }
  versionColumnClickAndSortingOfDataVerification() {
    cy.get(versionColumn).click();
    this.recordsTextInvokeFunction1(versionRecords1, 3)
    this.recordsTextInvokeFunction2(versionRecords2, 3)
    cy.log(arr1)
    cy.log(arr2)
    this.sortedAscending()
    cy.get(versionColumn).click();
    cy.wait(2000)
    this.recordsTextInvokeFunction1(versionRecords1, 3)
    this.recordsTextInvokeFunction2(versionRecords2, 3)
    cy.log(arr1)
    cy.log(arr2)
    this.sortedDescending()
  }
  modifiedbyColumnClickAndSortingOfDataVerification() {
    cy.get(modifiedbyColumn).click();
    this.recordsTextInvokeFunction1(modifiedByRecords1, 3)
    this.recordsTextInvokeFunction2(modifiedByRecords2, 3)
    cy.log(arr1)
    cy.log(arr2)
    this.sortedAscending()
    cy.get(modifiedbyColumn).click();
    this.recordsTextInvokeFunction1(modifiedByRecords1, 3)
    this.recordsTextInvokeFunction2(modifiedByRecords2, 3)
    cy.log(arr1)
    cy.log(arr2)
    this.sortedDescending()
  }
  modifiedonColumnClickAndSortingOfDataVerification() {
    cy.get(modifiedonColumn).click();
    this.recordsTextInvokeFunction1(modifiedOnRecords1, 3)
    this.recordsTextInvokeFunction2(modifiedOnRecords2, 3)
    cy.log(arr1)
    cy.log(arr2)
    this.sortedAscending()
    cy.get(modifiedonColumn).click();
    cy.wait(2000)
    this.recordsTextInvokeFunction1(modifiedOnRecords1, 3)
    this.recordsTextInvokeFunction2(modifiedOnRecords2, 3)
    cy.log(arr1)
    cy.log(arr2)
    this.sortedDescending()
  }
  createdbyColumnClickAndSortingOfDataVerification() {
    cy.get(createdBy).click();
    this.recordsTextInvokeFunction1(createdByRecords1, 3)
    this.recordsTextInvokeFunction2(createdByRecords2, 3)
    cy.log(arr1)
    cy.log(arr2)
    this.sortedAscending()
    cy.get(createdBy).click();
    this.recordsTextInvokeFunction1(createdByRecords1, 3)
    this.recordsTextInvokeFunction2(createdByRecords2, 3)
    cy.log(arr1)
    cy.log(arr2)
    this.sortedDescending()
  }
  createdOnColumnClickAndSortingOfDataVerification() {
    cy.get(createdOn).click();
    this.recordsTextInvokeFunction1(createdOnRecords1, 3)
    this.recordsTextInvokeFunction2(createdOnRecords2, 3)
    cy.log(arr1)
    cy.log(arr2)
    this.sortedAscending()
    cy.get(createdOn).click();
    cy.wait(2000)
    this.recordsTextInvokeFunction1(createdOnRecords1, 3)
    this.recordsTextInvokeFunction2(createdOnRecords2, 3)
    cy.log(arr1)
    cy.log(arr2)
    this.sortedDescending()
  }
  modalityColumnClickkAndSortingOfDataVerification() {
    cy.get(modalityColumn).click();
    this.recordsTextInvokeFunction1(modalityRecords1, 3)
    this.recordsTextInvokeFunction2(modalityRecords2, 3)
    cy.log(arr1)
    cy.log(arr2)
    this.sortedAscending()
    cy.get(modalityColumn).click();
    cy.wait(2000)
    this.recordsTextInvokeFunction1(modalityRecords1, 3)
    this.recordsTextInvokeFunction2(modalityRecords2, 3)
    cy.log(arr1)
    cy.log(arr2)
    this.sortedDescending()
  }
  patterntypeColumnClickAndSortingOfDataVerification() {
    cy.get(patterntypeColumn).click();
    this.recordsTextInvokeFunction1(patternTypeRecords1, 3)
    this.recordsTextInvokeFunction2(patternTypeRecords2, 3)
    cy.log(arr1)
    cy.log(arr2)
    this.sortedAscending()
    cy.get(patterntypeColumn).click();
    cy.wait(2000)
    this.recordsTextInvokeFunction1(patternTypeRecords1, 3)
    this.recordsTextInvokeFunction2(patternTypeRecords2, 3)
    cy.log(arr1)
    cy.log(arr2)
    this.sortedDescending()
  }
  serciceconextColumnClickAndSortingOfDataVerification() {
    cy.get(serciceconextColumn).click();
    this.recordsTextInvokeFunction1(modifiedOnColumnInKnowledgeRecords1, 3)
    this.recordsTextInvokeFunction2(serviceContextRecords2, 3)
    cy.log(arr1)
    cy.log(arr2)
    this.sortedAscending()
    cy.get(serciceconextColumn).click();
    cy.wait(2000)
    this.recordsTextInvokeFunction1(modifiedOnColumnInKnowledgeRecords1, 3)
    this.recordsTextInvokeFunction2(serviceContextRecords2, 3)
    cy.log(arr1)
    cy.log(arr2)
    this.sortedDescending()
  }
  severityColumnClickAndSortingOfDataVerification() {
    cy.get(severityColumn).click();
    this.recordsTextInvokeFunction1(severityRecords1, 1)
    this.recordsTextInvokeFunction2(severityRecords2, 1)
    cy.log(arr1)
    cy.log(arr2)
    this.sortedAscending()
    cy.get(severityColumn).click();
    cy.wait(2000)
    this.recordsTextInvokeFunction1(severityRecords1, 1)
    this.recordsTextInvokeFunction2(severityRecords2, 1)
    cy.log(arr1)
    cy.log(arr2)
    this.sortedDescending()
  }
  modifiedOnColumnSortedVerificationForASC() {
    cy.get(sortinIcon).should(assertionConstants.haveAttributeAssertion, 'class', upArrow)
    cy.get(sortinIcon).should(assertionConstants.haveNotAttributeAssertion, 'class', downArrow)
  }
  modifiedOnColumnSortVerificationForASC() {
    cy.get(sortinIcon).should(assertionConstants.haveAttributeAssertion, 'class', upArrow)
    cy.get(sortinIcon).should(assertionConstants.haveNotAttributeAssertion, 'class', downArrow)
  }
  modifiedOnColumnSortedIconVerificationForASC() {
    cy.get(sortinIcon).should(assertionConstants.haveAttributeAssertion, 'class', downArrow)
    cy.get(sortinIcon).should(assertionConstants.haveNotAttributeAssertion, 'class', upArrow)
  }
  sortedDataVerification() {
    cy.xpath(firstRecordText).eq(0).invoke('text').then((value1) => {
      cy.wait(2000)
      arr1.length = 0
      arr1.push(value1.toString())
    });
    cy.xpath(secodRecordText).eq(0).invoke('text').then((value2) => {
      cy.wait(2000)
      arr2.length = 0
      arr2.push(value2.toString())
    });
  }
  modifiedonColumnClickk() {
    cy.get(modifiedonColumn).scrollIntoView().click({ force: true });
  }
  modifiedOnColumnDescSortedVerification() {
    cy.get(sortinIcon).should(assertionConstants.haveAttributeAssertion, 'class', downArrow)
  }
  modifiedOnColumnASCSortedVerification() {
    cy.get(sortinIcon).should(assertionConstants.haveAttributeAssertion, 'class', downArrow)
  }
  modifiedOnColumnASCSortedVerificationInKnowledgeDashboard() {
    cy.get(sortinIcon).should(assertionConstants.haveAttributeAssertion, 'class', upArrow)
  }
  modifiedOnColumnDESCSortedVerification() {
    cy.get(sortinIcon).should(assertionConstants.haveAttributeAssertion, 'class', downArrow)
  }
  modifiedOnColumnSortedIconVerificationDESC() {
    cy.get(sortinIcon).should(assertionConstants.haveAttributeAssertion, 'class', downArrow)
    cy.get(sortinIcon).should(assertionConstants.haveNotAttributeAssertion, 'class', upArrow)

  }
  byDefaultModifiedOnColumnSortedVerification() {
    return cy.get(modifiedonColumn).should(assertionConstants.haveAttributeAssertion, 'aria-sort')
  }
  modifiedOnColumnSortedVerification() {
    return cy.get(modifiedonColumn).should(assertionConstants.haveAttributeAssertion, 'aria-sort', 'descending')
  }
  clearButtonClick() {
    return cy.get(clearButton).click()
  }
  modalityColumnClick() {
    return cy.xpath("//div[contains(text(),'DXR')]").scrollIntoView().click()
  }
  modalityClick() {
    cy.get(scrollingElement).eq(0).scrollIntoView()
    return cy.xpath("//th[@id='column_metadata.modality']").scrollIntoView().click()
  }
  dropdownResultVerification() {
    cy.get(dropdownResults).each(($el) => {
      cy.wrap($el).should(assertionConstants.beVisibleAssertion);
    });
  }
  breadcrumbVisible() {
    return cy.get(breadcrumb).should(assertionConstants.beVisibleAssertion);
  }
  myPatternClick() {
    return cy.get(myPattern).click({ force: true });
  }
  firstPatternClick() {
    return cy.get(firstPattern).click({ force: true });
  }
  patternGuidVisible() {
    return cy.xpath(patternGuid).should(assertionConstants.beVisibleAssertion);
  }
  patternDiscriptionVisible() {
    return cy.xpath(patternDiscription).should(assertionConstants.beVisibleAssertion);
  }
  PublishedOnFilterClick() {
    return cy.contains("Published On").click({ force: true });
  }
  PublishedByFilterClick() {
    return cy.contains("Published By").click({ force: true });
  }
  ReviewedByFilterClick() {
    return cy.contains("Reviewed By").click({ force: true });
  }
  CreatedByFilterClick() {
    return cy.contains("Created By").click({ force: true });
  }
  CreatedOnFilterClick() {
    return cy.contains("Created On").click({ force: true });
  }
  patternDropdownWithAdditionOfColumnVisible() {
    return cy.contains(patternDropdownWithAdditionOfColumn).should(assertionConstants.beVisibleAssertion);
  }
  tagsButtonClick() {
    return cy.get(tagsButton).click({ force: true });
  }
  reviewdByColumnClick() {
    return cy.get(reviewdBy).click();
  }
  publishedByColumnClick() {
    return cy.get(publishedBy).click();
  }
  publishedOnColumnClick() {
    return cy.get(publishedOn).click();
  }
  createdByColumnClick() {
    return cy.get(createdBy).click();
  }
  createdOnColumnClick() {
    return cy.get(createdOn).click();
  }
  tagsColumnClick() {
    return cy.get(tags).click();
  }
  patternStateColumnVisible() {
    return cy.get(patternStateColumn).should(assertionConstants.beVisibleAssertion);
  }
  versionColumnVisible() {
    return cy.get(versionColumn).should(assertionConstants.beVisibleAssertion);
  }
  modifiedbyColumnVisible() {
    return cy.get(modifiedbyColumn).should(assertionConstants.beVisibleAssertion);
  }
  modifiedonColumnVisible() {
    return cy.get(modifiedonColumn).should(assertionConstants.beVisibleAssertion);
  }
  modalityColumnVisible() {
    return cy.get(modalityColumn).should(assertionConstants.beVisibleAssertion);
  }
  patterntypeColumnVisible() {
    return cy.get(patterntypeColumn).should(assertionConstants.beVisibleAssertion);
  }
  patternNameColumnVisible() {
    return cy.get(patternNameColumn).should(assertionConstants.beVisibleAssertion);
  }
  entriesPerPageVisible() {
    return cy.contains(entriesPerPage).should(assertionConstants.beVisibleAssertion);
  }
  entriesPerPageCountVerification() {
    return cy.get(entriesPerpage).invoke('text').should("include", "15");
  }
  clearFiltersVisible() {
    return cy.contains(clearFilters).should(assertionConstants.beVisibleAssertion);
  }
  clearFiltersClick() {
    return cy.contains(clearFilters).click();
  }
  recordsVisible() {
    return cy.get(records).should(assertionConstants.beVisibleAssertion);
  }
  patternDropdownVisible() {
    return cy.get(patternNameDropdown).should(assertionConstants.beVisibleAssertion);
  }
  patternDropdownClick() {
    return cy.get(patternNameDropdown).click({ force: true });
  }
  withdrawPatternButtonDisabled() {
    return cy.get(withdrawPatternButton).should("be.disabled");
  }
  withdrawPatternButtonVisible() {
    return cy.get(withdrawPatternButton).should(assertionConstants.beVisibleAssertion);
  }
  deletePatternButtonDisabled() {
    return cy.get(deletePatternButton).should("be.disabled");
  }
  deletePatternButtonVisible() {
    return cy.get(deletePatternButton).should(assertionConstants.beVisibleAssertion);
  }
  patternTitleVisible() {
    return cy.xpath(patternTitle).should(assertionConstants.beVisibleAssertion);
  }
  dashboardButtonClick() {
    return cy.get(dashboardButton).eq(0).click();
  }
  dashboardButtonVisible() {
    return cy.get(dashboardButton).eq(0).should(assertionConstants.beVisibleAssertion);
  }
  myPatternDashboardButtonVisible() {
    return cy.get(dashboardButton).eq(1).should(assertionConstants.beVisibleAssertion);
  }
  myPatternDashboardButton() {
    return cy.get(myPatternDashboardButton);
  }
  dashboardButton() {
    return cy.get(dashboardButton);
  }
  patternDropdown() {
    return cy.contains(patternDropdown);
  }
  patternDropdownWithAdditionOfColumn() {
    return cy.contains(patternDropdownWithAdditionOfColumn);
  }
  dropdownResults() {
    return cy.get(dropdownResults);
  }
  patternNameField() {
    return cy.get(patternNameField);
  }
  deletePatternButton() {
    return cy.get(deletePatternButton);
  }
  withdrawPatternButton() {
    return cy.get(withdrawPatternButton);
  }
  patternTitle() {
    return cy.xpath(patternTitle);
  }
  patternNameColumn() {
    return cy.get(patternNameColumn);
  }
  patternStateColumn() {
    return cy.get(patternStateColumn);
  }
  versionColumn() {
    return cy.get(versionColumn);
  }
  modifiedbyColumn() {
    return cy.get(modifiedbyColumn);
  }
  modifiedonColumn() {
    return cy.get(modifiedonColumn);
  }
  modalityColumn() {
    return cy.get(modalityColumn);
  }
  patterntypeColumn() {
    return cy.get(patterntypeColumn);
  }
  serciceconextColumn() {
    return cy.get(serciceconextColumn);
  }
  severityColumn() {
    return cy.get(severityColumn);
  }
  sideClick() {
    return cy.xpath(sideClick);
  }
  reviewdBy() {
    return cy.get(reviewdBy);
  }
  publishedBy() {
    return cy.get(publishedBy);
  }
  publishedOn() {
    return cy.get(publishedOn);
  }
  createdBy() {
    return cy.get(createdBy);
  }
  createdOn() {
    return cy.get(createdOn);
  }
  tags() {
    return cy.get(tags);
  }
  clearFilters() {
    return cy.contains(clearFilters);
  }
  entriesPerPage() {
    return cy.contains(entriesPerPage);
  }
  records() {
    return cy.get(records);
  }
  patternGuid() {
    return cy.xpath(patternGuid);
  }
  patternDiscription() {
    return cy.xpath(patternDiscription);
  }
  patternDashboardTitleVisible() {
    cy.get(patternDashboardTitle).should(assertionConstants.haveTextAssertion, 'Patterns').and(assertionConstants.beVisibleAssertion)
  }
  patternDashboardBreadCrumVisible() {
    cy.get(patternDashboardBreadCrum).find('li').should(assertionConstants.havelengthAssertion, '5')
  }

  patternClick() {
    cy.get(pattern).last().find('td').eq(1).find('[class="btn-link ng-star-inserted"]').first().click({ force: true })
  }

  fullscreenViewButtonvisible() {
    cy.get(fullscreenViewButton).should(assertionConstants.beVisibleAssertion)
  }

  fullscreenViewButtonClick() {
    cy.get(fullscreenViewButton).click({ force: true })
  }

  fullScreenVisible() {
    cy.get(fullScreen).should(assertionConstants.beVisibleAssertion)
  }

  patternHeaderWithPatternDetailsVisible() {
    cy.get(patternHeaderWithPatternDetails).find('span').first().should(assertionConstants.haveTextAssertion, 'Pattern Details ').and(assertionConstants.beVisibleAssertion)
  }

  buttonsAtBottomVisible() {
    cy.get(buttonsAtBottom).find('button').should(assertionConstants.beVisibleAssertion)
  }

  backArrowClick() {
    cy.get(backArrow).click()
  }

  fullScreenNotExist() {
    cy.get(fullScreen).should(assertionConstants.notExistsAssertion)
  }

  readOnlyModeExist() {
    cy.get(readOnlyMode).should(assertionConstants.beExistAssertion)
  }

  dashboardWithPattrensVisible() {
    cy.get(dashboardWithPattrens).find('td').should(assertionConstants.beVisibleAssertion)
  }

  toggleIconVisible() {
    cy.get(toggleIcon).should(assertionConstants.beVisibleAssertion)
  }

  leftPaneDashboardBoxVisible() {
    cy.get(leftPaneDashboardBox).should(assertionConstants.beVisibleAssertion)
  }

  myPattrenDashboardClick() {
    cy.get(myPattrenDashboard).last().click()
  }

  mypatternDashboardBreadCrumVisible() {
    cy.get(patternDashboardBreadCrum).find('li').should(assertionConstants.havelengthAssertion, '7')
  }
  patternsVisible() {
    cy.get(patterns).find('tr').should(assertionConstants.beVisibleAssertion)
  }

  patternsCheckboxUnchecked() {
    cy.get(patternsCheckbox).should(assertionConstants.notBeCheckedAssertion)
  }

  threeDotsClick() {
    cy.get(threeDots).last().scrollIntoView().click()
  }

  cloneButtonEnabledVisible() {
    cy.get(cloneButton).should(assertionConstants.notHaveClassAssertion, 'pt-menu-item pt-disabled ng-star-inserted').and(assertionConstants.beVisibleAssertion)
  }

  firstKnowledgwSelect() {
    cy.get(KnowledgwSelectcheckBox).eq(1).click()
  }






  patternDetailsIngridVisible() {
    cy.get(patternDetailsIngrid).should(assertionConstants.beVisibleAssertion)
  }

  patternNameExist() {
    cy.get(patternName).invoke('text').then((name) => {
      expect(name).to.be.exist
    })
  }

  versionLableExist() {
    cy.get(versionLable).invoke('text').then((versionlable) => {
      expect(versionlable).to.be.exist
    })
  }

  versionValueExist() {
    cy.get(versionValue).invoke('text').then((versionvalue) => {
      expect(versionvalue).to.be.exist
    })
  }

  draftIconVisible() {
    cy.get(Icon).should(assertionConstants.beVisibleAssertion)
  }

  screenExpandIconVisible() {
    cy.get(Icon2).should(assertionConstants.beVisibleAssertion)
  }

  patternDetailsExpanded() {
    cy.get(patternDetails).eq(0).invoke('text').then((el) => {
      expect(el).to.be.exist
    })
  }

  MetadataInfoVisible() {
    cy.get(MetadataInfo).should(assertionConstants.beVisibleAssertion)
  }

  knowledgeInfoVisible() {
    cy.get(knowledgeInfo).should(assertionConstants.beVisibleAssertion)
  }

  auditInfoVisible() {
    cy.get(auditInfo).should(assertionConstants.beVisibleAssertion)
  }

  deleteButtonVisibleAndEnabled() {
    cy.get(button).eq(0).should(assertionConstants.beVisibleAssertion).and(assertionConstants.notBeDisabledAssertion)
  }

  withdrawButtonVisible() {
    cy.get(button).eq(1).should(assertionConstants.beVisibleAssertion)
  }

  cloneButtonVisibleAndEnabled() {
    cy.get(button).eq(2).should(assertionConstants.beVisibleAssertion).and(assertionConstants.notBeDisabledAssertion)
  }

  editButtonVisibleAndEnabled() {
    cy.get(editButton).should(assertionConstants.beVisibleAssertion).and(assertionConstants.notBeDisabledAssertion)
  }

  closeButtonVisibleAndEnabled() {
    cy.get(closeButton).should(assertionConstants.beVisibleAssertion).and(assertionConstants.notBeDisabledAssertion)
  }

  expandAndCollapseIconVisible() {
    cy.get(expandAndCollapseIcon).should(assertionConstants.beVisibleAssertion)
  }

  patternIdVisible() {
    cy.get(patternDetails).eq(0).invoke('text').then((patternid) => {
      expect(patternid).to.be.exist
    })
  }

  patternDescriptionVisible() {
    cy.get(patternDetails).eq(1).invoke('text').then((patterndescription) => {
      expect(patterndescription).to.be.exist
    })
  }

  orderOfExecutionVisible() {
    cy.get(patternDetails).eq(2).invoke('text').then((orderofexecution) => {
      expect(orderofexecution).to.be.exist
    })
  }

  dataModelVisible() {
    cy.get(patternDetails).eq(3).invoke('text').then((datamodel) => {
      expect(datamodel).to.be.exist
    })
  }

  conditionLogicalExpressionVisible() {
    cy.get(patternDetails).eq(4).invoke('text').then((conditionlogicalexperssion) => {
      expect(conditionlogicalexperssion).to.be.exist
    })
  }

  actionDetailsVisible() {
    cy.get(patternDetails).eq(5).invoke('text').then((actiondetails) => {
      expect(actiondetails).to.be.exist
    })
  }

  patternDetailsoptionClick() {
    cy.get(patternDetailsOption).eq(0).click({ force: true })
  }

  patternDetailsCollapsed() {
    cy.contains(patternGuideOption).should(assertionConstants.notVisibleAssertion)
  }

  metadataOptionClick() {
    cy.get(patternDetailsOption).eq(1).click()
  }

  metadataDetailsCollapsed() {
    cy.get(metadataDetails).should(assertionConstants.notVisibleAssertion)
  }

  metadataDetailsExpanded() {
    cy.get(metadataDetails).should(assertionConstants.beVisibleAssertion)
  }

  patternTypeExist() {
    cy.get(paternTypeAndValue).children().first().invoke('text').then((patterntype) => {
      expect(patterntype).to.exist
    })
  }

  patternValueExist() {
    cy.get(paternTypeAndValue).children().last().invoke('text').then((patternvalue) => {
      expect(patternvalue).to.exist
    })
  }

  serviceContextTextExist() {
    cy.get(serviceContextAndValue).children().first().invoke('text').then((servicecontexttext) => {
      expect(servicecontexttext).to.exist
    })
  }

  serviceContextValueExist() {
    cy.get(serviceContextAndValue).children().last().invoke('text').then((servicecontextvalue) => {
      expect(servicecontextvalue).to.exist
    })
  }

  timeSpanTextExist() {
    cy.get(timeSpanAndValue).first().invoke('text').then((timespantext) => {
      expect(timespantext).to.exist
    })
  }

  timeSpanValueExist() {
    cy.get(timeSpanAndValue).last().invoke('text').then((timespanvalue) => {
      expect(timespanvalue).to.exist
    })
  }

  modalityTextExist() {
    cy.get(modalityTextAndValue).children().first().invoke('text').then((modalitytext) => {
      expect(modalitytext).to.exist
    })
  }

  modalityValueExist() {
    cy.get(modalityTextAndValue).children().last().invoke('text').then((modalityvalue) => {
      expect(modalityvalue).to.exist
    })
  }

  relevanceTextExist() {
    cy.get(relevanceText).children().first().invoke('text').then((relevancetext) => {
      expect(relevancetext).to.exist
    })
  }

  closeButtonClick() {
    cy.get(closeButton).click()
  }

  myPatternArrowClick() {
    cy.get(myPatternArrow).eq(1).click({force: true})
  }

  withdrawButtonVisibleAndEnabled() {
    cy.get(button).eq(1).should(assertionConstants.beVisibleAssertion)
  }

  myPatternDashboardBreadCrumVisible() {
    cy.get(myPatternDashboardBreadCrum).find('li').should(assertionConstants.havelengthAssertion, '7')
  }

  expandedProductfamilyVisible() {
    cy.get(expandedProductfamily).last().should(assertionConstants.beVisibleAssertion)
  }

  commentTextVisible() {
    cy.get(comment).first().children().first().should(assertionConstants.haveTextAssertion, 'Comment').and(assertionConstants.beVisibleAssertion)
  }

  commentValueExist() {
    cy.get(comment).first().children().last().invoke('text').then((commentText) => {
      expect(commentText).to.exist
    })
  }

  severityTextVisible() {
    cy.get(severity).first().children().first().should(assertionConstants.haveTextAssertion, 'Severity').and(assertionConstants.beVisibleAssertion)
  }

  severityValueExist() {
    cy.get(severity).first().children().last().invoke('text').then((severityValue) => {
      expect(severityValue).to.exist
    })
  }

  tagsTextVisible() {
    cy.get(tagsText).first().should(assertionConstants.haveTextAssertion, 'Tags').and(assertionConstants.beVisibleAssertion)
  }








  patternDashboardPageVisible() {
    return cy.get(patternDashboardPage).should(assertionConstants.haveTextAssertion, 'Patterns').and(assertionConstants.beVisibleAssertion)
  }

  patternTabArrowClick() {
    return cy.get(patternTabArrow).eq(3).click()
  }

  MyknowledgeArrowClick() {
    return cy.get(MyknowledgeArrow).eq(6).click()
  }

  PatternAndAutoringWorkFlowList() {
    return cy.get(patternAndAutoringWorkFlowList).eq(8).click()
  }

  AddAuthoringWokFlowButtonClick() {
    return cy.get(AddAuthoringWokFlowButton).click()
  }

  workFlowMessageVisible() {
    return cy.contains(workFlowMessage).should(assertionConstants.beVisibleAssertion)
  }

  scrollUptoElement(){
    cy.get(searchBox).eq(0).scrollIntoView()
  }

  scrollUp(){
    cy.get(patternNameAtTop).scrollIntoView()
  }

  modalityDropdownColumnClick() {
    cy.get(modalityColumnDropdown).eq(3).click({force:true})
    cy.wait(1000)
  }

  selectAllCheckBoxClick(){
    cy.get(selectAllCheckBox).last().click()
  }

  modalityApplyButtonClick(){
    cy.xpath(modalityApplyButton).click()
  }

  crossMarkInOverlaySectionClick(){
    cy.get(crossMarkInOverlaySection).click()
  }

  tagSectionInOverlaySectionWithUniqueTagsVisible(){
    cy.get(tagSectionInOverlaySection).should(assertionConstants.containAssertion,'DICOM/RIS/PACS').and(assertionConstants.havelengthAssertion,'1')
    cy.get(tagSectionInOverlaySection).should(assertionConstants.containAssertion,'Detector').and(assertionConstants.havelengthAssertion,'1')
  }

  uniqueTagsInDetailsPageVerification(){
    cy.get(tagsInDetailsPage).should(assertionConstants.containAssertion,'DICOM/RIS/PACS').and(assertionConstants.havelengthAssertion,'1')
    cy.get(tagsInDetailsPage).should(assertionConstants.containAssertion,'DICOM/RIS/PACS').and(assertionConstants.havelengthAssertion,'1')
  }

  FirstRecordRightClick() {
  return cy.xpath(FirstRecord).rightclick()
  }

  publishButtonInPatternDashboardEnable(){
    cy.get(publishButtonInPatternDashboard).should(assertionConstants.notHaveClassAssertion,'.pt-menu-item pt-disabled ng-star-inserted')
  }

  publishButtonInPatternDashboardClick(){
    cy.get(publishButtonInPatternDashboard).first().click({force: true})
  }

  cancelButtonInPopUpVisible() {
    cy.get(cancelButtonInPopUp).should(assertionConstants.beVisibleAssertion)
  }

  messageInPublishPopUpVisible(){
    cy.get(messageInPublishPopUp).should(assertionConstants.haveTextAssertion,'The below  1 Pattern(s) will be published. Are you sure you want to proceed?').and(assertionConstants.beVisibleAssertion)
  }

  patternNameInPopUpVisible(){
    cy.get(patternNameInPopUP).should(assertionConstants.beVisibleAssertion)
  }

  publishButtonInPopUpVisible(){
    cy.get(publishButtonInPopUp).should(assertionConstants.beVisibleAssertion)
  }

  cancelButtonInPopUpClick() {
    cy.get(cancelButtonInPopUp).click()
  }

  publishPatternPopUpNotExist(){
    cy.get(publishPatternPopUp).should(assertionConstants.notExistsAssertion)
  }

  
  patternInDraft(){
    cy.get(PatternInDraft).children('td').eq(2).find('span').first().should(assertionConstants.haveTextAssertion,'Draft ')
  }

  publishButtonInPopUpClick(){
    cy.get(publishButtonInPopUp).click()
  }

  patternInPublished(){
    cy.get(PatternInDraft).should(assertionConstants.containAssertion,'Published ')
  }

  editButtonClick() {
    cy.get(editButton).click({force:true})
  }

  norecordTextVisible(){
    cy.contains(norecordText).should(assertionConstants.beVisibleAssertion)
  }

  removeFilterButtonOfDescriptionFilterClick() {
    return cy.get(crosssIcon).click()
  }

 scrollElemntAfterDeleringPattern(){
  cy.get(searchBox).scrollIntoView()
 }

 withdrawButtonClick(){
  cy.get(withdrawButton).click()
 }

 publishButtonInPatternDashboardUnderThreeDotsClick(){
  cy.get(publishButtonUnderThreeDots).first().click({force:true})
}

publishButtonInPatternDashboardNotExist(){
  cy.get(publishButtonInPatternDashboard).should(assertionConstants.notExistsAssertion)
}

publishButtonInPatternDashboardDisabled(){
  cy.get(publishButtonInPatternDashboard).should(assertionConstants.haveClassAssertion,'topbtns pt-button ng-star-inserted')
}

publishButtonInPatternDashboardUnderThreeDotsDisabled(){
  cy.get(publishButtonUnderThreeDotsOfFirstRecord).should(assertionConstants.haveClassAssertion,'pt-menu-item pt-disabled ng-star-inserted')
}

patternNameSearchOptionWFnameType(){
  cy.get(patternNameSearchOption).type('Authoring_WF_Tes',{force: true})
}

patternNameSearchIconClick(){
  cy.get(patternNameSearchIcon).click({force: true})
}

secondRecordThreeDotClick() {
  cy.get(firstRecordThreeDot).first().scrollIntoView().then(() => {
    cy.wait(3000)
    cy.get(firstRecordThreeDot).eq(1).click({ force: true })
  })
}

// secondRecordThreeDotClick() {
//     cy.get(firstRecordThreeDot).eq(1).click({ force: true })

// }



secondPatternClick() {
  cy.get(pattern).last().find('tr').eq(1).find('td').eq(1).find('[class="btn-link ng-star-inserted"]').first().click({ force: true })
}

withdrawButtonInpatternDetailsPageClick(){
  cy.get(button).eq(1).click({force: true})
}

selectingDraftAndWithdrawPattern(){
  cy.get(KnowledgwSelectcheckBox).eq(1).click({force: true})
  cy.wait(1000)
  cy.get(KnowledgwSelectcheckBox).eq(2).click({force: true})
  cy.wait(1000)
}

publishButtonInPatternDashboardExist(){
  cy.get(publishButtonInPatternDashboard).should(assertionConstants.beExistAssertion)
}

myPatternTextScrollElement(){
  cy.get(myPatternTextScrollElement).scrollIntoView()
}

checkedCheckBoxClick(){
  cy.get(checkedCheckBox).eq(0).click()
}

selectingSecondRecord(){
  cy.get(KnowledgwSelectcheckBox).eq(2).click({force: true})
}

selectingWithdrawAndDraftPattern(){
  cy.get(KnowledgwSelectcheckBox).eq(1).click({force: true})
  cy.wait(1000)
  cy.get(KnowledgwSelectcheckBox).last().click({force: true})
  cy.wait(1000)

}

deleteButtonIndashbaordClick(){
  cy.get(deleteButtonIndashbaord).click()
}

IGTmodalitySelect(){
  cy.get(modalitySelectOptions).eq(4).click()
}

secondPatternCheckBoxClick(){
  cy.get(patternNameCheckbox).eq(2).click({force:true})
  cy.wait(1000)
}

publishButtonInDashboardClick(){
  cy.get(publishButtonInPatternDashboard).last().click()
}

// patternDashboardClick() {
//   cy.get(Dashboard).first().click().as('dashboardContent')
//   cy.get(modalityColumnDropdown).eq(3).as('abc')
//   cy.get('@abc').click({force: true})
// }

selectAllPatternsCheckBoxClick(){
  cy.get(patternNameCheckbox).eq(0).click({force:true})
  cy.wait(1000)
}

patternsInPublishedStateVisible(){
  cy.get(patternsInPublishedState).should(assertionConstants.beVisibleAssertion)
}

modifiedByWithUserNameVisible(){
  cy.get(modifiedByOption).eq(2).find('span').first().should(assertionConstants.beVisibleAssertion)
}

modifiedOnWithDateVisible(){
  cy.get(modifiedByOption).eq(3).find('span').first().should(assertionConstants.beVisibleAssertion)
}

popUpOkButtonClick(){
  cy.get(cy.get(okButton).click())
}

firstPatternsCheckBoxClick(){
  cy.get(patternNameCheckbox).eq(1).click({force:true})
  cy.wait(1000)
}

deleteButtonInDetailsPageClick(){
  cy.get(button).eq(0).click()
}

withdrawButtonInDetailsPageClick(){
  cy.get(button).eq(1).click()
}

patternInWithdraw(){
  cy.get(PatternInDraft).children('td').eq(2).find('span').first().should(assertionConstants.haveTextAssertion,'Withdrawn ')
}

patternDeleteMessageVisible(){
  cy.contains(patternDeleteMessage).should(assertionConstants.beVisibleAssertion)
}

selectingFirstTwoRecords(){
  cy.get(checkboxInDashboard).eq(1).scrollIntoView()
  cy.get(checkboxInDashboard).eq(1).scrollIntoView().click({ force: true })
  cy.get(checkboxInDashboard).eq(2).click()
}

patternWithdrawMessageVisible(){
  cy.contains(patternWithdrawMessage).should(assertionConstants.beVisibleAssertion)
}

selectingSecondAndThirdRecords(){
  cy.get(checkboxInDashboard).eq(1).scrollIntoView()
  cy.get(checkboxInDashboard).eq(2).scrollIntoView().click({ force: true })
  cy.wait(1000)
  cy.get(checkboxInDashboard).eq(3).click()
  cy.wait(2000)
}

withdrawPatternButtonClick() {
  cy.get(withdrawPatternButton).click()
}

thirdPatternClick() {
  cy.get(pattern).last().find('tr').eq(2).find('td').eq(1).find('[class="btn-link ng-star-inserted"]').first().click({ force: true })
}

selectAllRecords(){
  cy.get(selectAllCheckBox).eq(0).click()
}



}
export default PatternDashboard;
