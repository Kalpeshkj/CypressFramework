/// <reference types="Cypress" />
/// <reference types='cypress-tags' />  

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();
import CreateKnowledge from "../../../../support/pageObjects/pages/KnowledgeAuthoring/CreateKnowledge";
const createKnowledge = new CreateKnowledge();

Then("Navigate to Knowledge dashboard", () => {
    cy.visit(Cypress.env("DAWAutomationURL"));
    cy.wait(2000)
    createPattern.knowledgeSectionClick()
    createPattern.myPatternDashboardClick()
    cy.wait(5000)
    createPattern.clearAllFiltersButtonClick()
    createKnowledge.withdrawnKnowledgeStatusSelection()
    console.log(printTimestamp(), ' User Navigates to Knowledge Dashboard')
});

Then("Navigates to Knowledge Dashboard", () => {
    createPattern.myPatternDashboardClick()
    console.log(printTimestamp(), ' User Navigates to Knowledge Dashboard')
});

When("User Clicks on edit button on one of the withdrawn Knowledge for which user has author access", () => {
    createKnowledge.firstKnowledgeRightClick()
    createKnowledge.editknowledgeButtonClick()
    console.log(printTimestamp(), ' Clicked on edit button on one of the withdrawn Knowledge for which user has author access')
});

Then("User should be able to click on edit button", () => {
    createPattern.createPatternHeadingActiveVerification()
    console.log(printTimestamp(), ' User able to click on edit button')
});

And("Performs any changes in Create Knowledge step and clicks on save", () => {
    createKnowledge.causeNameOneRemoveIconClick()
    createPattern.okButtonClick()
    createKnowledge.breadcumbCaptureValue()
    createKnowledge.saveAsDraftClick()
    cy.wait(3000)
    console.log(printTimestamp(), ' Performed any changes in Create Knowledge step')
});

Then("Edited Knowledge should be available in Knowledge dashboard", () => {
    createPattern.myPatternDashboardClick()
    createPattern.clearAllFiltersButtonClick()
    cy.wait(2000)
    createKnowledge.patternNameTypeInKnowledgeSearchFilter()
    createKnowledge.editedknowledgeVisible()
    console.log(printTimestamp(), ' Edited Knowledge available in Knowledge dashboard')
});

And("Verifies the status of the modified Knowledge in Knowledge dashboard", () => {
    createKnowledge.editedknowledgeStatusVisible()
    console.log(printTimestamp(), " Verified the status of the modified Knowledge in Knowledge dashboard")
});

Then("Repeat above steps for My Knowledge Dashboard", () => {
    createPattern.patternSectionCollapseClick()
    createPattern.myPatternDashboardClick()
    createPattern.clearAllFiltersButtonClick()
    console.log(printTimestamp(), ' Steps repeated for My Knowledge Dashboard')
});