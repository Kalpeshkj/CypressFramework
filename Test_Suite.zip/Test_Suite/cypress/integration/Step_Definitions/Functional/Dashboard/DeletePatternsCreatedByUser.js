/// <reference types="Cypress" />
/// <reference types = 'cypress-tags' />

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';

import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();
import KnowledgeDashboard from "../../../../support/pageObjects/pages/Knowledge_Dashboard/KnowledgeDashboard";
const knowledgeDashboard = new KnowledgeDashboard();
import PatternDashboard from "../../../../support/pageObjects/pages/Dashboard/PatternDashboard";
const patternDashboard = new PatternDashboard();
const filePath = 'cypress/fixtures/patternNameCreation.json'


Then("Verifies at least two to three patterns should be present", () => {
    cy.wait(3000)
    patternDashboard.recordsAvailable()
    console.log(printTimestamp(), ' Verified count of available patterns')
})

When("User clicks on three dots of any pattern", () => {
    patternDashboard.invokedTextOfFirstRecord()
    patternDashboard.firstRecordThreeDotClick()
    console.log(printTimestamp(), ' Three dots of my pattern clicked')
})

Then("User should be able to click on delete option", () => {
    patternDashboard.deleteOptionClick()
    console.log(printTimestamp(), ' Delete option clicked')
})

And("Clicks on Delete from confirmation pop up", () => {
    createPattern.okButtonClick()
    console.log(printTimestamp(), ' Delete confirmation pop up clicked')
})

And("Verifies deleted pattern should not be available in UI", () => {
    patternDashboard.deletedPatternNotVisible()
    console.log(printTimestamp(), ' Deleted pattern not available in UI')
})

And("Repeat above steps and perform delete action from Pattern Details Page", () => {
    patternDashboard.deleteRecordFromPatternDetailsPage()
    console.log(printTimestamp(), ' Delete action performed from pattern details page')
})

When("User selects multiple patterns and click on Delete button", () => {
    patternDashboard.patternNamesCheckboxesClick()
    patternDashboard.deletePatternButtonFromDashboardClick()
    patternDashboard.invokeTextOfDeletingRecordsVerification()
    console.log(printTimestamp(), ' Multiple patterns selected and clicked on delete')
})

Then("All selected patterns should get deleted from UI", () => {
    createPattern.okButtonClick()
    patternDashboard.deletedPatternNotVisible()
    console.log(printTimestamp(), ' All selected patterns deleted')
})

When("User creates Authoring Wf and adds details and clicks on Save as Draft", () => {
    cy.createPattern()
    createPattern.saveAsDraftButtonClick()
    console.log(printTimestamp(), ' WF created and details added')
})

Then("Navigates to Dashboard and verifies created pattern should be present", () => {
    patternDashboard.myPatternDashboardClick()
    createPattern.okButtonClick()
    cy.readFile(filePath).then(function (result) {
        var PatternName = result.name;
        patternDashboard.patternNameSearchField().type(PatternName).type('{enter}')
        cy.contains(PatternName).should('be.visible') 
    });
    cy.wait(3000)
    console.log(printTimestamp(), ' Navigated to Dashboard and verified created pattern present')
})

Then("User navigates to authoring wf and delete wf", () => {
    patternDashboard.naviagationToNewlyCreatedAuthWFCLick()
    patternDashboard.deleteButtonClick()
    createPattern.okButtonClick()
    console.log(printTimestamp(), ' WF deleted')
})

And("Navigate to Dashboard and verify created pattern should not be displayed", () => {
    patternDashboard.myPatternDashboardButtonClick()
    cy.readFile(filePath).then(function (result) {
        var PatternName = result.name;
        cy.get("#" + PatternName + " > #nav-dropdown-btn > .ng-star-inserted > #Layer_1").should('not.exist')
    });
    console.log(printTimestamp(), ' Navigated to dashboard and verified created pattern not displayed')
})
