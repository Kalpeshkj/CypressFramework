


/**
 * @type {Cypress.PluginConfig}
 */
// eslint-disable-next-line no-unused-vars
//  module.exports = (on, config) => {
// //   // `on` is used to hook into various events Cypress emits
// //   // `config` is the resolved Cypress config
// }

const cucumber = require('cypress-cucumber-preprocessor').default;
const AzureAdSingleSignOn = require('./azure-ad-sso/plugin').AzureAdSingleSignOn


const postgreSQL = require('cypress-postgresql');
const pg = require('pg');
const dbConfig = require('../../cypress.json');

module.exports = (on, config) => {
  const pool = new pg.Pool(dbConfig.env.db);
  const tasks = postgreSQL.loadDBPlugin( pool );
  on('task', tasks);
  on('file:preprocessor', cucumber())
  on('task', {AzureAdSingleSignOn:AzureAdSingleSignOn})
}




