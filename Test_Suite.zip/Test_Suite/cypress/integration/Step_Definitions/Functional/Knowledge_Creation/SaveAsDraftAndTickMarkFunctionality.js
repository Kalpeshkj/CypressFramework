/// <reference types="Cypress" />
/// <reference types='cypress-tags' />

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import KnowledgeDashboard from "../../../../support/pageObjects/pages/Knowledge_Dashboard/KnowledgeDashboard";
const knowledgeDashboard = new KnowledgeDashboard();
import CreateKnowledge from "../../../../support/pageObjects/pages/KnowledgeAuthoring/CreateKnowledge";
const createKnowledge = new CreateKnowledge();
import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();
const filePath = 'cypress/fixtures/patternNameCreation.json'

var arr = []

When("User expands knowledge and clicks on add knowledge", () => {
    knowledgeDashboard.knowledgeClick()
    knowledgeDashboard.addKnowledgeClick()
    console.log(printTimestamp(), ' Knowledge expanded and add knowledge clicked')
});

Then("User should be navigated to new workflow", () => {
    // knowledgeDashboard.breadcumbLastValue().last().invoke("text")
    // .then((text1) => {
    //     arr.push(text1)
    //     cy.wait(2000)
    // })
    createKnowledge.knowledgeStepsVisible()
    console.log(printTimestamp(), ' Navigated to new workflow')
});

When("User Clicks on Causes and Solution section", () => {
    createKnowledge.causeAndSolutionSectionClick()
    console.log(printTimestamp(), ' Clicked on cause and solution section')
});

Then("User should be able to upload image or file by drag and drop or browse option", () => {
    createKnowledge.addCauseButtonClick()
    createKnowledge.insertFileButtonClick()
    createKnowledge.browseFileIconClick().attachFile('SampleFile.pdf')
    console.log(printTimestamp(), ' Image uploaded')
});

And("Verifies uploaded image or file in Cause and solution section", () => {
    createKnowledge.uploadedImageVerification()
    console.log(printTimestamp(), ' Details updated in cause and solution')
});

And("Update details in rich text editor of cause and solution", () => {
    createKnowledge.inputFieldInCauseSectionClickAndType()
    createKnowledge.addSolutionButtonClick()
    createKnowledge.inputFieldInSolutionSectionClickAndType()
    console.log(printTimestamp(), ' Details updated in cause and solution')
});

When("User clicks on tick mark option available on the section", () => {
    createKnowledge.tickMarkIconClick()
    console.log(printTimestamp(), ' Clicked on tick mark available in section')
});

Then("Attachment should get uploaded and then rich text content should get uploaded", () => {
    cy.wait(5000)
    createKnowledge.DetailsSavedVerification()
    createKnowledge.mandatoryDetailsAddition()
    console.log(printTimestamp(), ' Attachment uploaded and rich text uploaded')
});

When("User clicks on save as draft button", () => {
    createKnowledge.saveAsDraftClick()
    cy.wait(5000)
    console.log(printTimestamp(), ' Save as draft btton clicked')
});

When("Relaunches the application", () => {
    cy.reload()
    console.log(printTimestamp(), ' Application relaunched')
});

Then("All saved details should be displayed", () => {
    cy.readFile(filePath).then(function (result) {
        var PatternName = result.name;
        cy.get("#" + PatternName).eq(0).click({ force: true })
    });
    createKnowledge.causeVerification()
    cy.readFile(filePath).then(function (result) {
        var PatternName = result.name;
        cy.get("#" + PatternName + " > #nav-dropdown-btn > .ng-star-inserted > #Layer_1").click({ force: true })
        createPattern.deleteOption().click({ force: true });
    });
    console.log(printTimestamp(), ' All details displayed')
});