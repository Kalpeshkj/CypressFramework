/// <reference types="Cypress" />
/// <reference types='cypress-tags' />

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';

import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();

import IncludeKnowlegePage from "../../../../support/pageObjects/pages/PatternAuthoring/includeKnowledgepageObj";
const includeKnowlegePage = new IncludeKnowlegePage();

When("By default Dashboard page under Patterns should be displayed", () => {
    createPattern.dashboardButtonVisible()
    console.log(printTimestamp(), ' Dashboard page under Patterns displayed')
});

Then("User should able to click on My Patterns three dots and able to see create pattern option", () => {
    createPattern.myPatternThreeDotsClick()
    createPattern.createPatternVisible()
    console.log(printTimestamp(), ' Clicked on My Patterns three dots')
});

When("User clicks on create pattern button", () => {
    createPattern.createPatternClick()
    console.log(printTimestamp(), ' Clicked on create pattern button')
});

Then("Grid values as Create Pattern, Apply Metadata, Include Knowledge, Validate and Request Review", () => {
    createPattern.gridVerification().each(($el) => {
        cy.wrap($el).should("be.visible");
    });
    console.log(printTimestamp(), ' Grid values present')
});

And("By default create pattern should be selected", () => {
    createPattern.createPatternGridAsSelected()
    console.log(printTimestamp(), ' By default create pattern was selected')
});

And("Import Data Model, Extends, Add Condition and Add Action should be present", () => {
    createPattern.importDataModelTabVisible()
    createPattern.extendsTabVisible()
    createPattern.addConditionTabVisible()
    createPattern.addActionTabVisible()
    console.log(printTimestamp(), ' All mandatory fields are visible')
});

And("Verify Fields available under Pattern Information like Name, description and order of execution", () => {
    createPattern.patternNameVisible()
    createPattern.patternDescriptionVisible()
    createPattern.orderOfExecutionTextBoxVisible()
    createPattern.atATimeOneExpandedVerification()
    console.log(printTimestamp(), ' Available fields are verified from pattern information section')
});

And("Import Data Model, Extends, Add Condition and Add Action should present with asterisk sign", () => {
    createPattern.patternInformationTabClick()
    includeKnowlegePage.patternNameMandatoryVisible()
    includeKnowlegePage.descriptionMandatoryVisible()
    includeKnowlegePage.adConditionTabMandatoryVisible()
    includeKnowlegePage.addActionTabMandatoryVisible()
    console.log(printTimestamp(), ' Asterisk sign present in all mandatory section')
});

When("User Clicks on any section and it should get expanded", () => {
    includeKnowlegePage.addActionTabClickAndExpandedVerification()
    console.log(printTimestamp(), ' Clicked on any of section')
});

When("User relaunches the application", () => {
    cy.reload()
    console.log(printTimestamp(), ' Application relaunched')
});

Then("Verifies expanded field should not be retained as By default, Pattern Information should be in expanded state", () => {
    includeKnowlegePage.addActionTabNotInExpandedVerification()
    console.log(printTimestamp(), ' Earlier expanded field erified as not retained similarly')
});

When("User Clicks on collapse option and verifies it should collapsed", () => {
    createPattern.patternInformationTab().click()
    createPattern.patternNameNotVisible()
    console.log(printTimestamp(), '  Collapsing of fileds verified as working')
});

Then("Close, Save as draft and Next button should be present in right side bottom corner", () => {
    createPattern.closeButtonVisible()
    createPattern.saveAsDraftButtonVisible()
    createPattern.nextButtonVisible()
    createPattern.buttonsVerification()
    console.log(printTimestamp(), ' Available Buttons verified')
});

And("User fills any of the mandatory field and verifies next button should be in disabled state", () => {
    createPattern.importDataModelAction()
    createPattern.nextButtonDisabledVerification()
    console.log(printTimestamp(), ' Filled one mandatory field')
});

And("User fills all mandatory fields and veries next button should be in enabled state", () => {
    cy.PatternCreation()
    createPattern.patternInformationTab().click();
    cy.readFile('cypress/fixtures/patternNameCreation.json').then(function (result) {
        var PatternName = result.name;
        createPattern.patternName().type(PatternName);
    });
    createPattern.description().type(Cypress.env("PatternDescription"));
    createPattern.addAction()
    createPattern.addConditionInPattern()
    createPattern.nextButtonEnabledVerification()
    console.log(printTimestamp(), ' All mandatory fields was filled')
});

And("User Clicks on next button and verifies it should land on apply metadata section", () => {
    createPattern.nextButtonClick()
    createPattern.applyMetadataActiveVerification()
    console.log(printTimestamp(), ' Next button clicked')
});

And("Close DAW application", () => {
    cy.DeleteWorkflow()
    cy.log("Test Case Executed Successfully")
    console.log(printTimestamp(), ' Test Case Executed Successfully')
});
