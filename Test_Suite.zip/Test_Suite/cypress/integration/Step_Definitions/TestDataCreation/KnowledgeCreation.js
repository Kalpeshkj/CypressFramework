
/// <reference types="Cypress" />
/// <reference types='cypress-tags' />  
import "../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../support/commands';

And("Create {string} Knowledges As per user input",(input)=>{
    cy.CreateMultipleKnowledgeAsPerUserInput(input)
    console.log(printTimestamp(), 'Create Multiple Knowledges As per user input')   
}) 