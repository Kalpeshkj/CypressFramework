import "../../../../support/index"
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import CreateKnowledge from "../../../../support/pageObjects/pages/KnowledgeAuthoring/CreateKnowledge";
const createKnowledge = new CreateKnowledge();
import Constants from "../../../../support/pageObjects/pages/PatternAuthoring/constants";
const constants = new Constants();

When("User create new knowledge Workflow", () => {
    createKnowledge.knowledgeOptionArrowClick()
    createKnowledge.addKnowledgeWorkflowButtonClick()
    cy.wait(3000)
    console.log(printTimestamp(), 'Navigated to newly created knowledge workflow')
});

And("Add details in Knowledge Information section", () => {
    createKnowledge.knowledgeNameTextBoxType()
    createKnowledge.descriptionFiledTextBoxType()
    console.log(printTimestamp(), 'Added details in Knowledge Information section')
});

And("Expand Symptom section and click on Select Symptom", () => {
    createKnowledge.symptomOptionClick()
    createKnowledge.selectSymptomClick()
    console.log(printTimestamp(), 'Expands Symptom section and clicked on Select Symptom')
});

When("User Click on show all", () => {
    createKnowledge.showAllCheckboxClick()
    cy.wait(2000)
    console.log(printTimestamp(), 'User Clicked on show all')
});

Then("All existing publishe knowledge Symptom should be displayed", () => {
    createKnowledge.existingPublishedSymptomOrCausesVisible()
    createKnowledge.firstSymptomOrCauseText()
    console.log(printTimestamp(), ' All existing published knowledges displayed')
});

When("User Select one Symptom and click on select button", () => {
    createKnowledge.firstSymptomOrCauseClick()
    cy.wait(2000)
    createKnowledge.selectButtonClick()
    cy.wait(2000)
    console.log(printTimestamp(), 'User Selects one Symptom and clicked on select button')
});

Then("Selected Symptom should get added under Symptom section", () => {
    createKnowledge.firstSelectedSymptomOrCauseInSymptomOrCauseAndSolutionSectionVisible()
    console.log(printTimestamp(), 'Selected Symptom gets added under Symptom section')

});

And("Name of Symptom should remain same as displayed in Select Symptom pop up", () => {
    createKnowledge.selectedFirstSymptomOrCauseNameInSymptomSection()
    console.log(printTimestamp(), 'Name of Symptom remain same as displayed in Select Symptom pop up')
});

And("Selected Symptom should be displayed in read only mode", () => {
    createKnowledge.editOptionNOtExists()
    console.log(printTimestamp(), constants.selectedSymptomDisplayedInReadMode)
});

And("Remove option inline with Symptom name should be displayed to remove selected Symptom", () => {
    createKnowledge.removeSymptomOrCauseButtonVisible()
    console.log(printTimestamp(), 'Remove option inline with Symptom name displayed to remove selected Symptom')
});

And("Symptom Name , Symptom Description,Symptom tags should be displayed", () => {
    createKnowledge.nameOfFirstSymptomOrCauseInSymptomOrCauseAndSolutionSectionVisible()
    createKnowledge.symptomOrCauseDescriptionInSymptonOrCauseAndSolutionSectionVisible()
    createKnowledge.symptomOrCauseTagIconVisible()
    console.log(printTimestamp(), 'Symptom Name , Symptom Description,Symptom tags displayed')
});

And("Where tags should be displayed in token", () => {
    // createKnowledge.tagsInTokenVisible()
    console.log(printTimestamp(), 'tags displayed in token')
});

When("User click on Select Symptom", () => {
    createKnowledge.selectSymptomClick()
    console.log(printTimestamp(), 'User clicked on Select Symptom')
});

And('User Click on show all', () => {
    createKnowledge.showAllButtonClick()
    cy.wait(2000)
    console.log(printTimestamp(), 'Clicked on show all')
})

Then("Select Symptom pop up should get displayed", () => {
    createKnowledge.selectSymptomOrCausePopUpVisible()
    console.log(printTimestamp(), 'Select Symptom pop up gets displayed')
});

Then("All existing publishe knowledges Symptom should be displayed", () => {
    createKnowledge.existingPublishedSymptomOrCausesVisible()
    createKnowledge.secondSymptomOrCauseText()
    createKnowledge.ThirdSymptomOrCauseText()
    console.log(printTimestamp(), ' All existing published knowledge Symptom displayed')
});

And("User Selects multiple Symptoms and click on select button", () => {
    createKnowledge.firstSymptomOrCauseClick()
    createKnowledge.secondSymptomClick()
    createKnowledge.thirdSymptomClick()
    createKnowledge.selectButtonClick()
    cy.wait(2000)
    console.log(printTimestamp(), 'Selects multiple Symptoms and clicked on select button')
})

And("All selected Symptom should get added under Symptom section.", () => {
    createKnowledge.firstSelectedSymptomOrCauseInSymptomOrCauseAndSolutionSectionVisible()
    createKnowledge.secondSelectedSymptomOrCauseInSymptomOrCauseAndSolutionSectionVisible()
    console.log(printTimestamp(), 'All selected Symptom gets added under Symptom section.')
});

And("Names of  Symptoms should remain same as displayed in Select Symptom pop up", () => {
    createKnowledge.selectedSecondSymptomOrCauseNameInSymptomOrCauseAndSolutionSection()
    createKnowledge.selectedThirdSymptomOrCauseNameInSymptomOrCauseAndSolutionSection()
    console.log(printTimestamp(), 'Name of Symptoms remain same as displayed in Select Symptom pop up')
});

And("Selected Symptom should be displayed in read only mode", () => {
    createKnowledge.editOptionNOtExists()
    console.log(printTimestamp(), constants.selectedSymptomDisplayedInReadMode)
});

And("Remove option inline with Symptom name should be displayed to remove selected cause", () => {
    createKnowledge.removeSymptomOrCauseButtonVisible()
    console.log(printTimestamp(), 'Remove option inline with Symptom name displayed to remove selected cause')
});

And("Symptom Names , Symptom Description, Symptom tags , should be displayed", () => {
    createKnowledge.nameOfFirstSymptomOrCauseInSymptomOrCauseAndSolutionSectionVisible()
    createKnowledge.nameOfSecondSymptomOrCauseInSymptomOrCauseAndSolutionSectionVisible()
    createKnowledge.symptomOrCauseTagIconVisible()
    console.log(printTimestamp(), 'Symptom Names , Symptom Description, Symptom tags , displayed')
});

And("tags should be displayed in token", () => {
    createKnowledge.multipleTagsInTokenVisible()
    console.log(printTimestamp(), 'tags displayed in token')
});
When("Add new Symptom from Add Symptom option", () => {
    createKnowledge.addSymptomButtonClick()
    createKnowledge.symptomOneTextBoxType()
    console.log(printTimestamp(), 'Added new Symptom from Add Symptom option')

});

When("User click on Select  Symptom", () => {
    createKnowledge.selectSymptomClick()
    console.log(printTimestamp(), 'User clicked on Select  Symptom')
});

Then("Select Symptom pop up should get displayed", () => {
    createKnowledge.selectSymptomPopUpVisible()
    console.log(printTimestamp(), 'Select Symptom pop up gets displayed')
});

Then("All existing published knowledges Symptom should be displayed", () => {
    createKnowledge.existingPublishedSymptomOrCausesVisible()
    console.log(printTimestamp(), 'All existing published knowledges Symptom displayed')
});

When("User click on checkbox available beside name", () => {
    createKnowledge.entriesPerPageDropDownClick()
    createKnowledge.FiveEntriesPerPageSelect()
    cy.wait(2000)
    createKnowledge.selectAllCheckBoxBesidesNameClick()
    console.log(printTimestamp(), 'Clicked on checkbox available beside name')
});

Then("All Symptom available in current page should get selected", () => {
    createKnowledge.symtomsOrCausesOnCurrentPageSelected()
    console.log(printTimestamp(), 'All Symptom available in current page gets selected under Symptom section')
});

When("User Navigate to next pages and select all Symptom", () => {
    createKnowledge.nextPageButtonClick()
    cy.wait(2000)
    createKnowledge.selectAllCheckBoxBesidesNameClick()
    cy.wait(2000)
    console.log(printTimestamp(), 'Navigated to next pages and select all Symptom')

});

Then("All Symptom for current pages should get selected Note : Selected Symptom on other pages should get retained", () => {
    createKnowledge.symtomsOrCausesOnCurrentPageSelected()
    console.log(printTimestamp(), 'All Symptom for current pages gets selected Note : Selected Symptom on other pages gets retained')
});

When("User Click on Select button", () => {
    createKnowledge.selectButtonClick()
    cy.wait(2000)
    console.log(printTimestamp(), 'Clicked on Select button')
});

Then("All selected causes from multiple pages should get added under Symptom section", () => {
    createKnowledge.allSelectedSymptomsOrCausesInSymptomOrCauseAndSolutionSectionVisible()
    console.log(printTimestamp(), 'All selected causes from multiple pages gets added under Symptom section')
});

And("Name of Symptoms should be remain same as displayed in Select Symptom pop up", () => {
    createKnowledge.allSelectedSymptomsOrCausesInSymptomOrCauseAndSolutionSectionVisible()
    console.log(printTimestamp(), 'Name of Symptom remain same as displayed in Select Symptom pop up')
});

And("Selected Symptoms should be displayed in read only mode", () => {
    createKnowledge.symptomsOrCauseWithoutEditOption()
    console.log(printTimestamp(), 'Selected Symptom displayed in read only mode')
});

And("Remove option inline with Symptom name should be displayed to remove selected Symptom", () => {
    createKnowledge.removeSymptomOrCauseButtonVisible()
    console.log(printTimestamp(), 'Remove option inline with Symptom name displayed to remove selected Symptom')
});

And("Symptom Name , Symptom Description,Symptom tags should be displayed", () => {
    createKnowledge.symptomAndCauseNamesVisible()
    createKnowledge.symptomAndCauseNamesVisible()
    createKnowledge.symptomOrCauseTagIconVisible()
    console.log(printTimestamp(), 'Symptom Name , Symptom Description,Symptom tags displayed')
});

Then("Where tags should be displayed in token", () => {
    createKnowledge.allTagsInTokenVisible()
    console.log(printTimestamp(), 'Where tags displayed in token')
});

And("Symptom added from Add Symptom should contain edit option", () => {
    createKnowledge.selectedSymptomOrCauseWithEditOptionVisible()
    console.log(printTimestamp(), 'Symptom added from Add Symptom contain edit option')
});

And("Symptom added from Select Symptom should not contain edit option", () => {
    createKnowledge.symptomsOrCauseWithoutEditOption()
    console.log(printTimestamp(), 'Symptom added from Select Symptom not contain edit option')
});

And("Close DAW application", () => {
    cy.DeleteWorkflow()
    cy.log('Test case executed successfully')
    console.log(printTimestamp(), 'Test case executed successfully')
});


