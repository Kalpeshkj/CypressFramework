/// <reference types="Cypress" />
/// <reference types='cypress-tags' />

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();

When("User Clicks on vertical three dots of My Patterns", () => {
    createPattern.myPatternThreeDotsClick();
    console.log(printTimestamp(), ' Clicked on vertical three dots of My Patterns')
});

Then("Verifies its available options", () => {
    createPattern.createPatternVisible();
    console.log(printTimestamp(), ' Verified available options')
});

When('User Clicks on Create Pattern', () => {
    createPattern.createPatternClick();
    console.log(printTimestamp(), ' Clicked on Create Pattern')
});

Then("Verifies fields available under Pattern Information", () => {
    createPattern.patternNameVisible();
    createPattern.descriptionVisible();
    console.log(printTimestamp(), ' Verified fields available under Pattern Information')
});

Then("Enters Pattern Name and Description in pattern information", () => {
    createPattern.patternNameType();
    createPattern.descriptionType();
    console.log(printTimestamp(), ' Entered Pattern Name and Description in pattern information')
});

And("Verifies Order of Execution available as text box", () => {
    createPattern.orderOfExecutionTextBoxVisible();
    console.log(printTimestamp(), ' Order of Execution available as text box')
});

And('Verifies Watermark 0 as default value should be displayed in text box', () => {
    createPattern.orderOfExecutionTextBoxDefaultValueVerification();
    console.log(printTimestamp(), ' Verified Watermark 0 as default value displayed')
});

When("User Enter any value in text box", () => {
    createPattern.orderOfExecutionTextBoxValueType();
    console.log(printTimestamp(), ' Entered value in text box')
});

Then("After removing value Watermark 0 Default should be displayed in text box", () => {
    createPattern.orderOfExecutionTextBoxValueClear();
    createPattern.orderOfExecutionTextBoxDefaultValueVerification();
    console.log(printTimestamp(), ' Watermark 0(Default) displayed in text box')
});

When("User Enters pattern name, description details in pattern information", () => {
    console.log(printTimestamp(), ' Entered pattern name, description details in pattern information')
});

When("User Enters all details available in create Pattern page except Order of execution", () => {
    createPattern.importDataModelAction();
    createPattern.addConditionInPattern();
    createPattern.addAction();
    console.log(printTimestamp(), ' Entered all details available in create Pattern page except Order of execution')
});

Then("Verifies Next button, that should be in enabled state", () => {
    createPattern.nextButtonInPatternVisibleAsEnabled();
    console.log(printTimestamp(), ' Verified Next button')
});

Then("Verifies validation for Order of execution", () => {
    createPattern.patternInformationTabClick();
    createPattern.orderOfExecutionTextBoxAlfabetInvalidValueTypeAndVerification();
    console.log(printTimestamp(), ' Verified validation for Order of execution')
});

Then("Verifies User should be able to enter values from -32768 to 32768 only", () => {
    createPattern.orderOfExecutionTextBoxValidValueVerification();
    console.log(printTimestamp(), ' Verified User should be able to enter values from -32768 to 32768 only')
});

Then("Verifies validation message when user enter values other than range", () => {
    createPattern.orderOfExecutionTextBoxInValidValueVerification();
    console.log(printTimestamp(), ' Verified validation message when user enter values other than range')
});

When("User enters Invalid order of execution like 3-3-3-3", () => {
    createPattern.orderOfExecutionTextBoxInValidWithNegativeValuTextVerification();
    console.log(printTimestamp(), ' Entered Invalid order of execution like 3-3-3-3')
});
