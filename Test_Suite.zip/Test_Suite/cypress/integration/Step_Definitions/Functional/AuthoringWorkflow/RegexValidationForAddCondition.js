/// <reference types="Cypress" />
/// <reference types='cypress-tags' />

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();

When("User Click on three dots available beside My Patterns and Verify available options", () => {
    createPattern.patternTabThreeDotsClick()
    createPattern.createPatternVisible()
    console.log(printTimestamp(), ' Clicked on three dots available beside My Patterns and Verified available options')
});

Then("Clicks on create pattern", () => {
    createPattern.createPatternClick()
    console.log(printTimestamp(), ' Clicked on create pattern')
});

And("Enters Pattern Information", () => {
    cy.PatternCreation()
    createPattern.patternNameTypeInPatternInformationSection()
    createPattern.descriptionType()
    console.log(printTimestamp(), ' PatternName and Description Added')
});

Then("Clicks on Import Data Model and Select any Data Model from drop down option", () => {
    createPattern.importDataModelAction()
    console.log(printTimestamp(), ' Clicked on Import Data Model and Selected Data Model')
});

Then("Clicks on Add condition and adds one condition", () => {
    createPattern.addConditionInPattern()
    console.log(printTimestamp(), ' Clicked on Add condition and added one condition')
});

Then("Clicks on Add Action and select any option", () => {
    createPattern.addAction()
    console.log(printTimestamp(), ' Clicked on Add Action and selected option')
});

When("User Clicks on Add Condition and Add event by selecting String Data Type attribute", () => {
    createPattern.addConditionTabClick()
    console.log(printTimestamp(), ' Clicked on Add Condition and event added by selecting String Data Type attribute')
});

Then("Select Operator 'matches'", () => {
    createPattern.operatorsDropdownClickAndMatchesOperatorSelection()
    console.log(printTimestamp(), ' "matches" operator selected')
});

And("Enters Invalid regex", () => {
    createPattern.valueTextBoxClickAndInvalidRegexType()
    console.log(printTimestamp(), ' Entered Invalid regex')
});

Then("Verifies Value text box highlighted when invalid regex entered", () => {
    createPattern.invalidRegexEnteredVerification()
    console.log(printTimestamp(), '  Verified Value text box highlighted when invalid regex entered')
});

Then("Clicks on Save as Draft and verify details in db", () => {
    createPattern.saveAsDraftButtonForceClick()
    console.log(printTimestamp(), ' Clicks on Save as Draft')
});

When("User Revisit wf and verifies validation for invalid regex values", () => {
    createPattern.invalidRegexEnteredVerification()
    console.log(printTimestamp(), ' Revisit wf and verifies validation for invalid regex values')
});

Then("Clicks on Add Condition and Add event by selecting String Data Type attribute", () => {
    console.log(printTimestamp(), ' Clicked on Add Condition and event added by selecting String Data Type attribute')
});

And("Enters valid regex", () => {
    createPattern.valueTextBoxClickAndValidRegexType()
    console.log(printTimestamp(), ' Valid regex entered')
});

And("User Revisit wf and verify validation for valid regex value", () => {
    createPattern.ValidRegexEnteredVerification();
    console.log(printTimestamp(), ' Revisited wf and verified validation for valid regex value')
});