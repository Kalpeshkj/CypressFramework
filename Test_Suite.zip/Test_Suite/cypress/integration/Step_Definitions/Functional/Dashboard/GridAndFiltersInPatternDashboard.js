/// <reference types="Cypress" />
/// <reference types='cypress-tags' />

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';

import PatternDashboard from "../../../../support/pageObjects/pages/Dashboard/PatternDashboard";
const patternDashboard = new PatternDashboard();

When("User Clicks on drop down of column configuration and select all optional columns", () => {
    patternDashboard.unSelectedAllColumnsChekboxClick()
    console.log(printTimestamp(), ' Clicked on drop down of column configuration and selected all optional columns')
});

Then("Verifies available filters for each column in data grid", () => {
    patternDashboard.allColumnsSelectedVerification()
    console.log(printTimestamp(), ' Verified available filters for each column in data grid')
});

When("User Enters Invalid pattern name in input text and clicks on enter", () => {
    patternDashboard.patternNameSearchWithInvalidText()
    console.log(printTimestamp(), ' Enters Invalid pattern name in input text')
});

Then("'No records found' message should be displayed in data grid", () => {
    patternDashboard.noRecordsFoundTextValidation()
    console.log(printTimestamp(), " 'No records found' message displayed")
});

When("User Enters valid pattern name in input text and clicks on enter", () => {
    patternDashboard.patternNameSearchWithValidText()
    patternDashboard.recordsVerificationBeforeClearFilter()
    console.log(printTimestamp(), ' Enters valid pattern name in input text')
});

Then("Pattern name should be displayed in grid", () => {
    patternDashboard.validPatternNameFilterTextVerification()
    console.log(printTimestamp(), ' Pattern name displayed in grid')
});

And("Verifies pattern count when filter applied", () => {
    patternDashboard.recordsVerificationBeforeClearFilter()
    console.log(printTimestamp(), ' Verified pattern count when filter applied')
});

When("User Removes searched pattern name available in input text or click on X icon", () => {
    patternDashboard.patternNameSearchClearText()
    console.log(printTimestamp(), ' Removed searched pattern name available in input text')
});

Then("Filtered data should get cleared", () => {
    patternDashboard.patternNameTextVerificationAferClearFilter()
    console.log(printTimestamp(), ' Filtered data got cleared')
});

And("Verifies pattern count when filter not applied", () => {
    patternDashboard.recordsVerificationAfterClearFilter()
    console.log(printTimestamp(), ' Verified pattern count when filter not applied')
});

When("User Clicks on 'Modality' column and selects one modality from drop down option", () => {
    patternDashboard.modalityColumnTextCapture()
    console.log(printTimestamp(), ' Clicks on "Modality" column and selects one modality from drop down')
});

Then("Filtered data should be displayed in grid as per selected modality", () => {
    patternDashboard.modalityRecordsTextVerificationAfterFilterApply()
    console.log(printTimestamp(), ' Filtered data displayed in grid as per selected modality')
});

When("User Clicks on 'Modality' column and select multiple modality from drop down option", () => {
    patternDashboard.modalityClick()
    cy.wait(2000)
    patternDashboard.MultipleOptionSelectionFromModalityDropdown()
    console.log(printTimestamp(), ' Clicks on "Modality" column and select multiple modality')
});

When("User Click on drop down of modality column and uncheck selected modality or click on remove filter icon", () => {
    patternDashboard.modalityClick()
    patternDashboard.clearButtonClick()
    console.log(printTimestamp(), ' Clicked on drop down of modality column and uncheck selected modality')
});

When("User Repeat above steps for multi select drop down related column Filters", () => {
    patternDashboard.patternStateColumnClick()
    cy.wait(2000)
    patternDashboard.MultipleOptionSelectionFromPatternStateDropdown()
    console.log(printTimestamp(), ' Repeated above steps for multi select drop down related column Filters')
});

Then("Filtered data should be displayed", () => {
    patternDashboard.patternStateRecordsTextVerificationAfterFilterApply()
    console.log(printTimestamp(), ' Filtered data displayed')
});

And("Verifies date range related text box", () => {
    patternDashboard.dateRangeColumnsVisible()
    console.log(printTimestamp(), ' Verifies date range text box')
});

When("User Click on Modified On column and select date range from calendar", () => {
    patternDashboard.modifiedonColumnDateRangeClick()
    patternDashboard.calenderDateSelection()
    console.log(printTimestamp(), ' Clicked on Modified On column and select date range from calendar')
});

Then("Based on selected date range filtered data should be displayed in grid", () => {
    console.log(printTimestamp(), ' filtered data displayed in grid')
});

When("User Click on 'Modified On' text box and tries to select future date range then it should not allow", () => {
    patternDashboard.modifiedonColumnDateRangeClick()
    patternDashboard.modifiedonColumnDateRangeClearButtonClick()
    patternDashboard.modifiedonColumnDateRangeClick()
    patternDashboard.calenderFutureDateSelection()
    patternDashboard.noRecordsFoundTextValidation()
    console.log(printTimestamp(), ' Clicked on "Modified On" text box and tried to select future date range but it should not allowed')
});

Then("User clicks on remove filter on modified on column", () => {
    patternDashboard.modifiedonColumnDateRangeClick()
    patternDashboard.modifiedonColumnDateRangeClearButtonClick()
    console.log(printTimestamp(), ' Clicked on remove filter on modified on column')
});

When("User selects future date", () => {
    patternDashboard.modifiedonColumnDateRangeClick()
    patternDashboard.calenderFutureDateSelection()
    console.log(printTimestamp(), ' Selected future date')
});

Then("No records found message should be displayed", () => {
    patternDashboard.noRecordsFoundTextValidation()
    patternDashboard.modifiedonColumnDateRangeClick()
    patternDashboard.modifiedonColumnDateRangeClearButtonClick()
    console.log(printTimestamp(), ' No records found message displayed')
});

And("Repeats above steps for all date range related column filters", () => {
    patternDashboard.publishedonColumnDateRangeClick()
    patternDashboard.calenderDateSelectionForPublishedOnColumn()
    patternDashboard.publishedonColumnDateRangeClick()
    patternDashboard.publishedonnColumnDateRangeClearButtonClick()
    console.log(printTimestamp(), ' Repeats above steps for all date range related column')
});

When("User Apply filter on one column or multiple columns", () => {
    patternDashboard.multipleColumnFilter()
    console.log(printTimestamp(), ' Applied filter on one or multiple columns')
});

Then("Filtered data should be available as per applied filter", () => {
    // patternDashboard.multipleFiltersAppliedRecordsTextVerification()
    console.log(printTimestamp(), ' Filtered data available as per applied filter')
});

And("Click on Clear All Filter and verify data grid and pattern count", () => {
    patternDashboard.clearAllFilterButtonClick()
    console.log(printTimestamp(), ' Clicked on Clear All Filter and verified data grid and pattern count')
});

And("Navigate to My Pattern Dashboard and repeat above all steps", () => {
    patternDashboard.myPatternDashboardNavigation()
    cy.wait(2000)
    patternDashboard.unSelectedAllColumnsChekboxClick()
    patternDashboard.allColumnsSelectedVerification()
    patternDashboard.patternNameSearchWithInvalidText()
    patternDashboard.noRecordsFoundTextValidation()
    patternDashboard.patternNameSearchWithValidText()
    patternDashboard.validPatternNameFilterTextVerification()
    patternDashboard.recordsVerificationBeforeClearFilter()
    patternDashboard.patternNameSearchClearText()
    patternDashboard.patternNameTextVerificationAferClearFilter()
    patternDashboard.multipleColumnFilter()
    cy.wait(2000)
    patternDashboard.multipleFiltersAppliedRecordsTextVerification()
    patternDashboard.clearAllFilterButtonClick()
    console.log(printTimestamp(), ' Navigated to My Pattern Dashboard and repeat above all steps')
});

And("Close the DAW Application", () => {
    cy.log("Test Case Executed Successfully")
    console.log(printTimestamp(), ' Test Case Executed Successfully')
});
