/// <reference types="Cypress" />
/// <reference types = 'cypress-tags' /> 

import "../../../../support/index"
import { When, Then, And } from "cypress-cucumber-preprocessor/steps"
import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();
import { printTimestamp } from '../../../../support/commands';

Then("User should be able to create Authoring Workflow or User should be able to navigate to existing Authoring WF", () => {
     createPattern.patternTabThreeDotsClick()
     createPattern.createPatternButtonClick()
     cy.wait(2000)
     console.log(printTimestamp(), 'User creates new authoring workflow')
})

When("User click on From Rule-Pattern from + Add Condition", () => {
     createPattern.addConditionOptionClick()
     createPattern.dropDownOptionUnderAddConditionClick()
     createPattern.fromRulePatternOpotionClick()
     console.log(printTimestamp(), createPattern.clickedFromRulePatternAndAddCondition)
})

Then("User should be able to select option from dropdown of common search", () => {
     createPattern.commonSearchDropdownClick()
     createPattern.tagsOptionUnderCommonSearchClick()
     console.log(printTimestamp(), ' selects option from dropdown option of common search')
})
And("User search pattern details", () => {
     createPattern.searchByKeyWordDicomOptionType()
     createPattern.searchButtonOfSearchByKeyWordClick()
     console.log(printTimestamp(), 'searched for pattern details')
})

Then("Searched pattern details should be available in grid", () => {
     createPattern.searchedPatternDetailsForDicomVisible()
     console.log(printTimestamp(), 'Searched pattern details are available in grid')
})

When("User Apply filter on any columns and Filtered data should be displayed in grid", () => {
     createPattern.nameFilterRejectedType()
     createPattern.searchButtonOfNameFilterClick()
     cy.wait(1000)
})

Then("Show All check box should be available in unchecked state", () => {
     createPattern.showAllCheckBoxUnchecked()
})

And("Searched-filtered content should get cleared from search text box-column level filter", () => {
     createPattern.nameFilterCleared()
     createPattern.descriptionFilterCleared()
     createPattern.dataModelFilterCleared()
     createPattern.tagsFilterCleared()
     console.log(printTimestamp(), 'Searched-filtered content  get cleared from search text box-column level filter')
})

When("User Click on cancel", () => {
     createPattern.cancelButtonClick()
     console.log(printTimestamp(), 'clicked on cancel')
})

And("User click on From Rule-Pattern from + Add Condition", () => {
     createPattern.dropDownOptionUnderAddConditionClick()
     createPattern.fromRulePatternOpotionClick().click()
     console.log(printTimestamp(), createPattern.clickedFromRulePatternAndAddCondition)
})

And("User select on Select All check box", () => {
     createPattern.showAllCheckBoxchecked()
     cy.wait(2000)
     console.log(printTimestamp(), ' clicked on Select All')
})

And("User should be able to select option from dropdown option of common search", () => {
     createPattern.commonSearchDropdownClick()
     createPattern.descriptionOptionUnderCommonSearchClick()
     console.log(printTimestamp(), ' selects option from dropdown option of common search')
})

When("Users search pattern details", () => {
     createPattern.searchByKeyWordErrorOptionType()
     createPattern.searchButtonOfSearchByKeyWordClick()
     cy.wait(2000)
     console.log(printTimestamp(), 'search pattern details')
})
Then("Searched patterns details should be available in grid", () => {
     createPattern.searchedPatternDetailsForErrorVisible()
     console.log(printTimestamp(), 'Searched patterns details available in grid')
})

When("User Apply filter on any columns and Filtered data should be displayed in grid", () => {
     createPattern.nameFilterRejectedType()
     createPattern.searchButtonOfNameFilterClick()
     cy.wait(1000)
     console.log(printTimestamp(), 'Applied filter on any columns and Filtered data displayed in grid')
})

Then("Show All check box should be available in unchecked state", () => {
     createPattern.showAllCheckBoxUnchecked()
     console.log(printTimestamp(), 'Show All check box available in unchecked state')
})

And("Show All should be available in unchecked state", () => {
     createPattern.showAllCheckBoxUnchecked()
     console.log(printTimestamp(), 'Show All check box  available in unchecked state')
})
When("Select on Show ALL", () => {
     createPattern.showAllCheckBoxchecked()
     cy.wait(3000)
     console.log(printTimestamp(), 'User select or click on Select All')
})
Then("All records total pattern details should be displayed", () => {
     createPattern.allFilteredRecordsVisible()
     console.log(printTimestamp(), 'All records total pattern details displayed')
})
And("All should be available in dropdown of common search", () => {
     createPattern.allOnCommonSearchVisible()
     console.log(printTimestamp(), 'All available in dropdown of common search')
})

And("Searched-filtered content should get cleared", () => {
     createPattern.nameFilterCleared()
     createPattern.descriptionFilterCleared()
     createPattern.dataModelFilterCleared()
     createPattern.tagsFilterCleared()
     console.log(printTimestamp(), 'Searched-filtered content  get cleared')
})

And("For ShowAll User should be able to apply filter on columns Pattern Name , Description and Data Model", () => {
     createPattern.nameFilterRejectedType()
     createPattern.searchButtonOfNameFilterClick()
     cy.wait(1000)
     createPattern.filteredDataOfNameFilterRejectedVisible()
     createPattern.removeFilterButtonOfNameFilterClick()
     cy.wait(2000)
     createPattern.DescriptionFilterxrayType()
     createPattern.searchButtonOfDescriptionFilterClick()
     cy.wait(1000)
     createPattern.filteredDataOfDescriptionFilterXrayVisible()
     createPattern.removeFilterButtonOfDescriptionFilterClick()
     cy.wait(1000)
     createPattern.dataModelsFilterClick()
     createPattern.filteredDataOfDataMOdelFilterVisible()
     createPattern.tagsFilterOptionClick()
     createPattern.tagsFilterDICOMandInteroperabilityOptionClick()
     createPattern.applyButtonOfTagsFilterClick()
     cy.wait(1000)
     createPattern.filteredDataOfTagsFilter()
     console.log(printTimestamp(), 'For ShowAll apply filter on columns Pattern Name , Description and Data Model')
})

When("User Uncheck Show All checkbox", () => {
     createPattern.showAllCheckBoxClicked()
     cy.wait(2000)
     console.log(printTimestamp(), ' Unchecked Show All checkbox')
})

Then("There should not be any change in the dashboard", () => {
     createPattern.allFilteredRecordsVisible()
})

When("Check Show All", () => {
     createPattern.showAllCheckBoxchecked()
     cy.wait(3000)
})

And("All the filters from the name Description and Data Model Column should be removed", () => {
     createPattern.nameFilterWithDetectorCleared()
     createPattern.descriptionFilterWitherrorCleared()
     createPattern.dataModelFilterCleared()
     createPattern.tagsFilterCleared()
})

When("USer Click on cancel", () => {
     createPattern.cancelButtonClick()
     cy.wait(1000)
     console.log(printTimestamp(), 'Clicked on cancel')
})

And("click on From Rule-Pattern from + Add Condition", () => {
     createPattern.addConditionOptionClick()
     cy.wait(1000)
     createPattern.dropDownOptionUnderAddConditionClick()
     cy.wait(1000)
     createPattern.fromRulePatternOpotionClick()
     console.log(printTimestamp(), createPattern.clickedFromRulePatternAndAddCondition)
})

Then("Show all should be available in unchecked state", () => {
     createPattern.showAllCheckBoxUnchecked()
     console.log(printTimestamp(), 'Show all available in unchecked state')
})

And("None of pattern details should be available", () => {
     createPattern.allFilteredRecordsNotExists()
     console.log(printTimestamp(), 'None of pattern details available')
})












