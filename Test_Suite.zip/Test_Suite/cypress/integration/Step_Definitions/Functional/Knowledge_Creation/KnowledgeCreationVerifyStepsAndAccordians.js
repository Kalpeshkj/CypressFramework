/// <reference types="Cypress" />
/// <reference types='cypress-tags' /> 

import "../../../../support/index";
import { When, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import CreateKnowledge from "../../../../support/pageObjects/pages/KnowledgeAuthoring/CreateKnowledge";
const createKnowledge = new CreateKnowledge();

When("User create knowledge workflow and Navigated to Newly Created knowledge  workflow", () => {
    createKnowledge.knowledgeOptionArrowClick()
    createKnowledge.addKnowledgeWorkflowButtonClick()
    cy.CreateMyKnowledge()
    createKnowledge.saveAsDraftClick()
    cy.wait(2000)
    cy.reload()
    console.log(printTimestamp(), 'Navigated to Newly Created knowledge workflow')
});

And("By default all accordian Knowledge info, symptoms, causes & solutions and tags for"
    + " selected knowledge should be displayed with knowledge information in expanded state", () => {
        createKnowledge.knowledgeInformationAccordianClick()
        createKnowledge.knowledgeInformationAccordianVisible()
        createKnowledge.symptomAccordianVisible()
        createKnowledge.causeAndSolutionAcordianVisible()
        createKnowledge.tagsAccordianVisible()
        createKnowledge.knowledgeInformationSectionExpandedVerification()
        console.log(printTimestamp(), "By default all accordian Knowledge info, symptoms, causes & solutions and tags for"
            + " selected knowledge should be displayed with knowledge information in expanded state")
    });



