/// <reference types="Cypress" />
/// <reference types = 'cypress-tags' /> 

import "../../../../support/index"
import {When, Then, And } from "cypress-cucumber-preprocessor/steps"
import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();
import ApplyMetadata from "../../../../support/pageObjects/pages/PatternAuthoring/applyMetadata";
const applyMetadata = new ApplyMetadata();
import {printTimestamp} from '../../../../support/commands';

When("User Clicks on the 3 dots present next to Patterns tab in Navigation Panel", () => {
    cy.CreatePatternsTillValidateStageCompletion(2)
    cy.visit(Cypress.env("DAWAutomationURL"));
    cy.wait(2000)
    createPattern.clearAllFiltersButtonClick()
    createPattern.patternNameTypeInSearchFilter()
    cy.wait(2000)
    createPattern.selectAllRecordClickInDashboard()
    createPattern.publishButtonClick()
    createPattern.withdrawButtonVisibleAsEnabled()
    console.log(printTimestamp(), ' Clicked on the 3 dots present next to Patterns tab in Navigation Panel')
});

Then("Edit Tag Association options should be present", () => {
    cy.visit('https://daw-bulk-edit-db.eu-west.philips-healthsuite.com/home')
	createPattern.patternTabThreeDotsClick()
	createPattern.editTagAssociationsVisible()
    console.log(printTimestamp(), ' Edit Tag Association option present')
});

When("User Click on Edit Tag Association", () => {
	createPattern.seditTagAssociationsClick()
    cy.wait(5000)
    console.log(printTimestamp(), ' Clicked on Edit Tag Association')
});

Then("A New Workflow should be created with header as Tag Associations", () => {
    cy.wait(3000)
	createPattern.NewPatternCreatedVisible()
    console.log(printTimestamp(), ' New Workflow created with header as Tag Associations')
});

When("User Clicks on the tag which is Mandatory", () => {
    createPattern.setHundredEntriesPerPage()
    cy.wait(2000)
    createPattern.severityFieldClick()
    createPattern.criticalNeedFieldClick()
    console.log(printTimestamp(), ' Clicked on tag which is Mandatory')
});

Then("User should be navigated to Edit stage with details of all the patterns associated with the tags should be visible", () => {
	createPattern.bulkStepNextClick()
    console.log(printTimestamp(), ' navigated to Edit stage with details of all the patterns associated with the tags visible')
});

Then("Verifies the buttons present", () => {
	createPattern.updateButtonVisible()
    createPattern.removeButtonVisible()
	createPattern.addButtonVisible()
    console.log(printTimestamp(), ' Verified buttons present')
});

When("User Select one or multiple pattern for which tag should be updated and click on the update button", () => {
	createPattern.patternNameTypeInSearchFilter()
    createPattern.selectAllRecords()
    createPattern.updateButtonClick()
    console.log(printTimestamp(), ' Selected one or multiple pattern for which tag updated and clicked on the update button')
});

Then("pop up should displayed having the header 'Update Tag Value for the tag'", () => {
	createPattern.selectClauseHeadingVisible()
    console.log(printTimestamp(), ' pop up displayed')
});

Then("The next line should be 'Select a new value for the tag'", () => {
	createPattern.selectTagHeadingVisible()
    console.log(printTimestamp(), ' pop up displayed')
});

And("There should be two buttons cancel and update button displayed", () => {
	createPattern.cancelButtononInPopUpVisible()
    createPattern.updateButtonInPopUpVisible()
    console.log(printTimestamp(), ' Two buttons cancel and update button displayed')
});

When("User Clicks on the dropdown", () => {
	createPattern.tagSelectionDropdownFirstValueClick()
    console.log(printTimestamp(), ' Clicked on the dropdown')
});

Then("Clicks on any of the disabled value in dropdown", () => {
	createPattern.tagSelectionDropdownSecondValueClick()
    console.log(printTimestamp(), ' Clicked on any of the disabled value in dropdown')
});

Then("Clicks on any of the value", () => {
	createPattern.updateButtonInPopUpClick()
    console.log(printTimestamp(), ' Clicke on any of the value')
});

Then("Repeat till update button click and click on OK button", () => {
	createPattern.bulkPublishButtonClick()
    console.log(printTimestamp(), ' Repeat till update button click and clicked on OK button')
});

When("Clicks on any of the pattern", () => {
    createPattern.patternDashboardClick()
    createPattern.patternNameTypeInSearchFilter()
    createPattern.firstRecordsNaviagationLinkClick()
    console.log(printTimestamp(), ' Clicked on any of the pattern')
});

Then("Pattern Details, Metadata, knowledge details should be displayed on the right side with collapsable window", () => {
    createPattern.patternNameInsidePatternVisible()
    createPattern.metadataSeverityVisible()
    console.log(printTimestamp(), ' Details displayed')
});

Then("Verifies the accordion on the pattern details", () => {
	createPattern.backAccordianVisible()
    createPattern.patternInfoInsidePatternVisible()
    console.log(printTimestamp(), ' Verified the accordion on the pattern details')
});

Then("Select on cancel button", () => {
	createPattern.patternInfoInsidePatternClick()
    console.log(printTimestamp(), ' Select on cancel button')
});

When("User Clicks on full screen on the Tag details row", () => {
    createPattern.fullScreenIconClick()
    console.log(printTimestamp(), 'Clicked on full screen on the Tag details row')
});

Then("Navigation panel should collapse", () => {
	createPattern.horizontalPanelVerification()
    console.log(printTimestamp(), ' Navigation panel collapsed')
});

Then("Clicks on full screen next to the details", () => {
    createPattern.collapseScreenIconClick()
    console.log(printTimestamp(), ' Clicked on full screen next to the details')
});

Then("Clicks on the workflow delete button", () => {
    cy.visit(Cypress.env("DAWAutomationURL"));
    cy.wait(3000)
	createPattern.patternNameTypeInSearchFilter()
    cy.wait(2000)
    createPattern.selectAllRecordClickInDashboard()
    createPattern.withdrawButtonVisibleAsDisabled()
    createPattern.deletePatternButtonInDashboardClick()
    createPattern.okButtonClick()
    console.log(printTimestamp(), ' Clicked on the workflow delete button')
});