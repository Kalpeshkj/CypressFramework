
/// <reference types="Cypress" />
/// <reference types='cypress-tags' />
import "../../../../support/index";
import { When, Then, Given } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();
import PatternDashboard from "../../../../support/pageObjects/pages/Dashboard/PatternDashboard";
const patternDashboard = new PatternDashboard();
import ValidationPage from "../../../../support/pageObjects/pages/PatternAuthoring/ValidatePage";
const validationPage = new ValidationPage();
import IncludeKnowledge from "../../../../support/pageObjects/pages/PatternAuthoring/includeKnowledgepageObj";
const includeKnowledge = new IncludeKnowledge();
Given("DAW application is available",()=>{
    cy.visit("https://daw-automation.eu-west.philips-healthsuite.com/home/patterns/dashboard")
})

When("User Create Multiple Patterns", () => {
	cy.CreateMultiplePatternsAsPerUserInput(1)
    console.log(printTimestamp(), ' User Create Multiple Patterns')  
});

When("Select all and click on Publish button", () => {
    cy.visit(Cypress.env("DAWAutomationURL"));
    cy.wait(2000)
    cy.reload()
    cy.wait(5000)
    patternDashboard.modalityDropdownColumnClick()
    cy.wait(1000)
    patternDashboard.selectAllCheckBoxClick()
    patternDashboard.modalityApplyButtonClick()
    patternDashboard.patternNameSearchOptionWFnameType()
    patternDashboard.patternNameSearchIconClick()
    cy.wait(2000)
    patternDashboard.selectAllPatternsCheckBoxClick()
    patternDashboard.publishButtonInPatternDashboardClick()
    cy.wait(2000)
    patternDashboard.publishButtonInPopUpClick()
    cy.wait(70000)
    console.log(printTimestamp(), ' Select all and click on Publish button') 
});

Then("Pattern Status should be displayed as 'Published'", () => {
	patternDashboard.patternsInPublishedStateVisible()
    console.log(printTimestamp(), "Pattern Status should be displayed as 'Published'") 
});

Then("Published by should be displayed as User name,Published on should be displayed as current date", () => {
	patternDashboard.modifiedByWithUserNameVisible()
    patternDashboard.modifiedOnWithDateVisible()
    console.log(printTimestamp(), ' Published by should be displayed as User name,Published on should be displayed as current date') 
});

Then("Latest Published pattern should be displayed in import Rule-Pattern", () => {
    createPattern.myPatternThreeDots().eq(1).click({ force: true });
    createPattern.createPatternButtonClick()
    cy.wait(2000)
    createPattern.addConditionTabClick()
    createPattern.addConditionPlusIconClick()
    cy.wait(1000)
    createPattern.formRulePatternOptionClick()
    cy.wait(2000)
    createPattern.showAllCheckboxClick()
    cy.wait(2000)
    createPattern.searchByKeyWordPublishedPatternNameType()
    cy.wait(1000)
    createPattern.searchIconClicked()
    cy.wait(4000)
    // createPattern.publishedPatternVisible() 
    createPattern.cancelButtononPopUpClick()
    console.log(printTimestamp(), ' Latest Published pattern should be displayed in import Rule-Pattern') 
});

Then("Validate pattern data with db Table Name - Patterns", () => {
	
    console.log(printTimestamp(), ' Validate pattern data with db Table Name - Patterns') 
});

When("Navigate to Pattern Dashboard,Edit published patterns e.g remove existing knowledge and add new knowledge and publish again", () => {
	createPattern.patternDashboardClick()
    cy.wait(2000)
    patternDashboard.modalityDropdownColumnClick()
    cy.wait(1000)
    patternDashboard.selectAllCheckBoxClick()
    patternDashboard.modalityApplyButtonClick()
    cy.wait(1000)
    createPattern.PatternNameSearchInSearchOption()
    createPattern.searchIconClicked()
    cy.wait(2000)
    patternDashboard.patternClick()
    cy.wait(2000)
    patternDashboard.editButtonClick()
    cy.wait(2000)
    createPattern.nextButtonClick()
    cy.wait(1000)
    createPattern.nextButtonClick()
    cy.wait(1000)
    includeKnowledge.removeKnowledgeIconClick()
    includeKnowledge.includeTabClick()
    includeKnowledge.showAllCheckBoxClick()
    cy.wait(1000)
    includeKnowledge.secondKnowledgwSelect()
    createPattern.nextButtonClick()
    cy.wait(1000)
    validationPage.validationIdDropdownClick()
    validationPage.selectFirstId()
    validationPage.selectButtonClick()
    validationPage.calenderOptionClick()
    validationPage.datePrevIconClick()
    validationPage.dateRangeSlection()
    validationPage.taskLimitInputBoxTypeOne()
    validationPage.validateButtonClick()
    cy.wait(3000)
    validationPage.saveAsDraftButtonClick()
    cy.wait(3000)
    createPattern.patternDashboardClick()
    cy.wait(2000)
    patternDashboard.modalityDropdownColumnClick()
    cy.wait(1000)
    patternDashboard.selectAllCheckBoxClick()
    patternDashboard.modalityApplyButtonClick()
    cy.wait(1000)
    patternDashboard.patternNameSearchOptionWFnameType()
    patternDashboard.patternNameSearchIconClick()
    cy.wait(3000)
    patternDashboard.patternClick()
    cy.wait(2000)
    patternDashboard.publishButtonInPatternDashboardClick()
    cy.wait(2000)
    patternDashboard.publishButtonInPopUpClick()
    cy.wait(30000)
    console.log(printTimestamp(), ' Navigate to Pattern Dashboard,Edit published patterns e.g remove existing knowledge and add new knowledge and publish again') 
});

When("Delete Publish patterns", () => {
    patternDashboard.patternClick()
    cy.wait(4000)
    patternDashboard.deleteButtonInDetailsPageClick()
    cy.wait(1000)
    patternDashboard.popUpOkButtonClick()
    cy.wait(2000)
    console.log(printTimestamp(), ' Delete Publish patterns') 
});

Then("Deleted pattern version should not get displayed in dashboard and import condition", () => {
    createPattern.myPatternThreeDots().eq(1).click({ force: true });
    createPattern.createPatternButtonClick()
    cy.wait(2000)
    createPattern.addConditionTabClick()
    createPattern.addConditionPlusIconClick()
    cy.wait(1000)
    createPattern.formRulePatternOptionClick()
    cy.wait(2000)
    createPattern.showAllCheckboxClick()
    cy.wait(2000)
    createPattern.searchByKeyWordPublishedPatternNameType()
    cy.wait(1000)
    createPattern.searchIconClicked()
    cy.wait(4000)
    createPattern.noResultsFoundInRelevanceMessageVisible()
    createPattern.cancelButtononPopUpClick()
    cy.ExistingWFClick()
    cy.DeleteWorkflow()
    console.log(printTimestamp(), "Deleted pattern's version should not get displayed in dashboard and import condition") 
});

Then("Perform Edit , Delete , Clone and Withdraw operations on latest published pattern", () => {
	createPattern.patternDashboardClick()
    cy.wait(2000)
    patternDashboard.modalityDropdownColumnClick()
    cy.wait(1000)
    patternDashboard.selectAllCheckBoxClick()
    patternDashboard.modalityApplyButtonClick()
    cy.wait(1000)
    createPattern.secondPatternNameSearchInSearchOption() 
    createPattern.searchIconClicked()
    cy.wait(2000)
    patternDashboard.patternClick()
    cy.wait(2000)
    patternDashboard.withdrawButtonInDetailsPageClick()
    cy.wait(2000)
    patternDashboard.popUpOkButtonClick()
    cy.wait(2000)
    patternDashboard.backArrowClick()
    patternDashboard.patternInWithdraw()
    patternDashboard.selectAllCheckBoxClick()
    patternDashboard.deleteButtonIndashbaordClick()
    patternDashboard.popUpOkButtonClick()
    cy.wait(2000)
    cy.DeleteLastPattern()
    console.log(printTimestamp(), ' Perform Edit , Delete , Clone and Withdraw operations on latest published pattern') 
});

