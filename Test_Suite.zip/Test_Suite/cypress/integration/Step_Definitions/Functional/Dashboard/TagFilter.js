/// <reference types="Cypress" />
/// <reference types='cypress-tags' />

import "../../../../support/index";
import { When, Then } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';

import PatternDashboard from "../../../../support/pageObjects/pages/Dashboard/PatternDashboard";
const patternDashboard = new PatternDashboard();

When("User Clicks on clear all filter button", () => {
    patternDashboard.clearAllFilterButtonClick()
    console.log(printTimestamp(), ' Clicked on clear all filter button')
});

Then("Verifies Modality filter should get cleared", () => {
    patternDashboard.modalityColumnValueVerification()
    console.log(printTimestamp(), ' Verified Modality filter got cleared')
});

Then("User Add Tags column from optional column drop down", () => {
    patternDashboard.patternDropdownClick()
    patternDashboard.selectTagsDropdownValue()
    patternDashboard.dashboardDropdownColumnClick()
    console.log(printTimestamp(), ' Tags column added from optional column drop down')
});

When("User Clicks on drop down of Tags and verify UI for filter options drop down", () => {
    patternDashboard.tagColumnClick()
    console.log(printTimestamp(), " Clicked on drop down of Tags and verify UI")
});

Then("Verifies details should be available in filter option drop down", () => {
    patternDashboard.tagColumnSearchBoxVisible()
    patternDashboard.tagColumnAllValueSelectionCheckBoxVisible()
    patternDashboard.TagsClearButtonVisible()
    patternDashboard.checkboxesAtColumnLevelValidation()
    console.log(printTimestamp(), ' Verifies details available in filter option drop down')
});

Then("Verifies order of filter value in drop down", () => {
    patternDashboard.tagColumnValuesSortedDataVerification()
    console.log(printTimestamp(), ' Verified order of filter value in drop down')
});

When("User Click on any tag value and verifies filtered pattern details", () => {
    patternDashboard.tagColumnFirstValueClick()
    patternDashboard.tagsColumnFirstValueSelectedVerification()
    console.log(printTimestamp(), ' Clicked on any tag value and verified filtered pattern details')
});

When("User Click on drop down of tags and enter tag value in filter text box", () => {
    patternDashboard.tagColumnClick()
    patternDashboard.tagColumnSearchBoxType()
    console.log(printTimestamp(), ' Clicked on drop down of tags and enter tag value')
});

Then("Matched tag values should get displayed", () => {
    patternDashboard.tagColumnSearchedValueVisible()
    console.log(printTimestamp(), ' Matched tag values displayed')
});

When("User Clicks x mark available beside text box", () => {
    patternDashboard.tagColumnBesideTheBoxClick()
    console.log(printTimestamp(), ' Clicked on x mark')
});

Then("Filter option pop for tags should get closed", () => {
    patternDashboard.TagsColumnPopUpNotVisible()
    console.log(printTimestamp(), ' Filter option pop for tags should got closed')
});

When("User Clicks on dropdown and verify entered value", () => {
    patternDashboard.tagColumnClick()
    patternDashboard.tagColumnSelectedValueVisible()
    console.log(printTimestamp(), ' Clicked on dropdown and verified entered value')
});

Then("Select multiple tag values and verify pattern data", () => {
    patternDashboard.multipleTagsSelectionFromDropdown()
    patternDashboard.tagsColumnMultipleValueSelectedVerification()
    console.log(printTimestamp(), ' Selected multiple tag values and verified pattern data')
});

When("User Click on drop down of tags and select all tags", () => {
    cy.wait(2000)
    patternDashboard.tagColumnClick()
    patternDashboard.tagColumnAllValueSelectionClick()
    console.log(printTimestamp(), ' Clicked on drop down of tags and select all tags')
});

Then("All associated patterns should be displayed", () => {
    patternDashboard.selectedTagsVisible()
    console.log(printTimestamp(), ' All associated patterns displayed')
});

When("User Unselect few tag values and verify data", () => {
    patternDashboard.tagColumnClick()
    patternDashboard.multipleTagsSelectionFromDropdown()
    console.log(printTimestamp(), ' Unselect few tag values and verified data')
});

Then("For unselected tags associated pattern should not be displayed", () => {
    patternDashboard.tagsColumnFirstValueSelectedNotVisible()
    console.log(printTimestamp(), ' For unselected tags associated pattern should not displayed')
});

Then("Deletes pattern and verify associated tags in drop down", () => {

    console.log(printTimestamp(), ' Deleted pattern and verified associated tags in drop down')
});