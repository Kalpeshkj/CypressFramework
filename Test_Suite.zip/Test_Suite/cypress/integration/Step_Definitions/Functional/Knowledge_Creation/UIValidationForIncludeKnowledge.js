/// <reference types="Cypress" />
/// <reference types='cypress-tags' />

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();
import IncludeKnowlegePage from "../../../../support/pageObjects/pages/PatternAuthoring/includeKnowledgepageObj";
const includeKnowlegePage = new IncludeKnowlegePage();
import NavigationPanel from "../../../../support/pageObjects/pages/Dashboard/NavigationPanel";
const navigationPanel = new NavigationPanel();
let arr = [];

When("User creates new workflow and fills pattern and apply metadata details", () => {
    cy.createPattern()
    createPattern.nextButtonClick()
    cy.ApplyMetaDetaPageCompletion()
    console.log(printTimestamp(), ' New knowledge workflow created')
});

Then("User clicks on Next button from apply metadata page", () => {
    createPattern.nextButtonClick()
    console.log(printTimestamp(), ' Next button clicked')
});

And("User should be able to navigate to Include Knowledge step", () => {
    createPattern.includeKnowledgeHeadingActiveVerification()
    console.log(printTimestamp(), ' Navigated to Include Knowledge step')
});

And("Verifies create pattern, appply metdata completed and validate, request review in disabled state in headers", () => {
    createPattern.createPatternHeadingCompletedVerification()
    createPattern.applyMetadataHeadingCompletedVerification()
    createPattern.includeKnowledgeHeadingActiveVerification()
    createPattern.validateHeadingPendingVerification()
    createPattern.requestReviewHeadingPendingVerification()
    console.log(printTimestamp(), ' Verified create pattern, appply metdata completed and validate, request review in disabled state in headers')
});

And("Verifies info icon, version, draft icon and expand icon in step header", () => {
    includeKnowlegePage.infoIconVisible()
    includeKnowlegePage.versionIconVisible()
    includeKnowlegePage.draftInfoVisible()
    includeKnowlegePage.draftIconVisible()
    includeKnowlegePage.draftIconVisible()
    includeKnowlegePage.expandIconVisible()
    console.log(printTimestamp(), ' Clicks on show all checkbox and verifies details like total records, column level filter, cancel and select button and entries per page')
});

And("Verifies previous, close, save as draft button as enabled and next button as disabled", () => {
    includeKnowlegePage.previousButtonEnabledVerification()
    includeKnowlegePage.closeButtonEnabledVerification()
    includeKnowlegePage.saveAsDraftButonEnabledVerification()
    includeKnowlegePage.nextButtonDisabledVerification()
    console.log(printTimestamp(), ' Verified previous, close, save as draft button as enabled and next button as disabled')
});

And("Verifies include, review tab and by default include tab as selected", () => {
    includeKnowlegePage.includeTabInKnowledgeVisible()
    includeKnowlegePage.reviewTabInKnowledgeVisible()
    includeKnowlegePage.includeTabInKnowledgeByDefaultSelectedVisible()
    console.log(printTimestamp(), ' Verified include, review tab and by default include tab as selected')
});

And("Verifies add knowledge text and hyperlink, show all checkbox and dropdown with by default all selected should displayed", () => {
    includeKnowlegePage.addKnowledgeTextVisible()
    includeKnowlegePage.addKnowledgeHyperlinkVisible()
    // includeKnowlegePage.showAllCheckBoxVisible()
    includeKnowlegePage.dropdownWithByDefaultAllSelectedVisible()
    console.log(printTimestamp(), ' Verifies add knowledge text and hyperlink, show all checkbox')
});

When("User clicks on Show All check box", () => {
    includeKnowlegePage.showAllCheckboxClick()
    console.log(printTimestamp(), ' Show All check box clicked')
});

Then("Total number records, Clear All Filter button, Column level filter and Entries per page should be displayed", () => {
    includeKnowlegePage.totalNumberOfRecordsVisible()
    includeKnowlegePage.clearAllFilterButtonVisible()
    includeKnowlegePage.entriesPerPageTextVisible()
    includeKnowlegePage.recordsFoundTextVerification()
    console.log(printTimestamp(), ' Total number records, Clear All Filter button, Column level filter and Entries per page displayed')
});

And("By default knowledge details should be displayed as per asc order of Knowledge Name", () => {
    includeKnowlegePage.sortingIconInAscendingOrderVisible()
    console.log(printTimestamp(), ' By default knowledge details should be displayed')
});

When("User Change entries per page from drop down option", () => {
    includeKnowlegePage.EntriesPerPageCountChange()
    console.log(printTimestamp(), ' Entries per page changed')
});

Then("Based on selected value from drop down number of records should be displayed", () => {
    includeKnowlegePage.totalResultsCountVerification()
    console.log(printTimestamp(), ' number of records verified')
});

When("User Navigate to next page by clicking on >", () => {
    includeKnowlegePage.nextPageNavigationIconVisibleandClick()
    console.log(printTimestamp(), ' Clicked on >')
});

Then("Based on that current page number and knowledge details should be displayed", () => {
    includeKnowlegePage.showingResultsVerificationAfterNextPageClick()
    console.log(printTimestamp(), ' Current page number and knowledge details verified')
});

When("User Navigate to previous page by clicking on <", () => {
    includeKnowlegePage.previousPageNavigationIconVisibleandClick()
    console.log(printTimestamp(), ' clicked on <')
});

Then("Based on that current page count and knowledge details should be displayed", () => {
    includeKnowlegePage.showingResultsVerificationAfterPreviousPageClick()
    console.log(printTimestamp(), ' Current page number and knowledge details verified')
});

And("Verifies available Knowledge details like Knowledge Name and Tags", () => {
    includeKnowlegePage.knowledgeDetailsVerification()
    console.log(printTimestamp(), ' Verified available Knowledge details')
});

When("User clicks on Full screen view icon and verify screen", () => {
    includeKnowlegePage.expandIconClickandVerification()
    console.log(printTimestamp(), ' Clicked on full screen icon and verified screen size')
});

Then("Again clicks on full screen icon then screen should get collapsed in default size", () => {
    navigationPanel.collapseIconClickandVerification()
    console.log(printTimestamp(), ' Again clicked on full screen icon and verified screen size')
});

