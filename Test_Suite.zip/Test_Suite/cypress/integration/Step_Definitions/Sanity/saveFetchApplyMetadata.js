/// <reference types="Cypress" />
/// <reference types='cypress-tags' />

import "../../../support/index";
import { Given, When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../support/commands';
import CreatePattern from "../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
import PatternDashboard from "../../../support/pageObjects/pages/Dashboard/PatternDashboard";
import AssertionConstants from "../../../support/pageObjects/pages/AssertionConstants";
import ApplyMetadata from "../../../support/pageObjects/pages/PatternAuthoring/applyMetadata";
import NavigationPanel from "../../../support/pageObjects/pages/Dashboard/NavigationPanel";

const applyMetadata = new ApplyMetadata()
const createPattern = new CreatePattern();
const patternDashboard = new PatternDashboard();
const constants = new AssertionConstants();
const navigationPanel = new NavigationPanel();

When("Enter all the mandatory details in Create pattern and clicks on next", () => {
    cy.createPattern()
    createPattern.nextButtonClick()
    cy.wait(5000)
    console.log(printTimestamp(), ' Entered all the mandatory details in Create pattern')
});

Then("Modality Dropdown is visible", () => {
    createPattern.modalityDropdownfield().eq(0).click({ force: true })
    createPattern.modalityDropdown().each(($el) => {
        cy.wrap($el).should(constants.beVisibleAssertion);
    });
    console.log(printTimestamp(), ' Clicked on Modality Dropdown')
});

And("Modality got selected from the list", () => {
    createPattern.modalityDropdown().eq(4).click()
    createPattern.modalityDropdown().eq(5).click()
    console.log(printTimestamp(), ' Selected modality')
});

When("Pattern type Dropdown is visible", () => {
    createPattern.modalityDropdownfield().eq(1).click({ force: true })
    console.log(printTimestamp(), ' Clicked on pattern type')
});

Then("Pattern type got selected from the list", () => {
    createPattern.patternTypeDropdown().each(($el) => {
        cy.wrap($el).should(constants.beVisibleAssertion);
    });
    createPattern.patternTypeDropdown().eq(0).click()
    console.log(printTimestamp(), ' selected pattern type')
});

When("Relevance Section Dropdown is visible", () => {
    console.log(printTimestamp(), ' Verified relevance Section')
});

Then("Relevance got selected from the list", () => {
    createPattern.relevanceField().eq(0).should(constants.beVisibleAssertion);
    createPattern.relevanceField().eq(0).click();
    console.log(printTimestamp(), ' Selected relevance')
});

When("Service Context Dropdown is visible", () => {
    createPattern.modalityDropdownfield().eq(2).should(constants.beVisibleAssertion);
    createPattern.modalityDropdownfield().eq(2).click({ force: true })
    cy.contains('FSE').should(constants.beVisibleAssertion)
    cy.contains('RME').should(constants.beVisibleAssertion)
    cy.contains('RSE').should(constants.beVisibleAssertion)
    console.log(printTimestamp(), ' Verified the Service Context')
});

Then("Service Context got selected from the list", () => {
    createPattern.serviceContextFields().eq(0).click();
    cy.wait(2000);
    createPattern.modalityDropdownfield().eq(2).click({ force: true })
    console.log(printTimestamp(), ' Selected Service Context')
});

When("Severity Dropdown is visible and selects any of users choice", () => {
    createPattern.modalityDropdownfield().last().click({ force: true })
    createPattern.severityFields().each(($el) => {
        cy.wrap($el).should(constants.beVisibleAssertion);
    })
    createPattern.severityFields().eq(0).click({ force: true })
    console.log(printTimestamp(), ' Verified Severity and selected one of its choices')
});

And("DaySpan is Visible with default value as 24 hrs", () => {
    applyMetadata.dayspanDayTextbox().should(constants.beVisibleAssertion)
    applyMetadata.dayspanUnitDropdown().should(constants.beVisibleAssertion)
    applyMetadata.dayspanDayTextbox().should('have.attr', 'placeholder', '24 (Default)');
    applyMetadata.dayspanUnitDropdown().invoke('text').should('include', 'h')

    console.log(printTimestamp(), ' timestamp Verified')
});

And("Comment section is available and user should able to type anything", () => {
    createPattern.commentBox().should(constants.beVisibleAssertion);
    createPattern.commentBox().click({ force: true }).type('TestComment')
    console.log(printTimestamp(), 'comment Verified ')
});

When("Clicks on Add Tag hyperlink", () => {
    createPattern.addTagButton().should(constants.beVisibleAssertion);
    createPattern.addTagButton().click();
    console.log(printTimestamp(), ' Clicked on Add Tag hyperlink')
});

Then("Buttons are present after clicking on tag hyperlink", () => {
    createPattern.withoutKeywordSection().should(constants.beVisibleAssertion);
    createPattern.withKeywordSection().should(constants.beVisibleAssertion);
    console.log(printTimestamp(), ' Verified the buttons present')
});

And("Cancel button is present and user able to click", () => {
    createPattern.cancelButton().should(constants.beVisibleAssertion);
    createPattern.cancelButton().click();
    console.log(printTimestamp(), ' Clicked on Cancel')
});

When("Clicks on hyperlink, add tags and clicks on done button", () => {
    createPattern.addTagButton().click();
    createPattern.selectTag().click();
    createPattern.addTagFromList().eq(0).click();
    createPattern.addTagOkButton().eq(0).click();
    createPattern.doneButton().click({ force: true });
    console.log(printTimestamp(), ' Clicked on hyperlink and add tags and clicked on done')
});

Then("Save as draft button us present and user clicks it", () => {
    createPattern.clicksOnPopUpOkButton();
    cy.wait(5000)
    console.log(printTimestamp(), ' Clicked on save as draft')
});

And("Navigates to workflow after visiting pattern dashboard", () => {
    patternDashboard.dashboardButton().eq(0).click();
    applyMetadata.clickingOnCreatedWorkflow()
    patternDashboard.valueToCompare().eq(1).invoke('text').should('include', 'IGT, MR')
    patternDashboard.valueToCompare().eq(2).invoke('text').should('eq', 'Diagnostics')
    patternDashboard.valueToCompare().eq(3).invoke('text').should('eq', 'FSE')
    patternDashboard.valueToCompare().eq(4).invoke('text').should('eq', '1-Critical Need')
    patternDashboard.tagValue().should(constants.beVisibleAssertion)
    console.log(printTimestamp(), ' Navigated to workflow after visiting pattern dashboard')
});

And("Validates buttons present in Apply metadata page", () => {
    createPattern.tagId().should(constants.beVisibleAssertion)
    createPattern.modalityDropdownfield().eq(2).invoke('text').as('serviceContext');
    cy.get('@serviceContext').should('eq', 'FSE')
    console.log(printTimestamp(), 'Verified buttons present in Apply metadata page')
});

And("Clicks on full screen", () => {
    applyMetadata.fullScreenButtonClick()
    applyMetadata.collapsednavigationPanelBlock().should(constants.beVisibleAssertion)
    navigationPanel.ArrowMarkClick()
    navigationPanel.DeleteLastWorkflowThreeDotsbasedOnPatternName()
    console.log(printTimestamp(), ' Clicked on full screen')
});
