/// <reference types="Cypress" /> 
/// <reference types='cypress-tags' /> 
import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import CreateKnowledge from "../../../../support/pageObjects/pages/KnowledgeAuthoring/CreateKnowledge";
const createKnowledge = new CreateKnowledge();

When("User create new knowledge workflow", () => {
    createKnowledge.knowledgeOptionArrowClick()
    createKnowledge.addKnowledgeWorkflowButtonClick()
    cy.wait(3000)
    createKnowledge.knowledgeNameInputBoxType()
    createKnowledge.decriptionFieldType()
    console.log(printTimestamp(), 'createed new knowledge workflow')
});

When("Import cause", () => {
    createKnowledge.causesAndSolutionSectionClick()
    createKnowledge.addCausesButtonClick()
    createKnowledge.causeOneInputBoxType()
    createKnowledge.tagButtonClick()
    createKnowledge.selectTagsDropDownClick()
    createKnowledge.DAPCollimeterTagsOptionsClick()
    createKnowledge.plusIconInAddTagsClick()
    createKnowledge.doneButtonClickInPopUpClick()
    console.log(printTimestamp(), 'Imported cause')
});

When("Import symptom", () => {
    createKnowledge.symptomOptionClick()
    createKnowledge.addSymptomButtonClick()
    createKnowledge.symptomOneTextBoxForRichTextEditorType()
    createKnowledge.tagButtonClick()
    createKnowledge.selectTagsDropDownClick()
    createKnowledge.detectorTagsOptionsClick()
    createKnowledge.plusIconInAddTagsClick()
    createKnowledge.doneButtonClickInPopUpClick()
    console.log(printTimestamp(), 'Imported symptom')
});

When("Click on Add in Tag section", () => {
    createKnowledge.tagsknowledgeInfoOptionsClick()
    createKnowledge.addTagsOptionClick()
    console.log(printTimestamp(), 'Click on Add in Tag section')
});

Then("Add tag pop up should get displayed", () => {
	createKnowledge.addPartPopUpVisible()
    console.log(printTimestamp(), 'Add tag pop up should get displayed')
});

When("User add tag", () => {
    createKnowledge.selectTagDropdownClick()
    createKnowledge.awsTagsOptionsClick()
    createKnowledge.plusIconInAddtagsClick()
    createKnowledge.doneButtonClickInPopUpClick()
    console.log(printTimestamp(), 'User add tag')
});

Then("tags added at cause-solution-symptom level,all unique tags should get added as token in Tags section", () => {
	createKnowledge.tagsAddedUnderTagsSectionVerification()
    console.log(printTimestamp(), 'tags added at cause-solution-symptom level,all unique tags should get added as token in Tags section')
});

And("tags added at knolwedge level,tags should get added as removable token in tags section", () => {
	createKnowledge.tagsAsRemovableToken()
    console.log(printTimestamp(), 'tags should get added as removable token in tags section')
});

When("User Hover on tags for imported cause,symptom", () => {
	// createKnowledge.hoverOnDAPTag()
    console.log(printTimestamp(), 'User Hover on tags for imported cause,symptom')
});

Then("KnowledgeABC-Cause1,KnowledgeABC-Cause1:Solution 1,KnowledgeABC-Symptom1", () => {
	
    console.log(printTimestamp(), 'KnowledgeABC-Cause1,KnowledgeABC-Cause1:Solution 1,KnowledgeABC-Symptom1')
});

Then("When same tag added at cause and symptom level only unique tag should get displayed in token", () => {
	createKnowledge.causesAndSolutionSectionClick()
    createKnowledge.tagIconUnderSolutionClick()
    createKnowledge.selectTagsDropDownClick()
    createKnowledge.detectorTagsOptionsClick()
    createKnowledge.plusIconInAddTagsClick()
    createKnowledge.doneButtonClickInPopUpClick()
    createKnowledge.symptomOptionClick()
    createKnowledge.tagButtonClick()
    createKnowledge.selectTagsDropDownClick()
    createKnowledge.detectorTagsOptionsClick()
    createKnowledge.plusIconInAddTagsClick()
    createKnowledge.doneButtonClickInPopUpClick()
    createKnowledge.tagSectionWithUniqueTags()
    console.log(printTimestamp(), 'When same tag added at cause and symptom level only unique tag should get displayed in token')
});

When("Hover on knowledge tags", () => {
	
    console.log(printTimestamp(), 'Hover on knowledge tags')
});

Then("There should not be any tooltip displayed", () => {
	
    console.log(printTimestamp(), 'There should not be any tooltip displayed')
});

When("Hover on tags for newly added cause-solution-symptom", () => {
	
    console.log(printTimestamp(), 'Hover on tags for newly added cause-solution-symptom')
});

Then("Cause 2:Solution 1, Symptom 1, Cause 2:Solution 2", () => {
	
    console.log(printTimestamp(), 'Cause 2:Solution 1, Symptom 1, Cause 2:Solution 2')
});

