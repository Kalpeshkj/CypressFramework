/// <reference types="Cypress" />
/// <reference types='cypress-tags' />

import "../../../support/index";
import { Given, When, Then} from "cypress-cucumber-preprocessor/steps";
import {printTimestamp} from '../../../support/commands';

import CreatePattern from "../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();
import AssertionConstants from "../../../support/pageObjects/pages/AssertionConstants";
const constants = new AssertionConstants();

When("Create Pattern is clicked", () => {
  createPattern.myPatternThreeDots().eq(0).click();
  createPattern.createPattern().should(constants.beVisibleAssertion);
  createPattern.createPattern().click();
  createPattern.workflowSuccessText().should(constants.beVisibleAssertion);
  console.log(printTimestamp() ,' clicked on Create Pattern')
});

Then(
  "Create Pattern, Apply Metadata, Include Knowledge, validate and Request Review should be displayed",
  () => {
    createPattern.createPatternHeading().should(constants.beVisibleAssertion);
    createPattern.applyMetadataHeading().should(constants.beVisibleAssertion);
    createPattern.includeKnowledgeHeading().should(constants.beVisibleAssertion);
    createPattern.validateHeading().should(constants.beVisibleAssertion);
    createPattern.requestReviewHeading().should(constants.beVisibleAssertion);
    console.log(printTimestamp() ,' Verified Create Pattern, Apply Metadata, Include Knowledge, validate and Request Review are displayed')
  }
);

Then(
  "Pattern Information Import Data Model, Extends, Add Condition, Add Action should be present",
  () => {
    createPattern.patternInformationTab().should(constants.beVisibleAssertion);
    createPattern.importdatamodelTab().should(constants.beVisibleAssertion);
    createPattern.adConditionTab().should(constants.beVisibleAssertion);
    createPattern.addActionTab().should(constants.beVisibleAssertion);
    console.log(printTimestamp() ,' Verified Pattern Information like Import Data Model, Extends, Add Condition, Add Action')
  }
);

Then(
  "By default pattern information shoudl be available as expanded state",
  () => {
    createPattern.patternName().should(constants.beVisibleAssertion);
    console.log(printTimestamp() ,' Verified By default pattern information should be in expanded')
  }
);

Then("Name, Description, Order of Execution should be displayed", () => {
  createPattern.patternName().should(constants.beVisibleAssertion);
  createPattern.description().should(constants.beVisibleAssertion);
  cy.wait(2000)
  createPattern.orderOfExecution().first().should(constants.beVisibleAssertion);
  console.log(printTimestamp() ,' Verified Name, Description, Order of Execution are displayed')
});

Then("Enter details for all fields available in Pattern Information", () => {
  createPattern.patternName().click();
  createPattern.patternName().type(Cypress.env("PatternName"));
  createPattern.description().click();
  createPattern.description().type(Cypress.env("PatternDescription"));
  console.log(printTimestamp() ,' Entered all the field details in pattern information')
});

Then("Click on Import Data Model", () => {
  createPattern.importdatamodelTab().should(constants.beVisibleAssertion);
  createPattern.importdatamodelTab().click();
  console.log(printTimestamp() ,' Clicked on Import Data Model')
});

Then("Click on drop down option and select data model", () => {
  createPattern.importdatamodelDrpdownArrow().should(constants.beVisibleAssertion);
  createPattern.importdatamodelDrpdownArrow().click();
  console.log(printTimestamp() ,' Clicked on drop down option and selected data model')
});

Then("Select Data Model from drop down", () => {
  createPattern.importDataModelDrpdownCommon().should(constants.beVisibleAssertion);
  createPattern.importDataModelDrpdownCommon().click();
  createPattern.clickoutsidetoGetResult().click({ force: true });
  console.log(printTimestamp() ,' Selected Data Model from drop down')
});

Then("Click on Add Condition, Click on plus Drop Down", () => {
  createPattern.adConditionTab().should(constants.beVisibleAssertion);
  createPattern.adConditionTab().click();
  createPattern.addConditionPlusIcon().should(constants.beVisibleAssertion);
  createPattern.addConditionPlusIcon().click({ force: true });
  console.log(printTimestamp() ,' Clicked on Add Condition, Click on plus Drop Down')
});

Then("Close the Application", () => {
  cy.log("Test case executed successfully");
  console.log(printTimestamp() ,' Test case executed successfully')
});

Then(
  "From DataModel, From Rule Pattern, From Variable should be displayed",
  () => {
    createPattern.fromdataModel().should(constants.beVisibleAssertion);
    createPattern.fromrulePattern().should(constants.beVisibleAssertion);
    createPattern.fromVariable().should(constants.beVisibleAssertion);
    console.log(printTimestamp() ,' From DataModel, From Rule Pattern, From Variable are displayed correctly')
  }
);

When("Click on Add Action, Click on plus Drop Down", () => {
  createPattern.addActionTab().should(constants.beVisibleAssertion);
  createPattern.addActionTab().click({force: true});
  createPattern.addactionPlusIcon().should(constants.beVisibleAssertion);
  createPattern.addactionPlusIcon().click({ force: true });
  console.log(printTimestamp() ,' Clicked on Add Action, Clicked on plus Drop Down successfully')
});

Then(
  "Raise Alert, Insert Alert, Suppress Alert options should be displayed and user should be able to select one of them",
  () => {
    createPattern.raiseAlert().should(constants.beVisibleAssertion);
    createPattern.insertAlert().should(constants.beVisibleAssertion);
    createPattern.suppressAlert().should(constants.beVisibleAssertion);
    createPattern.raiseAlert().click();
    console.log(printTimestamp() ,' Raise Alert, Insert Alert, Suppress Alert options are available and user was able to select any one of them')
  }
);

Then(
  "Click on Save as Draft Pattern Details should be saved successfully",
  () => {
    createPattern.clickOnPopUpOkButton().should(constants.beVisibleAssertion);
    createPattern.clickOnPopUpOkButton().click({force:true});
    console.log(printTimestamp() ,' clicked on Save as Draft Pattern')
  }
);

Then("User relaunches application", () => {
  cy.visit(Cypress.env("URL"));
  console.log(printTimestamp() ,' Relaunched the application')
});

Then("Navigate to last Workflow", () => {
  cy.get("#" + Cypress.env("PatternName")).click();
  console.log(printTimestamp() ,' Navigated to last Workflow')

});

Then("Saved pattern details should be displayed", () => {
  cy.contains('Pattern Information ').click()
  createPattern.patternInformationVisible()
  cy.get('app-token-tooltip>ul>li>span.pt-token-label').eq(0).invoke('text').should('eq',Cypress.env("PatternName"))
  createPattern.patternInfo().eq(1).invoke('text').should('eq','EventLog')
  // createPattern.patternInfo().eq(2).invoke('text').should('eq','SystemParameters')
  // createPattern.patternInfo().eq(3).invoke('text').should('eq','SystemConfiguration')
  // createPattern.patternInfo().eq(4).invoke('text').should('eq','EventLog')
  //cy.get('app-token-tooltip>ul>li>span.pt-token-label').eq(5).invoke('text').should('eq','Raise Alert')
  cy.get("#" +Cypress.env("PatternName") +" > #nav-dropdown-btn > .ng-star-inserted > #Layer_1").click();
  cy.DeletePattern()
  console.log(printTimestamp() ,' Saved pattern details are displayed correctly')
});
