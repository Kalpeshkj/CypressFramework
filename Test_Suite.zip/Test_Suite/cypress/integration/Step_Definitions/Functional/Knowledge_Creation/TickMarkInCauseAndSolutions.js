/// <reference types="Cypress" />
/// <reference types='cypress-tags' />

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';

import CreateKnowledge from "../../../../support/pageObjects/pages/KnowledgeAuthoring/CreateKnowledge";
const createKnowledge = new CreateKnowledge();

When("User expands knowledge and clicks on add knowledge", () => {
    createKnowledge.knowledgeClick()
    createKnowledge.addKnowledgeClick()
    console.log(printTimestamp(), ' Knowledge expanded and add knowledge clicked')
});

Then("User should be navigated to new workflow", () => {
    createKnowledge.knowledgeStepsVisible()
    console.log(printTimestamp(), ' Navigated to new workflow')
});

When("User Clicks on Causes and Solution section", () => {
    createKnowledge.causeAndSolutionSectionClick()
    console.log(printTimestamp(), ' Clicked on cause and solution section')
});

Then("User should be able to upload image or file by drag and drop or browse option", () => {
    createKnowledge.addCauseButtonClick()
    createKnowledge.insertFileButtonClick()
    createKnowledge.browseFileIconClick().attachFile('SampleFile.pdf')
    console.log(printTimestamp(), ' Image uploaded')
});

And("Verifies uploaded image or file in Cause and solution section", () => {
    createKnowledge.uploadedImageVerification()
    console.log(printTimestamp(), ' Details updated in cause and solution')
});

Then("User Click on the tick mark available on the right top of the cause and solution section", () => {
    createKnowledge.cause1TextBoxClickAndType()
    createKnowledge.solution1TextBoxClickAndType()
    createKnowledge.tickMarkIconClick()
    console.log(printTimestamp(), ' Clicked on tick mark available in section')
});

