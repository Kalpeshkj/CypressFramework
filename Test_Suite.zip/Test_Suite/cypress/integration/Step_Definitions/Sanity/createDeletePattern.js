/// <reference types="Cypress" />

/// <reference types = 'cypress-tags' />

import "../../../support/index";
import { When, Then } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../support/commands';
import CreatePattern from "../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
import AssertionConstants from "../../../support/pageObjects/pages/AssertionConstants";
import NavigationPanel from "../../../support/pageObjects/pages/Dashboard/NavigationPanel";
const navigationPanel = new NavigationPanel();
const createPattern = new CreatePattern();
const constants = new AssertionConstants();

When("Click on three vertical dots of My Pattern and Click on Create Pattern option",() => {
    createPattern.myPatternThreeDotsClick()
    createPattern.createPatternVisible()
    createPattern.createPatternClick()
    console.log(printTimestamp(), ' Clicked on three vertical dots of My Pattern and Clicked on Create Pattern option')
  }
);

Then("User should be able to click on My Pattern followed by Create Pattern Authoring_WF1 should be created",() => {
    createPattern.workflowSuccessTextVisible()
    navigationPanel.pushLastWorkflowtoArray()
    cy.wait(3000);
    console.log(printTimestamp(), ' Clicked on My Pattern and CreatePattern And Authoring_WF1 to be created')
  }
);

Then("User should be able to create multiple authoring wf many times on click of create pattern",() => {
    createPattern.myPatternThreeDotsClick()
    createPattern.createPatternVisible()
    createPattern.createPatternClick()
    createPattern.workflowSuccessTextVisible()
    cy.wait(3000)
    navigationPanel.pushLastWorkflowtoArray()
    console.log(printTimestamp(), ' Created multiple authoring wf many times on click of create pattern')
  }
);

When("User Clicks on 3 dots of Authoring WF", () => {
  navigationPanel.scrolltoLastWorkflow()
  createPattern.threeDotsOfAuthoringWorkflow().last().click({ force: true });
  console.log(printTimestamp(), 'Clicked on 3 dots of Authoring WF')
});

Then("Rename and Delete option should be present", () => {
  createPattern.threeDotsOfAuthoringWorkflow().eq(3).click();
  createPattern.renameOptionVisible()
  createPattern.deleteOptionVisible()
  console.log(printTimestamp(), 'Verified Rename and Delete option are present')
});

When("Click on delete button", () => {
  navigationPanel.navigateToLastWorkflowThreeDots()
  cy.DeletePattern()
  console.log(printTimestamp(), ' Clicked on Delete button')
});

Then("Workflow should be deleted", () => {
  createPattern.deleteWorkFlowMessageVisible()
  console.log(printTimestamp(), ' Verified Workflow is deleted')
});

When("User relaunches application", () => {
  createPattern.relaunchApplication();
  console.log(printTimestamp(), 'User relaunched application')
});

Then("Already created Authoring WF should be displayed", () => {
  navigationPanel.scrolltoLastWorkflow()
  navigationPanel.navigateToLastWorkflowThreeDotsAfterDeletion().scrollIntoView().should(constants.beVisibleAssertion);
  navigationPanel.navigateToLastWorkflowThreeDotsAfterDeletion().click();
  cy.DeletePattern()
  console.log(printTimestamp(), 'Verified Already created Authoring WF are displayed')
});

Then("Close The Application", () => {
  cy.log('Test case executed successfully')
  console.log(printTimestamp(), 'Test case executed successfully')
});
