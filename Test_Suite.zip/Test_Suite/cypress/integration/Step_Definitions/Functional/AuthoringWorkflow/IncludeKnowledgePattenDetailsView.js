/// <reference types="Cypress" />
/// <reference types='cypress-tags' />

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';

import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();
import IncludeKnowlegePage from "../../../../support/pageObjects/pages/PatternAuthoring/includeKnowledgepageObj";
const includeKnowlegePage = new IncludeKnowlegePage();
import PatternDashboard from "../../../../support/pageObjects/pages/Dashboard/PatternDashboard";
const patternDashboard = new PatternDashboard();
const filePath = 'cypress/fixtures/patternNameCreation.json'
var arr = [];

When("User clicks on three dots of my pattern", () => {

    console.log(printTimestamp(), ' Three dots clicked')
});

Then("User should be able to add details in create pattern and apply metadata page", () => {
    cy.createPattern()
    createPattern.nextButtonClick()
    cy.wait(4000)
    cy.ApplyMetaDetaPageCompletion()
    console.log(printTimestamp(), ' details added in create pattern and apply metadata page')
});

When("User clicks on Next button from apply metadata page", () => {
    createPattern.nextButtonClick()
    console.log(printTimestamp(), ' Next button clicked')
});

Then("User clicks on show all checkbox or search any keyword", () => {
    includeKnowlegePage.showAllCheckboxClick()
    console.log(printTimestamp(), ' show all checkbox clicked')
});

And("User selects multiple knowledge and clicks on Save as Draft", () => {
    includeKnowlegePage.knowledgeResultsSelection()
    includeKnowlegePage.saveAsDraftButtonClick()
    console.log(printTimestamp(), ' User selected multiple knowledge and clicked on Save as Draft')
});

And("Relaunch DAW application and verifies saved details", () => {
    cy.reload()
    includeKnowlegePage.savedDetailsVerification()
    console.log(printTimestamp(), ' DAW application relaunched')
});

When("User navigate to Pattern Dashboard and clicks on newly created pattern name", () => {
    patternDashboard.myPatternDashboardClick()
    cy.readFile(filePath).then(function (result) {
        var PatternName = result.name;
        patternDashboard.patternNameSearchField().type(PatternName).type('{enter}')
        cy.wait(1000)

    });
    cy.wait(3000)
    patternDashboard.naviagationToNewlyCreatedAuthWFCLick()
    console.log(printTimestamp(), ' User navigated to Pattern Dashboard and clicked on newly created pattern name')
});

Then("Verifies details in Pattern Details and Metadata", () => {
    includeKnowlegePage.savedDetailsVerificationFromDashboardNavigation()
    console.log(printTimestamp(), ' Verified details in Pattern Details and Metadata')
});

When("User clicks on Knowledge section", () => {
    includeKnowlegePage.selectedKnowledge1Click()
    console.log(printTimestamp(), ' Knowledge section clicked')
});

Then("Knowledge title and list of saved knowledge name should be displayed in left side", () => {
    includeKnowlegePage.knowledgeTitleVisible()
    includeKnowlegePage.selectedKnowledgeVisible()
    console.log(printTimestamp(), ' Knowledge title and list of saved knowledge name displayed in left side')
});

And("Knowledge name, collapse expand icons and full screen view icon should be available in right side", () => {
    includeKnowlegePage.selectedKnowledgeVisible()
    includeKnowlegePage.fullscreenViewIconVisible()
    includeKnowlegePage.collapseButtonVisible()
    console.log(printTimestamp(), ' Knowledge name, collapse expand icons and full screen view icon available')
});

And("Verify each section available for knowledge", () => {
    includeKnowlegePage.rightSideSectionVerification()
    console.log(printTimestamp(), ' Verified each section available for knowledge')
});

When("User clicks on full screen icon", () => {
    includeKnowlegePage.fullscreenViewIconInKnowledgeViewClick()
    console.log(printTimestamp(), ' full screen icon clicked')
});

Then("Knowledge name should not be displayed in left side section", () => {
    includeKnowlegePage.selectedKnowledgeNotVisible()
    includeKnowlegePage.fullscreenCollapseIconInKnowledgeViewClick()
    console.log(printTimestamp(), ' Knowledge name not displayed in left side section')
});

And("Other sections should be displayed as it is in from right side section", () => {
    includeKnowlegePage.rightSideSectionVerification()
    console.log(printTimestamp(), ' Other sections displayed as it is')
});

Then("Knowledge name should be displayed in left side section", () => {
    includeKnowlegePage.knowledgeTitleVisible()
    includeKnowlegePage.selectedKnowledgeVisible()
    console.log(printTimestamp(), ' Knowledge name displayed in left side section')
});

And("DAW application closes", () => {
    cy.DeleteDynamicPattern()
    console.log(printTimestamp(), ' Test Case Executed Successfully')
});
