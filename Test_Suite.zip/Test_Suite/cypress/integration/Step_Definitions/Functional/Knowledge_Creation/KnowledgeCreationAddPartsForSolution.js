/// <reference types="Cypress" />
/// <reference types = 'cypress-tags' />    

import "../../../../support/index"
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import CreateKnowledge from "../../../../support/pageObjects/pages/KnowledgeAuthoring/CreateKnowledge";
const createKnowledge = new CreateKnowledge();
import { printTimestamp } from '../../../../support/commands';

When("User Navigate to Newly Created knowledge workflow", () => {
    createKnowledge.knowledgeOptionArrowClick()
    createKnowledge.addKnowledgeWorkflowButtonClick()
    cy.wait(3000)
    console.log(printTimestamp(), 'Navigated to newly created knowledge workflow')
});

And("Add details in Knowledge Information section", () => {
    createKnowledge.knowledgeNameTextBoxType()
    createKnowledge.descriptionFiledTextBoxType()
    console.log(printTimestamp(), 'Added details in Knowledge Information section')
});

And("Expand causes and solutions section and add cause", () => {
    createKnowledge.causeAndSolutionOptionClick()
    createKnowledge.addCauseButtonClick()
    createKnowledge.causeOneInputBoxType()
    console.log(printTimestamp(), 'Expanded causes and solutions section and add cause')
});

And("Click on Add Solution", () => {
    createKnowledge.addSolutionButtonClick()
    console.log(printTimestamp(), 'Clicked on Add Solution')
});

Then("Solution for cause should get added", () => {
    createKnowledge.addedSolutionVisible()
    console.log(printTimestamp(), 'Solution for cause  gets added')
});

When("Click on parts icon", () => {
    createKnowledge.PartsIconClick()
    console.log(printTimestamp(), 'Clicked on parts icon')
});

Then("Add Part pop up should be displayed", () => {
    createKnowledge.addPartPopUpVisible()
    console.log(printTimestamp(), 'Add Part pop up displayed')
});

When("User Add 12NC and Description and click on Add + icon", () => {
    createKnowledge.twelveNCTextBoxTypeSdd()
    createKnowledge.descriptionTextBoxTypebdd()
    createKnowledge.addPlusIconClick()
    console.log(printTimestamp(), 'Added 12NC and Description and clicked on Add + icon')
});

Then("Next row should get added", () => {
    createKnowledge.secondRowTwelveNCTextBoxVisible()
    createKnowledge.secondRowDescriptionTextBoxVisible()
    console.log(printTimestamp(), 'Next row gets added')
});

When("Add All details in second row", () => {
    createKnowledge.partsNameTextBoxSecondRowType()
    createKnowledge.descriptionBoxSecondRoqType()
})

Then("Done button should be enabled", () => {
    createKnowledge.doneButtonEnabled()
    console.log(printTimestamp(), 'Done button enabled')
});

When("User Click on cancel", () => {
    createKnowledge.cancelButtonClick()
    console.log(printTimestamp(), 'Clicked on cancel')
});

Then("Add parts pop up should get closed", () => {
    createKnowledge.addPartPopUpNotExist()
    console.log(printTimestamp(), 'Add parts pop up closed')
});

And("None of parts should get added at solution level", () => {
    createKnowledge.partsInsolutionNotExist()
    console.log(printTimestamp(), 'None of parts added at solution level')
});

When("User Click on add parts icon", () => {
    createKnowledge.PartsIconClick()
    console.log(printTimestamp(), 'Clicked on add parts icon')
});

Then("None of parts data should be displayed in add parts pop up", () => {
    createKnowledge.partsNameTextBoxFirstRowEmpty()
    console.log(printTimestamp(), 'None of parts data displayed in add parts pop up')
});

When("User Add multiple parts by clicking on Add + icon And Add 12NC and Description details", () => {
    createKnowledge.twelveNCTextBoxTypeSdd()
    createKnowledge.descriptionTextBoxTypebdd()
    createKnowledge.addPlusIconClick()
    createKnowledge.partsNameTextBoxSecondRowType()
    createKnowledge.descriptionBoxSecondRoqType()
    createKnowledge.addPlusIconClick()
    createKnowledge.partsNameTextBoxThirdRowType()
    createKnowledge.descriptionBoxThirdRowType()
    createKnowledge.addPlusIconClick()
    createKnowledge.partsNameTextBoxFourthRowType()
    createKnowledge.descriptionBoxFourthRowType()
    console.log(printTimestamp(), 'Added multiple parts by clicking on Add + icon And Add 12NC and Description details')
});

And("Click on Remove X icon for few of parts data", () => {
    createKnowledge.removeIconFourthClick()
    createKnowledge.removeIconThirdClick()
    console.log(printTimestamp(), 'Clicked on Remove X icon for few of parts data')
});

Then("Added parts data should get removed from pop up", () => {
    createKnowledge.screwsRemovedFromAddPartPopUp()
    createKnowledge.nutRemovedFromAddPartPopUp()
    console.log(printTimestamp(), 'Added parts data removed from pop up')
});

When("User Click on Done button", () => {
    createKnowledge.doneButtonClickInPopUpClick()
    console.log(printTimestamp(), 'Clicked on Done button')
});

Then("All added parts should get added as removable token at solution level inline with parts icon", () => {
    createKnowledge.firstAddedPartsAtSolutionLevelvisible()
    createKnowledge.secondAddedPartsAtSolutionLevelvisible()
    console.log(printTimestamp(), 'All added parts gets added as removable token at solution level inline with parts icon')
});

// When("User Hover on parts name 12NC", () => {

//     console.log(printTimestamp() ,'User Hovered on parts name 12NC')
// });

// Then("Parts description should be displayed in tooltip Description as title Added description data", () => {

//     console.log(printTimestamp() ,'Parts description displayed in tooltip Description as title Added description data')
// });

When("User Click on Remove icon from token", () => {
    createKnowledge.removeIconForBoltspartInTokenClick()
    console.log(printTimestamp(), 'User Clicked on Remove icon from token')
});

Then("Parts should get removed from token", () => {
    createKnowledge.boltsPartInTokenNotExist()
    console.log(printTimestamp(), 'Parts get removed from token')
});

When("User Click on parts icon", () => {
    createKnowledge.PartsIconClick()
    console.log(printTimestamp(), 'Clicked on parts icon')
});

Then("Add Parts pop up should be displayed", () => {
    createKnowledge.addPartPopUpVisible()
    console.log(printTimestamp(), 'Add Parts pop up displayed')
});

And("Removed parts from token should not be available in pop up", () => {
    createKnowledge.boltsPartInAddPartPopUpNotExist()
    console.log(printTimestamp(), 'Removed parts from token not be available in pop up')
});

And("Already available as token parts data should be displayed in pop up", () => {
    createKnowledge.partsInPartsPopUp()
    console.log(printTimestamp(), 'Already available as token parts data displayed in pop up')
});

And("Done button should be displayed in enabled state until any changes made in Add Parts pop up", () => {
    createKnowledge.doneButtonEnabled()
    createKnowledge.cancelButtonClick()
    console.log(printTimestamp(), 'Done button displayed in enabled state until any changes made in Add Parts pop up')
});
