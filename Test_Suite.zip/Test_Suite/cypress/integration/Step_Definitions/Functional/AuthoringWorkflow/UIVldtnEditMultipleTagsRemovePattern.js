/// <reference types="Cypress" />
/// <reference types = 'cypress-tags' /> 

import "../../../../support/index"
import {When, Then, And } from "cypress-cucumber-preprocessor/steps"
import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();
import CreateKnowledge from "../../../../support/pageObjects/pages/KnowledgeAuthoring/CreateKnowledge";
const createKnowledge = new CreateKnowledge();
import {printTimestamp} from '../../../../support/commands';

When("User Clicks on 3 dots present next to Patterns tab in Navigation Panel", () => {
    cy.CreatePatternsTillValidateStageCompletion(1)
    cy.visit(Cypress.env("DAWAutomationURL"));
    cy.wait(2000)
    createPattern.clearAllFiltersButtonClick()
    createPattern.patternNameTypeInSearchFilter()
    cy.wait(2000)
    createPattern.selectAllRecordClickInDashboard()
    createPattern.publishButtonClick()
    createPattern.withdrawButtonVisibleAsEnabled()
    console.log(printTimestamp(), ' Clicked on the 3 dots present next to Patterns tab in Navigation Panel')
});

Then("Edit Tag Association options should be present", () => {
    cy.visit('https://daw-bulk-edit-db.eu-west.philips-healthsuite.com/home')
	createPattern.patternTabThreeDotsClick()
	createPattern.editTagAssociationsVisible()
    console.log(printTimestamp(), ' Edit Tag Association option present')
});

When("User Click on Edit Tag Association", () => {
	createPattern.seditTagAssociationsClick()
    cy.wait(5000)
    console.log(printTimestamp(), ' Clicked on Edit Tag Association')
});

Then("A New Workflow should be created with header as Tag Associations", () => {
    cy.wait(3000)
	createPattern.NewPatternCreatedVisible()
    console.log(printTimestamp(), ' New Workflow created with header as Tag Associations')
});

When("User Clicks any of the metadata Tag present", () => {
    createPattern.tagsFieldClick()
    console.log(printTimestamp(), ' Clicked on any of the metadata Tag present')
});

Then("Verifies the Columns present in the edit section", () => {
	createPattern.bulkStepNextClick()
    cy.wait(3000)
    createPattern.patternNameColumnVisible()
	createPattern.versionColumnVisible()
    console.log(printTimestamp(), ' Verified the Columns present in the edit section')
});

Then("Validates the buttons present in the pages", () => {
	createPattern.updateButtonVisible()
    createPattern.removeButtonVisible()
	createPattern.addButtonVisible()
    createPattern.closeButtonInsidePatternVisible()
    createPattern.saveAsDraftButtonInsidePatternVisible()
    createPattern.previousButtonInsidePatternVisible()
    console.log(printTimestamp(), ' Validated the buttons present in the pages')
});

When("User Selects single pattern name", () => {
	createPattern.patternNameTypeInSearchFilter()
    console.log(printTimestamp(), ' Selected single pattern name')
});

Then("Clicks on the row of any of the pattern", () => {
    createPattern.selectAllRecords()
    createKnowledge.breadcumbCaptureValue()
    console.log(printTimestamp(), ' Clicked on the row of any of the pattern')
});

Then("Clicks on remove button", () => {
	createPattern.removeButtonClick()
    console.log(printTimestamp(), ' Clicked on remove button')
});

And("Clicks on cancel Button", () => {
	createPattern.closeButtonInsidePatternClick()
    console.log(printTimestamp(), ' Clicked on cancel button')
});

Then("Clicks on the OK button", () => {
	createPattern.okButtonClick()
    cy.wait(5000)
    console.log(printTimestamp(), ' Clicked on the OK button')
});

Then("Repeat removal step and click on save as draft button", () => {
	createPattern.newlyCreatedPatternNavigation()
    createPattern.tagsFieldClick()
    createPattern.bulkStepNextClick()
    cy.wait(3000)
    createPattern.patternNameTypeInSearchFilter()
    createPattern.selectAllRecords()
    createPattern.removeButtonClick()
    cy.wait(3000)
	createPattern.saveAsDraftButtonInsidePatternClick()
    console.log(printTimestamp(), ' Repeated removal step and clicked on save as draft button')
});

And("Clicks on full screen on the Tag details row", () => {
	createPattern.fullScreenIconClick()
    console.log(printTimestamp(), ' Clicked on full screen on the Tag details row')
});

And("Clicks on full screen next to the details", () => {
	createPattern.collapseScreenIconClick()
    console.log(printTimestamp(), ' Clicked on full screen next to the details')
});

Then("Clicks on the workflow delete button", () => {
    cy.DeleteDynamicPattern()
    cy.wait(3000)
    cy.visit(Cypress.env("DAWAutomationURL"));
    cy.wait(3000)
    createPattern.clearAllFiltersButtonClick()
	createPattern.patternNameTypeInSearchFilter()
    cy.wait(2000)
    createPattern.selectAllRecordClickInDashboard()
    createPattern.withdrawButtonVisibleAsDisabled()
    createPattern.deletePatternButtonInDashboardClick()
    createPattern.okButtonClick()
    console.log(printTimestamp(), ' Clicked on the workflow delete button')
});