/// <reference types="Cypress" />
/// <reference types='cypress-tags' />

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();

When("User Clicks on vertical three dots of My Patterns", () => {
    createPattern.myPatternThreeDotsClick();
    console.log(printTimestamp(), ' Clicked on vertical three dots of My Patterns')
});

Then('User Clicks on Create Pattern', () => { 
    createPattern.createPatternClick();
    console.log(printTimestamp(), ' Clicked on Create Pattern')
});

Then("Verifies created Authoring Workflow", () => {
    cy.wait(2000)
    createPattern.breadcumbLastValueCapture();
    console.log(printTimestamp(), ' Verified available options')
});

When("User Click on vertical three dots Authoring WF", () => {
    createPattern.NewPatternCreatedThreeDotsClick();
    console.log(printTimestamp(), ' Clicked on vertical three dots Authoring WF')
});

Then("Verifies Delete and Rename buttons should be visible", () => {
    createPattern.NewPatternCreatedThreeDotsClickAndItsAvailableButtonsVerification();
    console.log(printTimestamp(), ' Verified Delete and Rename buttons visible')
});
 
Then("Enters Pattern name and description in Pattern information", () => {
    createPattern.patternNameType();
    createPattern.descriptionType();
    console.log(printTimestamp(), ' Entered Pattern Name and Description in pattern information')
});

When("User Enters all details available in create Pattern", () => {
    createPattern.importDataModelAction();
    createPattern.addConditionInPattern();
    createPattern.addAction();
    console.log(printTimestamp(), ' Entered all details available in create Pattern page except Order of execution')
});

Then('Clicks on Save as draft button', () => {
    createPattern.SaveAsDraftClick();
    console.log(printTimestamp(), ' Clicked on Save as draft button')
});

When("User Click on Authoring WF and Select Rename option", () => {
    cy.wait(3000)
    createPattern.breadcumbLastValueCapture()
    createPattern.NewPatternThreeDotsClick();
    createPattern.renameOptionClick();
    console.log(printTimestamp(), ' Clicked on Authoring WF and Selected Rename option')
});

Then('"Workflow Renamed Successfully" toast message should displayed after renaming the WF', () => {
    createPattern.renameTextBoxType();
    createPattern.renamedPopUptextVisible();
    console.log(printTimestamp(), ' "Workflow Renamed Successfully" toast message should displayed')
});

And("Verifies max length for Authoring WF name that should be 250 characters only", () => {
    createPattern.NewPatternThreeDotsClick();
    createPattern.renameOptionClick();
    cy.PatternNameWithInvalidLength()
    createPattern.renameInvalidValueType();
    console.log(printTimestamp(), ' Verified max length for Authoring WF')
});

Then("User relaunches the application", () => {
    cy.reload()
    console.log(printTimestamp(), ' Relaunched application')
});

And("Clicks on My Pattern section", () => {
    cy.wait(2000)
    console.log(printTimestamp(), ' Clicked on My Pattern section')
});

Then("Verifies updated Authoring WF and Available content should be available", () => {
    createPattern.patternNameVisible();
    createPattern.descriptionVisible();
    console.log(printTimestamp(), ' Verified updated Authoring WF and Available content')
});

When("User Click on three vertical dots of Authoring WF and Select Delete option", () => {
    createPattern.NewPatternThreeDotsClick();
    createPattern.deleteOptionClick();
    console.log(printTimestamp(), ' Clicked on three vertical dots of Authoring WF and Selected Delete option')
});

Then("Confirmation pop up should be displayed with delete icon and Are you sure you want to delete this workflow? text", () => {
    createPattern.deleteWFTextVisible();
    createPattern.deleteWFBodyTextVisible()
    console.log(printTimestamp(), ' Confirmation pop up displayed')
});

And("Cancel and Delete button also displayed", () => {
    createPattern.cancelButtonInDeleteWFPopupVisible();
    createPattern.deleteButtonInDeleteWFPopupVisible();
    console.log(printTimestamp(), ' Cancel and Delete button displayed')
});

Then("Verifies Workflow Name in Confirmation pop up", () => {
    createPattern.deleteWFBodyTextVisible()
    console.log(printTimestamp(), ' Verified Workflow Name in Confirmation pop up')
});

And("Clicks on Cancel button", () => {
    createPattern.cancelButtonInDeleteWFPopupClick();
    console.log(printTimestamp(), ' Clicked on Cancel button')
});

And("Verifies that Authoring Workflow should be available in UI", () => {
    createPattern.NewPatternCreatedVisible();
    console.log(printTimestamp(), ' Verified Authoring Workflow available in UI')
});

Then("Clicks on Delete button", () => {
    createPattern.NewPatternThreeDotsClick();
    createPattern.deleteOptionClick();
    createPattern.okButtonClick()
    console.log(printTimestamp(), ' Clicked on Delete button')
});

And("Verifies deleted Authoring WF should not present in left pane", () => {
    createPattern.NewPatternCreatedNotVisible();
    console.log(printTimestamp(), ' Verified deleted Authoring WF not present in left pane')
});