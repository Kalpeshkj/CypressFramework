/// <reference types="Cypress" />
/// <reference types='cypress-tags' />

import "../../../../support/index";
import {When, Then, And} from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import AssertionConstants from "../../../../support/pageObjects/pages/AssertionConstants"
const assertionConstants = new AssertionConstants();
import PatternDashboard from "../../../../support/pageObjects/pages/Dashboard/PatternDashboard";
const patternDashboard = new PatternDashboard();

When("By default pattern dashboard page is displayed", () => {
  patternDashboard.dashboardButtonVisible();
  patternDashboard.recordsVerificationBeforeClearFilter()
  console.log(printTimestamp(), ' Pattern dashboard page displayed')
});

Then("Close Application", () => {
  cy.log("Test case executed successfully");
  console.log(printTimestamp(), ' Test case executed successfully')
});

When("User clicks on Clear All Filter", () => {
    patternDashboard.clearFiltersClick();
    console.log(printTimestamp(), ' Clear All Filter clicked')
});

Then("All Filter should get removed and all data should be displayed", () => {
    patternDashboard.recordsVerificationAfterClearFilter()
    console.log(printTimestamp(), ' All Filter got removed')
});

When("User clicks on drop down of column configuration", () => {
    patternDashboard.columnConfigurationDropdownClick();
    console.log(printTimestamp(), ' Clicked on column configuration')
}); 

Then("User should be able to select all columns available in drop down", () => {
    patternDashboard.selectDropdownValues();
    console.log(printTimestamp(), ' selected all columns available')
});

When("User clicks on each columns and Check boxes for filter, search text box with search icon, clear and apply button should be visible",() => {
    patternDashboard.columnFilters().eq(0).click().then(()=>{
    patternDashboard.columnFilters().eq(0).click()
    patternDashboard.filtersCheckboxes().each(($el) => {
        cy.wrap($el).scrollIntoView().should(assertionConstants.beExistAssertion)
    })
    patternDashboard.filtersValues().each(($el) => {
        cy.wrap($el).scrollIntoView().should(assertionConstants.beVisibleAssertion)
    })
    patternDashboard.searchTextBox().each(($el) => {
        cy.wrap($el).scrollIntoView().should(assertionConstants.beVisibleAssertion)
    })
    patternDashboard.clearFilterButton().each(($el) => {
        cy.wrap($el).scrollIntoView().should(assertionConstants.beVisibleAssertion)
    })
    patternDashboard.applyFilterButton().each(($el) => {
        cy.wrap($el).scrollIntoView().should(assertionConstants.beVisibleAssertion)
    })
    })

    patternDashboard.columnFilters().eq(1).click().then(()=>{
    patternDashboard.columnFilters().eq(1).click()
    patternDashboard.filtersCheckboxes().each(($el) => {
        cy.wrap($el).scrollIntoView().should(assertionConstants.beVisibleAssertion)
    })
    patternDashboard.filtersValues().each(($el) => {
        cy.wrap($el).scrollIntoView().should(assertionConstants.beVisibleAssertion)
    })
    patternDashboard.searchTextBox().each(($el) => {
        cy.wrap($el).scrollIntoView().should(assertionConstants.beVisibleAssertion)
    })
    patternDashboard.versionClearButton().each(($el) => {
        cy.wrap($el).scrollIntoView().should(assertionConstants.beVisibleAssertion)
    })
    patternDashboard.versionApplyButton().each(($el) => {
        cy.wrap($el).scrollIntoView().should(assertionConstants.beVisibleAssertion)
    })
    })

    patternDashboard.columnFilters().eq(3).click().then(()=>{
    patternDashboard.filtersCheckboxes().each(($el) => {
        cy.wrap($el).scrollIntoView().should(assertionConstants.beVisibleAssertion)
    })
    patternDashboard.filtersValues().each(($el) => {
        cy.wrap($el).scrollIntoView().should(assertionConstants.beVisibleAssertion)
    })
    patternDashboard.searchTextBox().each(($el) => {
        cy.wrap($el).scrollIntoView().should(assertionConstants.beVisibleAssertion)
    })
    })

    patternDashboard.columnFilters().eq(4).click().then(()=>{
    patternDashboard.filtersCheckboxes().each(($el) => {
        cy.wrap($el).scrollIntoView().should(assertionConstants.beVisibleAssertion)
    })
    patternDashboard.filtersValues().each(($el) => {
        cy.wrap($el).scrollIntoView().should(assertionConstants.beVisibleAssertion)
    })
    patternDashboard.searchTextBox().each(($el) => {
        cy.wrap($el).scrollIntoView().should(assertionConstants.beVisibleAssertion)
    })
    })

    patternDashboard.columnFilters().eq(5).click().then(()=>{
    patternDashboard.filtersCheckboxes().each(($el) => {
        cy.wrap($el).scrollIntoView().should(assertionConstants.beVisibleAssertion)
    })
    patternDashboard.filtersValues().each(($el) => {
        cy.wrap($el).scrollIntoView().should(assertionConstants.beVisibleAssertion)
    })
    patternDashboard.searchTextBox().each(($el) => {
        cy.wrap($el).scrollIntoView().should(assertionConstants.beVisibleAssertion)
    })
    })

    patternDashboard.columnFilters().eq(6).click().then(()=>{
    patternDashboard.filtersCheckboxes().each(($el) => {
        cy.wrap($el).scrollIntoView().should(assertionConstants.beVisibleAssertion)
    })
    patternDashboard.filtersValues().each(($el) => {
        cy.wrap($el).scrollIntoView().should(assertionConstants.beVisibleAssertion)
    })
    patternDashboard.searchTextBox().each(($el) => {
        cy.wrap($el).scrollIntoView().should(assertionConstants.beVisibleAssertion)
    })
    })

    patternDashboard.columnFilters().eq(7).click().then(()=>{
    patternDashboard.filtersCheckboxes().each(($el) => {
        cy.wrap($el).scrollIntoView().should(assertionConstants.beVisibleAssertion)
    })
    patternDashboard.filtersValues().each(($el) => {
        cy.wrap($el).scrollIntoView().should(assertionConstants.beVisibleAssertion)
    })
    patternDashboard.searchTextBox().each(($el) => {
        cy.wrap($el).scrollIntoView().should(assertionConstants.beVisibleAssertion)
    })
    })
    console.log(printTimestamp(), ' Verified buttons and filter checkboxes')
});

When("User Enter invalid value in search box of filter pop up", () => {
    patternDashboard.searchTextBoxInvalidTextType();
    console.log(printTimestamp(), ' Enter invalid value in search box')
});

Then("None of filter value should be displayed", () => {
    patternDashboard.filtersCheckboxesNotExistVerification();
    console.log(printTimestamp(), ' None of filter value displayed')
});

And("User should be able to remove filter value by clicking on clear button", () => {
    patternDashboard.severityClearButtonClick();
    console.log(printTimestamp(), ' clear button clicked')
});

When("User Enter valid value in search box of filter pop up", () => {
    patternDashboard.searchTextBoxValidTextTypeinTagsColumn();
    console.log(printTimestamp(), ' Entered valid value for in search box')
});

Then("Searched data should be available in drop down", () => {
    patternDashboard.filtersCheckboxesVisible();
    console.log(printTimestamp(), ' Searched data is available')
});

And("Selects one or multiple values from drop down", () => {
    patternDashboard.clearFiltersClick();
    patternDashboard.selectMultipleCheckboxes()
    console.log(printTimestamp(), ' Selected one or multiple values')
});

And("Data count should get updated as per filtered data", () => {
    patternDashboard.recordsVerificationAfterClearFilter();
    console.log(printTimestamp(), ' Data count get updated')
});

When("User clicks on any other column and Selects one or multiple values from drop down", () => {
    console.log(printTimestamp(), ' clicked on any other column and Selected one or multiple values from drop down')
});

Then("Data count should get updated as per filtered data", () => {
    patternDashboard.recordsVerificationAfterClearFilter();
    console.log(printTimestamp(), ' Data count got updated')
});

And("Repeats all above steps in my pattern dashboard", () => {
    patternDashboard.myPatternClick();
    patternDashboard.myPatternDashboardButtonClick();
    patternDashboard.clearFiltersClick();
    patternDashboard.patternDropdownClick();
    patternDashboard.selectDropdownValues();
    patternDashboard.columnFilters().eq(0).click().then(()=>{
        patternDashboard.filtersCheckboxes().each(($el) => {
            cy.wrap($el).scrollIntoView().should(assertionConstants.beVisibleAssertion)
        })
        patternDashboard.filtersValues().each(($el) => {
            cy.wrap($el).scrollIntoView().should(assertionConstants.beVisibleAssertion)
        })
        patternDashboard.searchTextBox().each(($el) => {
            cy.wrap($el).scrollIntoView().should(assertionConstants.beVisibleAssertion)
        })
        patternDashboard.clearFilterButton().each(($el) => {
            cy.wrap($el).scrollIntoView().should(assertionConstants.beVisibleAssertion)
        })
        patternDashboard.applyFilterButton().each(($el) => {
            cy.wrap($el).scrollIntoView().should(assertionConstants.beVisibleAssertion)
        })
        })
    
        patternDashboard.columnFilters().eq(1).click().then(()=>{
        patternDashboard.filtersCheckboxes().each(($el) => {
            cy.wrap($el).scrollIntoView().should(assertionConstants.beVisibleAssertion)
        })
        patternDashboard.filtersValues().each(($el) => {
            cy.wrap($el).scrollIntoView().should(assertionConstants.beVisibleAssertion)
        })
        patternDashboard.searchTextBox().each(($el) => {
            cy.wrap($el).scrollIntoView().should(assertionConstants.beVisibleAssertion)
        })
        patternDashboard.versionClearButton().each(($el) => {
            cy.wrap($el).scrollIntoView().should(assertionConstants.beVisibleAssertion)
        })
        patternDashboard.versionApplyButton().each(($el) => {
            cy.wrap($el).scrollIntoView().should(assertionConstants.beVisibleAssertion)
        })
        })
    
        patternDashboard.columnFilters().eq(3).click().then(()=>{
        patternDashboard.filtersCheckboxes().each(($el) => {
            cy.wrap($el).scrollIntoView().should(assertionConstants.beVisibleAssertion)
        })
        patternDashboard.filtersValues().each(($el) => {
            cy.wrap($el).scrollIntoView().should(assertionConstants.beVisibleAssertion)
        })
        patternDashboard.searchTextBox().each(($el) => {
            cy.wrap($el).scrollIntoView().should(assertionConstants.beVisibleAssertion)
        })
        })
    
        patternDashboard.columnFilters().eq(4).click().then(()=>{
        patternDashboard.filtersCheckboxes().each(($el) => {
            cy.wrap($el).scrollIntoView().should(assertionConstants.beVisibleAssertion)
        })
        patternDashboard.filtersValues().each(($el) => {
            cy.wrap($el).scrollIntoView().should(assertionConstants.beVisibleAssertion)
        })
        patternDashboard.searchTextBox().each(($el) => {
            cy.wrap($el).scrollIntoView().should(assertionConstants.beVisibleAssertion)
        })
        })
    
        patternDashboard.columnFilters().eq(5).click().then(()=>{
        patternDashboard.filtersCheckboxes().each(($el) => {
            cy.wrap($el).scrollIntoView().should(assertionConstants.beVisibleAssertion)
        })
        patternDashboard.filtersValues().each(($el) => {
            cy.wrap($el).scrollIntoView().should(assertionConstants.beVisibleAssertion)
        })
        patternDashboard.searchTextBox().each(($el) => {
            cy.wrap($el).scrollIntoView().should(assertionConstants.beVisibleAssertion)
        })
        })
    
        patternDashboard.columnFilters().eq(6).click().then(()=>{
        patternDashboard.filtersCheckboxes().each(($el) => {
            cy.wrap($el).scrollIntoView().should(assertionConstants.beVisibleAssertion)
        })
        patternDashboard.filtersValues().each(($el) => {
            cy.wrap($el).scrollIntoView().should(assertionConstants.beVisibleAssertion)
        })
        patternDashboard.searchTextBox().each(($el) => {
            cy.wrap($el).scrollIntoView().should(assertionConstants.beVisibleAssertion)
        })
        })
    
        patternDashboard.columnFilters().eq(7).click().then(()=>{
        patternDashboard.filtersCheckboxes().each(($el) => {
            cy.wrap($el).scrollIntoView().should(assertionConstants.beVisibleAssertion)
        })
        patternDashboard.filtersValues().each(($el) => {
            cy.wrap($el).scrollIntoView().should(assertionConstants.beVisibleAssertion)
        })
        patternDashboard.searchTextBox().each(($el) => {
            cy.wrap($el).scrollIntoView().should(assertionConstants.beVisibleAssertion)
        })
        })
    patternDashboard.searchTextBoxInvalidTextType();
    patternDashboard.filtersCheckboxesNotExistVerification();
    patternDashboard.severityClearButtonClick();
    patternDashboard.searchTextBoxValidTextTypeinTagsColumn();
    patternDashboard.TagsClearButtonClick();
    patternDashboard.selectMultipleCheckboxes()
    console.log(printTimestamp(), ' steps repeated in my pattern dashboard')
});
