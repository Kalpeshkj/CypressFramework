/// <reference types="Cypress" />  
/// <reference types = 'cypress-tags' />    

import "../../../../support/index"
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';

import IncludeKnowledge from "../../../../support/pageObjects/pages/PatternAuthoring/includeKnowledgepageObj";
const includeKnowledge = new IncludeKnowledge();

When("Navigate to existing wf, fill details in create pattern and apply metadata page and click on next", () => {
    cy.createPattern()
    cy.get('#pat-step-next > .pt-layout-container > span').click()
    cy.wait(5000)
    cy.ApplyMetaDetaPageCompletion()
    cy.get('#pat-step-next > .pt-layout-container > span').click({ force: true })
    cy.wait(5000)
    console.log(printTimestamp(), 'Navigated to existing wf, filled details in create pattern and apply metadata page and clicked on next')
});

Then("User should be able to navigate to Include Knowledge step", () => {
    includeKnowledge.includeKnowledgePageVisible()
    console.log(printTimestamp(), 'User navigated to Include Knowledge step')
});

When("User Click on show all checkbox", () => {
    includeKnowledge.showAllCheckboxClick()
    console.log(printTimestamp(), 'Clicked on show all checkbox')
});

Then("Data should be displayed in grid", () => {
    includeKnowledge.dataInGridVisible()
    console.log(printTimestamp(), 'Data displayed in grid')
});

When("User Click on any knowledge name", () => {
    includeKnowledge.firstKnowledgwSelect()
    cy.wait(2000)
    console.log(printTimestamp(), 'Clicked on any knowledge name')
});

Then("Knowledge details for selected knowledge should be displayed in right section", () => {
    includeKnowledge.knowledgeDescriptionVisible()
    includeKnowledge.knowledgeSymptomVisible()
    includeKnowledge.knowledgeCauseAndSolutionVisible()
    includeKnowledge.knowledgeTagsVisible()
    console.log(printTimestamp(), 'Knowledge details for selected knowledge displayed in right section')

});

And("Knowledge Name should be displayed in line with full screen view", () => {
    includeKnowledge.knowledgeNameInIncludeTabRightSectionVisible()
    console.log(printTimestamp(), 'Knowledge Name displayed in line with full screen view')
});

And("By default, Description accordion should be displayed in expanded state Accordions for Symptoms, Cause and Solutions and Tags should be available in expanded state", () => {
    includeKnowledge.descriptionAccordionsExpanded()
    includeKnowledge.symptomsAccordionsExpanded()
    includeKnowledge.causeAndSoultionAccordionsExpanded()
    includeKnowledge.tagsAccordionsExpanded()
    console.log(printTimestamp(), 'By default, Description accordion displayed in expanded state Accordions for Symptoms, Cause and Solutions and Tags available in expanded state')

});

When("User Click on collapse icon of Description", () => {
    includeKnowledge.collapsableAndExpandableIconOfDescriptionInIncludeTabClick()
    cy.wait(2000)
    console.log(printTimestamp(), 'Clicked on collapse icon of Description')
});

Then("Description accordion should get collapsed Description header should be displayed when accordion is collapsed", () => {
    includeKnowledge.descriptionAccordionsCollapsed()
    console.log(printTimestamp(), 'Description accordion gets collapsed Description header displayed when accordion is collapsed')

});

When("User Click on expand icon of Description", () => {
    includeKnowledge.collapsableAndExpandableIconOfDescriptionInIncludeTabClick()
    cy.wait(3000)
    console.log(printTimestamp(), 'Clicked on expand icon of Description')
});

Then("Description accordion should get expanded Description details should be displayed", () => {
    includeKnowledge.descriptionDetailsVisible()
    console.log(printTimestamp(), 'Description accordion gets expanded Description details displayed')
});

When("When any accordions is collapsed", () => {
    includeKnowledge.collapsableAndExpandableIconOfCauseAndSolutionInIncludeTabClick()
    cy.wait(2000)
    console.log(printTimestamp(), 'accordions is collapsed')
});

Then("For Description:Description,For Symptoms: Symptoms,For Cause and Solution: Causes and Solutions,For Tags: Tags displayed", () => {
    includeKnowledge.knowledgeCauseAndSolutionDetailsvisible()
    console.log(printTimestamp(), 'For Description:Description,For Symptoms: Symptoms,For Cause and Solution: Causes and Solutions,For Tags: Tags displayed')

});

When("When any accordions is expanded", () => {
    includeKnowledge.collapsableAndExpandableIconOfCauseAndSolutionInIncludeTabClick()
    cy.wait(2000)
    console.log(printTimestamp(), 'accordions is expanded')
});

Then("details for respective section should be displayed", () => {
    includeKnowledge.detailsOfCauseAndSolutionInIncludeTabVisible()
    console.log(printTimestamp(), 'details for respective section displayed')
});

And("At a time, multiple all accordion can be available in expanded-collapsible state", () => {
    includeKnowledge.collapsableAndExpandableIconOfDescriptionInIncludeTabClick()
    cy.wait(2000)
    includeKnowledge.collapsableAndExpandableIconOfCauseAndSolutionInIncludeTabClick()
    cy.wait(2000)
    includeKnowledge.collapsableAndExpandableIconOfDescriptionInIncludeTabClick()
    cy.wait(2000)
    includeKnowledge.collapsableAndExpandableIconOfCauseAndSolutionInIncludeTabClick()
    cy.wait(2000)

    console.log(printTimestamp(), 'At a time, multiple all accordion available in expanded-collapsible state')
});

When("User Select multiple knowledge name and navigate to Review Tab", () => {
    includeKnowledge.secondKnowledgwSelect()
    includeKnowledge.reviewTabClick()
    console.log(printTimestamp(), 'Selects multiple knowledge name and navigate to Review Tab')
});

Then("Number of selected knowledge count should be displayed in Review tab", () => {
    includeKnowledge.reviewTabWithKnowledgeCountVisible()
    console.log(printTimestamp(), 'Number of selected knowledge count displayed in Review tab')
});

And("Knowledge Name as header should be displayed,All selected knowledge name should be listed in left side with X mark", () => {
    includeKnowledge.knowledgeNameHeaderVisible()
    console.log(printTimestamp(), 'Knowledge Name as header displayed,All selected knowledge name listed in left side with X mark')

});

And("By default, first knowledge should be available in selected state and details should be displayed in right side section", () => {
    includeKnowledge.selectedFirstKnowledge()
    includeKnowledge.selectedKnowledgeDetailsVisible()
    console.log(printTimestamp(), 'By default, first knowledge available in selected state and details displayed in right side section')

});

And("Based on selection in Include tab , order of knowledge should be displayed in review tab", () => {
    includeKnowledge.KnowledgeText()
    includeKnowledge.orderOfKnowledges()
    console.log(printTimestamp(), ' Based on selection in Include tab , order of knowledge displayed in review tab')
});

And("Knowledge Name should be display in line with full screen view", () => {
    includeKnowledge.knowledgeNameInReviewTabRightSectionVisible()
    console.log(printTimestamp(), 'Knowledge Name display in line with full screen view')
});

And("By default, Description accordion should be displayed in expanded state", () => {
    includeKnowledge.descriptionAccordionsInReviewtabExpanded()
    console.log(printTimestamp(), 'By default, Description accordion displayed in expanded state')
});

And("Accordions for Symptoms, Cause and Solutions and Tags should be available in expanded state", () => {
    includeKnowledge.symptomsAccordionsInReviewtabExpanded()
    includeKnowledge.causeAndSoultionAccordionsInReviewtabExpanded()
    includeKnowledge.tagsAccordionsInReviewtabExpanded()
    console.log(printTimestamp(), 'Accordions for Symptoms, Cause and Solutions and Tags available in expanded state')
});

When("When any accordion is collapsed", () => {
    includeKnowledge.collapsableAndExpandableIconInReviewTabClick()
    cy.wait(2000)
    console.log(printTimestamp(), 'any accordion is collapsed')
});

Then("For Description:Description,and For Symptoms: Symptoms,For Cause and Solution: Causes and Solutions,For Tags: Tags displayed", () => {
    includeKnowledge.knowledgeDescriptionInrewviewTabVisible()
    console.log(printTimestamp(), 'For Description:Description,and For Symptoms: Symptoms,For Cause and Solution: Causes and Solutions,For Tags: Tags displayed')
});

When("When any accordion is expanded", () => {
    includeKnowledge.collapsableAndExpandableIconInReviewTabClick()
    cy.wait(2000)
    console.log(printTimestamp(), 'any accordion is expanded')
});

Then("details for respective sections should be displayed", () => {
    includeKnowledge.descriptionDetailsVisible()
    console.log(printTimestamp(), 'details for respective sections displayed')
});

When("Click on X mark of any knowledge", () => {
    includeKnowledge.crossMarkOfFirstKnowaledgeClick()
    cy.wait(2000)
    console.log(printTimestamp(), 'Clicked on X mark of any knowledge')
});

Then("Knowledge should get removed from Review tab Count should get updated", () => {
    includeKnowledge.reviewTabWithUpdatedKnowledgeCountVisible()
    console.log(printTimestamp(), 'Knowledge gets removed from Review tab Count gets updated')
});

When("User Navigate to Include tab and verify removed knowledge from review tab", () => {
    includeKnowledge.includeTabClick()
    console.log(printTimestamp(), 'User Navigated to Include tab and verified removed knowledge from review tab')
});

Then("Removed knowledge should be available in unselected state", () => {
    includeKnowledge.removedKnowledgeUnselected()
    console.log(printTimestamp(), 'Removed knowledge available in unselected state')
});

When("Click on Full screen icon in Include tab available for right side section", () => {
    includeKnowledge.fullScreenButtonInIncludeTabClick()
    console.log(printTimestamp(), 'Clicked on Full screen icon in Include tab available for right side section')
});

Then("Right side section should be available in full screen view by covering left side section", () => {
    includeKnowledge.rightSectionInFullScreenView()
    console.log(printTimestamp(), 'Right side section available in full screen view by covering left side section')
})

And("Left pane, buttons, tabs Include, Review and workflow steps should be displayed", () => {
    includeKnowledge.leftPaneVisible()
    includeKnowledge.includeTabVisible()
    includeKnowledge.reviewTabWithUpdatedKnowledgeCountVisible()
    console.log(printTimestamp(), 'Left pane, buttons, tabs Include, Review and workflow steps displayed')
});

When("User Click on Full screen icon available in line with pattern name", () => {
    includeKnowledge.fullScreenViewButtonAtPatternLevelClick()
    console.log(printTimestamp(), 'Clicked on Full screen icon available in line with pattern name')
});

Then("Full screen view should be displayed Left pane should get collapsed", () => {
    includeKnowledge.leftPaneCollapsed()
    console.log(printTimestamp(), 'Full screen view displayed Left pane should gets collapsed')
});

When("Click on Full screen icon available in line with pattern name", () => {
    includeKnowledge.fullScreenViewButtonAtPatternLevelClick()
    console.log(printTimestamp(), 'Clicked on Full screen icon available in line with pattern name')
});

Then("Right side section should be available in full screen view by covering left side section", () => {
    includeKnowledge.rightSectionInFullScreenView()
    console.log(printTimestamp(), 'Right side section available in full screen view by covering left side section')
});

And("Left pane, buttons, tabs Include, Review and workflow steps should be displayed", () => {
    includeKnowledge.leftPaneVisible()
    includeKnowledge.includeTabVisible()
    includeKnowledge.reviewTabWithUpdatedKnowledgeCountVisible()
    console.log(printTimestamp(), 'Left pane, buttons, tabs Include, Review and workflow steps displayed')
});

When("User Click on Full screen icon in Include tab available for right side section", () => {
    includeKnowledge.fullScreenButtonInIncludeTabClick()
    console.log(printTimestamp(), 'Clicked on Full screen icon in Include tab available for right side section')
});

And("All details should be displayed including search, buttons, workflow step", () => {
    includeKnowledge.previousButtonVisible()
    includeKnowledge.allButtonsVisible()
    includeKnowledge.searchButtonVisible()
    console.log(printTimestamp(), 'All details displayed including search, buttons, workflow step')
});

And("Close DAW application", () => {
    cy.DeleteWorkflow()
    cy.log("Test Case Executed Successfully")
    console.log(printTimestamp(), 'Closed DAW application')
});
