import "../../../../support/index";
import { Then, When, And } from "cypress-cucumber-preprocessor/steps";
import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();
import PatternDashboard from "../../../../support/pageObjects/pages/Dashboard/PatternDashboard";
const patternDashboard = new PatternDashboard();
import KnowledgeDashboard from "../../../../support/pageObjects/pages/Knowledge_Dashboard/KnowledgeDashboard";
const knowledgeDashboard = new KnowledgeDashboard();
import {printTimestamp} from '../../../../support/commands';


When("Clicks on three dots of my pattern", () => { 
    createPattern.myPatternThreeDotsClick()
    console.log(printTimestamp(), ' Clicked on three dots of my pattern')
});

When("User clicks on three dot of My Patterns", () => {
    createPattern.myPatternThreeDotsClick()
    console.log(printTimestamp(), ' Clicked on three dots of my pattern')
});

Then("Create Pattern option is displayed", () => {
    createPattern.createPatternVisible()
    console.log(printTimestamp() ,'Create Pattern option displayed')
});

When("User Click on Create Pattern", () => { 
    createPattern.createPatternButtonClick()
    cy.wait(2000)
    console.log(printTimestamp() ,'Clicked on Create Pattern')
}); 

And("Click on Add  Condition", () => {
    createPattern.addConditionTabClick()
    console.log(printTimestamp(), 'Clicked on Add Condition')
});

Then("Add Condition should get expanded", () => {
	createPattern.expandedAddConditionSectionVerification()
    console.log(printTimestamp(), 'Add Condition gets expanded')
});


Then("Create Pattern option should be displayed and able to open any existing workflow", () => {
    createPattern.createPatternVisible()
    createPattern.createPatternClick()
    console.log(printTimestamp(), ' Create patern displayed and clicked on existing WF')
});

Then("User should be able to create Authoring WF", () => {
    createPattern.createPatternVisible()
    createPattern.createPatternClick()
    console.log(printTimestamp(), ' Authoring WF Created')
});
When("User clicks on Add Condition and Add Condition gets expanded", () => {
    createPattern.addConditionTabVisible()
    createPattern.addConditionTabClick()
    createPattern.expandedAddConditionSectionVerification()
    console.log(printTimestamp(), ' Add Condition Clicked and get expanded')
});

When("User clicks on rule pattern from add condition section", () => {
    createPattern.addConditionTabVisible()
    createPattern.addConditionTabClick()
    createPattern.addConditionPlusIconClick()
    createPattern.fromrulePatternVisible()
    createPattern.fromRulePatternClick()
    console.log(printTimestamp(), ' Clicked on rule pattern')

});

When("User clicks on add tag Hyperlink", () => {
    createPattern.addTagButtonClick()
    console.log(printTimestamp(), ' Add tag huyperlink clicked')
})

Then("Pop-up Window should open with title as Add Tag", () => {
    createPattern.addTagHeadingVisible()
    console.log(printTimestamp(), ' Pop up verified')
})

And("With and without tabs should be visible", () => {
    createPattern.withKeywordSectionVisible()
    createPattern.withoutKeywordSectionVisible()
    console.log(printTimestamp(), ' With and without tabs visible')
})

And("User verifies Done button should be disabled and Cancel button should be enabled", () => {
    createPattern.doneButtonDisabledVerification()
    createPattern.cancelButtononPopUpEnabledVerification()
    console.log(printTimestamp(), ' Done and cancel button present')
})


And('Textbox should be available to search keyword with drop down option and with water mark as "Select Tags"', () => {
    createPattern.searchTextBoxVisibleWithWatermark()
    console.log(printTimestamp(), ' textbox present withwatermark')
})

When("Any tag gets added then Done button should be enabled", () => {
    createPattern.addTagInWithoutKeywordSection()
    createPattern.doneButtonEnabledVerification()
    console.log(printTimestamp(), ' Done button verified as enabled when any tags added')
})

And("Added tag should be available as removable token in added tags section", () => {
    createPattern.removeMarkVerification()
    console.log(printTimestamp(), ' Remove icon present for added tag')
})

And("Added tags should not be available in dropdown, so user cannot add same tags multiple times", () => {
    createPattern.addedTagNotAvailableInDropdownVerification()
    console.log(printTimestamp(), ' Added tag not available in dropdown')
})

Then("Similar Value should not be available in dropdown once its added by users in previous added tag", () => {
    knowledgeDashboard.addedTagNotAvailableInWithoutKeywordDropdownVerification()
    console.log(printTimestamp(), ' Same value verified as not present in dropdown')
})

And("User should be able to add multiple tags and Added tags should not be displayed in Tags dropdown section", () => {
    createPattern.keywordDropdownClick()
    createPattern.operatorDropdownClick()
    createPattern.valueDropdownClick()
    createPattern.addTagPlusIconClick()
    console.log(printTimestamp(), ' Multiple tags added and verified as displayed in both section')
})

And("All tags should get added in Tags section as removable token", () => {
    createPattern.removeMarkVerification()
    console.log(printTimestamp(), ' Tags are present with remve icon')
})

And("Tags should get removed from Tags section of Added Tags", () => {
    createPattern.removeMarkVerification().each(($el) => {
    cy.wrap($el).click()
    });
    console.log(printTimestamp(), ' All tags removed')
})

And("Search textbox with 'Search by Keyword' watermark is available", () => {
    createPattern.searchBoxTestVisible()
    console.log(printTimestamp(), ' "Search by Keyword" text available in search box')
});

When("User enters any keyword or word in common search box", () => {
    createPattern.searchBoxType()
    console.log(printTimestamp(), ' keyword entered in searchbox')
});

Then("Total records found should be displayed as per search", () => {
    createPattern.recordsFoundTextVerification()
    console.log(printTimestamp(), ' Records count displayed')
});

Then("Total count of result should be displayed", () => {
    createPattern.recordsFoundTextVerification()
    console.log(printTimestamp(), ' Total count displayed')
});

When("User clicks on search button", () => {
    createPattern.searchButtonClick()
    console.log(printTimestamp(), ' Clicked search button')
});

Then("Filter result should be available in grid", () => {
    console.log(printTimestamp(), ' Filtered data displayed')
});

And("User should able to select Show All checkbox", () => {
    createPattern.showAllCheckboxClick()
    console.log(printTimestamp(), ' Show all checkbox selected')
});

And("All data should gets displayed", () => {
    createPattern.showAllResultVerification()
    console.log(printTimestamp(), ' All data displayed')
});

And("Searched result should displayed as per content search", () => {
    createPattern.clearSearchBoxType()
    createPattern.searchBoxType()
    cy.wait(2000)
    console.log(printTimestamp(), '  Verified data as per entered text')
});

And("No Data Available should displayed if no records found", () => {
    createPattern.clearSearchBoxType()
    createPattern.searchBoxTypewithInvalidTextSearch()
    createPattern.noDataFoundVerification()
    console.log(printTimestamp(), ' verified data after search')
});

And("Search result should displayed as per content search", () => {
    createPattern.clearSearchBoxType()
    createPattern.searchBoxType()
    cy.wait(2000)
    createPattern.searchedDataFoundVerification()
    console.log(printTimestamp(), '  Verified data as per entered text')
});

And("Common search text box should be available", () => {
    createPattern.searchBoxVisible()
    console.log(printTimestamp(), ' Common search box available')
});

And("Clicks on drop down and verifies ALl, Name, Solution, Description, Associations, Tags are available", () => {
    createPattern.dropdownValuesVerification()
    console.log(printTimestamp(), ' Details verified from dropdown section')
});

When("User select all the columns in the select options", () => {
    patternDashboard.patternDropdownVisible();
    patternDashboard.patternDropdownClick();
    patternDashboard.selectDropdownValues();
    patternDashboard.patternDropdownWithAdditionOfColumnVisible();
    console.log(printTimestamp(),' Selected all the columns from the select options')
  
  });

Then("Close Application", () => {
    cy.log("Test case executed successfully");
    console.log(printTimestamp(), ' Test case executed successfully')
});


And("close DAW application", () => {
    createPattern.cancelButtonClick()
    cy.DeleteWorkflow()
    cy.log("Test Case Executed Successfully")
    console.log(printTimestamp(), ' Test Case Executed Successfully')
});

