/// <reference types="Cypress" />
/// <reference types='cypress-tags' />

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';

import KnowledgeDashboard from "../../../../support/pageObjects/pages/Knowledge_Dashboard/KnowledgeDashboard";
const knowledgeDashboard = new KnowledgeDashboard();
import PatternDashboard from "../../../../support/pageObjects/pages/Dashboard/PatternDashboard";
const patternDashboard = new PatternDashboard();

When("User Navigates to Knowledge Dashboard", () => {
    knowledgeDashboard.knowledgeClick()
    knowledgeDashboard.knowledgeDashboardClick({ force: true })
    cy.wait(2000)
    console.log(printTimestamp(), ' Navigated to knowledge dashboard')
});

When("User clicks on Knowledge name", () => {
    knowledgeDashboard.knowledgeRecordClick()
    console.log(printTimestamp(), ' Knowledge name clicked')
});

Then("Verifies knowledge Details should be displayed in grid", () => {
    knowledgeDashboard.knowledgeDetailsVisible()
    console.log(printTimestamp(), ' Knowledge details verified')
});

And("Verifies < Knowledge name at left corner should displayed", () => {
    knowledgeDashboard.knowledgeNameVisible()
    console.log(printTimestamp(), ' Knowledge name verified at left side corner')
});

And("At right corner Version: Version Value, Draft icon , screen expand icon should be displayed", () => {
    patternDashboard.versionLableExist()
    patternDashboard.versionValueExist()
    knowledgeDashboard.draftIconVisible()
    knowledgeDashboard.screenExpandIconVisible()
    console.log(printTimestamp(), ' Version value and draft icon displayed')
});

And("Description, Symptoms, Tags and Associations section should present", () => {
    knowledgeDashboard.descriptionSectionVisible()
    knowledgeDashboard.AssociationSectionVisible()
    knowledgeDashboard.causeAndSolutionSectionVisible()
    knowledgeDashboard.symptomsSectionVisible()
    knowledgeDashboard.tagSectionVisible()
    console.log(printTimestamp(), ' sections are present')
});

And("Delete and Close buttons are present", () => {
    knowledgeDashboard.deleteButtonVisibleAsDisabled()
    knowledgeDashboard.closeButtonVisibleAsEnabled()
    console.log(printTimestamp(), ' Buttons are present')
});

And("User Verifies all sections are in expanded state and each section present with level icons", () => {
    knowledgeDashboard.descriptionIconAndValueValidation()
    knowledgeDashboard.symptomsIconAndValueValidation()
    knowledgeDashboard.causesAndSolutionValueValidation()
    knowledgeDashboard.tagsValueValidation()
    console.log(printTimestamp(), ' Verified all section and expanded')
});

And("Knowledge name and description should present in knowledge section", () => {
    knowledgeDashboard.knowledgeDetailsVisible()
    knowledgeDashboard.descriptionDetailsVisible()
    console.log(printTimestamp(), ' knowledge name and description present')
});

And("Symptom Name, Description, tags should be present in Symptoms section", () => {
    knowledgeDashboard.symptomNameVisible()
    // knowledgeDashboard.symptomDescriptionVisible()
    // knowledgeDashboard.symptomTagsVisible()
    console.log(printTimestamp(), ' symptom name, description and tags present')
});

And("Cause Name, Description with solution name should be present in cause and solution section", () => {
    knowledgeDashboard.causeAndSolutionNameVisible()
    knowledgeDashboard.causeAndSolutionDescriptionVisible()
    console.log(printTimestamp(), ' Cause name and description present')
});

And("Tags values should present in Tags section", () => {
    knowledgeDashboard.tagsValueValidation()
    console.log(printTimestamp(), '  Tag values present')
});

When("User clicks on Description section", () => {
    knowledgeDashboard.descriptionSectionClick()
    console.log(printTimestamp(), ' Description section clicked')
});

Then("Description section should get collapsed", () => {
    knowledgeDashboard.descriptionCollapsedVerification()
    console.log(printTimestamp(), ' Description section collapsed')
});

When("User clicks on any other section", () => {
    knowledgeDashboard.symptomsSectionClick()
    console.log(printTimestamp(), ' Symptoms section clicked')
});

Then("Clicked Section should get collapsed and re verify it for expansion", () => {
    knowledgeDashboard.symptomCollapsedVerification()
    console.log(printTimestamp(), ' Section collapsed and verified for expansion of section')
});

When("User clicks on close button", () => {
    knowledgeDashboard.closeButtonClick()
    console.log(printTimestamp(), ' Clicked on close button')
});

Then("User should navigated to knowledge dashboard", () => {
    knowledgeDashboard.knowledgeDashboardNavigationVerification()
    console.log(printTimestamp(), ' User navigated to knowledge dashboard')
});

When("User opens any knowledge and clicks on < icon", () => {
    knowledgeDashboard.tableFirstRecordClick()
    knowledgeDashboard.backArrowClick()
    console.log(printTimestamp(), ' User opened knowledge and clicked on < icon')
});

And("Repeats all steps for my knowledge dashboard", () => {
    knowledgeDashboard.myKnowledgeClick()
    knowledgeDashboard.myKnowledgeDashboardClick()
    knowledgeDashboard.tableFirstRecordClick()
    knowledgeDashboard.knowledgeDetailsVisible()
    knowledgeDashboard.knowledgeNameVisible()
    patternDashboard.versionLableExist()
    patternDashboard.versionValueExist()
    knowledgeDashboard.draftIconVisible()
    knowledgeDashboard.screenExpandIconVisible()
    knowledgeDashboard.descriptionSectionVisible()
    knowledgeDashboard.AssociationSectionVisible()
    knowledgeDashboard.causeAndSolutionSectionVisible()
    knowledgeDashboard.symptomsSectionVisible()
    knowledgeDashboard.tagSectionVisible()
    knowledgeDashboard.deleteButtonVisibleAsDisabled()
    knowledgeDashboard.closeButtonVisibleAsEnabled()
    knowledgeDashboard.descriptionIconValidationForMyknowledge()
    knowledgeDashboard.symptomIconValidationForMyknowledge()
    knowledgeDashboard.causesAndSolutionValueValidationForMyknowledge()
    knowledgeDashboard.tagsValueValidationForMyknowledge()
    knowledgeDashboard.descriptionSectionClick()
    knowledgeDashboard.descriptionCollapsedVerification()
    knowledgeDashboard.symptomsSectionClick()
    knowledgeDashboard.symptomCollapsedVerification()
    console.log(printTimestamp(), ' All steps repeated for my knowledge dashboard')
});
