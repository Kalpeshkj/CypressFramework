/// <reference types="Cypress" />
/// <reference types='cypress-tags' />

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';

import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();

import ApplyMetadata from "../../../../support/pageObjects/pages/PatternAuthoring/applyMetadata";
const applyMetadata = new ApplyMetadata();

When("User creates new workflow and fills all mandatory details", () => {
    cy.wait(4000)
    cy.createPattern()
    console.log(printTimestamp(), ' User createed new workflow and filled all mandatory details')
});

Then("Clicks on Next button", () => {
    createPattern.nextButtonClick()
    cy.wait(4000)
    console.log(printTimestamp(), ' Clicked on Next button')
});

Then("Verify UI for Modality that should be available in selected state", () => {
    applyMetadata.modalityDropdownInApplyMetadataSectionVerification()
    console.log(printTimestamp(), ' Verified UI for Modality that available in selected state')
});

Then("Verify UI for Modality that should available in selected state", () => {
    applyMetadata.modalityDropdownInApplyMetadataVerification()
    console.log(printTimestamp(), ' Verified UI for Modality that available in selected state')
});

Then("Verify UI for Relevance should be available in Expanded State", () => {
    applyMetadata.modalityDropdownSelection()
    applyMetadata.relevanceInExpandedStateVerification()
    console.log(printTimestamp(), ' Verified UI for Relevance available in Expanded State')
});

And("All Product Family in collapsed state should be displayed", () => {
    applyMetadata.productFamilyRelevanceInCollapsedStateVerification()
    console.log(printTimestamp(), ' All Product Family in collapsed state displayed')
});

When("User Expand Product Family", () => {
    applyMetadata.productFamilyRelevanceClick()
    console.log(printTimestamp(), ' User Expanded Product Family')
});

Then("List system type should be displayed with expand icon", () => {
    applyMetadata.productFamilyRelevanceVisible()
    console.log(printTimestamp(), ' List system type displayed with expand icon')
});

When("User Expand System Type", () => {
    applyMetadata.systemTypeInRelevanceClick()
    console.log(printTimestamp(), ' User Expanded System Type')
});

Then("List of Level should be displayed with expand icon", () => {
    applyMetadata.systemTypeInRelevanceVisible()
    console.log(printTimestamp(), ' List of Level displayed with expand icon')
});

When("User Expands Level", () => {
    applyMetadata.productLevelsRelevanceClick()
    console.log(printTimestamp(), ' User Expanded Level')
});

Then("List of Release should be displayed with expand icon", () => {
    applyMetadata.productLevelsRelevanceVisible()
    console.log(printTimestamp(), ' List of Release displayed with expand icon')
});

When("User Expands Release", () => {
    applyMetadata.productReleasesInRelevanceClick()
    console.log(printTimestamp(), '  User Expanded Release')
});

Then("List of Major build should be displayed with expand icon", () => {
    applyMetadata.productReleasesInRelevanceVisible()
    console.log(printTimestamp(), ' List of Major build displayed with expand icon')
});

When("User Expand Major Build", () => {
    applyMetadata.productsMajorBuildReleaseInRelevanceClick()
    console.log(printTimestamp(), ' User Expanded Major Build')
});

Then("List of Minor build should be displayed", () => {
    applyMetadata.productsMajorBuildReleaseInRelevanceVisible()
    createPattern.clicksOnPopUpOkButton()
    console.log(printTimestamp(), ' List of Minor build displayed')
});

When("User selects multiple modality including default selected", () => {
    applyMetadata.modalityMultipleDropdownSelectionWithDefaultSelectedValue()
    console.log(printTimestamp(), ' User selected multiple modality including default selected')
});

Then("Verify UI for system relevance as default modality expanded and rest are in collapsed state", () => {
    applyMetadata.relevanceInExpandedStateVerification()
    applyMetadata.newlyAddedModalityVisible()
    console.log(printTimestamp(), ' Verified UI for system relevance as default modality expanded and rest are in collapsed state')
});

When("User selects multiple modality excluding default selected", () => {
    createPattern.modalityDropDownInApplyMetadataPageClick()
    applyMetadata.modalitySelection()
    applyMetadata.modalityMultipleDropdownSelectionWithoutDefaultSelectedValue()
    console.log(printTimestamp(), ' User selected multiple modality excluding default selected')
});

Then("Verify UI for system relevance in collapsed state", () => {
    applyMetadata.newlyAddedModalityVisible()
    console.log(printTimestamp(), ' Verified UI for system relevance')
});

When("Uncheck selected Modality", () => {
    applyMetadata.uncheckAllTheModalities()
    console.log(printTimestamp(), ' Unchecked selected Modality')
});

Then("Respective relevance data should not be displayed", () => {
    createPattern.modalityDropDownInApplyMetadataPageClick()
    cy.wait(2000)
    createPattern.relevanceNoResultsFoundMessageTextVisible()
    console.log(printTimestamp(), ' Respective relevance data not displayed')
});

When("Select modalities one by one", () => {
    createPattern.modalityDropDownInApplyMetadataPageClick()
    cy.wait(2000)
    applyMetadata.selectModalityOneByOne()
    console.log(printTimestamp(), ' Selected modalities one by one')
});

Then("Selected modality relevance data should be displayed", () => {
    applyMetadata.relevanceInExpandedStateClick()
    applyMetadata.newlyAddedModalitySequentiallyVisible()
    console.log(printTimestamp(), ' Selected modality relevance data displayed')
});

Then("Verify UI if any node name is lengthier", () => {

    console.log(printTimestamp(), ' Verified UI if any node name is lengthier')
});