/// <reference types="Cypress" />
/// <reference types='cypress-tags' />

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';

import KnowledgeDashboard from "../../../../support/pageObjects/pages/Knowledge_Dashboard/KnowledgeDashboard";
const knowledgeDashboard = new KnowledgeDashboard();
var arr = [];

When("User navigates to Knowledge Dashboard", () => {
    knowledgeDashboard.knowledgeClick()
    knowledgeDashboard.knowledgeDashboardClick()
    console.log(printTimestamp(), ' Navigated to knowledge dashboard')
});

Then("User should be able to add all optional columns from drop down", () => {
    knowledgeDashboard.knowledgeColumnsDropdownClick()
    knowledgeDashboard.knowledgeUnselectedColumnsClick()
    knowledgeDashboard.knowledgeOutsideClickToGetResults()
    console.log(printTimestamp(), ' All optional columns added from dropdown')
});

And("Verifies types of filter for each column as like text filter for Name and Associations and dropdown for rest of the columns", () => {
    knowledgeDashboard.knowledgeNameSearchFilterVisible()
    knowledgeDashboard.noOfAssociationsSearchFilterVisible()
    knowledgeDashboard.dropdownFilterColumnsVisible()
    console.log(printTimestamp(), ' Types of filter verified for all column')
});

When("User types any value in Name column filter", () => {
    knowledgeDashboard.knowledgeNameSearchValueType()
    console.log(printTimestamp(), ' Value typed in Name filter column')
});

Then("Data must be filtered based on the searched value", () => {
    knowledgeDashboard.filteredDataVerification()
    console.log(printTimestamp(), ' Data filtered as per given value')
});

When("User clicks on X button in the filter", () => {
    knowledgeDashboard.crossIconClick()
    console.log(printTimestamp(), ' Clicked on x icon')
});

Then("The filter should be removed and all the values should be displayed", () => {
    knowledgeDashboard.allDataPresentInTableVerification()
    console.log(printTimestamp(), ' Filtered data removed')
});

When("User types any value in # of Associations column filter", () => {
    knowledgeDashboard.noOfAssociationsSearchValueType()
    console.log(printTimestamp(), ' Value typed in # of Associations')
});

When("User clicks on x button in the filter", () => {
    knowledgeDashboard.crossIconClickInNoOfAssociationSearch()
    console.log(printTimestamp(), ' Clicked on x icon')
});

When("User repeats all the steps for multiselect dropdown column filters", () => {
    knowledgeDashboard.modalityColumnClick()
    knowledgeDashboard.modalityDropdownValueSelectionClick()
    knowledgeDashboard.applyFilterButtonClick()
    console.log(printTimestamp(), ' All steps repeated for multiselect column filter')
});

Then("Multi select filter functionality should work as expected", () => {
    knowledgeDashboard.filteredDataVerificationInDropdownColumn()
    console.log(printTimestamp(), ' Multiselect functionality verified as working as expected')
});

When("User selects Date range filter and apply filter", () => {
    knowledgeDashboard.modifiedOnColumnClick()
    knowledgeDashboard.calenderDateSelection()
    knowledgeDashboard.knowledgeOutsideClickToGetResults()
    console.log(printTimestamp(), ' Date range selected and filter applied')
});

Then("Filtered data should be displayed in dashboard", () => {
    knowledgeDashboard.filteredDataVerificationForDate()
    console.log(printTimestamp(), ' Filtered data displayed')
});

And("Clicks on Clear All Filters and verifies data", () => {
    knowledgeDashboard.clearAllFiltersClick()
    console.log(printTimestamp(), ' Clear all filter clicked and data verified')
});

When("User Navigates to my knowledge dashboard", () => {
    knowledgeDashboard.myKnowledgeClick()
    knowledgeDashboard.myKnowledgeDashboardClick()
    console.log(printTimestamp(), ' Navigated to my knowledge dashboard')
});

Then("Repeats all above steps and verifies the data present as filtered", () => {
    knowledgeDashboard.knowledgeColumnsDropdownClick()
    knowledgeDashboard.knowledgeUnselectedColumnsClick()
    knowledgeDashboard.knowledgeOutsideClickToGetResults()
    knowledgeDashboard.knowledgeNameSearchFilterVisible()
    knowledgeDashboard.noOfAssociationsSearchFilterVisible()
    knowledgeDashboard.dropdownFilterColumnsVisible()
    knowledgeDashboard.knowledgeNameSearchValueType()
    knowledgeDashboard.crossIconClick()
    knowledgeDashboard.allDataPresentInTableVerification()
    knowledgeDashboard.noOfAssociationsSearchValueType()
    knowledgeDashboard.crossIconClickInNoOfAssociationSearch()
    knowledgeDashboard.modalityColumnClick()
    knowledgeDashboard.modalityDropdownValueSelectionClick()
    knowledgeDashboard.applyFilterButtonClick()
    knowledgeDashboard.filteredDataVerificationInDropdownColumn()
    console.log(printTimestamp(), ' All steps repeated and result data verified')
});

And("Close the DAW Application", () => {
    cy.log("Test Case Executed Successfully")
    console.log(printTimestamp(), ' Test Case Executed Successfully')
});
