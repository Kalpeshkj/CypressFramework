/// <reference types="Cypress" />
/// <reference types='cypress-tags' />

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';

import TagDashboard from "../../../../support/pageObjects/pages/Dashboard/TagDashboard";
const tagDashboard = new TagDashboard();
import NavigationPanel from "../../../../support/pageObjects/pages/Dashboard/NavigationPanel";
const navigationPanel = new NavigationPanel();


const recordsFoundText = 'records found';
const appName = 'Diagnostic Authoring Workspot';
const pageRecordsCountValue = '15';
const tagNameWithColumnCount = 'Tag Name ... +6 more';
const tagManagementDashboardText = 'Tag Management';

When("Click on Tag management", () => {
    tagDashboard.settingsDropdownClick()
    tagDashboard.settinsOptionClick()
    tagDashboard.tagManagementDashboardVerification().eq(1).invoke('text').should('contains', tagManagementDashboardText)
    console.log(printTimestamp(), ' Clicked on Tag management')
});

Then("create tag an delete tag buttons are visible", () => {
    tagDashboard.tagsHeadingTextVisible()
    tagDashboard.createTagVisible()
    tagDashboard.deleteTagVisible()
    tagDashboard.tagsDropDownCountVisible()
    tagDashboard.tagsDropDownCount().invoke('text').should('eq', tagNameWithColumnCount);
    tagDashboard.recordsFoundText()
    tagDashboard.clearAllFilterVisible()
    tagDashboard.entriesPerPageFieldVisible()
    tagDashboard.pageRecordVisible()
    tagDashboard.pageRecord().invoke('text').should('eq', pageRecordsCountValue)
    tagDashboard.showingCountVisible()
    console.log(printTimestamp(), ' Verified create and delete tag buttons availibility')
});

And("Tag dashboard is displayed with name {string} in left side corner", (name) => {
    tagDashboard.tagsHeadingText()
        .invoke("text").then((text) => {
            expect(text.trim()).to.equal(name);
            console.log(printTimestamp(), ' Tag name was visible in left side corner')
        })
});

And("Application name should be Displayed", () => {
    navigationPanel.displayName().invoke('text').should('eq', appName)
    console.log(printTimestamp(), 'Application Name displayed')
});


And("User name is available on right side corner with downword pointing chevron", () => {
    tagDashboard.userNameisVisible()
    tagDashboard.userNamewithDownChevronVisible()
    console.log(printTimestamp(), ' User name verified from right side corner with downword chevron')
});

And("My profile ,user management sections are disabled and tag management section is enabled and selected", () => {
    tagDashboard.myProfileisDisabled()
    tagDashboard.userDashboardDisabled()
    console.log(printTimestamp(), ' My profile ,user management sections are verified as disabled and Tag management section as enabled')
});

And("total number of records and entries per page available", () => {
    tagDashboard.recordsFoundText()
    tagDashboard.clearAllFilterVisible()
    tagDashboard.entriesPerPageFieldVisible()
    tagDashboard.pageRecordVisible()
    tagDashboard.pageRecord().invoke('text').should('eq', '15')
    tagDashboard.showingCountVisible()
    console.log(printTimestamp(), ' Verified total number of records and entries per page available')
});

And("by default user name filter applied", () => {
    tagDashboard.userNameFilterVisible()
    console.log(printTimestamp(), ' Verified by default filter for modality')
});

And("User should be able to navigate to next page by clicking on >", () => {
    tagDashboard.nextPageIconClick()
    console.log(printTimestamp(), ' Navigated to next page by clicking on >')
});

And("User should be able to navigate to next page by clicking on <", () => {
    tagDashboard.previousPageIconClick()
    console.log(printTimestamp(), ' Navigated to previous page by clicking on <')
});

And("On click of arrow, left panel should get collapsed", () => {
    tagDashboard.leftPanelCollapseClick()
    console.log(printTimestamp(), ' Left panel collapsed')
});

And("Navigation panel text should be visible", () => {
    tagDashboard.navigationPanelTextVisible()
    console.log(printTimestamp(), ' Navigation panel textvisible')
});

And("On click of arrow, left panel should get expanded", () => {
    tagDashboard.leftPanelExpandClick()
    console.log(printTimestamp(), ' Left panel expanded')
});

And("Home ,Settings and Tag management is available in breadcumb and should navigate to home page after click on home", () => {
    tagDashboard.breadcumbVerification()
    console.log(printTimestamp(), ' Verified Home ,Settings and Tag management options in breadcumb and navigated to home page after click on home')
});

And("Close Application", () => {
    cy.log("Test Case Executed Successfully")
    console.log(printTimestamp(), ' Test Case Executed Successfully')
});
