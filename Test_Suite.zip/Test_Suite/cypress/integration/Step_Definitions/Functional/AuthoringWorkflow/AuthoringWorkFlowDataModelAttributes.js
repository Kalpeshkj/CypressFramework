/// <reference types="Cypress" />
/// <reference types='cypress-tags' /> 

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();

When("User Click on three dot of My Patterns", () => {
    createPattern.myPatternThreeDotsClick()
    console.log(printTimestamp(), 'Clicked on three dot of My Patterns')
});

Then("Create Pattern option should be displayed", () => {
    createPattern.createPatternVisible()
    console.log(printTimestamp(), 'Create Pattern option displayed')
});

And("User should be able to create Authoring Workflow", () => {
    createPattern.createPatternButtonClick()
    cy.wait(2000)
    createPattern.patternNameType()
    createPattern.descriptionType()
    createPattern.orderOfExecutionType()
    console.log(printTimestamp(), 'User selects existing created Authoring Workflow')
});

When("Click on Import Data Model and Select any Data Model from drop down option", () => {
    createPattern.importDataModelClick()
    createPattern.dataModelDropArrowClick()
    createPattern.dataModelCommonOptionDropArrowClick()
    createPattern.eventLogDataModelClick()
    createPattern.dataModelDropArrowClick()
    console.log(printTimestamp(), 'Clicked on Import Data Model and Select any Data Model from drop down option')
});

When("Click on Add Condition", () => {
    createPattern.addConditionTabVisible()
    createPattern.addConditionTabClick()
    console.log(printTimestamp(), 'Clicked on Add Condition')
});

Then("Add Condition should get expanded", () => {
    createPattern.expandedAddConditionSectionVerification()
    console.log(printTimestamp(), 'Add Condition get expanded')
});

When("Click on + drop down", () => {
    createPattern.addConditionPlusIconClick()
    cy.wait(2000)
    console.log(printTimestamp(), 'Clicked on + drop down')
});

And("Hover on data model name", () => {
    createPattern.formDataModelClick()
    cy.wait(1000)
    console.log(printTimestamp(), 'Hover on data model name')
});

Then("List of attribute for respective data model should be displayed", () => {
    createPattern.importedEventLogModelClick()
    createPattern.dataModelAttributeListVisible()
    console.log(printTimestamp(), 'List of attribute for respective data model displayed')
});

And("attributes for selected data model should be matched with asp api response based on data model", () => {

    console.log(printTimestamp(), 'attributes for selected data model matched with asp api response based on data model')
});

When("Click on any attribute", () => {
    createPattern.dataModelAdditionalInfoAttributeClick()
    console.log(printTimestamp(), 'Clicked on any attribute')
});

Then("Attributes available in dropdown should be matched with db based on each data model", () => {

    console.log(printTimestamp(), 'Attributes available in dropdown matched with db based on each data model')
});

And("Click on From rule Pattern", () => {
    createPattern.formRulePatternOptionClick()
    console.log(printTimestamp(), 'Clicked on From rule Pattern')
});

Then("Import condition pop up should be displayed", () => {
    createPattern.importConditionPopUpVisible()
    console.log(printTimestamp(), 'Import condition pop up displayed')
});

When("Click on Pattern , Select Pattern and click on Import", () => {
    createPattern.ShowCheckboxClick()
    createPattern.patternClick()
    createPattern.importButtonClick()
    console.log(printTimestamp(), 'Clicked on Pattern , Selects Pattern and clicked on Import')
});

Then("pattern should be available under Add Condition as editable", () => {
    createPattern.patternUnderAddConditionVisible()
    console.log(printTimestamp(), 'pattern available under Add Condition as editable')
});

And("Attribute values should be matched with db based selected pattern applicable for  data model", () => {

    console.log(printTimestamp(), 'Attribute values matched with db based selected pattern applicable for  data model')
});

When("User select Add Expression from drop down option of attribute", () => {
    createPattern.attributeDropDownClick()
    createPattern.addCondtionOptionForTestOneClick()
    console.log(printTimestamp(), 'User selects Add Expression from drop down option of attribute')
});

Then("Add Expression pop up should be displayed", () => {
    createPattern.addConditionPopUpVisible()
    console.log(printTimestamp(), 'Add Expression pop up displayed')
});

And("Attribute values except string and boolean data type should be matched with db based applicable of  data model", () => {



    createPattern.addExpressionPopUpCloseButtonClick()
    console.log(printTimestamp(), 'Attribute values except string and boolean data type matched with db based applicable of  data model')
});
// Comment code to repeate above steps with remaining data models like test,systemParameter,system configuration
// And("Repeats above steps by covering all supported modalities", () => {
// 	createPattern.importDataModelClick()
//     createPattern.dataModelDropArrowClick()
//     createPattern.selectedTestDataModelClick()
//     createPattern.deleteButtonClick()
//     createPattern.dataModelDropArrowClick()
//     createPattern.selectedEventLOgDataModelClick()
//     createPattern.deleteButtonClick()
//     createPattern.dataModelDropArrowClick()
//     createPattern.dataModelCommonOptionDropArrowClick()
//     createPattern.systemParameterDataModelClick()
//     createPattern.dataModelDropArrowClick()
//     createPattern.adConditionTabVisible()
//     createPattern.adConditionTabClick()
//     createPattern.addConditionPlusIconClick()
//     cy.wait(2000)
//     createPattern.formDataModelClick()
//     cy.wait(1000)
//     createPattern.importedSystemDataModelVisible()
//     createPattern.importedSystemDataModelClick()
//     createPattern.dataModelAttributeListVisible()

//     createPattern.groupAttributesOfSystemParameterImportedDataModelClick()

//     createPattern.importDataModelClick()
//     createPattern.dataModelDropArrowClick()
//     createPattern.selectedSystemParameterDataModelClick()
//     createPattern.deleteButtonClick()
//     createPattern.dataModelDropArrowClick()
//     createPattern.dataModelCommonOptionDropArrowClick()
//     createPattern.systemConfigurationDataModelClick()
//     createPattern.dataModelDropArrowClick()
//     createPattern.adConditionTabClick()
//     createPattern.addConditionPlusIconClick()
//     cy.wait(2000)
//     createPattern.formDataModelClick()
//     cy.wait(1000)
//     createPattern.importedSystemConfigurationDataModelVisible()
//     createPattern.importedSystemConfigurationDataModelClick()
//     createPattern.dataModelAttributeListVisible()

//     createPattern.countAttributesOfSystemConfigurationImportedDataModelClick()

//     createPattern.importDataModelClick()
//     createPattern.dataModelDropArrowClick() 
//     createPattern.selectedSystemConfigurationDataModelClick()
//     createPattern.deleteButtonClick()
//     createPattern.dataModelDropArrowClick()
//     createPattern.dataModelCommonOptionDropArrowClick()
//     createPattern.eventLogDataModelClick()
//     createPattern.dataModelDropArrowClick()
//     createPattern.adConditionTabClick()
//     createPattern.addConditionPlusIconClick() 
//     cy.wait(2000)
//     createPattern.formDataModelClick()
//     cy.wait(1000)
//     createPattern.importedEventLogDataModelVisible()
//     createPattern.importedEventLogDataModelClick()
//     createPattern.dataModelAttributeListVisible()

//     createPattern.additionalInfoAttributesOfEventLogImportedDataModelClick()

//     console.log(printTimestamp() ,'Repeated above steps by covering all supported modalities')
// });

And("close DAW Application", () => {
    cy.DeleteWorkflow()
    cy.log('Test case executed successfully')
    console.log(printTimestamp(), 'Test case executed successfully')
})
