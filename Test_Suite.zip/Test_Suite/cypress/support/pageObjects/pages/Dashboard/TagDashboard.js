import "../../../index";
import AssertionConstants from "../../../../support/pageObjects/pages/AssertionConstants"
const assertionConstants = new AssertionConstants();

// Contants
const recordsFoundText = 'records found';
const pageRecordsCount = ' Showing 2 of 2 ';
export const pageRecordsCountValue = '15';
export const tagNameWithColumnCount = 'Tag Name ... +6 more';
export const tagManagementDashboardText = 'Tag Management';
export const beVisible = 'be.visible';

// Locators
const settingsDropdown = 'img[class="arrowdown-icon"]';
const settinsOption = '#Settings';
const tagManagementDashboardVerification = 'a[class="menuitem-link ng-star-inserted pt-active"]';
const tagsHeadingText = "//dls-label[contains(text(),'Tags')]";
const createTag = "#tag-create";
const deleteTag = "#tag-delete";
const tagsDropDownCount = "//span[contains(text(),'Tag Name ... +6 more')]";
const tagsRecordCout = "#record-count";
const clearAllFilter = "Clear All Filters";
const entriesPerPageField = ".pt-paginator-wrapper >.pt-entries-per-page";
const showingCount = ".pt-navigation >.showing";
const pageRecord = 'dls-dropdown[role="listbox"]> .pt-layout-container > .ng-star-inserted'
const tagNameColumn = "#column_tagName";
const matadataColumn = "#column_uiMetadata";
const keywordColumn = "#column_uiKeyword";
const valuetypeColumn = "#column_valueType";
const valueColumn = "#column_value";
const usergroupColumn = "#column_userGroup";
const modifyByDropdown = "//span[contains(text(),'Modified By')]";
const createdonDropdown = "//span[contains(text(),'Created On')]";
const createdbyDropdown = "//span[contains(text(),'Created By')]";
const hierarchyDropdown = "//span[contains(text(),'Hierarchy')]";
const mandatoryDropdown = "//span[contains(text(),'Mandatory')]";
const modifiedonColumn = "#column_modifiedDate";
const modifiedbyColumn = "#column_modifiedBy";
const createdonColumn = "#column_createdDate";
const createdbyColumn = "#column_createdBy";
const hierarchyColumn = "#column_showHeirarchy";
const firstTag = 'span[class="btn-link ng-star-inserted"]';
const tagNameInsideTag = "//dls-label[contains(text(),'Tag Name')]";
const valueTypeInsideTag = "//dls-label[contains(text(),'Value Type')]";
const userNameisVisible = "#user-name-with-menu > span";
const userNamewithDownChevron = "#user-name-with-menu > span > .arrowdown-icon";
const myProfileisDisabled = "div[aria-label='My Profile']";
const userDashboardDisabled = "a[id='User Management']";
const breadcumbVerification = ".pt-layout-container > ul > li > a";
const nextPageIconClick = ".pt-layout-container > .pt-icon";
const leftPanelCollapseClick = "#side-nav-toggle-icon";
const leftPanelCollapsed = 'div[class="dashboard_left active"]';
const navigationPanelText = '.sidebar_block';
const showResultCountVisible = "//section[contains(text(),'Showing 2 of 2')]"
const caretBesideName = '[class="arrowdown-icon"]'
const settingButton = '[id="Settings"]'
const tagsPage = 'Tags'
const homeOptionInbreadcrumb = '[class="menuitem-link ng-star-inserted"]'
const knowledgeDashboardSelected = '[aria-label="Dashboard"]'
const ariaSelectedClass = 'aria-selected'

class TagDashboard {
  userNameFilterVisible() {
    return cy.get('p-sorticon[arialabelasc="Activate to sort in descending order"]').eq(6).should('exist');
  }
  createdonDropdownVisible() {
    return cy.xpath(createdonDropdown).should(beVisible);
  }
  createdonDropdownClick() {
    return cy.xpath(createdonDropdown).click();
  }
  createdbyDropdownVisible() {
    return cy.xpath(createdbyDropdown).should(beVisible);
  }
  createdbyDropdownClick() {
    return cy.xpath(createdbyDropdown).click();
  }
  hierarchyDropdownVisible() {
    return cy.xpath(hierarchyDropdown).should(beVisible);
  }
  hierarchyDropdownClick() {
    return cy.xpath(hierarchyDropdown).click();
  }
  mandatoryDropdownVisible() {
    return cy.xpath(mandatoryDropdown).should(beVisible);
  }
  mandatoryDropdownClick() {
    return cy.xpath(mandatoryDropdown).click();
  }
  modifiedbyColumnVisible() {
    return cy.get(modifiedbyColumn).scrollIntoView().should(beVisible);
  }
  modifiedonColumnVisible() {
    return cy.get(modifiedonColumn).should(beVisible);
  }
  hierarchyColumnVisible() {
    return cy.get(hierarchyColumn).should(beVisible);
  }
  hierarchyColumnClick() {
    return cy.get(hierarchyColumn).click({ force: true });
  }
  createdonColumnVisible() {
    return cy.get(createdonColumn).should(beVisible);
  }
  createdonColumnClick() {
    return cy.get(createdonColumn).click({ force: true });
  }
  createdbyColumnVisible() {
    return cy.get(createdbyColumn).should(beVisible);
  }
  createdbyColumnClick() {
    return cy.get(createdbyColumn).click({ force: true });
  }
  tagNameColumnVisible() {
    return cy.get(tagNameColumn).should(beVisible);
  }
  matadataColumnVisible() {
    return cy.get(matadataColumn).should(beVisible);
  }
  keywordColumnVisible() {
    return cy.get(keywordColumn).should(beVisible);
  }
  valuetypeColumnVisible() {
    return cy.get(valuetypeColumn).should(beVisible);
  }
  valueColumnVisible() {
    return cy.get(valueColumn).should(beVisible);
  }
  usergroupColumnVisible() {
    return cy.get(usergroupColumn).should(beVisible);
  }
  showingCountVisible() {
    return cy.get(showingCount).should(beVisible);
  }
  pageRecordVisible() {
    return cy.get(pageRecord).should(beVisible);
  }
  entriesPerPageFieldVisible() {
    return cy.get(entriesPerPageField).should(beVisible);
  }
  clearAllFilterVisible() {
    return cy.contains(clearAllFilter).should(beVisible);
  }
  tagsDropDownCountVisible() {
    return cy.xpath(tagsDropDownCount).should(beVisible);
  }
  tagsDropDownCountClick() {
    return cy.xpath(tagsDropDownCount).click({ force: true });
  }
  deleteTagVisible() {
    return cy.get(deleteTag).should(beVisible);
  }
  createTagVisible() {
    return cy.get(createTag).should(beVisible);
  }
  tagsHeadingTextVisible() {
    return cy.xpath(tagsHeadingText);
  }
  settinsOptionClick() {
    return cy.get(settinsOption).click();
  }
  settingsDropdownClick() {
    return cy.get(settingsDropdown).click();
  }
  leftPanelExpandClick() {
    return cy.get(leftPanelCollapseClick).click();
  }
  navigationPanelTextVisible() {
    return cy.get(navigationPanelText).should(beVisible)
  }
  leftPanelCollapseClick() {
    cy.get(leftPanelCollapseClick).click();
    cy.get(leftPanelCollapsed).should('be.exist');
    return leftPanelCollapseClick;
  }
  nextPageIconClick() {
    cy.get(nextPageIconClick).eq(1).click();
    cy.wait(2000)
    cy.xpath(showResultCountVisible).should('have.text', pageRecordsCount)
    return nextPageIconClick;
  }
  previousPageIconClick() {
    return cy.get(nextPageIconClick).eq(0).click();
  }
  breadcumbVerification() {
    cy.get(breadcumbVerification).first().invoke("text").then((text) => {
      expect(text.trim()).to.equal("Home");
    })
    cy.get(breadcumbVerification).eq(1).invoke("text").then((text) => {
      expect(text.trim()).to.equal("Settings");
    })
    cy.get(breadcumbVerification).last().invoke("text").then((text) => {
      expect(text.trim()).to.equal("Tag Management");
    })
    cy.get(breadcumbVerification).first().click()
    cy.wait(2000)
    cy.get(breadcumbVerification).last().invoke("text").then((text) => {
      expect(text.trim()).to.equal("Dashboard");
    })
    return breadcumbVerification;
  }
  userDashboardDisabled() {
    return cy.get(userDashboardDisabled).should('not.have.attr', ariaSelectedClass);
  }
  myProfileisDisabled() {
    return cy.get(myProfileisDisabled).should('have.attr', ariaSelectedClass, 'false');
  }
  userNamewithDownChevronVisible() {
    return cy.get(userNamewithDownChevron).should(beVisible);
  }
  userNameisVisible() {
    return cy.get(userNameisVisible).should(beVisible);
  }
  modifyByDropdownVisible() {
    return cy.xpath(modifyByDropdown).should(beVisible);
  }
  modifyByDropdownClick() {
    return cy.xpath(modifyByDropdown).click();
  }
  userManagementButton() {
    return cy.xpath(userManagementButton);
  }
  tagNameInsideTagVisible() {
    return cy.xpath(tagNameInsideTag).first().should(beVisible);
  }
  valueTypeInsideTagVisible() {
    return cy.xpath(valueTypeInsideTag).first().should(beVisible);
  }
  firstTagVisible() {
    return cy.get(firstTag).first().scrollIntoView().should(beVisible);
  }
  firstTagClick() {
    return cy.get(firstTag).first().click();
  }
  settingsDropdown() {
    return cy.get(settingsDropdown);
  }
  settinsOption() {
    return cy.get(settinsOption);
  }
  tagManagementDashboardVerification() {
    return cy.get(tagManagementDashboardVerification);
  }
  tagsHeadingText() {
    return cy.xpath(tagsHeadingText);
  }
  createTag() {
    return cy.get(createTag);
  }
  deleteTag() {
    return cy.get(deleteTag);
  }
  tagsDropDownCount() {
    return cy.xpath(tagsDropDownCount);
  }
  tagsRecordCout() {
    return cy.get(tagsRecordCout);
  }
  clearAllFilter() {
    return cy.contains(clearAllFilter);
  }
  entriesPerPageField() {
    return cy.get(entriesPerPageField);
  }
  showingCount() {
    return cy.get(showingCount);
  }
  pageRecord() {
    return cy.get(pageRecord);
  }
  tagNameColumn() {
    return cy.get(tagNameColumn);
  }
  matadataColumn() {
    return cy.get(matadataColumn);
  }
  keywordColumn() {
    return cy.get(keywordColumn);
  }
  valuetypeColumn() {
    return cy.get(valuetypeColumn);
  }
  valueColumn() {
    return cy.get(valueColumn);
  }
  usergroupColumn() {
    return cy.get(usergroupColumn);
  }
  modifyByDropdown() {
    return cy.xpath(modifyByDropdown);
  }
  createdonDropdown() {
    return cy.xpath(createdonDropdown);
  }
  createdbyDropdown() {
    return cy.xpath(createdbyDropdown);
  }
  hierarchyDropdown() {
    return cy.xpath(hierarchyDropdown);
  }
  mandatoryDropdown() {
    return cy.xpath(mandatoryDropdown);
  }
  modifiedbyColumn() {
    return cy.get(modifiedbyColumn);
  }
  modifiedonColumn() {
    return cy.get(modifiedonColumn);
  }
  hierarchyColumn() {
    return cy.get(hierarchyColumn);
  }
  createdonColumn() {
    return cy.get(createdonColumn);
  }
  createdbyColumn() {
    return cy.get(createdbyColumn);
  }
  recordsFoundText() {
    cy.get(tagsRecordCout).invoke('text').as('recordsCount');
    return cy.get('@recordsCount').should('include', recordsFoundText)
  }




  caretBesideNameClick() {
    cy.get(caretBesideName).click()
  }

  settingButtonVisible() {
    cy.get(settingButton).should(assertionConstants.beVisibleAssertion)
  }

  settingButtonClick() {
    cy.get(settingButton).click()
  }

  tagsPageVisible() {
    cy.contains(tagsPage).should(assertionConstants.beVisibleAssertion)
  }

  homeOptionInbreadcrumbClick() {
    cy.get(homeOptionInbreadcrumb).click()
  }

  knowledgeDashboardSelected() {
    cy.get(knowledgeDashboardSelected).last().should(assertionConstants.haveAttributeAssertion, ariaSelectedClass, 'true')
  }
}
export default TagDashboard;
