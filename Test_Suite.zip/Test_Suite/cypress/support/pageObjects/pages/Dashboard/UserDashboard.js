import "../../../index";
import AssertionConstants from "../../../../support/pageObjects/pages/AssertionConstants"
const assertionConstants = new AssertionConstants();

// Contants
const recordsFoundText = 'records found';

// Locators
const settingsDropdown = '#user-name-with-menu img';
const settinsOption = '#Settings';
const tagsDropDownCount = "//span[contains(text(),'Tag Name ... +6 more')]";
const tagsRecordCout = "#record-count";
const clearAllFilter = "Clear All Filters";
const entriesPerPageField = ".pt-paginator-wrapper >.pt-entries-per-page";
const showingCount = ".pt-navigation >.showing";
const pageRecord = 'dls-dropdown[role="listbox"]> .pt-layout-container > .ng-star-inserted'
const createdonColumn = "#column_createdDate";
const createdbyColumn = "#column_createdBy";
const userManagementButton = "section[id='User Management']";
const usersText = "#user-tab dls-label";
const deleteUser = "#delete-user";
const addUser = "#add-user";
const userEmailColumn = "#column_emailId";
const userNameClumn = "#column_userName";
const groupameColumn = "#column_groupName";
const usersTab = "#p-tabpanel-0-label";
const groupsTab = "#p-tabpanel-1-label";
const entriesPerPage = 'section[class="pt-entries-per-page"]';
const showingPerPage = 'section[class="showing"]';
const firstRecordInUserEmail = '//tbody/tr[1]/td[2]';
const emailColumnFilter = '#emailId_filter';
const userNameColumnFilter = '#userName_filter';
const groupNameColumnFilter = '#multiselect-filter>div';
const createdByColumnFilter = '#createdBy_filter';
const createdDateColumnFilter = '#createdDate_filter';
const validNameSearchText = 'DAW_Automation';
const invalidNameSearchText = 'Testing';
const validEmailSearchText = 'cat_zeppelin_user@philips.com';
const filteredData = 'tr td>span[class="ng-star-inserted"]';
const ClearedFilterValidation = 'span[class="p-checkbox-icon"]';
const noRecordsFoundText = ' No records found ';
const groupNameColumnDropDownCheckbox = 'ul[role="listbox"] li';
const searchBoxInGroupNameColumn = 'input[role="textbox"]';
const groupNameRecords = 'div[role="checkbox"]';
const datePicker = '.p-datepicker-header';
const firstDayDatePicker = 'table>tbody>tr>td>span[draggable="false"]';
const todaysDatePicker = '.p-datepicker-today';
const entriesPerPageCheckbox = 'dls-dropdown[role="listbox"]';
const entriesPerPageValues = 'dls-option[role="option"]';
const nextPageNavigation = 'dls-icon[class="pt-icon icon-dls-navigation-right custom-right-icon"]';
const previousPageNavigation = 'dls-icon[class="pt-icon icon-dls-navigation-left custom-left-icon"]';
const userEmailRecord1 = '//tbody/tr[1]/td[2]/span[1]';
const userEmailRecord2 = '//tbody/tr[2]/td[2]/span[1]';
const emailColumn = '#column_emailId';
const groupNameDropdownOption = '[id="multiselect-filter"]'

let arr1 = []
let arr2 = []

class UserDashboard {
  groupNameColumnFilterClick() {
    cy.get(groupNameColumnFilter).first().click()
  }
  showingCountVisible() {
    return cy.get(showingCount).should(assertionConstants.beVisibleAssertion)
  }
  pageRecordVisible() {
    return cy.get(pageRecord).should(assertionConstants.beVisibleAssertion)
  }
  entriesPerPageFieldVisible() {
    return cy.get(entriesPerPageField).should(assertionConstants.beVisibleAssertion)
  }
  recordsTextInvokeFunction1(record, textValue) {
    cy.xpath(record).invoke('text').then((value) => {
      cy.wait(2000)
      arr1.length = 0
      arr1.push(value.slice(0, textValue))
    });
  }
  recordsTextInvokeFunction2(record, textValue) {
    cy.xpath(record).invoke('text').then((value) => {
      cy.wait(2000)
      arr2.length = 0
      arr2.push(value.slice(0, textValue))
    });
  }
  userEmailColumnClickAndSortingOfDataVerification() {
    cy.contains(clearAllFilter).click()
    cy.get(emailColumn).click();
    this.recordsTextInvokeFunction1(userEmailRecord1, 3)
    this.recordsTextInvokeFunction2(userEmailRecord2, 3)
    if (arr1 >= arr2) {
      cy.log("Data is sorted as ascending");
    }
    else {
      cy.log("Data is sorted as descending");
    }
    cy.get(emailColumn).click();
    cy.wait(2000)
    this.recordsTextInvokeFunction1(userEmailRecord1, 3)
    this.recordsTextInvokeFunction2(userEmailRecord2, 3)
    if (arr1 >= arr2) {
      cy.log("Data is sorted as descending");
    }
    else {
      cy.log("Data is sorted as ascending");
    }
  }
  pageNavigationValidation() {
    cy.get(nextPageNavigation).click()
    cy.get(previousPageNavigation).click()
  }
  entriesPerPageValuesChangedToTwentyVerification() {
    cy.get(entriesPerPageValues).eq(2).click()
    cy.get(groupNameRecords).should(assertionConstants.haveLengthGreaterThanAssertion, 19)
  }
  entriesPerPageValuesVerification() {
    cy.get(entriesPerPageCheckbox).click()
    cy.get(entriesPerPageValues).each(($el) => {
      cy.wrap($el).should(assertionConstants.beVisibleAssertion)
    })
  }
  todaysDateSelectionAtAddedOnColumn() {
    cy.get(firstDayDatePicker).should('not.have.attr', 'class', 'p-disabled').eq(0).click({ force: true })
    cy.get(todaysDatePicker).click()
  }
  datePickerVisibleConfirmationAtAddedOnColumn() {
    cy.get(createdDateColumnFilter).click()
    cy.get(datePicker).should(assertionConstants.beVisibleAssertion)
  }
  groupNameFilteredRecordsVisible() {
    cy.get(groupNameRecords).should(assertionConstants.haveLengthGreaterThanAssertion, 3)
  }
  groupNameColumnDropDownCheckboxClick() {
    cy.get(groupNameColumnDropDownCheckbox).eq(1).scrollIntoView().then(() => {
      cy.get('li[class="p-ripple p-element p-multiselect-item"] span[class="ng-star-inserted"]').eq(0)
        .invoke('text').then((value) => {
          arr1.push(value)
          cy.log(arr1)
          cy.wait(2000)
        })
    })
    cy.get(groupNameColumnDropDownCheckbox).eq(1).click()
    cy.get(groupNameColumnFilter).first().click()
    cy.get(groupNameColumnDropDownCheckbox).eq(2).click()
    cy.get(groupNameColumnDropDownCheckbox).eq(3).click()
  }
  groupNameColumnFilteredDataVerification() {
    cy.get(userNameColumnFilter).click()
    cy.contains(arr1[0]).should(assertionConstants.beVisibleAssertion)
  }
  searchBoxInGroupNameColumnVisible() {
    cy.get(searchBoxInGroupNameColumn).should(assertionConstants.beVisibleAssertion)
  }
  groupNameColumnDropDownCheckboxVisible() {
    cy.contains(clearAllFilter).click()
    cy.get(groupNameColumnFilter).first().click().then(() => {
      cy.get(groupNameColumnDropDownCheckbox).each(($el) => {
        cy.wrap($el).should(assertionConstants.beExistAssertion)
      })
    })

  }
  noRecordsFoundTextVisible() {
    cy.contains(noRecordsFoundText).should(assertionConstants.beVisibleAssertion)
  }
  invalidUserNameColumnFilterValidation() {
    cy.get(userNameColumnFilter).type(invalidNameSearchText)
  }
  ClearedFilterValidation() {
    return cy.get(ClearedFilterValidation).should(assertionConstants.haveLengthGreaterThanAssertion, 5)
  }
  clearAllFilterButtonClick() {
    return cy.contains(clearAllFilter).click()
  }
  clearAllFilterButtonVisible() {
    return cy.contains(clearAllFilter).should(assertionConstants.beVisibleAssertion)
  }
  filteredDataVerification() {
    cy.get(filteredData).eq(0).invoke('text').should('contains', validEmailSearchText)
    cy.get(filteredData).eq(1).invoke('text').should('contains', validNameSearchText)

  }
  userEmailColumnFilterValidation() {
    cy.get(emailColumnFilter).type(validEmailSearchText)
  }
  userNameColumnFilterValidation() {
    cy.get(userNameColumnFilter).type(validNameSearchText)
  }
  FilterTextboxVisible() {
    cy.get(emailColumnFilter).should(assertionConstants.beVisibleAssertion)
    cy.get(userNameColumnFilter).should(assertionConstants.beVisibleAssertion)
    cy.get(groupNameColumnFilter).first().should(assertionConstants.beVisibleAssertion)
    cy.get(createdByColumnFilter).should(assertionConstants.beVisibleAssertion)
    cy.get(createdDateColumnFilter).should(assertionConstants.beVisibleAssertion)
  }
  hyperlinkNotVisibleInRecords() {
    return cy.xpath(firstRecordInUserEmail).should('not.have.a.property', 'a')
  }
  userEmailColumnVisible() {
    return cy.get(userEmailColumn).should(assertionConstants.beVisibleAssertion)
  }
  userNameColumnVisible() {
    return cy.get(userNameClumn).should(assertionConstants.beVisibleAssertion)
  }
  userNameColumnSortedVisible() {
    return cy.get(userNameClumn).should(assertionConstants.haveAttributeAssertion, 'aria-sort', 'ascending')
  }
  groupameColumnVisible() {
    return cy.get(groupameColumn).should(assertionConstants.beVisibleAssertion)
  }
  createdonColumnVisible() {
    return cy.get(createdonColumn).should(assertionConstants.beVisibleAssertion)
  }
  createdbyColumnVisible() {
    return cy.get(createdbyColumn).should(assertionConstants.beVisibleAssertion)
  }
  showingPerPageVerification() {
    cy.get(showingPerPage).should(assertionConstants.beVisibleAssertion)
  }
  entriesPerPageVerification() {
    cy.get(entriesPerPage).should(assertionConstants.beVisibleAssertion).find('span[class="ng-star-inserted"]')
      .invoke('text').should('eq', '15')
  }
  deleteUserButtonVisible() {
    return cy.get(deleteUser).should(assertionConstants.beVisibleAssertion)
  }
  addUserButtonVisible() {
    return cy.get(addUser).should(assertionConstants.beVisibleAssertion)
  }
  tabsVisible() {
    cy.get(usersTab).should(assertionConstants.beVisibleAssertion)
    cy.get(groupsTab).should(assertionConstants.beVisibleAssertion)
  }
  usersDasboardNavigationTextVisible() {
    return cy.get(usersText).should(assertionConstants.beVisibleAssertion)
  }
  userManagementButtonClick() {
    return cy.get(userManagementButton).click()
  }
  settingsDropdownClick() {
    return cy.get(settingsDropdown).click()
  }
  settinsOptionClick() {
    return cy.get(settinsOption).click()
  }
  settinsOptionVisible() {
    return cy.get(settinsOption).should(assertionConstants.beVisibleAssertion)
  }
  userEmailColumn() {
    return cy.get(userEmailColumn);
  }
  userNameClumn() {
    return cy.get(userNameClumn);
  }
  groupameColumn() {
    return cy.get(groupameColumn);
  }
  deleteUser() {
    return cy.get(deleteUser);
  }
  addUser() {
    return cy.get(addUser);
  }
  usersText() {
    return cy.get(usersText);
  }
  userManagementButton() {
    return cy.get(userManagementButton);
  }
  settingsDropdown() {
    return cy.get(settingsDropdown);
  }
  settinsOption() {
    return cy.get(settinsOption);
  }
  clearAllFilter() {
    return cy.contains(clearAllFilter);
  }
  entriesPerPageField() {
    return cy.get(entriesPerPageField);
  }
  showingCount() {
    return cy.get(showingCount);
  }
  pageRecord() {
    return cy.get(pageRecord);
  }
  usergroupColumn() {
    return cy.get(usergroupColumn);
  }
  modifyByDropdown() {
    return cy.xpath(modifyByDropdown);
  }
  createdonDropdown() {
    return cy.xpath(createdonDropdown);
  }
  createdbyDropdown() {
    return cy.xpath(createdbyDropdown);
  }
  createdonColumn() {
    return cy.get(createdonColumn);
  }
  createdbyColumn() {
    return cy.get(createdbyColumn);
  }
  recordsFoundText() {
    cy.get(tagsRecordCout).invoke('text').as('recordsCount');
    return cy.get('@recordsCount').should('include', recordsFoundText)
  }

  groupNameDropdownOptionClick(){
    cy.get(groupNameDropdownOption).first().click()
  }
}

export default UserDashboard;
