/// <reference types="Cypress" />
/// <reference types='cypress-tags' />

import "../../../../support/index";
import { When, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import CreateKnowledge from "../../../../support/pageObjects/pages/KnowledgeAuthoring/CreateKnowledge";
const createKnowledge = new CreateKnowledge();
var arr = [];

And("Cause pop up should get displayed when user clicked on Select cause button", () => {
    createKnowledge.causeButtonVisible()
    createKnowledge.causeButtonClick()
    createKnowledge.selectClauseHeadingVisible()
    console.log(printTimestamp(), ' Cause pop up displayed')
});

And("User clicks on 'X' icon and entered text should gets cleared", () => {
    createKnowledge.crossMarkClick()
    createKnowledge.searchBoxTestVisible()
    console.log(printTimestamp(), ' Data got cleared after click of X')
});

When("User Clicks on Show all checkbox", () => {
    createKnowledge.showAllCheckboxClick()
    console.log(printTimestamp(), ' Show all checkbox clicked')
});

And("Close DAW Application", () => {
    createKnowledge.cancelButtonClickForClaus()
    cy.DeleteWorkflow()
    cy.log("Test Case Executed Successfully")
    console.log(printTimestamp(), ' Test Case Executed Successfully')
});
