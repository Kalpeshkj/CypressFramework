/// <reference types="Cypress" />
/// <reference types='cypress-tags' />
import "../../../../support/index";
import { When, Then, And, Given, } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import CreateKnowledge from "../../../../support/pageObjects/pages/KnowledgeAuthoring/CreateKnowledge";
const createKnowledge = new CreateKnowledge();
import KnowledgeDashboard from "../../../../support/pageObjects/pages/Knowledge_Dashboard/KnowledgeDashboard";
const knowledgeDashboard = new KnowledgeDashboard();
import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();
import IncludeKnowledge from "../../../../support/pageObjects/pages/PatternAuthoring/includeKnowledgepageObj";
const includeKnowledge = new IncludeKnowledge();
import ValidationPage from "../../../../support/pageObjects/pages/PatternAuthoring/ValidatePage";
const validationPage = new ValidationPage();
import PatternDashboard from "../../../../support/pageObjects/pages/Dashboard/PatternDashboard";
const patternDashboard = new PatternDashboard();
import ApplyMetadata from "../../../../support/pageObjects/pages/PatternAuthoring/applyMetadata";
const applyMetadata = new ApplyMetadata();


When("User Create knowledge workflow", () => {
    createKnowledge.knowledgeOptionArrowClick()
    createKnowledge.addKnowledgeWorkflowButtonClick()
    createKnowledge.patternNameTypeInPatternInformationSection()
    createKnowledge.decriptionFieldType()
    console.log(printTimestamp(), 'User Create knowledge workflow')
});

And("enter all the mandatory field and save knowledge along wiht tags of cause,solution and symptoms"
+" including rich text content", () => {
    createKnowledge.causesAndSolutionSectionClick()
    createKnowledge.addCausesButtonClick()
    createKnowledge.causeOneInputBoxType()
    createKnowledge.tagButtonClick()
    createKnowledge.selectTagsDropDownClick()
    createKnowledge.DAPCollimeterTagsOptionsClick()
    createKnowledge.plusIconInAddTagsClick()
    createKnowledge.doneButtonClickInPopUpClick()
    createKnowledge.addSolutionButtonClick()
    createKnowledge.solutionOneTextBoxType()
    createKnowledge.symptomOptionClick()
    createKnowledge.addSymptomButtonClick()
    createKnowledge.symptomOneTextBoxForRichTextEditorType()
    createKnowledge.tagButtonClick()
    createKnowledge.selectTagsDropDownClick()
    createKnowledge.detectorTagsOptionsClick()
    createKnowledge.plusIconInAddTagsClick()
    createKnowledge.doneButtonClickInPopUpClick()
    createKnowledge.tagsknowledgeInfoOptionsClick()
    createKnowledge.addTagsOptionClick()
    createKnowledge.selectTagDropdownClick()
    createKnowledge.awsTagsOptionsClick()
    createKnowledge.plusIconInAddtagsClick()
    createKnowledge.doneButtonClickInPopUpClick()
    createKnowledge.causesAndSolutionSectionClick()
    createKnowledge.tagIconUnderSolutionClick()
    createKnowledge.selectTagsDropDownClick()
    createKnowledge.detectorTagsOptionsClick()
    createKnowledge.plusIconInAddTagsClick()
    createKnowledge.doneButtonClickInPopUpClick()
    createKnowledge.symptomOptionClick()
    createKnowledge.tagButtonClick()
    createKnowledge.selectTagsDropDownClick()
    createKnowledge.detectorTagsOptionsClick()
    createKnowledge.plusIconInAddTagsClick()
    createKnowledge.doneButtonClickInPopUpClick()
    createKnowledge.tagSectionWithUniqueTags()
    createKnowledge.saveAsDraftClick() 
    cy.wait(5000) 
    createKnowledge.getPatternName()
    cy.wait(1000)
    console.log(printTimestamp(), "enter all the mandatory field and save knowledge along wiht tags of cause,solution and symptoms"
    +" including rich text content")
});

And("Publish the knowledge and map the knowledge to a particular pattern in include knowledge page", () => {
    knowledgeDashboard.knowledgeDashboardClick()
    cy.wait(1000)
    createKnowledge.knowledgeNameSearch()
    knowledgeDashboard.searchIconForKnowledgeNameClick()
    cy.wait(2000)
    knowledgeDashboard.searchedKnowledgeClick()
    knowledgeDashboard.knowledgePublishOptionClick()
    knowledgeDashboard.okButtonButtonInPopUpClick()
    cy.wait(2000)
    cy.createPattern()
    createPattern.saveAsDraftClick() 
    cy.wait(2000) 
    createPattern.nextButtonClick()
    cy.ApplyMetaDetaPageCompletion()
    createPattern.nextButtonClick()
    cy.wait(1000)
    includeKnowledge.showAllCheckboxClick()
    cy.wait(4000)
    createKnowledge.filterForKeywordTypeKnowledgeName()
    knowledgeDashboard.searchIconForKnowledgeNameClick() 
    cy.wait(2000)
    createKnowledge.firstRecordCheckboxClick()
    createKnowledge.nextButtonOnIncludeKnowledgePageClick()
    cy.wait(2000)
    validationPage.validationIdDropdownClick()
    validationPage.selectFirstId()
    validationPage.selectButtonClick()
    validationPage.calenderOptionClick()
    validationPage.datePrevIconClick()
    validationPage.dateRangeSlection()
    validationPage.taskLimitInputBoxTypeOne()


    validationPage.previousButtonClick()
    cy.wait(1000)
    validationPage.previousButtonClick()
    cy.wait(1000)
    applyMetadata.selectiongAllUnderRelevnceClick()
    applyMetadata.nextButtonClick()
    cy.wait(1000)
    applyMetadata.nextButtonClick()
    cy.wait(2000)

    validationPage.validateButtonClick()
    cy.wait(2000)
    validationPage.saveAsDraftButtonClick()
    cy.wait(3000)
    createPattern.getPatternName()
    cy.wait(1000)
    console.log(printTimestamp(), ' Publish the knowledge and map the knowledge to a particular pattern in include knowledge page')
});

When("Navigate to the pattern dashboard", () => {
    createPattern.patternDashboardClick()
    cy.wait(2000)
    patternDashboard.modalityDropdownColumnClick()
    patternDashboard.selectAllCheckBoxClick()
    patternDashboard.modalityApplyButtonClick()
    createPattern.PatternNameSearchInSearchOption()
    createPattern.searchIconClicked()
    cy.wait(2000)
    console.log(printTimestamp(), 'Navigate to the pattern dashboard')
});

And("Click on the pattern for which the knowledge is mapped", () => {
    patternDashboard.patternDashboardColumnFirstRecordClick();
    console.log(printTimestamp(), 'Click on the pattern for which the knowledge is mapped')
});

Then("An overlay section should be displayed with knowledge details", () => {
    patternDashboard.rightSideOverlaySectionVisible()
    console.log(printTimestamp(), 'An overlay section should be displayed with knowledge details')
});

And("Rich text contents added in cause solution and symptom should appear in the overlay section", () => {
    patternDashboard.knowledgeNameInOverlayScreenVisible()
    patternDashboard.knowledgeSectionExpandCollapseIconVisible()
    patternDashboard.symptomsSectionInOverlayVisible()
    patternDashboard.causeAndSolutionSectionInOverlayVisible()
    patternDashboard.tagsSectionInOverlayVisible()
    console.log(printTimestamp(), 'Rich text contents added in cause solution and symptom should appear in the overlay section')
});

And("User Should be able to see unique tags", () => {
    patternDashboard.tagSectionInOverlaySectionWithUniqueTagsVisible()
    console.log(printTimestamp(), 'User should be able to see unique tags')
});

And("Tooltip to be shown for the tags associated with cause-solution-symptom with cause-solution-symptom"
+" name to which its associated", () => {
	
    console.log(printTimestamp(), "Tooltip to be shown for the tags associated with cause-solution-symptom with cause-solution-symptom"
    +" name to which its associated")
});

And("For knowledge level tags, tooltip will not be shown", () => {
	
    console.log(printTimestamp(), 'For knowledge level tags, tooltip will not be shown')
});

When("Navigate to the Pattern dashboard", () => {
	patternDashboard.crossMarkInOverlaySectionClick()
    console.log(printTimestamp(), 'Navigate to the pattern dashboard')
});

And("Click on the pattern Name hyperlink for the recently added knowledge", () => {
	patternDashboard.patternClick()
    console.log(printTimestamp(), 'Click on the pattern Name hyperlink for the recently added knowledge')
});

Then("User should be able to view pattern details with knowledge section expanded", () => {
    patternDashboard.readOnlyModeExist()
    console.log(printTimestamp(), 'User should be able to view pattern details with knowledge section expanded')
});

And("Repeat last Four steps", () => {
    patternDashboard.knowledgeNameInOverlayScreenVisible()
    patternDashboard.knowledgeSectionExpandCollapseIconVisible()
    patternDashboard.symptomsSectionInOverlayVisible()
    patternDashboard.causeAndSolutionSectionInOverlayVisible()
    patternDashboard.tagsSectionInOverlayVisible()
    patternDashboard.uniqueTagsInDetailsPageVerification()
    cy.DeleteDynamicPattern()
    console.log(printTimestamp(), 'Repeat last Four steps')
});
 





