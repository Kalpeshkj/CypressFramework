/// <reference types="Cypress" />
/// <reference types='cypress-tags' />  
import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import CreateKnowledge from "../../../../support/pageObjects/pages/KnowledgeAuthoring/CreateKnowledge";
const createKnowledge = new CreateKnowledge();
import KnowledgeDashboard from "../../../../support/pageObjects/pages/Knowledge_Dashboard/KnowledgeDashboard";
const knowledgeDashboard = new KnowledgeDashboard();

When("Navigate to knowledge dashboard", () => {
	createKnowledge.knowledgeOptionArrowClick()
    cy.CreateMultipleKnowledgeAsPerUserInput(2)
    console.log(printTimestamp(), 'Navigated to knowledge dashboard')   
});

And("Select entries per page as 500", () => {
    knowledgeDashboard.myPatternDropArrowClick() 
    knowledgeDashboard.KnowledgeDashboardSelect()
    cy.wait(3000)
    knowledgeDashboard.pageCountDropArrowClick()
	knowledgeDashboard.differentValueSelectionFromEnterPerPageDropdown()
    console.log(printTimestamp(), 'Selects entries per page as 500') 
});

Then("Max 500 knowledge should be displayed in current page", () => {
    knowledgeDashboard.tenRecordsInKnowledgenDashBoard()
    console.log(printTimestamp(), 'Max 500 knowledge displayed in current page')
});

When("Select all knowledge Knowledge available in current page Knowledge should not have any associations or Knowledge should have associations only with withdrawn pattern", () => {
	knowledgeDashboard.selectingFirstFiveKnowledges()
    console.log(printTimestamp(), 'Selects all knowledge Knowledge available in current page Knowledge not have any associations or Knowledge should have associations only with withdrawn pattern')
});

And("Click on Delete button of KnowledgeDashboard", () => {
	knowledgeDashboard.deleteButtonInKnowledgeDashboardClick()
    console.log(printTimestamp(), 'Clicked on Delete button')
});

Then("Confirmation message Delete icon - Are you sure you want to delete the following 500 knowledges ? 10 Knowledge Name + 490 more Cancel and Delete buttons", () => {
	knowledgeDashboard.confirmationPopUpHeaderVisible()
    knowledgeDashboard.knowledgeNamesOnPopUpVisible()
    knowledgeDashboard.cancelButtonVisible()
    knowledgeDashboard.deleteButtonOnPopUpVisible()
    knowledgeDashboard.deleteButtonOnPopUpClick()
    cy.wait(2000)
    console.log(printTimestamp(), 'Confirmation message Delete icon - Are you sure you want to delete the following 500 knowledges ? 10 Knowledge Name + 490 more Cancel and Delete buttons')
});

And("All 500 selected knowledge should get deleted", () => {
	knowledgeDashboard.knowledgesDeletedMessageVisible()
    console.log(printTimestamp(), 'All 500 selected knowledge should get deleted')
});

// And("Verify deleted knowledge details in db", () => {
	
//     console.log(printTimestamp(), 'Verified deleted knowledge details in db')
// });

And("Repeat above steps in My Knowledge Dashboard", () => {
    cy.CreateMultipleKnowledgeAsPerUserInput(2)
    knowledgeDashboard.myKnowledgeDashboardClick()
    cy.wait(3000)
    knowledgeDashboard.pageCountDropArrowClick()
	knowledgeDashboard.differentValueSelectionFromEnterPerPageDropdown()
    knowledgeDashboard.tenRecordsInKnowledgenDashBoard()
    knowledgeDashboard.selectingFirstFiveKnowledges()
    knowledgeDashboard.deleteButtonInKnowledgeDashboardClick()
    knowledgeDashboard.confirmationPopUpHeaderVisible()
    knowledgeDashboard.knowledgeNamesOnPopUpVisible()
    knowledgeDashboard.cancelButtonVisible()
    knowledgeDashboard.deleteButtonOnPopUpVisible()
    knowledgeDashboard.deleteButtonOnPopUpClick()
    knowledgeDashboard.knowledgesDeletedMessageVisible()
    console.log(printTimestamp(), 'Repeats above steps in My Knowledge Dashboard')
});

