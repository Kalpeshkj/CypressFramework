/// <reference types='cypress-tags' /> 
import "../../../../support/index";
import {When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import KnowledgeDashboard from "../../../../support/pageObjects/pages/Knowledge_Dashboard/KnowledgeDashboard";
const knowledgeDashboard = new KnowledgeDashboard();
import CreateKnowledge from "../../../../support/pageObjects/pages/KnowledgeAuthoring/CreateKnowledge";
const createKnowledge = new CreateKnowledge();
When("navigate to knowledge dashboard", () => {
    createKnowledge.knowledgeOptionArrowClick()
    createKnowledge.addKnowledgeWorkflowButtonClick()
    cy.wait(2000)
    cy.CreateMyKnowledgeNormal()
    createKnowledge.saveAsDraftClick()
    cy.wait(3000) 
    createKnowledge.getPatternName()
    cy.wait(1000)
    knowledgeDashboard.knowledgeDashboardClick()
    cy.wait(1000)
    createKnowledge.knowledgeNameSearch()
    knowledgeDashboard.searchIconForKnowledgeNameClick()
    cy.wait(2000)
    knowledgeDashboard.searchedKnowledgeClick()
    knowledgeDashboard.knowledgePublishOptionClick()
    knowledgeDashboard.okButtonButtonInPopUpClick()
    createKnowledge.addKnowledgeWorkflowButtonClick() 
    cy.wait(2000)
    cy.CreateKnowledgeAssociation()
    createKnowledge.saveAsDraftClick()
    cy.wait(3000)
    createKnowledge.getPatternName()
    cy.wait(1000)
    knowledgeDashboard.knowledgeDashboardClick()
    createKnowledge.secondKnowledgeSearch()
    knowledgeDashboard.searchIconForKnowledgeNameClick()
    cy.wait(2000)
    knowledgeDashboard.searchedKnowledgeClick()
    cy.wait(1000)
    knowledgeDashboard.knowledgePublishOptionClick()
    cy.wait(2000)
    knowledgeDashboard.okButtonButtonInPopUpClick()
    knowledgeDashboard.searchedKnowledgeNameRemoveOptionClick()
    cy.wait(2000)
    console.log(printTimestamp(), 'Navigate to knowledge dashboard')
});

Then("Delete button should be displayed at op right corner,right click on row,In submenu row level and knowledge details view page", () => {
	knowledgeDashboard.deleteButtonInKnowledgeDashboardVisible()
    knowledgeDashboard.rowLevelThreeDotsClick()
    knowledgeDashboard.deleteButtonUnderThreeDotsVisible()
    console.log(printTimestamp(), 'Delete button should be displayed at op right corner')
});

When("User select knowledge which doesn't has any association", () => {
    knowledgeDashboard.checkBoxSelectingKnowledgeWithOutAssociationClick()
    console.log(printTimestamp(), "User elect knowledge which doesn't has any association")
});

Then("Delete buttons at all places should be enabled", () => {
	knowledgeDashboard.deleteButtonInKnowledgeDashboardEnabled()
    knowledgeDashboard.rowLevelThreeDotsClick()
    knowledgeDashboard.deleteButtonUnderThreeDotsVisible()
    knowledgeDashboard.searchedKnowledgeClick()
    cy.wait(2000)
    knowledgeDashboard.deleteButttonWhenClickedOnlinkEnabled()
    knowledgeDashboard.backArrowClick()
    console.log(printTimestamp(), 'Delete buttons at all places should be enabled')
});

When("Select knowledge which have associations except associated with withdrawn, draft pattern", () => {
	knowledgeDashboard.unselectingFirstKnowledge()
    knowledgeDashboard.checkBoxSelectingKnowledgeHavingAssociationClick()
    cy.wait(5000)
    console.log(printTimestamp(), 'Select knowledge which have associations except associated with withdrawn, draft pattern')
});

Then("Delete buttons at all places should be disabled", () => {
    knowledgeDashboard.deleteButtonInKnowledgeDashboardDisabled() 
    knowledgeDashboard.rowLevelThreeDotsForAssociatedKnowledgeClick()
    knowledgeDashboard.deleteButtonUnderThreeDotsDisabled()
    knowledgeDashboard.searchedSecondKnowledgeClick()
    cy.wait(2000)
    knowledgeDashboard.deleteButttonWhenClickedOnlinkDisabled()
    knowledgeDashboard.backArrowClick()
    console.log(printTimestamp(), 'Delete buttons at all places should be disabled')
});

// When("Hover on delete button and verify tooltip On top right corner Delete button,"
// +"Submenu Delete button and right click at row level delete button", () => {
	
//     console.log(printTimestamp(), "Hover on delete button and verify tooltip On top right corner Delete button,"
//     +"Submenu Delete button and right click at row level delete button")
// });

// Then("tooltip message should be displayed Selected knowledges either are not allowed for deletion or have associations , please disassociate.", () => {
	
//     console.log(printTimestamp(), 'tooltip message should be displayed Selected knowledges either are not allowed for deletion or have associations , please disassociate.')
// });

When("Click on knowledge name", () => {
    knowledgeDashboard.searchedSecondKnowledgeClick()
    cy.wait(2000)
    console.log(printTimestamp(), 'Click on knowledge name')
});

Then("Delete button should be disabled", () => {
    knowledgeDashboard.deleteButttonWhenClickedOnlinkDisabled()
    knowledgeDashboard.backArrowClick()
    console.log(printTimestamp(), 'Delete button should be disabled')
});

// And("Tooltip message Selected knowledge has associations, please disassociate should be displayed", () => {
	
//     console.log(printTimestamp(), 'Tooltip message Selected knowledge has associations, please disassociate should be displayed')
// });

Then("User Navigate to my Knowledge dashboard", () => {
    knowledgeDashboard.myKnowledgeDashboardClick()
    knowledgeDashboard.rowLevelThreeDotsClick()
    cy.wait(1000)
    knowledgeDashboard.deleteButtonUnderThreeDotsClick()
    cy.wait(1000)
    knowledgeDashboard.okButtonButtonInPopUpClick()
    cy.wait(2000)
    knowledgeDashboard.rowLevelThreeDotsClick()
    cy.wait(1000)
    knowledgeDashboard.deleteButtonUnderThreeDotsClick()
    cy.wait(1000)
    knowledgeDashboard.okButtonButtonInPopUpClick()
    console.log(printTimestamp(), 'User Navigate to my knowledge dashboard')
});

Then("repeat above steps", () => {
	createKnowledge.addKnowledgeWorkflowButtonClick()
    cy.wait(2000)
    cy.CreateMyKnowledgeNormal()
    createKnowledge.saveAsDraftClick()
    cy.wait(3000) 
    createKnowledge.getPatternName()
    cy.wait(1000)
    knowledgeDashboard.knowledgeDashboardClick()
    cy.wait(1000)
    createKnowledge.knowledgeNameInMyPatternSearch()
    knowledgeDashboard.searchIconForKnowledgeNameClick()
    cy.wait(2000)
    knowledgeDashboard.searchedKnowledgeClick()
    knowledgeDashboard.knowledgePublishOptionClick()
    knowledgeDashboard.okButtonButtonInPopUpClick()
    createKnowledge.addKnowledgeWorkflowButtonClick() 
    cy.wait(2000)
    cy.CreateKnowledgeAssociationInMyPattern()
    createKnowledge.saveAsDraftClick()
    cy.wait(3000)
    createKnowledge.getPatternName()
    cy.wait(1000)
    knowledgeDashboard.knowledgeDashboardClick()
    createKnowledge.knowledgeSearchOptionKnowledgeAsscociationType()
    knowledgeDashboard.searchIconForKnowledgeNameClick()
    cy.wait(2000)
    knowledgeDashboard.searchedKnowledgeClick()
    cy.wait(1000)
    knowledgeDashboard.knowledgePublishOptionClick()
    cy.wait(2000)
    knowledgeDashboard.okButtonButtonInPopUpClick()
    knowledgeDashboard.searchedKnowledgeNameRemoveOptionClick()
    cy.wait(2000)
    knowledgeDashboard.myKnowledgeDashboardClick()
    knowledgeDashboard.deleteButtonInKnowledgeDashboardVisible()
    knowledgeDashboard.rowLevelThreeDotsClick()
    knowledgeDashboard.deleteButtonUnderThreeDotsVisible()
    knowledgeDashboard.checkBoxSelectingKnowledgeWithOutAssociationClick()
    knowledgeDashboard.deleteButtonInKnowledgeDashboardEnabled()
    knowledgeDashboard.rowLevelThreeDotsClick()
    knowledgeDashboard.deleteButtonUnderThreeDotsVisible()
    knowledgeDashboard.searchedKnowledgeClick()
    cy.wait(2000)
    knowledgeDashboard.deleteButttonWhenClickedOnlinkEnabled()
    knowledgeDashboard.backArrowClick()
    knowledgeDashboard.unselectingFirstKnowledge()
    knowledgeDashboard.checkBoxSelectingKnowledgeHavingAssociationClick()
    cy.wait(5000)
    knowledgeDashboard.deleteButtonInKnowledgeDashboardDisabled() 
    knowledgeDashboard.rowLevelThreeDotsForAssociatedKnowledgeClick()
    cy.wait(1000)
    knowledgeDashboard.deleteButtonUnderThreeDotsDisabled()
    knowledgeDashboard.searchedSecondKnowledgeClick()
    cy.wait(2000)
    knowledgeDashboard.deleteButttonWhenClickedOnlinkDisabled()
    knowledgeDashboard.backArrowClick()
    knowledgeDashboard.searchedSecondKnowledgeClick()
    cy.wait(2000)
    knowledgeDashboard.deleteButttonWhenClickedOnlinkDisabled()
    knowledgeDashboard.backArrowClick()
    knowledgeDashboard.rowLevelThreeDotsClick()
    cy.wait(1000)
    knowledgeDashboard.deleteButtonUnderThreeDotsClick()
    cy.wait(1000)
    knowledgeDashboard.okButtonButtonInPopUpClick()
    cy.wait(2000)
    knowledgeDashboard.rowLevelThreeDotsClick()
    cy.wait(1000)
    knowledgeDashboard.deleteButtonUnderThreeDotsClick()
    cy.wait(1000)
    knowledgeDashboard.okButtonButtonInPopUpClick()
    console.log(printTimestamp(), 'repeat above steps')
});