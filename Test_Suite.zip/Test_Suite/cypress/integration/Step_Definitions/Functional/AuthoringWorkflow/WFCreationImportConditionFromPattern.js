/// <reference types="Cypress" />
/// <reference types='cypress-tags' /> 

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();

When("User create Authoring Workflow", () => {
    createPattern.myPatternThreeDotsClick()
    createPattern.createPatternButtonClick()
    cy.wait(2000)
    createPattern.patternNameType()
    createPattern.descriptionType()
    createPattern.orderOfExecutionType()
    createPattern.addActionClick()
    cy.wait(1000)
    createPattern.plusIconUnderAddActionClick({ force: true })
    cy.wait(1000)
    createPattern.insertAlertOptionClick()
    console.log(printTimestamp(), 'creates Authoring Workflow')
});

And("Click on Add Condition  Click on + - Click on From Rule Pattern", () => {
    createPattern.addConditionTabClick()
    createPattern.addConditionPlusIconClick()
    cy.wait(2000)
    createPattern.formRulePatternOptionClick()
    console.log(printTimestamp(), 'Clicked on Add Condition  Clicked on + - Clicked on From Rule Pattern')
});

Then("Import Condition pop up should be displayed", () => {
    createPattern.popupVisible()
    console.log(printTimestamp(), 'Import Condition pop up displayed')
});

When("User select Show All option", () => {
    createPattern.ShowCheckboxClick()
    cy.wait(1000)
    console.log(printTimestamp(), 'selects Show All option')
});

Then("Existing  published pattern details based on modality access should be available in Import Conditions pop up", () => {
    createPattern.allFilteredRecordsVisible()
    console.log(printTimestamp(), 'Existing  published pattern details based on modality access available in Import Conditions pop up')
});

And("User Select pattern from Import Conditions pop up", () => {
    createPattern.patternClick()
    console.log(printTimestamp(), 'Selects pattern from Import Conditions pop up')
});

When("User Click on Cancle button", () => {
    createPattern.cancelButtonClick()
    console.log(printTimestamp(), 'Clicked on Cancle button')
});

Then("Selected Pattern details should not be available under Add condition", () => {
    createPattern.addConditionSectionWithOutPatternDetails()
    console.log(printTimestamp(), 'Selected Pattern details not be available under Add condition')
});

And("Data model for that pattern should not be available in imported data model", () => {
    createPattern.importedDataModelSectionWithOutDataModel()
    console.log(printTimestamp(), 'Data model for that pattern not available in imported data model')
});

When("click on + drop down and click on From Rule Pattern option", () => {
    createPattern.addConditionPlusIconClick()
    cy.wait(2000)
    createPattern.formRulePatternOptionClick()
    console.log(printTimestamp(), 'clicked on + drop down and clicked on From Rule Pattern option')
});

Then("Import Conditions pop up should be displayed", () => {
    createPattern.popupVisible()
    createPattern.ShowCheckboxClick()
    cy.wait(1000)
    console.log(printTimestamp(), 'Import Conditions pop up displayed')
});

When("Select Pattern from Import Conditions pop up", () => {
    createPattern.patternThreeClick()
    console.log(printTimestamp(), 'Selects Pattern from Import Conditions pop up')
});

And("Click on Import button", () => {
    createPattern.importButtonClick()
    console.log(printTimestamp(), 'Clicked on Import button')
});

Then("Data model should get added in Imported Data Model for which conditions added from Import Condition pop up", () => {
    createPattern.importedDataModelSectionWithDataModel()
    console.log(printTimestamp(), 'Data model gets added in Imported Data Model for which conditions added from Import Condition pop up')
});

When("Add multiple conditions with attribute, value and operator", () => {
    createPattern.addConditionButtonAtConditionThreeClick()
    createPattern.addConditionButtonAtConditionFourClick()
    console.log(printTimestamp(), 'Added multiple conditions with attribute, value and operator')
});

Then("Attribute,Operator-Attribute vs Value,Between two condition,Value watermark  should be available", () => {
    createPattern.operatorWaterMarkVisible()
    createPattern.valueWaterMarkVisible()
    createPattern.attributeWaterMarkVisible()
    console.log(printTimestamp(), 'Attribute,Operator-Attribute vs Value,Between two condition,Value watermark available')
});

And("When user select option from drop down and enter value watermark-placeholder should not be available", () => {
    createPattern.attributeDropdownAtConditionFourClick()
    createPattern.attributeForSecondConditionClick()
    createPattern.operatorDropdownBetweenAttrAndValueConditionFourClick()
    createPattern.equaltoOperatorClick()
    createPattern.valueInputBoxForConditionFourType()
    createPattern.attributeDropdownAtConditionFiveClick()
    createPattern.attributeForSecondConditionClick()
    createPattern.operatorDropdownBetweenAttrAndValueConditionFiveClick()
    createPattern.equaltoOperatorClick()
    createPattern.valueInputBoxForConditionFiveType()
    console.log(printTimestamp(), 'user select option from drop down and enter value watermark-placeholder not available')
});

When("operator selected between two event", () => {
    createPattern.operatorDropdownAtEventAndConditionBetweenEventTwoAndThreeClick()
    createPattern.andNotOperatorAtEventLevelForEvent2And3Click()
    console.log(printTimestamp(), 'operator selected between two event')
});

Then("Logical expression should be displayed under generated event", () => {
    createPattern.logicalExpressionUnderEventVisible()
    console.log(printTimestamp(), 'Logical expression displayed under generated event')
});

When("Select operator between added conditions", () => {
    createPattern.operatorDropdownAtEventAndConditionForConditionFourClick()
    createPattern.andOperatorOptionsUnderDropdownForConditionFourClick()
    createPattern.operatorDropdownAtEventAndConditionForConditionFiveInEventOneClick()
    createPattern.andOperatorOptionsUnderDropdownForConditionFourClick()
    console.log(printTimestamp(), 'Selects operator between added conditions')
});

And("Add expressions for given condition", () => {
    createPattern.addedCondtionAttributeDropdownForFirstEvent()
    createPattern.addCondtionOptionForTestOneClick()
    cy.AddExpressionPopUpDataFilled()
    console.log(printTimestamp(), 'Added expression for given condition')
});

And("Collapse Add condition", () => {
    createPattern.addConditionTabClick()
    cy.wait(1000)
    console.log(printTimestamp(), 'Collapsed Add condition')
});

Then("Logical expression for added condition should be displayed as tag", () => {
    createPattern.logicalExpressionForAddedConditionExist()
    console.log(printTimestamp(), 'Logical expression for added condition displayed as tag')
});

When("Click on Save as Draft and Verify saved details", () => {
    createPattern.addConditionTabClick()
    cy.wait(1000)
    createPattern.operatorForEventOneClick()
    createPattern.equaltoOperatorClick()
    createPattern.ValueForTestOneType()
    createPattern.addConditionTabClick()
    createPattern.saveAsDraftButtonClick()
    cy.wait(2000)
    console.log(printTimestamp(), 'Clicked on Save as Draft and Verified saved details')
});

When("Expand Add Condition,import patterns conditions", () => {
    createPattern.addConditionTabClick()
    cy.wait(3000)
    createPattern.addConditionIconClick()
    cy.wait(2000)
    createPattern.formRulePatternOptionClick()
    createPattern.ShowCheckboxClick()
    cy.wait(1000)
    createPattern.patternClick()
    createPattern.importButtonClick()
    createPattern.operatorDropdownAtEventAndConditionBetweenEventFourAndFiveClick()
    createPattern.andOperatorForEventClick()
    console.log(printTimestamp(), 'Expanded Add Condition,import patterns conditions')
});

Then("logical expression should get updated and displayed as tag", () => {
    createPattern.updatesLogicalExpressionForAddedConditionExist()
    console.log(printTimestamp(), 'logical expression gets updated and displayed as tag')
}); 


