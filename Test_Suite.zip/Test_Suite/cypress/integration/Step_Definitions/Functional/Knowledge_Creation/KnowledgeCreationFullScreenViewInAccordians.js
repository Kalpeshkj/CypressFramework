/// <reference types="Cypress" />
/// <reference types = 'cypress-tags' />    

import "../../../../support/index"
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import CreateKnowledge from "../../../../support/pageObjects/pages/KnowledgeAuthoring/CreateKnowledge";
const createKnowledge = new CreateKnowledge();
import NavigationPanel from "../../../../support/pageObjects/pages/Dashboard/NavigationPanel";
const navigationPanel = new NavigationPanel();
import { printTimestamp } from '../../../../support/commands';

When("Click on Authoring workflow under My knowledge", () => {
    createKnowledge.knowledgeOptionArrowClick()
    createKnowledge.addKnowledgeWorkflowButtonClick()
    cy.PatternCreation()
    cy.readFile('cypress/fixtures/patternNameCreation.json').then(function (result) {
        var PatternName = result.name;
        createKnowledge.patternName().type(PatternName);
    });
    createKnowledge.description().type(Cypress.env("PatternDescription"));
    cy.wait(2000)
    createKnowledge.saveAsDraftClick()
    cy.wait(2000)
    cy.reload()
    createKnowledge.existingWorkflow()
    createKnowledge.newlyCreatedWokFlow()
    cy.wait(2000)
    console.log(printTimestamp(), 'Clicked on Authoring workflow under My knowledge')
});

Then("User should be able to see the authoring workflow data on right section of the page", () => {
    createKnowledge.knowledgeInformationAccordianClick()
    createKnowledge.knowledgeNameVisible()
    console.log(printTimestamp(), 'User able to see the authoring workflow data on right section of the page')
});

And("By default all accordian Knowledge info, symptoms, causes & solutions and tags for"
    + " selected knowledge should be displayed with knowledge information in expanded state", () => {
        createKnowledge.knowledgeInformationAccordianClick()
        createKnowledge.knowledgeInformationAccordianVisible()
        createKnowledge.symptomAccordianVisible()
        createKnowledge.causeAndSolutionAcordianVisible()
        createKnowledge.tagsAccordianVisible()
        createKnowledge.knowledgeInformationSectionExpandedVerification()
        console.log(printTimestamp(), "By default all accordian Knowledge info, symptoms, causes & solutions and tags for"
            + " selected knowledge should be displayed with knowledge information in expanded state")
    });

When("User Click on symptoms section", () => {
    createKnowledge.symptomSectionClick()
    console.log(printTimestamp(), ' Clicked on symptoms section')
});

Then("Full screen view button should be available at right top corner of symptom section", () => {
    createKnowledge.fullScreenViewButtonInSymptomSectionVisible()
    console.log(printTimestamp(), ' Full screen view button available')
});

When("Click on icon of full screen view", () => {
    createKnowledge.fullScreenViewButtonInSymptomSectionClick()
    console.log(printTimestamp(), ' Clicked on icon of full screen view')
});

Then("Full screen for the symptoms section should be displayed and navigation panel should get collapsed", () => {
    createKnowledge.sypmtomSectionInFullScreen()
    navigationPanel.leftPanelNotVisible()
    navigationPanel.navigationPanelLable()
    console.log(printTimestamp(), ' Full screen for the symptoms section displayed')
});

When("Click on icon of full screen view again", () => {
    createKnowledge.fullScreenButtonInExpandedSymptomSectionClick()
    console.log(printTimestamp(), ' Clicked on icon of full screen view again')
});

Then("The section should retain back to its initial position", () => {
    navigationPanel.leftPanelVisible()
    console.log(printTimestamp(), ' section retained back to its initial position')
});

When("User Refresh application", () => {
    cy.reload()
    console.log(printTimestamp(), ' Application relaunched')
});

Then("Full screen view should not be retained", () => {
    navigationPanel.leftPanelVisible()
    console.log(printTimestamp(), ' Full screen view not retained')
});

And("Repeat above steps for cause and solution section", () => {
    createKnowledge.causeAndSolutionSectionClick()
    createKnowledge.fullScreenViewButtonInCauseAndSolutionSectionVisible()
    createKnowledge.fullScreenViewButtonInCauseAndSolutionSectionClick()
    navigationPanel.leftPanelNotVisible()
    navigationPanel.navigationPanelLable()
    createKnowledge.fullScreenButtonInExpandedCauseAndSolutionSectionClick()
    navigationPanel.leftPanelVisible()
    cy.reload()
    navigationPanel.leftPanelVisible()
    console.log(printTimestamp(), ' Repeated above steps for cause and solution section')
});

