/// <reference types="Cypress" />
/// <reference types='cypress-tags' />

import "../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../support/commands';
import KnowledgeDashboard from "../../../support/pageObjects/pages/Knowledge_Dashboard/KnowledgeDashboard";
import PatternDashboard from "../../../support/pageObjects/pages/Dashboard/PatternDashboard";
const patternDashboard = new PatternDashboard();
const knowledgeDashboard = new KnowledgeDashboard();


When("By default pattern dashboard page is displayed", () => {
    patternDashboard.dashboardButtonVisible();
    console.log(printTimestamp(), ' Pattern dashboard page displayed')
});

When("User clicks on knowledge dropdown and clicks on dashboard", () => {
    knowledgeDashboard.knowledgeClick()
    knowledgeDashboard.knowledgeDashboardClick()
    console.log(printTimestamp(), ' Knowledge dashboard clicked') 
});

Then("Verifies navigation panel, Knowledge as title, Delete button, Data grids, Advance filter hyperlink, "
+"Checkboxes available, entries per page and showing results are present", () => {
    knowledgeDashboard.knowledgedashboardHeadingVisible()
    cy.wait(3000)
    knowledgeDashboard.navigationPanelVerification()
    knowledgeDashboard.deleteButtonInKnowledgeDashboardVisible()
    knowledgeDashboard.advanceFilterHyperlinkVisible()
    patternDashboard.recordsVisible()
    knowledgeDashboard.checkboxesAvailableInEachKnowledgeRecord()
    knowledgeDashboard.knowledgeColumnsDropdownVisible()
    knowledgeDashboard.entriesPerPageVisible()
    knowledgeDashboard.showingResultsVisible()
    console.log(printTimestamp(), ' Details verified in knowledge dashboard')
});

And("Verifies by default filter for modality applied", () => {
    knowledgeDashboard.byDefaultModalityVisible()
    console.log(printTimestamp(), ' By default filter for modality verified')
});

And("Verifies Data grid for Knowledge Dashboard", () => {
    knowledgeDashboard.gridColumnsVerification()
    console.log(printTimestamp(), ' Verified Data grid for Knowledge Dashboard')
});

When("User clicks on column configuration drop down and select all unchecked options", () => {
    knowledgeDashboard.columnSelection()
    console.log(printTimestamp(), ' column configuration drop down clicked')
});

Then("All the newly added columns should be displayed", () => {
    knowledgeDashboard.gridColumnsVerification()
    console.log(printTimestamp(), ' Newly added columns displayed')
});

When("User click on Knowledge name", () => {
    knowledgeDashboard.knowledgeResultClick()
    console.log(printTimestamp(), ' Knowledge name clicked')
});

Then("verifies knowledge details from selected knowledge", () => {
    knowledgeDashboard.knowledgeNameVisible()
    knowledgeDashboard.descriptionSectionVisible()
    knowledgeDashboard.closeButtonClick()
    console.log(printTimestamp(), ' Knowledge details verified')
});

When("User clicks on any of the knowledge row , without clicking on the hyperlink", () => {
    knowledgeDashboard.FirstRecordClick()
    console.log(printTimestamp(), ' Clicked on any of the knowledge')
});

Then("Knowledge Overlay section should pop up with knowledge name, knowledge Association, View option should displayed", () => {
    knowledgeDashboard.knowledgeOverlayPopUpDetailsVerification()
    console.log(printTimestamp(), ' Knowledge Overlay section displayed')
});

When("User clicks on cross icon on the overlay section", () => {
    knowledgeDashboard.closeIconInOverlayClick()
    console.log(printTimestamp(), ' Clicked on cross icon')
});

When("User clicks on My Knowledge dashboard under knowledge option", () => {
    knowledgeDashboard.knowledgeClick()
    knowledgeDashboard.myKnowledgeClick()
    knowledgeDashboard.myKnowledgeDashboardClick()
    console.log(printTimestamp(), ' Knowledge dashboard clicked')
});

Then("User should be navigated to my knowledge Dashboard", () => {
    knowledgeDashboard.knowledgedashboardHeadingVisible()
    console.log(printTimestamp(), ' Knowledge details verified')
});

And("Verifies by default filter for modality", () => {
    knowledgeDashboard.modalityInKnowledgeDashboardVerification()
    console.log(printTimestamp(), ' By default filter for modality verified')
});