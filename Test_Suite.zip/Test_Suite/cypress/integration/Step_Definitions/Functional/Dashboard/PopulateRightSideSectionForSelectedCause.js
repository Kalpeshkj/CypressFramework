/// <reference types="Cypress" />
/// <reference types = 'cypress-tags' />      
import "../../../../support/index"
import { When, Then } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import IncludeKnowledge from "../../../../support/pageObjects/pages/PatternAuthoring/includeKnowledgepageObj";
const includeKnowledge = new IncludeKnowledge();

When("Navigate to existing wf, fill details in create pattern and apply metadata page", () => {
    cy.createPattern()
    cy.get('#pat-step-next > .pt-layout-container > span').click()
    cy.wait(5000)

    cy.ApplyMetaDetaPageCompletion()
    cy.get('#pat-step-next > .pt-layout-container > span').click({ force: true })
    cy.wait(5000)
    console.log(printTimestamp(), 'navigate to new workflow fill details in create pattern and apply metadata page')
});

Then("User should be able to navigate to Include Knowledge step", () => {
    includeKnowledge.includeKnowledgePageVisible()
    console.log(printTimestamp(), 'navigate to Include Knowledge step')
});

When("User Click on show all checkbox", () => {
    includeKnowledge.showAllCheckboxClick()
    console.log(printTimestamp(), 'Clicked on show all checkbox')
});

Then("Data should be displayed in grid", () => {
    includeKnowledge.dataInGridVisible()
    console.log(printTimestamp(), 'Data displayed in grid')
});

When("User Select any knowledge name", () => {
    includeKnowledge.firstKnowledgwSelect()
    console.log(printTimestamp(), 'Selects any knowledge name')
});

Then("Right side section should be displayed for selected knowledge", () => {
    includeKnowledge.selectedKnowledgeTextInRightSection()
    console.log(printTimestamp(), 'Right side section displayed for selected knowledge')
});

Then("Icon > to collapse right side section should be displayed at bottom of between left and right section", () => {
    includeKnowledge.iconToCollaspeRightSideSectionVisible()
    console.log(printTimestamp(), 'Icon > to collapse right side section displayed at bottom of between left and right section')
});

When("Click on > available between left and right section at bottom", () => {
    includeKnowledge.iconToCollaspeRightSideSectionClick()
    console.log(printTimestamp(), 'Clicked on > available between left and right section at bottom')
});

When("Right side section should get collapsed", () => {
    includeKnowledge.KnowledgeDetailsTextWhenRightSideCollapse()
    console.log(printTimestamp(), 'Right side section get collapsed')
});

When("Icon < to expand right side section should be displayed", () => {
    includeKnowledge.iconToExpandRightSideSectionVisible()
    console.log(printTimestamp(), 'Icon < to expand right side section displayed')
});

When("At right side horizontally Knowledge Details name should be available", () => {
    includeKnowledge.KnowledgeDetailsLableVisible()
    console.log(printTimestamp(), 'At right side horizontally Knowledge Details name available')
});

When("Click on < available at right side Knowledge Details", () => {
    includeKnowledge.iconToExpandRightSideSectionClick()
    console.log(printTimestamp(), 'Clicked on < available at right side Knowledge Details')
});

Then("Right side section should get expanded and details should be displayed", () => {
    includeKnowledge.iconToCollaspeRightSideSectionVisible()
    includeKnowledge.knowledgeDetailsInIncludeTabVisible()
    console.log(printTimestamp(), ' Right side section expanded and details displayed')
});

When("User Select multiple knowledge name", () => {
    includeKnowledge.multipleknowledgeSelection()
    console.log(printTimestamp(), 'User Selects multiple knowledge name')
});

Then("Right side section should be displayed for last selected knowledge", () => {
    includeKnowledge.knowledgeInRightSection()
    console.log(printTimestamp(), 'Right side section displayed for last selected knowledge')
});

When("Select All checkbox for knowledge name", () => {
    includeKnowledge.showAllNameCheckBoxClick()
    console.log(printTimestamp(), 'Clicked on Select All checkbox for knowledge name')
});

Then("Right side section should be displayed for first selected knowledge available for that page", () => {
    includeKnowledge.selectedKnowledgeTextInRightSection()
    console.log(printTimestamp(), 'Right side section displayed for first selected knowledge available for that page')
});

Then("Navigate to Review tab", () => {
    includeKnowledge.reviewTabClick()
    console.log(printTimestamp(), 'Navigated to Review tab ')
});

Then("Repeat above steps in Review tab", () => {
    includeKnowledge.detaInReviewTabGridVisible()
    includeKnowledge.firstKnowledgwSelectInReviewTab()
    includeKnowledge.selectedKnowledgeTextInRightSection()
    includeKnowledge.iconToCollaspeRightSideSectionInReviewTabVisible()
    includeKnowledge.iconToCollaspeRightSideSectionInReviewTabClick()
    includeKnowledge.KnowledgeDetailsTextWhenRightSideCollapse()
    includeKnowledge.iconToExpandRightSideSectionInReviewTabVisible()
    includeKnowledge.KnowledgeDetailsTextWhenRightSideCollapseInReviewTabVisible()
    includeKnowledge.iconToExpandRightSideSectionInReviewTabClick()
    includeKnowledge.knowledgeDetailsInReviewTabVisible()
    includeKnowledge.secondKnowledgeInReviewTabClick()
    includeKnowledge.iconToCollaspeRightSideSectionInReviewTabVisible()
    console.log(printTimestamp(), 'Repeated above steps in Review tab')
});

Then("Close DAW application", () => {
    cy.DeleteWorkflow()
    cy.log("Test Case Executed Successfully")
    console.log(printTimestamp(), ' Test Case Executed Successfully')
});
