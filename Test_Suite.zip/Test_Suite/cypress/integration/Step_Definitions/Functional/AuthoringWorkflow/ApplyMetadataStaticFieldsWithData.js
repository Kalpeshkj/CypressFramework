/// <reference types="Cypress" />
/// <reference types='cypress-tags' />
import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();
import NavigationPanel from "../../../../support/pageObjects/pages/Dashboard/NavigationPanel";
const  navigationPanel = new NavigationPanel(); 
import ApplyMetadata from "../../../../support/pageObjects/pages/PatternAuthoring/applyMetadata";
const applyMetadata = new ApplyMetadata();

When("User create Authoring Workflow", () => {
    cy.createPattern()
    createPattern.SaveAsDraftClick()
    cy.wait(2000)
    createPattern.getPatternName()
    console.log(printTimestamp(), 'User created Authoring Workflow')
});
 
And("Click on next button", () => {
    createPattern.nextButtonClick()
    console.log(printTimestamp(), 'Clicked on next button')
});

And("navigate to the apply Metadata page", () => {
	applyMetadata.applyMetadataActiveVerification() 
    cy.ApplyMetaDetaPageCompletionForPatternCreation()
    console.log(printTimestamp(), 'navigated to the apply Metadata page')
});

Then("Steps header should be highlighted with the 2 Apply Metadata", () => {
    applyMetadata.applyMetadataHeadingActiveVerification()
    console.log(printTimestamp(), 'Steps header highlighted with the 2 Apply Metadata')
});

And("pattern  section should be ticked right mark Include Knowledge,Validate and Request review should be disabled", () => {
    createPattern.createPatternWithRightMarkVisible()
    createPattern.includeKnowledgeHeadingPendingVerification()
    createPattern.validateHeadingPendingVerification()
    createPattern.requestReviewHeadingPendingVerification()
    console.log(printTimestamp(), 'pattern  section ticked right mark Include Knowledge,Validate and Request review disabled')
});

And("Pattern name with i info icon at left corner Version and Full Screen icon at right corner"
+" e.g. Version : Draft version icon full screen icon", () => {
	applyMetadata.newlyCreatedPatternTextWithISymbolVisible()
    console.log(printTimestamp(), "Pattern name with i info icon at left corner Version and Full Screen icon at right corner"
    +" e.g. Version : Draft version icon full screen icon")
});

// When("Hover on i info icon", () => {
// 	createPattern.hoveredOnIIcon()
//     console.log(printTimestamp(), 'Hovered on i info icon')
// });

// Then("Description should be displayed while hovering on i info icon", () => {
	
//     console.log(printTimestamp(), 'Description displayed while hovering on i info icon')
// });

And("Previous,Close - enabled,Save as Draft - enabled,Next  - enabled", () => {
	applyMetadata.previousButtonVisible()
    applyMetadata.closeButtonEnabled()
    applyMetadata.saveAsDraftEnabled()
    applyMetadata.nextButtonEnabledVerification()
    console.log(printTimestamp(), 'Previous,Close - enabled,Save as Draft - enabled,Next  - enabled')
});

And("Time Span mandatory Comment nonmandatory,with default watermark as Comment"
+" Tags Non mandatory  where tags should be Placeholder", () => {
    applyMetadata.timeSpanOptionVisible()
    applyMetadata.commentBoxWithWatermark()
    applyMetadata.tagsOptionVisible()
    console.log(printTimestamp(), "Time Span mandatory Comment nonmandatory,with default watermark as Comment"
    +" Tags Non mandatory  where tags Placeholder")
});

And("Watermark for Day span should be available as 24 Default.", () => {
	applyMetadata.daySpanTextBoxWithDefaultWatermark()
    console.log(printTimestamp(), 'Watermark for Day span available as 24 Default."')
});

And("Default value should be available as 24", () => {
    applyMetadata.daySpanTextBoxWithDefaultWatermark()
    console.log(printTimestamp(), 'Default value available as 24')
});

And("Default unit should be available as h", () => {
    applyMetadata.daySpanUnitTextBoxWithDefaultUnit()
    console.log(printTimestamp(), 'Default unit available as h')
});

And("h-representing hours value,d-representing days value units should be available in time span unit drop down", () => {
	applyMetadata.daySpanUnitTextBoxClick()
    applyMetadata.daySpanUnitDropdownOptions()
    console.log(printTimestamp(), 'h-representing hours value,d-representing days value units available in time span unit drop down')
});

And("Place holder should be available Range 0 to 999", () => {
	applyMetadata.rangePlaceholderVisible()
    console.log(printTimestamp(), 'Place holder available Range 0 to 999')
});

And("Only positive numeric value should be allowed", () => {
	applyMetadata.daySpanTextBoxTypeLessThanOneShowingRedBorderVerification()
    console.log(printTimestamp(), 'Only positive numeric value allowed')
});

And("User should not be able to enter beyond 999 value", () => {
	applyMetadata.daySpanTextBoxTypeMoreThan999ShowingRedBorderVerification()
    console.log(printTimestamp(), 'User not able to enter beyond 999 value')
});

When("entered value is removed", () => {
	applyMetadata.removingValueFromDaySpanTextBox()
    console.log(printTimestamp(), 'entered value is removedentered value is removed')
});

Then("Text box should be highlighted with red color", () => {
	applyMetadata.daySpanTextBoxTypeLessThanOneShowingRedBorderVerification()
    console.log(printTimestamp(), 'Text box highlighted with red color')
});

And("Watermark for Day Span should be available as 24 Default.Default value should be taken as 24", () => {
    applyMetadata.daySpanTextBoxWithDefaultWatermark()
    console.log(printTimestamp(), 'Watermark for Day Span available as 24 Default.Default value  taken as 24')
});

When("User Enter data in comment field", () => {
	applyMetadata.commentBoxWithCommentype()
    console.log(printTimestamp(), 'User Entered data in comment field')
});

Then("field Left characters count should get decreases", () => {
	applyMetadata.commentFieldCharacterTextDecreased()
    console.log(printTimestamp(), 'field Left characters count gets decreases')
});

When("Remove data from comment field", () => {
	applyMetadata.commentBoxWithOutComment()
    console.log(printTimestamp(), 'Removed data from comment field')
});

Then("field Left characters count should get increased  e.g Characters left:4000 out of 4000",() => {
	applyMetadata.commentFieldCharacterTextWithOriginalCount()
    applyMetadata.addCommnetInCommentBoxType()
    console.log(printTimestamp(), 'field Left characters count gets increased  e.g Characters left:4000 out of 4000 ')
});

When("Click on Full Screen icon", () => {
	applyMetadata.fullScreenViewButtonClick()
    console.log(printTimestamp(), 'Clicked on Full Screen icon')
});

Then("Screen should go into Full view where the left pane gets collapsed", () => {
    navigationPanel.leftPanelNotVisible()
    console.log(printTimestamp(), 'Screen go into Full view where the left pane gets collapsed')
});

And("steps and buttons are hide", () => {
    navigationPanel.leftPanelNotVisible()
    // applyMetadata.buttonsNotVisibleOnApplyMetadataPageVerification()
    console.log(printTimestamp(), 'steps and buttons are hide')
});

When("Expand left pane", () => {
    navigationPanel.ArrowMarkClick()
    console.log(printTimestamp(), 'Expanded left pane')
});

Then("Apply metadata page should get resized -default size", () => {
    navigationPanel.patternExpanded()
    console.log(printTimestamp(), 'Apply metadata page gets resized -default size')
});

When("Click on Full Screen icon", () => {
	applyMetadata.fullScreenViewButtonClick()
    console.log(printTimestamp(), 'Clicked on Full Screen icon')
});

Then("Screen should go into Full view where the left pane gets collapsed", () => {
	navigationPanel.leftPanelNotVisible()
    console.log(printTimestamp(), 'Screen goes into Full view where the left pane gets collapsed')
});

And("steps and buttons are hide", () => {
	navigationPanel.leftPanelNotVisible()
    // applyMetadata.buttonsNotVisibleOnApplyMetadataPageVerification()
    console.log(printTimestamp(), 'Entered unique pattern name')
});

When("Click on Full Screen icon", () => {
    applyMetadata.fullScreenViewButtonClick()
    console.log(printTimestamp(), 'Clicked on Full Screen icon')
});

Then("Apply metadata page should get resized -default size", () => {
	applyMetadata.applyMatadataPageResizedToDefaultSizeVerification()
    console.log(printTimestamp(), 'Apply metadata page gets resized -default size')
});

And("The version icon should be displayed with pattern version value.", () => {
	applyMetadata.versionIconVisible()

    console.log(printTimestamp(), 'The version icon displayed with pattern version value.')

});

When("Add content in any field", () => {
	applyMetadata.daySpanTextBoxTypeTen()
    console.log(printTimestamp(), 'Added content in any field')
});

Then("Save as Draft button should be enabled", () => {
	applyMetadata.saveAsDraftOnCreatePatternEnabled()
    console.log(printTimestamp(), 'Save as Draft button enabled')
});

When("Click on Save as Draft Create Pattern-Apply Metadata Page", () => {
	applyMetadata.SaveAsDraftClick()
    cy.wait(2000)
    console.log(printTimestamp(), 'Clicked on Save as Draft Create Pattern-Apply Metadata Page')
});

Then("data entered it should be displayed in pattern details view page", () => {
	createPattern.myPatternDashboardClick()
    cy.wait(1000)
    createPattern.patternFilterOptionType()
    createPattern.searchButtonClick()
    cy.wait(1000)
    createPattern.firstPatternInMyPatternClick()
    cy.wait(2000)
	applyMetadata.enteredDetailsOfApplyMetadataPageVisibleVerification()
    createPattern.patternNameOnDetailsPageClick()
    console.log(printTimestamp(), 'data entered it displayed in pattern details view page')
});


When("Click on Previous button", () => {
	applyMetadata.previousButtonClick()
    console.log(printTimestamp(), 'Clicked on Previous button')
});

Then("User should be navigate to Create Pattern page", () => {
	createPattern.createPatternPageVisible()
    console.log(printTimestamp(), 'User navigate to Create Pattern page')
});

When("Click on Next button", () => {
    createPattern.nextButtonClick()
    console.log(printTimestamp(), 'Clicked on Next button')
});

Then("navigate to Apply Metadata Page", () => {
	applyMetadata.applyMetadataHeadingActiveVerification()
    console.log(printTimestamp(), 'navigated to Apply Metadata Page')
});

And("Entered details should be available", () => {
	applyMetadata.enteredDetailsOfApplyMetadataPageVisibleVerification()
    console.log(printTimestamp(), 'Entered details available')
});

