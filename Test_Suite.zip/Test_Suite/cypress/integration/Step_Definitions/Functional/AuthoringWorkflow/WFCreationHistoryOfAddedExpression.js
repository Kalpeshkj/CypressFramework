/// <reference types="Cypress" />
/// <reference types='cypress-tags' />  
import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();

When("User add multiple events with conditions From Data Model option", () => {
    createPattern.formDataModelClick()
    cy.wait(1000)
    createPattern.eventLogAttributeClick()
    createPattern.additionalInfoAttributeClick()
    createPattern.operatorForEventOneClick()
    createPattern.equaltoOperatorClick()
    createPattern.ValueForTestOneType()
    cy.wait(1000)
    createPattern.addConditionPlusIconClick()
    cy.wait(1000)
    createPattern.formDataModelClick()
    cy.wait(1000)
    createPattern.importedEventLogModelClick()
    createPattern.dataModelAdditionalInfoAttributeClick()
    createPattern.opeartorDropDownForEvent3ConditionOneClick()
    createPattern.equaltoOperatorClick()
    createPattern.valueForFirstConditionInThridEventType()
    console.log(printTimestamp(), 'added multiple events with conditions From Data Model option')
});

And("add multiple expressions in condition C1 for E1 event", () => {
    createPattern.addedCondtionAttributeDropdownInFirstEventClick()
    createPattern.addCondtionOptionForTestOneClick()
    createPattern.operatorOneDropdownFortetsOneClick()
    createPattern.absOperatorforTestOneClick()
    createPattern.attributeOneDropDownArrowForTestOneClick()
    createPattern.eventLogOneUnderAttributeclick()
    createPattern.OperatorForeventLog1UnderAtribute1Click()
    createPattern.operatorTwoFortetsOneClick()
    createPattern.starOperatorforTestOneClick()
    createPattern.attributetwoArrowForTestOneClick()
    createPattern.eventLogOneUnderAttributeclick()
    createPattern.OperatorForeventLog1UnderAtribute2InExpressionPopUpClick()
    createPattern.doneButtonClickInPopUpClick()
    createPattern.addedCondtionAttributeDropdownInFirstEventClick()
    createPattern.addCondtionOptionForTestOneClick()
    createPattern.operatorOneDropdownFortetsOneClick()
    createPattern.absOperatorforTestOneClick()
    createPattern.attributeOneDropDownArrowForTestOneClick()
    createPattern.eventLogOneUnderAttributeclick()
    createPattern.OperatorForeventLog1UnderAtribute1Click()
    createPattern.operatorTwoFortetsOneClick()
    createPattern.starOperatorforTestOneClick()
    createPattern.attributetwoArrowForTestOneClick()
    createPattern.eventLogOneUnderAttributeclick()
    createPattern.OperatorForeventLog1UnderAtribute2InExpressionPopUpClick()
    createPattern.doneButtonClickInPopUpClick()
    console.log(printTimestamp(), 'added multiple expressions in condition C1 for E1 event')
});

And("add condition C2 in event E1", () => {
    createPattern.addedExpressionForEventOneInConditionOne()
    createPattern.addConditionButtonForeventOneClick()
    console.log(printTimestamp(), 'added condition C2 in event E1')
});

And("In condition C2 of E1 click on attribute dropdown", () => {
    createPattern.addedCondtionAttributeDropdownForConditionTwoEventOneClick()
    console.log(printTimestamp(), 'In condition C2 of E1 clicked on attribute dropdown')
});

Then("All added expressions for C1 should be available", () => {
    createPattern.expressionAddedInC1VisibleInC2OfEventVerification()
    console.log(printTimestamp(), 'All added expressions for C1 available')
});

When("Clicked on attribute dropdown Of condition C1 of E2", () => {
    createPattern.addedCondtionAttributeDropdownForConditionTwoEventOneClick()
    createPattern.addedCondtionAttributeDropdownClick()
    console.log(printTimestamp(), 'Clicked on attribute dropdown Of condition C1 of E2')
});

Then("Added expression for C1 of E1 should not be available in C1 of E2", () => {
    createPattern.expressionAddedInC1NotVisibleInE2Verification()
    console.log(printTimestamp(), 'Added expression for C1 of E1 not be available in C1 of E2')
});

When("User add multiple expression in condition C1 for E2 event", () => {
    createPattern.addCondtionOptionForTestOneClick()
    createPattern.addConditionPopUpVisible()
    createPattern.operatorOneDropdownFortetsOneClick()
    createPattern.absOperatorforTestOneClick()
    createPattern.attributeOneDropDownArrowForTestOneClick()
    createPattern.eventLogOneUnderAttributeclick()
    createPattern.OperatorForeventLog1UnderAtribute1Click()
    createPattern.operatorTwoFortetsOneClick()
    createPattern.slashOperatorforTestOneClick()
    createPattern.attributetwoArrowForTestOneClick()
    createPattern.eventLogOneUnderAttributeclick()
    createPattern.OperatorForeventLog1UnderAtribute2Click()
    createPattern.doneButtonClickInPopUpClick()
    createPattern.addedCondtionAttributeDropdownClick()
    createPattern.addCondtionOptionForTestOneClick()
    createPattern.addConditionPopUpVisible()
    createPattern.operatorOneDropdownFortetsOneClick()
    createPattern.absOperatorforTestOneClick()
    createPattern.attributeOneDropDownArrowForTestOneClick()
    createPattern.eventLogOneUnderAttributeclick()
    createPattern.OperatorForeventLog1UnderAtribute1Click()
    createPattern.operatorTwoFortetsOneClick()
    createPattern.starOperatorforTestOneClick()
    createPattern.attributetwoArrowForTestOneClick()
    createPattern.eventLogOneUnderAttributeclick()
    createPattern.OperatorForeventLog1UnderAtribute2Click()
    createPattern.doneButtonClickInPopUpClick()
    console.log(printTimestamp(), 'added multiple expression in condition C1 for E2 event')
});

And("add condition C2 in event E2", () => {
    createPattern.addConditionButtonAtConditionThreeClick()
    console.log(printTimestamp(), 'added condition C2 in event E2')
});

When("Clicked on attribute dropdown Of condition C2 of E2", () => {
    createPattern.addedCondtionAttributeDropdownForConditionTwoEventTwoClick()
    createPattern.firstAddedExpressionInC1OfE2()
    console.log(printTimestamp(), 'Clicked on attribute dropdown Of condition C2 of E2')
});

Then("All added expression for C1 of E2 should be available to add in C2 in E2", () => {
    createPattern.expressionAddedInC1VisibleInC2OfEventVerification()
    console.log(printTimestamp(), 'All added expression for C1 of E2 available to add in C2 in E2')
});

When("User Delete condition e.g C1 from E2", () => {
    createPattern.conditionRemoveIconOfConditionOneInEventTwoClick()
    console.log(printTimestamp(), 'Deleted condition e.g C1 from E2')
});

Then("Expression added in that condition should not be available for further use in E2", () => {
    createPattern.addedCondtionAttributeDropdownForConditionOneEventTwoClick()
    createPattern.expressionAddedInC1NotVisibleInE2Verification()
    createPattern.operatorForEventLastClick()
    createPattern.equaltoOperatorClick()
    createPattern.ValueForEventOneType()
    createPattern.unitDropdownClick()
    createPattern.msUnitClick()
    createPattern.operatorForFirstEventConditionOneClick()
    createPattern.equaltoOperatorClick()
    createPattern.ValueForTestOneType()
    console.log(printTimestamp(), 'Expression added in that condition not available for further use in E2')
});

And("Previously added expression in that condition should be available for further use within event within that session "
    + "if user navigate from other wf then history should not be available for further use", () => {
        createPattern.addedCondtionAttributeDropdownForConditionOneEventTwoClick()
        createPattern.firstExpressionAddedInC1VisibleInC2OfEventVerification()
        createPattern.addedCondtionAttributeDropdownForConditionOneEventTwoClick()
        createPattern.attributeForSecondConditionInFirstEventClick()
        createPattern.attributeForSecondConditionClick()
        createPattern.operatorDropDownForSecondConditionClick()
        createPattern.equalToOperatorForSecondConditonClick()
        createPattern.valueForSecondConditionFirstEventType()
        createPattern.addActionClick()
        createPattern.plusIconUnderAddActionClick()
        cy.wait(1000)
        createPattern.raiseAlertOptionClick()
        console.log(printTimestamp(), "Previously added expression in that condition available for further use within event within that session"
            + " if user navigate from other wf then history not available for further use")
    });

// And("Tooltip should be available for added expression in attribute drop down list", () => {

//     console.log(printTimestamp(), 'Tooltip available for added expression in attribute drop down list')
// });

And("Relaunch DAW application", () => {
    cy.reload()
    cy.wait(5000)
    console.log(printTimestamp(), 'Relaunched DAW application')
});

Then("List of added expression which are used should be available in drop down within event level", () => {
    createPattern.addConditionOptionClick()
    createPattern.addedCondtionAttributeDropdownInFirstEventClick()
    createPattern.addedExpressionInDropdownOfC1InE1Exist()
    console.log(printTimestamp(), 'List of added expression which are used available in drop down within event level')
});

When("User Add multiple expression across event", () => {
    createPattern.addedCondtionAttributeDropdownInFirstEventClick()
    createPattern.addedCondtionAttributeDropdownForConditionOneEventTwoClick()
    createPattern.addCondtionOptionForTestOneClick()
    createPattern.operatorOneDropdownFortetsOneClick()
    createPattern.absOperatorforTestOneClick()
    createPattern.attributeOneDropDownArrowForTestOneClick()
    createPattern.eventLogOneUnderAttributeclick()
    createPattern.OperatorForeventLog1UnderAtribute1Click()
    createPattern.operatorTwoFortetsOneClick()
    createPattern.slashOperatorforTestOneClick()
    createPattern.attributetwoArrowForTestOneClick()
    createPattern.eventLogOneUnderAttributeclick()
    createPattern.OperatorForeventLog1UnderAtribute2Click()
    createPattern.doneButtonClickInPopUpClick()
    createPattern.addedCondtionAttributeDropdownClick()
    createPattern.addCondtionOptionForTestOneClick()
    createPattern.addConditionPopUpVisible()
    createPattern.operatorOneDropdownFortetsOneClick()
    createPattern.absOperatorforTestOneClick()
    createPattern.attributeOneDropDownArrowForTestOneClick()
    createPattern.eventLogOneUnderAttributeclick()
    createPattern.OperatorForeventLog1UnderAtribute1Click()
    createPattern.operatorTwoFortetsOneClick()
    createPattern.starOperatorforTestOneClick()
    createPattern.attributetwoArrowForTestOneClick()
    createPattern.eventLogOneUnderAttributeclick()
    createPattern.OperatorForeventLog1UnderAtribute2Click()
    createPattern.doneButtonClickInPopUpClick()
    console.log(printTimestamp(), 'Added multiple expression across event')
});

Then("In drop down list of expression should be available within event", () => {
    createPattern.addedCondtionAttributeDropdownForConditionOneEventTwoClick()
    createPattern.firstExpressionAddedInC1VisibleInC2OfEventVerification()
    console.log(printTimestamp(), 'In drop down list of expression available within event')
});
