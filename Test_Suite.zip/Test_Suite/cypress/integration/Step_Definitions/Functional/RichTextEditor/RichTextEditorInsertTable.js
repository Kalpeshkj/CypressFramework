/// <reference types="Cypress" />
/// <reference types='cypress-tags' />  
import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import PatternDashboard from "../../../../support/pageObjects/pages/Dashboard/PatternDashboard";
const patternDashboard = new PatternDashboard();
import CreateKnowledge from "../../../../support/pageObjects/pages/KnowledgeAuthoring/CreateKnowledge";
const createKnowledge = new CreateKnowledge();
Then("Pattern Dashboard page should be displayed", () => {
    patternDashboard.patternDashboardTitleVisible()
    cy.wait(2000)
    console.log(printTimestamp() ,'Pattern Dashboard page displayed')
});

When("User create new Authoring Workflow", () => {
    createKnowledge.MyknowledgeArrowClick()
    createKnowledge.AddAuthoringWokFlowButtonClick()
    cy.wait(3000)
    createKnowledge.workFlowMessageVisible()
    console.log(printTimestamp() ,'New Authoring Workflow Created')
});

And("Expand Cause and Solution section", () => {
    createKnowledge.causeAndSolutionSectionClick()
    console.log(printTimestamp() ,'Expanded Cause and Solution section')
});

And("Click on Add Cause", () => {
    createKnowledge.addCauseClick()
    cy.wait(1000)
    console.log(printTimestamp() ,'Clicked on Add Cause')
});

Then("Rich Text Editor should appear", () => {
    createKnowledge.richTextEditorWindowVisible()
    console.log(printTimestamp() ,'Rich Text Editor appeared')
});

When("User select matrix", () => {
    createKnowledge.insertTableOptionClick()
    createKnowledge.matrixClick()
    console.log(printTimestamp() ,'Rich Text Editor appeared')
});

Then("Based on selected matrix , Table should get inserted in Rich Text", () => {
	createKnowledge.addedTableVisible()
    console.log(printTimestamp() ,'Rich Text Editor appeared')
});

When("User Select any cell from table", () => {
	createKnowledge.firstCellClick()
    console.log(printTimestamp() ,'Rich Text Editor appeared')
});

Then("Table Header,Remove Table,Row -with drop down values Insert row above,Insert row below,Delete row", () => {
	createKnowledge.tableHeaderOptionVisible()
    createKnowledge.removeTableOptionVisible()
    createKnowledge.rowOptionVisible()
    createKnowledge.rowOptionClick()
    cy.wait(1000)
    createKnowledge.insertRowAboveOptionVisible()
    createKnowledge.insertRowBelowOptionVisible()
    createKnowledge.deleteRowOptionVisible()
    console.log(printTimestamp() ,'Rich Text Editor appeared')
});

And("Column with drop down values Insert column before,Insert column after,Delete column", () => {
	createKnowledge.columnOptionVisible()
    createKnowledge.columnOptionClick()
    createKnowledge.insertColumnBeforeOptionVisible()
    createKnowledge.insertColumnAfterOptionVisible()
    createKnowledge.deleteColumnOptionVisible()
    console.log(printTimestamp() ,'Rich Text Editor appeared')
});

And("Table style with drop down values Dashed Borders,Alternate Rows", () => {
	createKnowledge.tableStyleOptionVisible()
    createKnowledge.tableStyleOptionClick()
    createKnowledge.dashedBordersOptionVisible()
    createKnowledge.alternateRowsOptionVisible()
    console.log(printTimestamp() ,'Rich Text Editor appeared')
});

And("Cell with drop down values Merge Cells,Vertical Split,Horizontal Split", () => {
	createKnowledge.tableCellOptionVisible()
    createKnowledge.tableCellOptionClick()
    createKnowledge.mergeCellOptionVisible()
    createKnowledge.verticalSplitOptionVisible()
    createKnowledge.horizontalSplitOptionVisible()
    console.log(printTimestamp() ,'Rich Text Editor appeared')
});

And("Cell Background back button,colors with delete icon , text box for HEX color and ok button", () => {
	createKnowledge.cellBackgroundOptionVisible()
    createKnowledge.cellBackgroundOptionClick()
    createKnowledge.backButtonVisible()
    createKnowledge.colorsVisible()
    createKnowledge.deleteButtonUnderCellBackGroundOptionVisible()
    createKnowledge.textBoxForHEXColorsVisible()
    createKnowledge.okButtonUnderCelBackgroundOptionVisible()
    createKnowledge.backButtonClick()
    console.log(printTimestamp() ,'Rich Text Editor appeared')
});

And("Vertical Align with drop down values Top,Middle,Bottom", () => {
	createKnowledge.verticalAllignmentOptionVisible()
    createKnowledge.verticalAllignmentOptionClick()
    createKnowledge.allignmentTopOptionVisible()
    createKnowledge.allignmentMiddleOptionVisible()
    createKnowledge.allignmentBottomOptionVisible()
    console.log(printTimestamp() ,'Rich Text Editor appeared')
});

And("Horizontal Align with drop down values Align Left,Align Center,Align right,Align Justify", () => {
	createKnowledge.horizontalAllignOptionVisible()
    createKnowledge.horizontalAllignOptionClick()
    cy.get(1000)
    createKnowledge.allignLeftOptionVisible()
    createKnowledge.allignCenterOptionVisible()
    createKnowledge.allignRightOptionVisible()
    createKnowledge.allignJustifyOptionVisible()
    console.log(printTimestamp() ,'Rich Text Editor appeared')
});

And("Cell Style with drop down values Highlighted and Thick", () => {
	createKnowledge.cellStyleOptionVisible()
    createKnowledge.cellStyleOptionClick()
    createKnowledge.highlightedOptionVisible()
    createKnowledge.thickOptionVisible()
    console.log(printTimestamp() ,'Rich Text Editor appeared')
});

When("table header option is selected", () => {
	createKnowledge.tableHeaderOptionClick()
    console.log(printTimestamp() ,'Rich Text Editor appeared')
});

Then("Table header with gray color should get added", () => {
    createKnowledge.addedTableHeaderVisible()
    console.log(printTimestamp() ,'Rich Text Editor appeared')
});

When("unselected header option", () => {
    createKnowledge.tableHeaderOptionClick()
    console.log(printTimestamp() ,'Rich Text Editor appeared')
});

Then("Table header row should get removed", () => {
	createKnowledge.addedTableHeaderRemoved()
    console.log(printTimestamp() ,'Rich Text Editor appeared')
});

When("Click on Remove Delete icon", () => {
    createKnowledge.firstCellClick()
	createKnowledge.removeTableOptionClick()
    cy.wait(1000)
    console.log(printTimestamp() ,'Rich Text Editor appeared')
});

Then("Table should get removed from rich text editor", () => {
	createKnowledge.firstCellNotExist()
    console.log(printTimestamp() ,'Rich Text Editor appeared')
});

When("Select matrix", () => {
    createKnowledge.insertTableOptionClick()
    createKnowledge.matrixClick()
    console.log(printTimestamp() ,'Selects matrix')
});

Then("Based on selected matrix , Table should get inserted in Rich Text", () => {
    createKnowledge.addedTableVisible()
    console.log(printTimestamp() ,'Based on selected matrix , Table inserted in Rich Text')
});

When("user selected Insert row above", () => {
    createKnowledge.firstCellClick()
	createKnowledge.rowOptionClick()
    createKnowledge.insertRowAboveOptionClick()
    console.log(printTimestamp() ,'selects Insert row above')
});

Then("above current row new row should get added", () => {
	createKnowledge.addedTableRowAbove()
    console.log(printTimestamp() ,'above current row new row gets added')
});

When("user selected Insert row below", () => {
    createKnowledge.rowOptionClick()
	createKnowledge.insertRowBelowOptionClick()
    console.log(printTimestamp() ,'selectes Insert row below')
});

Then("below current row new row should get added", () => {
	createKnowledge.addedTableRowBelow()
    console.log(printTimestamp() ,'below current row new row gets added')
});

When("user selected Delete row", () => {
    createKnowledge.firstCellClick()
	createKnowledge.rowOptionClick()
    createKnowledge.deleteRowOptionClick()
    console.log(printTimestamp() ,'user selects Delete row')
});

Then("selected row should get deleted", () => {
	createKnowledge.tableWithTwoRows()
    console.log(printTimestamp() ,'selected row gets deleted')
});

When("user selected Insert column before", () => {
	createKnowledge.firstCellClick()
    createKnowledge.columnOptionClick()
    createKnowledge.insertColumnBeforeOptionClick()
    console.log(printTimestamp() ,'selectes Insert column before')
});

Then("left side of current column new column should get added", () => {
	createKnowledge.tableWithThreeColumns()
    console.log(printTimestamp() ,'left side of current column new column get added')
});

When("user selected Insert column after", () => {
    createKnowledge.columnOptionClick()
    createKnowledge.insertColumnAfterOptionClick()
    console.log(printTimestamp() ,'user selectes Insert column after')
});

Then("right side of current column new should get added", () => {
    createKnowledge.tableWithFourColumns()
    console.log(printTimestamp() ,'right side of current column new gets added')
});

When("user selected Delete column", () => {
    createKnowledge.columnOptionClick()
    createKnowledge.deleteColumnOptionClick()
    console.log(printTimestamp() ,'user selectes Delete column')
});

Then("selected column should get deleted", () => {
	createKnowledge.tableWithThreeColumns()
    console.log(printTimestamp() ,'selected column gets deleted')
});

When("user  select Dashed Borders", () => {
    createKnowledge.tableCellAfterAddingColumnClick()
	createKnowledge.tableStyleOptionClick()
    createKnowledge.dashedBordersOptionClick()
    console.log(printTimestamp() ,'selects Dashed Borders')
});

Then("table border should be displayed in dashed broders", () => {
	createKnowledge.tablewithDashedBordrs()
    console.log(printTimestamp() ,'table border displayed in dashed broders')
});

When("user select Alternate Row", () => {
    createKnowledge.tableStyleOptionClick()
    createKnowledge.alternateRowsOptionClick()
    console.log(printTimestamp() ,'user select Alternate Row')
});

Then("alternate row in table should be displayed in gray color", () => {
	createKnowledge.tablewithRowsWithGreyColor()
    console.log(printTimestamp() ,'alternate row in table displayed in gray color')
});

When("two cell is selected", () => {
	createKnowledge.selectingTwoCell()
    console.log(printTimestamp() ,'two cell selects')
});  

Then("Merge Cell option should be available in enabled state", () => {
    createKnowledge.tableCellOptionClick()
    createKnowledge.mergeCellOptionEnabled()
    console.log(printTimestamp() ,'Merge Cell option available in enabled state')
});

When("user select Merge Cell option", () => {
	createKnowledge.mergeCellOptionClick()
    console.log(printTimestamp() ,'selects Merge Cell option')
});

Then("two selected cells should get mergerd", () => {
	createKnowledge.tableCellsAfterMerge()
    console.log(printTimestamp() ,'two selected cells gets mergerd')
});

When("user select Vertical Split", () => {
    createKnowledge.tableCellAfterAddingColumnClick()
    createKnowledge.tableCellOptionClick()
    createKnowledge.verticalSplitOptionClick()
    console.log(printTimestamp() ,'selects Vertical Split')
});

Then("selected cell should get split into two vertical cell", () => {
	createKnowledge.tableCellAfterVerticalSplit()
    console.log(printTimestamp() ,'selected cell  gets split into two vertical cell')
});

When("user select Horizontal Split", () => {
    createKnowledge.tableCellAfterAddingColumnClick()
    createKnowledge.tableCellOptionClick()
    createKnowledge.horizontalSplitOptionSplit()
    console.log(printTimestamp() ,'selects Horizontal Split')
});

Then("selected cell should get split into two horizontal cell", () => {
	createKnowledge.tableCellAftetHorizontalSplit()
    console.log(printTimestamp() ,'selected cell gets split into two horizontal cell')
});

When("user select any color from available option and click on ok", () => {
	createKnowledge.tableCellAfterAddingColumnClick()
    createKnowledge.cellBackgroundOptionClick()
    createKnowledge.userColorClick()
    console.log(printTimestamp() ,'selects any color from available option and clicked on ok')
});

Then("color pop up should get closed and selected cell should get background color based on selected color in pop up", () => {
	createKnowledge.colorPopUpNotExist()
    createKnowledge.tabelCellAfterColorSelection()
    console.log(printTimestamp() ,'color pop up gets closed and selected cell gets background color based on selected color in pop up')
});

When("user write any HEX code", () => {
    createKnowledge.cellBackgroundOptionClick()
    cy.wait(1000)
    createKnowledge.HEXcolorInputBoxType()
    cy.wait(1000)
    createKnowledge.okButtonUnderCelBackgroundOptionClick()
    console.log(printTimestamp() ,' written any HEX code')
});

Then("based on code cell color should get changed", () => {
	createKnowledge.tableCellAfterHEXColorSelection()
    console.log(printTimestamp() ,'based on code cell color get changed')
});

When("user click on delete icon", () => {
	createKnowledge.tableCellAfterAddingColumnClick()
    createKnowledge.cellBackgroundOptionClick()
    createKnowledge.deleteButtonUnderCellBackGroundOptionClick()
    console.log(printTimestamp() ,'clicked on delete icon')
});

Then("applied background color should get removed", () => {
	createKnowledge.tableCellWithRemovedColor()
    console.log(printTimestamp() ,'applied background color gets removed')
});

When("User Merge multiple cells ,and add data", () => {
    createKnowledge.selectingTwoCell()
	createKnowledge.tableCellOptionClick()
    createKnowledge.mergeCellOptionClick()
    createKnowledge.addingDataInCell()
    console.log(printTimestamp() ,'Merged multiple cells ,and add data')
});

And("user select Top", () => {
	createKnowledge.verticalAllignmentOptionClick()
    createKnowledge.allignmentTopOptionClick()
    console.log(printTimestamp() ,'selects Top')
});

Then("data should get aligned in top for selected cells", () => {
	createKnowledge.dataAllignedTop()
    console.log(printTimestamp() ,'data gets aligned in top for selected cells')
});

When("user select Middle", () => {
	createKnowledge.verticalAllignmentOptionClick()
    createKnowledge.allignmentMiddleOptionClick()
    console.log(printTimestamp() ,'selects Middle')
});

Then("data should get aligned in middle for selected cells", () => {
    createKnowledge.dataAllignedMiddle()
    console.log(printTimestamp() ,'data gets aligned in middle for selected cells')
});

When("user select Bottom", () => { 
    createKnowledge.verticalAllignmentOptionClick()
    createKnowledge.allignmentBottomOptionClick()
    console.log(printTimestamp() ,'selects Bottom')
});

Then("data should get aligned in bottom for selected cells", () => {
	createKnowledge.dataAllignedBottom()
    console.log(printTimestamp() ,'data gets aligned in bottom for selected cells')
});

When("Add details in table", () => {
	createKnowledge.tableCellAfterAddingColumnClick()
    console.log(printTimestamp() ,'Added details in table')
});

Then("Align Left should be available as default alignment", () => {
	createKnowledge.allignLeftOptionSelected()
    console.log(printTimestamp() ,'Align Left available as default alignment')
});

When("user select Align Center", () => {
	createKnowledge.horizontalAllignOptionClick()
    createKnowledge.allignCenterOptionClick()
    console.log(printTimestamp() ,'selects Align Center')
});

Then("data should get aligned in center for selected cells", () => {
	createKnowledge.firstCellWithAlignCenter()
    console.log(printTimestamp() ,'data gets aligned in center for selected cells')
});

When("user select Align Right", () => {
	createKnowledge.horizontalAllignOptionClick()
    createKnowledge.allignRightOptionClick()
    console.log(printTimestamp() ,'selects Align Right')
});

Then("data should get aligned in right for selected cells", () => {
	createKnowledge.firstCellWithAlignRight()
    console.log(printTimestamp() ,'data gets aligned in right for selected cells')
});

When("user select Align Justify", () => {
	createKnowledge.horizontalAllignOptionClick()
    createKnowledge.allignJustifyOptionClick()
    console.log(printTimestamp() ,'selects Align Justify')
});

Then("data should get aligned in justify for selected cells", () => {
	createKnowledge.firstCellWithAlignJustify()
    console.log(printTimestamp() ,'data gets aligned in justify for selected cells')
});

When("user select Highlighted from style", () => {
	createKnowledge.cellStyleOptionClick()
    createKnowledge.highlightedOptionClick()
    console.log(printTimestamp() ,'selects Highlighted from style')
});

Then("cell should get highlighted with Red border", () => {
	createKnowledge.firstCellWithHighlightedRedBorder()
    console.log(printTimestamp() ,'cell gets highlighted with Red border')
});

When("user select Thick", () => {
	createKnowledge.cellStyleOptionClick()
    createKnowledge.thickOptionClick()
    console.log(printTimestamp() ,'user selects Thick')
});

Then("cell should get bordered with thick dashed borders", () => {
    createKnowledge.firstCellbordered()
    console.log(printTimestamp() ,'cell gets bordered with thick dashed borders')
});

And("Undo and Redo functionality should work as expected", () => {
	createKnowledge.cellStyleOptionClick()
    createKnowledge.thickOptionClick()
    createKnowledge.firstCellUndobordered()
    createKnowledge.cellStyleOptionClick()
    createKnowledge.highlightedOptionClick()
    createKnowledge.firstCellWitUndoHighlightedRedBorder()
    createKnowledge.cellStyleOptionClick()
    createKnowledge.highlightedOptionClick()
    createKnowledge.firstCellWithHighlightedRedBorder()
    createKnowledge.cellStyleOptionClick()
    createKnowledge.thickOptionClick() 
    createKnowledge.firstCellbordered()
    console.log(printTimestamp() ,'Undo and Redo functionality work as expected')
});

When("Click on full screen of rich text editor-cause and solution level full screen", () => {
	createKnowledge.fullScreenIconAtCauseAndSolutionLevelClick()
    cy.wait(1000)
    console.log(printTimestamp() ,'Clicked on full screen of rich text editor-cause and solution level full screen')
});

Then("All functionality should work as expected based on mentioned in above steps", () => {
	cy.RichTextEditorInsertTableFunctionality()
    createKnowledge.causeCollpaseIconAtCauseAndSolutionLevelClick()
    cy.wait(1000)
    createKnowledge.knowledgeInformationOptionClick()
    cy.CreateMyKnowledgeForInsertTable()
    console.log(printTimestamp() ,'All functionality work as expected based on mentioned in above steps')
});

When("Click on save as draft", () => {
	createKnowledge.saveAsDraftBButtonClick()
    console.log(printTimestamp() ,'Clicked on save as draft')
});

Then("Details should get saved in S3", () => {
	
    console.log(printTimestamp() ,'Details gets saved in S3')
});

When("Relaunch or Refresh application", () => {
	cy.reload()
    cy.wait(5000)
    console.log(printTimestamp() ,'Relaunched application')
});

Then("All applied functionality of rich text editor should be retained", () => {
    createKnowledge.causeAndSolutionOptionClick()
    createKnowledge.tableWithAppliedFunctionalityVisible()
    console.log(printTimestamp() ,'All applied functionality of rich text editor retained')
});

