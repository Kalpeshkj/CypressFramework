/// <reference types="Cypress" />
/// <reference types = 'cypress-tags' />

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();
import KnowledgeDashboard from "../../../../support/pageObjects/pages/Knowledge_Dashboard/KnowledgeDashboard";
const knowledgeDashboard = new KnowledgeDashboard();

When("User navigates to knowledge workflow", () => {
    knowledgeDashboard.knowledgeClick()
    knowledgeDashboard.addKnowledgeClick()
    console.log(printTimestamp(), ' All details entered in create pattern')
})

Then("User enters all details in Knowledge Creation", () => {
    createPattern.symptomsClick()
    createPattern.selectSymptomsButtonClick()
    createPattern.showAllCheckboxClick()
    knowledgeDashboard.firstRecordClick()
    knowledgeDashboard.selectButtonClick()
    createPattern.causesAndSolutionsClick()
    knowledgeDashboard.selectCauseClick()
    createPattern.showAllCheckboxClick()
    knowledgeDashboard.firstRecordClick()
    knowledgeDashboard.selectButtonClick()
    console.log(printTimestamp(), ' Navigated to apply metadata section')
})

And("Added tags should be available as removable token in added tags section", () => {
    createPattern.removeMarkVerificationInKnowledge()
    console.log(printTimestamp(), ' Remove icon present for added tag')
})

And("Added tag should not be available in dropdown, so user cannot add same tags multiple times", () => {
    knowledgeDashboard.addedTagNotAvailableInDropdownVerification()
    console.log(printTimestamp(), ' Added tag not available in dropdown')
})

And("User removes earlier added tag", () => {
    createPattern.removeMarkVerificationInKnowledge().last().click({ force: true })
    console.log(printTimestamp(), ' Tag removed')
})

When("User Clicks on With Keyword and verify its content as like Keyword, Operator and value should present with dropdown", () => {
    createPattern.withKeywordClick()
    createPattern.keywordDropdownVisibleInTagSection()
    createPattern.operatorDropdownVisibleInTagSection()
    createPattern.valueDropdownVisibleInTagSection()
    console.log(printTimestamp(), ' Contens verified at with keyword section')
})

And("Verifies added tags section should be available for both with and without keyword tags", () => {
    createPattern.keywordDropdownClick()
    createPattern.operatorDropdownClick()
    createPattern.valueDropdownClick()
    createPattern.addTagPlusIconClick()
    cy.wait(2000)
    createPattern.addedTagVisible()
    createPattern.withoutKeywordClick()
    cy.wait(2000)
    createPattern.addedTagVisible()
    createPattern.removeMarkVerificationInKnowledge().last().click()
    console.log(printTimestamp(), ' Added tags present in both sections with and without')
})

When("User Selects keyword ,operator and value from dropdown and clicks on + icon", () => {
    createPattern.withKeywordClick()
    createPattern.keywordDropdownClick()
    createPattern.operatorDropdownClick()
    createPattern.valueDropdownClick()
    createPattern.addTagPlusIconClick()
    console.log(printTimestamp(), ' User selects values from dropdown')
})

Then("Added tags should be available as removable token in added tags section", () => {
    createPattern.removeMarkVerificationInKnowledge()
    console.log(printTimestamp(), ' removable mark available in added tags')
})

When("User removes added tag and re add any new tag", () => {
    createPattern.removeMarkVerification().last().click({ force: true })
    createPattern.withKeywordClick()
    createPattern.keywordDropdownClick()
    createPattern.operatorDropdownClick()
    createPattern.valueDropdownClick()
    createPattern.addTagPlusIconClick()
    console.log(printTimestamp(), ' User removed one tag and added another one')
})

When("User clicks on add tag hyperlink", () => {
    knowledgeDashboard.tagSectionClick()
    knowledgeDashboard.addTagsButtonClick()
    console.log(printTimestamp(), ' Add tag huyperlink clicked')
})

And("close DAW application", () => {
    createPattern.cancelButtonClick()
    cy.DeleteWorkflow()
    cy.log("Test Case Executed Successfully")
    console.log(printTimestamp(), ' Test Case Executed Successfully')
});
