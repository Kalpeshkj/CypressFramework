/// <reference types="Cypress" />
/// <reference types='cypress-tags' />

import "../../../../support/index";
import { When, Then } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import PatternDashboard from "../../../../support/pageObjects/pages/Dashboard/PatternDashboard";
const patternDashboard = new PatternDashboard();
import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();
import IncludeKnowledge from "../../../../support/pageObjects/pages/PatternAuthoring/includeKnowledgepageObj";
const includeKnowledge = new IncludeKnowledge();


When("User Navigate to existing or created new wf and moves On step 3 Include knowledge", () => {
    cy.createPattern()
    createPattern.nextButtonClick()
    cy.ApplyMetaDetaPageCompletion()
    createPattern.nextButtonClick()
    console.log(printTimestamp(), ' Created new Wf')
});

When("User Click on dropdown of Tags and verify UI for filter options drop down", () => {
    includeKnowledge.tagColumnInIncludeKnowledgeClick()
    console.log(printTimestamp(), " Clicked on drop down of Tags and verify UI")
});

Then("Verifies order of filter values in drop down", () => {
    patternDashboard.tagColumnValuesSortedDataVerification()
    console.log(printTimestamp(), ' Verified order of filter value in drop down')
});

Then("Verifies details should be available in filter option dropdown", () => {
    patternDashboard.tagColumnSearchBoxVisible()
    patternDashboard.tagColumnAllValueSelectionCheckBoxVisible()
    includeKnowledge.tagsClearButtonVisible()
    patternDashboard.checkboxesAtColumnLevelValidation()
    console.log(printTimestamp(), ' Verifies details available in filter option drop down')
});

When("User Clicks on any tag value and verifies filtered details", () => {
    includeKnowledge.tagColumnFirstValueClick()
    includeKnowledge.tagsColumnFirstValueSelectedVerification()
    console.log(printTimestamp(), ' Clicked on any tag value and verified filtered pattern details')
});

When("User Clicks on dropdown of tags and enter tag value in filter text box", () => {
    includeKnowledge.tagColumnInIncludeKnowledgeClick()
    patternDashboard.tagColumnSearchBoxType()
    console.log(printTimestamp(), ' Clicked on drop down of tags and enter tag value')
});

When("User Clicks x mark available beside textbox", () => {
    includeKnowledge.tagColumnBesideTheBoxClick()
    console.log(printTimestamp(), ' Clicked on x mark')
});

When("User Clicks on drop down and verify entered value", () => {
    includeKnowledge.tagColumnInIncludeKnowledgeClick()
    patternDashboard.tagColumnSelectedValueVisible()
    console.log(printTimestamp(), ' Clicked on dropdown and verified entered value')
});

Then("Matched tags values should get displayed", () => {
    patternDashboard.tagColumnSearchedValueVisible()
    console.log(printTimestamp(), ' Matched tag values displayed')
});

Then("Filter option popup for tags should get closed", () => {
    patternDashboard.TagsColumnPopUpNotVisible()
    console.log(printTimestamp(), ' Filter option pop for tags should got closed')
});

When("User Clicks on drop down and verify entered value text", () => {
    includeKnowledge.tagColumnInIncludeKnowledgeClick()
    patternDashboard.tagColumnSelectedValueVisible()
    console.log(printTimestamp(), ' Clicked on dropdown and verified entered value')
});

Then("Select multiple tags value and verify patterns data", () => {
    includeKnowledge.multipleTagsSelectionFromDropdown()
    includeKnowledge.tagsColumnMultipleValueSelectedVerification()
    console.log(printTimestamp(), ' Selected multiple tag values and verified pattern data')
});

When("User Clicks on dropdown of tags and select all tags", () => {
    includeKnowledge.tagColumnInIncludeKnowledgeClick()
    includeKnowledge.tagColumnAllValueSelectionClick()
    console.log(printTimestamp(), ' Clicked on drop down of tags and select all tags')
});

Then("All Associated pattern should be displayed", () => {
    includeKnowledge.selectedTagsVisible()
    console.log(printTimestamp(), ' All associated patterns displayed')
});

When("User Unselect few tag and verify data", () => {
    includeKnowledge.tagColumnInIncludeKnowledgeForceClick()
    includeKnowledge.multipleTagsSelectionFromDropdown()
    console.log(printTimestamp(), ' Unselect few tag values and verified data')
});

Then("For unselected tag associated patterns should not displayed", () => {
    includeKnowledge.tagsColumnFirstValueSelectedNotVisible()
    console.log(printTimestamp(), ' For unselected tags associated pattern should not displayed')
});

Then("Search any keyword or clicks on show all check box", () => {
    createPattern.ShowCheckboxClick()
    console.log(printTimestamp(), ' Clicked on show all check box')
});

Then("Apply filter on knowledge name and verify UI for filter text box", () => {
    includeKnowledge.knowledgeNameColumnType()
    includeKnowledge.selectedTagsVisible()
    console.log(printTimestamp(), ' Filter multiple columns')
});

Then("Apply filter on tags and search data on top of filter data", () => {
    includeKnowledge.tagColumnInIncludeKnowledgeForceClick()
    includeKnowledge.multipleTagsSelectionFromDropdown()
    console.log(printTimestamp(), ' Filter multiple columns')
});

And("Search by keyword and on top of that applies filter for columns", () => {
    includeKnowledge.commonFilterType()
    includeKnowledge.knowledgeNameColumnType()
    console.log(printTimestamp(), " Clicked on drop down of Tags and verify UI")
});

And("Clicks on X mark available in knowledge name textbox and verify data", () => {
    includeKnowledge.commonSearchNameClear()
    includeKnowledge.knowledgeNameColumnClear()
    createPattern.ShowCheckboxClick()
    includeKnowledge.selectedTagsVisible()
    console.log(printTimestamp(), " Clicked on drop down of Tags and verify UI")
});