/// <reference types="Cypress" />
/// <reference types='cypress-tags' />
import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();
 
When("Enter unique pattern name", () => {
    createPattern.createPatternButtonClick()
    cy.wait(2000)
    createPattern.patternNameType()
    console.log(printTimestamp(), 'Entered unique pattern name')
});

Then("Validation has to be successful", () => {
	createPattern.patternNameIndicatorTextNotExist()
    console.log(printTimestamp(), 'Validation successful')
});

And("Close enabled,Save as draft enabled,Next-disabled", () => {
	createPattern.closeButtonEnabled()
    createPattern.saveAsDraftOnCreatePatternEnabled()
    createPattern.nextButtonDisabledVerification()
    console.log(printTimestamp(), 'Close enabled,Save as draft enabled,Next-disabled')
});

When("Add all details in Create Pattern page and click on Save AS Draft button", () => {
    createPattern.descriptionType()
    createPattern.orderOfExecutionType()
    createPattern.importdatamodelTabClick()
    createPattern.importdatamodelDrpdownClick()
    createPattern.importdatamodelDrpdownCommonSelection()
    createPattern.importdatamodelTabClick()
    createPattern.addConditionPlusIconClick()
    cy.wait(1000)
	createPattern.formDataModelClick()
    cy.wait(1000)
	createPattern.importedEventLogModelClick()
    createPattern.dataModelAdditionalInfoAttributeClick()
    createPattern.addConditionTabClick()
    cy.wait(2000)
    createPattern.operatorForEventOneClick()
    createPattern.equaltoOperatorClick()
    createPattern.ValueForTestOneType()
    createPattern.addActionClick()
    createPattern.addActionPlusIconClick()
    createPattern.raiseAlertOptionClick()
    createPattern.saveAsDraftBButtonClick()
    cy.wait(1000)
    console.log(printTimestamp(), 'Added all details in Create Pattern page and clicked on Save AS Draft button')
});

Then("“Workflow saved successfully” message should be displayed at top right corner", () => {
    createPattern.messageVisible()
    cy.wait(1000)
    createPattern.getPatternName()
    console.log(printTimestamp(), '“Workflow saved successfully” message displayed at top right corner')
});

And("After saving draft ,Save as Draft button should be disabled", () => {
    createPattern.saveAsDraftDisabled()
    console.log(printTimestamp(), 'After saving draft ,Save as Draft button disabled')
});

When("Click on next and fill all details in apply metadata page", () => {
    createPattern.nextButtonClick()
    cy.ApplyMetaDetaPageCompletionForPatternCreation()
    createPattern.clicksOnPopUpOkButton()
    cy.wait(1000)
    console.log(printTimestamp(), 'Clicked on next and filled all details in apply metadata page')
});

And("Click on Previous button", () => {
	createPattern.previousButtonClick()
    cy.wait(1000)
    console.log(printTimestamp(), 'Clicked on Previous button')
});

Then("User should be able to click on Save as Draft button", () => {
    createPattern.saveAsDraftOnCreatePatternEnabled()
    console.log(printTimestamp(), 'clicked on Save as Draft button')
});

// And("Details of created Authoring Workflow should be available in db and matched with UI", () => {
	
//     console.log(printTimestamp(), 'Details of created Authoring Workflow available in db and matched with UI')
// });

When("User relaunch application", () => {
	cy.reload()
    cy.wait(5000)
    console.log(printTimestamp(), 'relaunched application')
});

Then("Previously saved details should be available in UI", () => {
    createPattern.previousButtonClick()
    cy.wait(2000)
	createPattern.patternDescriptionVisible()
    createPattern.patternNameVisible()
    createPattern.selectedRaiseAlertoptionTextVisible()
    createPattern.deletePattern()
    createPattern.deleteOption().click({force:true});
    createPattern.okButtonClick()
    cy.wait(1000)
    console.log(printTimestamp(), 'Previously saved details available in UI')
});

When("Create Workflow , fill all details and Click on Next", () => {
    createPattern.myPatternThreeDotsClick()
    createPattern.createPatternButtonClick()
    cy.wait(2000)
    createPattern.patternNameType()
    createPattern.descriptionType()
    createPattern.orderOfExecutionType()
    createPattern.importdatamodelTabClick()
    createPattern.importdatamodelDrpdownClick()
    createPattern.importdatamodelDrpdownCommonSelection()
    createPattern.importdatamodelTabClick()
    createPattern.addConditionPlusIconClick()
    cy.wait(1000)
	createPattern.formDataModelClick()
    cy.wait(1000)
	createPattern.importedEventLogModelClick()
    createPattern.dataModelAdditionalInfoAttributeClick()
    createPattern.addConditionTabClick()
    cy.wait(2000)
    createPattern.operatorForEventOneClick() 
    createPattern.equaltoOperatorClick()
    createPattern.ValueForTestOneType()
    createPattern.addActionClick()
    createPattern.addActionPlusIconClick()
    createPattern.raiseAlertOptionClick()
    createPattern.saveAsDraftBButtonClick()
    cy.wait(1000)
    createPattern.nextButtonClick()
    cy.ApplyMetaDetaPageCompletionForPatternCreation()
    createPattern.clicksOnPopUpOkButton()
    cy.wait(1000)
    console.log(printTimestamp(), 'Created Workflow , filled all details and Clicked on Next')
});

// Then("Details of created Authoring Workflow should be available in db and matched with UI", () => {
	
//     console.log(printTimestamp(), 'Details of created Authoring Workflow available in db and matched with UI')
// });

Then("User should be redirected to Apply Metadata page", () => {
	createPattern.applyMetadataActiveVerification() 
    console.log(printTimestamp(), 'redirected to Apply Metadata page')
});

When("Click on Previous button from Apply Metadata Page", () => {
	createPattern.previousButtonClick()
    cy.wait(1000)
    console.log(printTimestamp(), 'Clicked on Previous button from Apply Metadata Page')
});

Then("User should be able to navigate to saved Authoring Workflow -Create Pattern Page", () => {
	createPattern.userOnCreatePatternPageVerification()
    console.log(printTimestamp(), 'navigated to saved Authoring Workflow -Create Pattern Page')
});

And("Save as draft button should be in disabled state", () => {
	createPattern.saveAsDraftDisabled()
    console.log(printTimestamp(), 'Save as draft button is in disabled state')
});

When("Update-Add content in any field of Create Pattern and apply metadata page", () => {
    createPattern.addActionClick()
    createPattern.addActionPlusIconClick()
    createPattern.insertAlertOptionClick()
    createPattern.saveAsDraftBButtonClick()
    cy.wait(1000)
    createPattern.nextButtonClick()
    cy.wait(1000)
    createPattern.modalityDropdownfieldInApplyMatadataPageClick()
    createPattern.severityFieldsSecondOptionInapplyMetadataPageClick()
    console.log(printTimestamp(), 'Updated-Added content in any field of Create Pattern and apply metadata page')
});

Then("Save as draft button should be in enabled", () => {
    createPattern.saveAsDraftOnCreatePatternEnabled()
    console.log(printTimestamp(), 'Save as draft button is enabled')
});

When("click on Save as Draft button", () => {
    createPattern.saveAsDraftBButtonClick()
    cy.wait(1000)
    console.log(printTimestamp(), 'clicked on Save as Draft button')
});

// Then("Based on updated content in UI,details get updated in db", () => {
	
//     console.log(printTimestamp(), 'Based on updated content in UI,details updated in db')
// });


Then("Updated details should be available in UI", () => {
    createPattern.previousButtonClick()
    cy.wait(1000)
	createPattern.insertAlertTextInUIVisible()
    createPattern.nextButtonClick()
    cy.wait(1000)
    createPattern.severityTextAfterUpdationVisible()
    createPattern.previousButtonClick()
    cy.wait(1000)
    console.log(printTimestamp(), 'Updated details available in UI')
});

When("Update-Add content in any field of Create Pattern and Apply Metadata page", () => {
    createPattern.addActionClick()
    createPattern.addActionPlusIconClick()
    createPattern.suppressAlertOptionSelect()
    createPattern.saveAsDraftBButtonClick()
    cy.wait(1000)
    console.log(printTimestamp(), 'Update-Added content in any field of Create Pattern and Apply Metadata page')
});

And("Navigate to Next Page and  Click on Save as draft button", () => {
    createPattern.nextButtonClick()
    cy.wait(1000)
    createPattern.modalityDropdownfieldInApplyMatadataPageClick()
    createPattern.severityFieldsThirdOptionInapplyMetadataPageClick()
    createPattern.saveAsDraftBButtonClick()
    cy.wait(1000)
    console.log(printTimestamp(), 'Navigated to Next Page and  Clicked on Save as draft button')
});

// Then("Based on updated content in UI , details get updated in db", () => {
	
//     console.log(printTimestamp(), 'Based on updated content in UI , details updated in db')
// });

When("Relaunch application", () => {
    cy.reload()
    cy.wait(5000)
    createPattern.previousButtonClick()
    cy.wait(2000)
    console.log(printTimestamp(), 'Relaunched application')
});

Then("updated details should be available in UI", () => {
	createPattern.supressAlertOptionTextVisible()
    createPattern.nextButtonClick()
    cy.wait(1000)
    createPattern.severityTextAFterSecondTimeUpdationVisible()
    createPattern.getPatternName()
    console.log(printTimestamp(), 'Updated details available in UI')
});

And("Repeat above steps by filling data in any order for each fields and verify functionality Save as draft", () => {
    createPattern.myPatternThreeDotsClick()
    createPattern.createPatternButtonClick()
    cy.wait(2000)
    createPattern.descriptionType()
    createPattern.orderOfExecutionType()
    createPattern.patternNameType()
    createPattern.importdatamodelTabClick()
    createPattern.importdatamodelDrpdownClick()
    createPattern.importdatamodelDrpdownCommonSelection()
    createPattern.importdatamodelTabClick()
    createPattern.addConditionPlusIconClick()
    cy.wait(1000)
	createPattern.formDataModelClick()
    cy.wait(1000)
	createPattern.importedEventLogModelClick()
    createPattern.dataModelAdditionalInfoAttributeClick()
    createPattern.addConditionTabClick()
    cy.wait(2000)
    createPattern.operatorForEventOneClick()
    createPattern.equaltoOperatorClick()
    createPattern.ValueForTestOneType()
    createPattern.addActionClick()
    createPattern.addActionPlusIconClick()
    createPattern.raiseAlertOptionClick()
    createPattern.saveAsDraftBButtonClick()
    cy.wait(1000)
    createPattern.nextButtonClick()
    cy.ApplyMetaDetaPageCompletionForPatternCreation()
    createPattern.clicksOnPopUpOkButton()
    cy.wait(1000)
	createPattern.previousButtonClick()
    cy.wait(1000)
    createPattern.addActionClick()
    createPattern.addActionPlusIconClick()
    createPattern.insertAlertOptionClick()
    createPattern.saveAsDraftBButtonClick()
    cy.wait(1000)
    createPattern.nextButtonClick()
    cy.wait(1000)
    createPattern.modalityDropdownfieldInApplyMatadataPageClick()
    createPattern.severityFieldsSecondOptionInapplyMetadataPageClick()
    createPattern.saveAsDraftBButtonClick()
    cy.wait(1000)
    cy.reload()
    cy.wait(5000)
    createPattern.previousButtonClick()
    cy.wait(1000)
	createPattern.insertAlertTextInUIVisible()
    createPattern.nextButtonClick()
    cy.wait(1000)
    createPattern.severityTextAfterUpdationVisible()
    createPattern.previousButtonClick()
    cy.wait(1000)
    createPattern.addActionClick()
    createPattern.addActionPlusIconClick() 
    createPattern.suppressAlertOptionSelect()
    createPattern.saveAsDraftBButtonClick()
    createPattern.nextButtonClick()
    cy.wait(1000)
    createPattern.modalityDropdownfieldInApplyMatadataPageClick()
    createPattern.severityFieldsThirdOptionInapplyMetadataPageClick()
    createPattern.saveAsDraftBButtonClick()
    cy.reload()
    cy.wait(5000)
    createPattern.previousButtonClick()
    cy.wait(2000)
    createPattern.nextButtonClick()
    cy.wait(1000)
    createPattern.modalityDropdownfieldInApplyMatadataPageClick()
    createPattern.severityFieldsThirdOptionInapplyMetadataPageClick()
    createPattern.saveAsDraftBButtonClick()
    cy.wait(1000)
    console.log(printTimestamp(), 'Repeats above steps by filling data in any order for each fields and verify functionality Save as draft')
});


