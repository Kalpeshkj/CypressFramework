/// <reference types="Cypress" />
/// <reference types='cypress-tags' />  

import "../../../../support/index";
import { When, Then } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import NavigationPanel from "../../../../support/pageObjects/pages/Dashboard/NavigationPanel";
const navigationPanel = new NavigationPanel();
import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();

var arr = [];

When("User Clicks on three dots of my pattern", () => {
    createPattern.myPatternThreeDotsClick()
    console.log(printTimestamp(), ' Clicked on three dots of my pattern')
});

Then("Create Pattern option is displayed", () => {
    navigationPanel.createPatternButtonVisible()
    console.log(printTimestamp(), 'Create Pattern option displayed')
});

When("User  click on Import Data Model and Select any Data Model from drop down option", () => {
    createPattern.createPatternButtonClick()
    cy.wait(2000)
    createPattern.importDataModelClick()
    createPattern.dataModelDropArrowClick()
    createPattern.dataModelCommonOptionDropArrowClick()
    createPattern.eventLogDataModelClick()
    createPattern.dataModelDropArrowClick()
    console.log(printTimestamp(), 'User  clicked on Import Data Model and Selects any Data Model from drop down option')
});

When("User clicks on Add Condition", () => {
    createPattern.addConditionTabClick()
    createPattern.expandedAddConditionSectionVerification()
    console.log(printTimestamp(), 'User clicked on Add Condition and Add Condition expanded')
});

When("User Click on + drop down", () => {
    createPattern.addConditionPlusIconClick()
    cy.wait(2000)
    console.log(printTimestamp(), 'Clicked on + drop down')
});

Then("From Data Model From Rule-Pattern From Variable option should be displayed", () => {
    createPattern.fromdataModelVisible()
    createPattern.fromrulePatternVisible()
    createPattern.fromVariableVisible()
    console.log(printTimestamp(), 'From Data Model From Rule-Pattern From Variable option displayed')
});

When("User Add events with conditions", () => {
    createPattern.formDataModelClick()
    cy.wait(1000)
    createPattern.importedEventLogModelClick()
    createPattern.dataModelAdditionalInfoAttributeClick()
    createPattern.opeartorDropDownForEvent3ConditionOneClick()
    createPattern.equaltoOperatorClick()
    createPattern.valueForFirstConditionInThridEventType()
    createPattern.addConditionButtonForeventOneClick()
    createPattern.attributeForSecondConditionInFirstEventClick()
    createPattern.attributeForSecondConditionClick()
    createPattern.operatorDropDownForSecondConditionClick()
    createPattern.equalToOperatorForSecondConditonClick()
    createPattern.valueForSecondConditionFirstEventType()
    createPattern.addConditionPlusIconClick()
    cy.wait(2000)
    createPattern.formDataModelClick()
    cy.wait(1000)
    createPattern.importedEventLogModelClick()
    createPattern.dataModelAdditionalInfoAttributeClick()
    createPattern.operatorDropDownForSecondEventFirstConditionClick()
    createPattern.equaltoOperatorClick()
    createPattern.valueForConditionTwoInEvenmtwoType()
    createPattern.addConditionPlusIconClick()
    cy.wait(2000)
    createPattern.formDataModelClick()
    cy.wait(1000)
    createPattern.importedEventLogModelClick()
    createPattern.dataModelAdditionalInfoAttributeClick()
    createPattern.opeartorDropDownForEvent3ConditionOneClick()
    createPattern.equaltoOperatorClick()
    createPattern.valueForFirstConditionInThridEventType()
    createPattern.addConditionPlusIconClick()
    cy.wait(2000)
    createPattern.formDataModelClick()
    cy.wait(1000)
    createPattern.importedEventLogModelClick()
    createPattern.dataModelAdditionalInfoAttributeClick()
    createPattern.operatorDropdownBetweenAttrAndValueForEventFourClick()
    createPattern.equaltoOperatorClick()
    createPattern.valueInputBoxForEventFourType()
    createPattern.addConditionPlusIconClick()
    cy.wait(2000)
    createPattern.formDataModelClick()
    cy.wait(1000)
    createPattern.importedEventLogModelClick()
    createPattern.dataModelAdditionalInfoAttributeClick()
    createPattern.operatorDropdownBetweenAttrAndValueForEventFiveClick()
    createPattern.equaltoOperatorClick()
    createPattern.valueInputBoxForEventFiveType()
    console.log(printTimestamp(), 'Added events with conditions')
});

Then("group disabled,Save as Rule disabled options should be available inline with logical expression of event", () => {
    createPattern.groupOptionAtEventDisabled()
    createPattern.saveAsRuleOptionDisabled()
    console.log(printTimestamp(), 'group disabled,Save as Rule disabled options available inline with logical expression of event')
});

Then("group disabled, X mark enabled options should be available inline with logical expression of condition", () => {
    createPattern.groupUngroupConditionOptionDisabled()
    createPattern.crossMarkAtGroupedConditionlevelEnabled()
    console.log(printTimestamp(), 'group disabled, X mark enabled options available inline with logical expression of condition')
});

When("User Select one check box available at event level", () => {
    createPattern.checkBoxAtEventOneClick()
    console.log(printTimestamp(), 'Selects one check box available at event level')
});

Then("Group option  should be disabled", () => {
    createPattern.groupOptionAtEventDisabled()
    console.log(printTimestamp(), 'Group option disabled')
});

When("Select one check box of  event and one check box of condition within event or across event", () => {
    createPattern.checkBoxAtConditionOneClick()
    console.log(printTimestamp(), 'Selects one check box of  event and one check box of condition within event or across event')
});

Then("Group option should be disabled", () => {
    createPattern.groupOptionAtEventDisabled()
    console.log(printTimestamp(), 'Group option disabled')
});

When("User Select two check box of  event", () => {
    createPattern.checkBoxAtConditionOneClick()
    createPattern.checkBoxAtEventTwoClick()
    console.log(printTimestamp(), 'User Selects two check box of  event')
});

Then("Group option at event level should be enabled", () => {
    createPattern.groupOptionAtEventEnabled()
    console.log(printTimestamp(), 'Group option at event level enabled')
});

Then("Condition level group option should be disabled", () => {
    createPattern.groupUngroupConditionOptionDisabled()
    console.log(printTimestamp(), 'Condition level group option disabled')
});

When("User Click on group At  Event", () => {
    createPattern.logicalExpressionAtEventLevelBeforeGrouping()
    createPattern.operatorDropdownAtEventAndConditionBetweenEventOneAndTwoClick()
    createPattern.orOperatorOptionsUnderDropdownClick()
    createPattern.groupOptionAtEventClick()
    console.log(printTimestamp(), 'Clicked on group At Event')
});

Then("Logical expression should get  updated after grouping", () => {
    createPattern.logicalExpressionAtEventLevelAfterGrouping()
    console.log(printTimestamp(), 'Logical expression updated after grouping')
});

Then("Group and Save as Rule disabled options should be available inline with logical expression of event", () => {
    createPattern.groupOptionAtEventDisabled()
    createPattern.saveAsRuleOptionDisabled()
    console.log(printTimestamp(), 'Group and Save as Rule disabled options available inline with logical expression of event')
});

Then("Operator dropdown Not and None option should be available at whole event level"
    + " below logical expression of event and for first event of each group", () => {
        createPattern.operatorDropdownAtEventAndConditionBetweenEventTwoAndThreeClick()
        createPattern.orOperatorOptionsUnderDropdownClick()
        createPattern.operatorDropdownAtEventAndConditionBetweenEventThreeAndFourClick()
        createPattern.orOperatorOptionsUnderDropdownBetweenEventsClick()
        createPattern.operatorDropdownAtEventAndConditionBetweenEventFourAndFiveClick()
        createPattern.orOperatorOptionsUnderDropdownBetweenEventsClick()
        createPattern.checkBoxAtEventThreeClick()
        createPattern.checkBoxAtEventFourClick()
        createPattern.groupOptionAtEventClick()
        createPattern.operatorDropdownAtEventAndConditionAtWholeEventClick()
        createPattern.noneOperatorVisible()
        createPattern.notOperatorVisible()
        createPattern.operatorDropdownAtEventAndConditionAtFirstEventGroupClick()
        createPattern.noneOperatorVisible()
        createPattern.notOperatorVisible()
        createPattern.operatorDropdownAtEventAndConditionAtSecondEventGroupClick()
        createPattern.noneOperatorVisible()
        createPattern.notOperatorVisible()
        console.log(printTimestamp(), "Operator dropdown Not and None option should be available at whole event level"
            + "below logical expression of event and for first event of each group")
    });

Then("Grouped event should be displayed in new block with Operator dropdown None and Not options,Ungroup enabled and X enabled options", () => {
    createPattern.groupedEventsOfEventOneAndTwoVisible()
    createPattern.groupedEventsOfEventThreeAndFourVisible()
    createPattern.ungroupOptionForGroupedEventsEnebled()
    createPattern.crossMarkAtGroupedEventsEnabled()
    console.log(printTimestamp(), 'Grouped event displayed in new block with Operator dropdown None and Not options,Ungroup enabled and X enabled options')
});

Then("Only one check box should be displayed for grouped event For each event within"
    + " grouped event Group disabled ,”X” enabled mark should be displayed", () => {
        createPattern.groupOptionAtGroupedEventDisabled()
        createPattern.crossMarkAtGroupedEventsEnabled()
        console.log(printTimestamp(), "Only one check box should be displayed for grouped event For each event within"
            + "grouped event Group disabled ,”X” enabled mark should be displayed")
    });

Then("“X” enabled  mark should be displayed inline with logical expression of condition within event", () => {
    createPattern.crossMarkAtGroupedEventsEnabled()
    console.log(printTimestamp(), '“X” enabled  mark displayed inline with logical expression of condition within event')
});

Then("For each condition checkbox , operator , attribute , operator  and value should be available", () => {
    createPattern.checkBoxForConditionsAnEventExist()
    createPattern.attributeDropdownsVisible()
    createPattern.operatorDropdownAtEventAndConditionVisible()
    createPattern.operatorsBetweenAttributeAndValueVisible()
    createPattern.valueOptionVisible()
    console.log(printTimestamp(), 'For each condition checkbox , operator , attribute , operator  and value available')
});

When("User Click on check box available for grouped event and check box one event", () => {
    createPattern.checkBoxForThirdAndFourthGroupedEventClick()
    createPattern.checkBoxForFifthEventClick()
    console.log(printTimestamp(), 'Clicked on check box available for grouped event and check box one event')
});

When("Click on group", () => {
    createPattern.groupOptionAtEventClick()
    console.log(printTimestamp(), 'Clicked on group')
});

Then("Logical expression should get updated based on further grouping", () => {
    createPattern.logicalExpressionAtEventLevelAfterGroupingGroupedAndUngroupedEvent()
    console.log(printTimestamp(), 'Logical expression get updated based on further grouping')
});

When("User Click on  Ungroup", () => {
    createPattern.ungroupOptionForGroupedEventsClick()
    console.log(printTimestamp(), 'Clicked on  Ungroup')
});

Then("User should be click on Ungroup Logical expression should get updated based on ungrouping", () => {
    createPattern.logicalExpressionAtEventLevelAfterUngroupingGroupedAndUngroupedEvent()
    console.log(printTimestamp(), 'clicked on Ungroup Logical expression get updated based on ungrouping')
});

Then("Checkbox for each event should be available", () => {
    createPattern.checkBoxForConditionsAnEventExist()
    console.log(printTimestamp(), 'Checkbox for each event available')
});

When("Click on “X” mark of ungrouped", () => {
    createPattern.crossMarkOfEventFiveClick()
    console.log(printTimestamp(), 'Clicked on “X” mark of ungrouped')
});

Then("Confirmation pop up with message “Are you sure you want to delete this event?”"
    + " “EventName” will be removed and all copied events if any will be deleted Cancel and Delete button", () => {
        createPattern.popupVisible()
        createPattern.popUpTitleVisible()
        createPattern.popUpDialogueVisible()
        createPattern.cancelButtonVisible()
        createPattern.deleteButtonVisible()
        console.log(printTimestamp(), "Confirmation pop up with message “Are you sure you want to delete this event?”"
            + " “EventName” will be removed and all copied events if any will be deleted Cancel and Delete button")
    });

When("Click on Cancel button", () => {
    createPattern.cancelButtonClick()
    console.log(printTimestamp(), 'Clicked on Cancel button')
});

Then("Event should not get  deleted", () => {
    createPattern.scrollElement()
    createPattern.lastEventVisible()
    console.log(printTimestamp(), 'Event not get  deleted')
});

When("Click on Delete button Of pop up", () => {
    createPattern.crossMarkOfEventFiveClick()
    createPattern.deleteButtonClick()
    console.log(printTimestamp(), 'Clicked on Delete button Of pop up')
});

Then("Event should get deleted and copied event from deleted event if any that also should get deleted", () => {
    createPattern.lastEventNotExist()
    console.log(printTimestamp(), 'Event get deleted and copied event from deleted event if any that also get deleted')
});

When("Group all events and Click on “X” mark of grouped event", () => {
    createPattern.checkBoxAtFirstGroupOfEventsClick()
    createPattern.checkBoxAtSecondGroupOfEventsClick()
    createPattern.groupOptionAtEventClick()
    createPattern.crossMarkAtGroupedEventsClick()
    console.log(printTimestamp(), 'Grouped all events and Clicked on “X” mark of grouped event')
});

Then("Confirmation pop up should be displayed with message “Are you sure you want to delete this events group?”"
    + " Events Group will be removed and all copied events if any will be deleted. Cancel and Delete button", () => {
        createPattern.popupVisible()
        createPattern.popUpTitleForDeletingAllGroupedEventsVisible()
        createPattern.popUpDialogueForDeletingAllGroupedEventsVisible()
        createPattern.cancelButtonVisible()
        createPattern.deleteButtonVisible()
        console.log(printTimestamp(), "Confirmation pop up displayed with message “Are you sure you want to delete this events group?”"
            + " Events Group will be removed and all copied events if any will be deleted. Cancel and Delete button")
    });

When("User Click on Cancel button", () => {
    createPattern.cancelButtonClick()
    console.log(printTimestamp(), 'Clicked on Cancel button')
});

Then("Grouped Events should not get deleted", () => {
    createPattern.groupedAllEventsVisible()
    console.log(printTimestamp(), 'Grouped Events not get deleted')
});

When("User Click on Delete button in popup", () => {
    createPattern.crossMarkAtGroupedEventsClick()
    createPattern.deleteButtonClick()
    console.log(printTimestamp(), 'Clicked on Delete button in popup')
});

Then("Event group should get deleted and none of condition event should be available", () => {
    createPattern.groupedAllEventsNotExist()
    console.log(printTimestamp(), 'Event group get deleted and none of condition event available')
});

When("Fill all mandatory fields in Create Pattern page and click on Save as Draft", () => {
    createPattern.patternInformationOptionClick()
    createPattern.patternNameType()
    createPattern.descriptionType()
    createPattern.orderOfExecutionType()
    createPattern.addActionClick()
    createPattern.addActionPlusIconClick()
    cy.wait(1000)
    createPattern.raiseAlertOptionClick()
    createPattern.saveAsDraftBButtonClick()
    cy.wait(1000)
    createPattern.messageVisible()
    createPattern.getPatternName()
    console.log(printTimestamp(), 'Filled all mandatory fields in Create Pattern page and clicked on Save as Draft')
});

Then("All details should be available in db", () => {
    createPattern.deletePattern()
    createPattern.deleteOption().click({ force: true });
    createPattern.okButtonClick()
    cy.wait(3000)
    console.log(printTimestamp(), 'All details available in db')
});

Then("Repeat above steps for grouping ungrouping events by importing Condition from rule pattern", () => {
    createPattern.myPatternThreeDotsClick()
    createPattern.createPatternButtonClick()
    cy.wait(2000)
    createPattern.importDataModelClick()
    createPattern.dataModelDropArrowClick()
    createPattern.dataModelCommonOptionDropArrowClick()
    createPattern.eventLogDataModelClick()
    createPattern.dataModelDropArrowClick()
    createPattern.addConditionTabClick()
    createPattern.expandedAddConditionSectionVerification()
    createPattern.addConditionPlusIconClick()
    cy.wait(2000)
    createPattern.fromdataModelVisible()
    createPattern.fromrulePatternVisible()
    createPattern.fromVariableVisible()
    createPattern.rulePatternOptionClick()
    createPattern.showAllCheckboxClick()
    cy.wait(2000)
    createPattern.patternClick()
    createPattern.importButtonClick()
    createPattern.addConditionPlusIconClick()
    cy.wait(2000)
    createPattern.rulePatternOptionClick()
    createPattern.ShowCheckboxClick()
    cy.wait(2000)
    createPattern.patternTwoClick()
    createPattern.importButtonClick()
    createPattern.scrollElement()
    cy.wait(1000)
    createPattern.addConditionPlusIconClick()
    cy.wait(2000)
    createPattern.rulePatternOptionClick()
    createPattern.ShowCheckboxClick()
    cy.wait(2000)
    createPattern.patternThreeClick()
    createPattern.importButtonClick()
    createPattern.groupOptionAtEventDisabled()
    createPattern.saveAsRuleOptionDisabled()
    createPattern.groupUngroupConditionOptionDisabled()
    createPattern.crossMarkAtGroupedConditionlevelEnabled()
    createPattern.checkBoxAtEventOneClick()
    createPattern.groupOptionAtEventDisabled()
    createPattern.checkBoxAtConditionOneClick()
    createPattern.groupOptionAtEventDisabled()
    createPattern.checkBoxAtConditionOneClick()
    createPattern.checkBoxAtEventTwoForRulePatternClick()
    createPattern.groupOptionAtEventEnabled()
    createPattern.groupUngroupConditionOptionDisabled()
    createPattern.operatorDropdownAtEventAndConditionBetweenEventTwoAndThreeForRulePattenClick()
    createPattern.andOperatorOptionsUnderDropdownClick()
    createPattern.operatorDropdownAtEventAndConditionBetweenEventThreeAndFourForRulePattenClick()
    createPattern.andOperatorOptionsUnderDropdownClick()
    createPattern.operatorDropdownAtEventAndConditionBetweenEventFourAndFiveForRulePattenClick()
    createPattern.andOperatorOptionsUnderDropdownClick()
    createPattern.logicalExpressionAtEventLevelBeforeGroupingForRulePattern()
    createPattern.groupOptionAtEventClick()
    createPattern.logicalExpressionAtEventLevelAfterGroupingForRulePattern()
    createPattern.groupOptionAtEventDisabled()
    createPattern.saveAsRuleOptionDisabled()
    createPattern.checkBoxAtEventThreeForRulePatternClick()
    createPattern.checkBoxAtEventFourForRulePatternClick()
    createPattern.groupOptionAtEventClick()
    createPattern.operatorDropdownAtEventAndConditionAtWholeEventClick()
    createPattern.noneOperatorVisible()
    createPattern.notOperatorVisible()
    createPattern.operatorDropdownAtEventAndConditionAtFirstEventGroupClick()
    createPattern.noneOperatorVisible()
    createPattern.notOperatorVisible()
    createPattern.operatorDropdownAtEventAndConditionForSecondGroupEventOneClick()
    createPattern.groupedEventsOfEventOneAndTwoVisible()
    createPattern.groupedEventsOfEventThreeAndFourVisible()
    createPattern.ungroupOptionForGroupedEventsEnebled()
    createPattern.crossMarkAtGroupedEventsEnabled()
    createPattern.groupOptionAtGroupedEventDisabled()
    createPattern.crossMarkAtGroupedEventsEnabled()
    createPattern.attributeDropdownsVisible()
    createPattern.operatorDropdownAtEventAndConditionVisible()
    createPattern.operatorsBetweenAttributeAndValueVisible()
    createPattern.valueOptionVisible()
    createPattern.checkBoxForThirdAndFourthGroupedEventForRulePatternClick()
    createPattern.checkBoxAtEventFiveForRulePatternClick()
    createPattern.groupOptionAtEventClick()
    createPattern.logicalExpressionAtEventLevelAfterGroupingGroupedAndUngroupedEventForRulePattern()
    createPattern.checkBoxForConditionsAnEventExist()
    createPattern.crossMarkOfEventFiveClick()
    createPattern.popupVisible()
    createPattern.popUpTitleVisible()
    createPattern.popUpDialogueVisible()
    createPattern.cancelButtonVisible()
    createPattern.deleteButtonVisible()
    createPattern.cancelButtonClick()
    createPattern.crossMarkOfEventFiveClick()
    createPattern.deleteButtonClick()
    createPattern.checkBoxAtFirstGroupOfEventsClick()
    createPattern.groupOptionAtEventClick()
    createPattern.crossMarkAtGroupedEventsClick()
    createPattern.popupVisible()
    createPattern.popUpTitleForDeletingAllGroupedEventsVisible()
    createPattern.popUpDialogueForDeletingAllGroupedEventsVisible()
    createPattern.cancelButtonVisible()
    createPattern.deleteButtonVisible()
    createPattern.cancelButtonClick()
    createPattern.groupedAllEventsVisible()
    createPattern.crossMarkAtGroupedEventsClick()
    createPattern.deleteButtonClick()
    createPattern.groupedAllEventsNotExist()
    createPattern.patternInformationOptionClick()
    createPattern.patternNameType()
    createPattern.descriptionType()
    createPattern.orderOfExecutionType()
    createPattern.addActionClick()
    createPattern.addActionPlusIconClick()
    cy.wait(1000)
    createPattern.raiseAlertOptionClick()
    createPattern.saveAsDraftBButtonClick()
    cy.wait(1000)
    createPattern.messageVisible()
    console.log(printTimestamp(), 'Repeated above steps for grouping ungrouping events by importing Condition from rule pattern')
});