/// <reference types="Cypress" />
/// <reference types='cypress-tags' />

import "../../../support/index";
import {  When, Then, And } from "cypress-cucumber-preprocessor/steps";
import {printTimestamp} from '../../../support/commands';

import UserDashboard from "../../../support/pageObjects/pages/Dashboard/UserDashboard";
const userDashboard = new UserDashboard();
import AssertionConstants from "../../../support/pageObjects/pages/AssertionConstants";
const constants = new AssertionConstants();

When("user clicks on settings button and verifies details present in User Management dashboard", () => {
    userDashboard.settingsDropdownClick()
    userDashboard.settinsOptionClick()
    userDashboard.userManagementButtonClick()
    console.log(printTimestamp() , 'Clicked on userDashboard and navigated to User management section')
});

Then("Add user and Delete user buttons are available in User Management dashboard", () => {
    userDashboard.usersDasboardNavigationTextVisible()
    userDashboard.deleteUserButtonVisible()
    userDashboard.addUserButtonVisible()
    console.log(printTimestamp() , 'Verified available buttons present in user Management dashboard')
});

And("Entries per page as 15 to be selected and total number of records are displayed", () => {
    userDashboard.recordsFoundText()
    userDashboard.clearAllFilterButtonVisible()
    userDashboard.entriesPerPageFieldVisible()
    userDashboard.pageRecordVisible()
    userDashboard.pageRecord().invoke('text').as('pageCount')
    cy.get('@pageCount').should('eq','15')
    userDashboard.showingCountVisible()
    console.log(printTimestamp() , 'Verified total number of records and entries per page available')
});

And("All the datagrid column values are present in user dashboard", () => {
    userDashboard.userEmailColumnVisible()
    userDashboard.userNameColumnVisible()
    userDashboard.groupameColumnVisible()
    userDashboard.createdbyColumnVisible()
    userDashboard.createdonColumnVisible()
    console.log(printTimestamp() , 'Verified data grid for user dashboard')
});

And("Close The Application", () => {
    cy.log("Test Case Executed Successfully")
    console.log(printTimestamp() , 'Test Case Executed Successfully')
});
