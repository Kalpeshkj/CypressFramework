/// <reference types="Cypress" />
/// <reference types='cypress-tags' />

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import KnowledgeDashboard from "../../../../support/pageObjects/pages/Knowledge_Dashboard/KnowledgeDashboard";
import PatternDashboard from "../../../../support/pageObjects/pages/Dashboard/PatternDashboard";
const patternDashboard = new PatternDashboard();
const knowledgeDashboard = new KnowledgeDashboard();

Then("Navigates to knowledge Dashboard", () => {
    knowledgeDashboard.knowledgeClick();
    knowledgeDashboard.knowledgeDashboardClick()
    console.log(printTimestamp(), ' Navigated to knowledge Dashboard')
});

And("Verifies data grid present in knowledge dashboard", () => {
    knowledgeDashboard.dataGridInKnowledgeDashboardVerification();
    console.log(printTimestamp(), ' Data grid verified')
});

And('Verifies drop down for column configuration as 8 columns pre selected', () => {
    knowledgeDashboard.columnConfiurationDropdownTextVerification();
    console.log(printTimestamp(), ' Verified drop down for column configuration as 9 columns pre selected')
});

When("User click on column dropdown", () => {
    patternDashboard.columnConfigurationDropdownClick();
    console.log(printTimestamp(), ' Column dropdown clicked')
});

Then("By default 8 columns should be selected and rest should be in unselected state", () => {
    knowledgeDashboard.selectedColumnsChekboxCountVerification();
    knowledgeDashboard.unSelectedColumnsChekboxCountVerification();
    console.log(printTimestamp(), ' By default 9 columns selected and rest was in unselected state')
});

When("User Verifies list of columns in Drop down options as checked or unchecked state", () => {
    knowledgeDashboard.selectedColumnsTextCountVerification();
    knowledgeDashboard.unSelectedColumnsTextCountVerification();
    console.log(printTimestamp(), ' Verified list of columns in Drop down options as per checked or unchecked state')
});

When('User adds any new unchecked column from list', () => {
    patternDashboard.unSelectedSingleColumnsChekboxClick();
    console.log(printTimestamp(), ' User added any new unchecked column')
});

Then("New Column should get displayed in data grid with result", () => {
    patternDashboard.newlyAddedColumnsInDataGridVerify();
    console.log(printTimestamp(), ' New Column displayed in data grid with results')
});

When("User naviagtes to next page and again revisits same page", () => {
    patternDashboard.pageNavigationClick();
    console.log(printTimestamp(), ' User naviagted to next page and again revisited in same page')
});

Then("Newly added column should retained", () => {
    patternDashboard.newlyAddedColumnsInDataGridVerification();
    console.log(printTimestamp(), ' Newly added column retained as it is')
});

Then("Newly added column should retain", () => {
    patternDashboard.newlyAddedColumnsInDataGridVerify();
    console.log(printTimestamp(), ' Newly added column retained as it is')
});

When("User relaunches the application", () => {
    cy.reload()
    cy.wait(2000)
    console.log(printTimestamp(), ' sorting operation performed on all columns')
});

Then("Newly added column should not retained", () => {
    patternDashboard.newlyAddedColumnsInDataGridNotPresentVerification();
    console.log(printTimestamp(), ' Newly added column not retained')
});

When("User adds all unselected columns from list", () => {
    patternDashboard.unSelectedAllColumnsChekboxClick();
    console.log(printTimestamp(), ' All unselected columns added')
});

Then("Newly added columns should displayed in dashboard", () => {
    patternDashboard.newlyAddedColumnsInDataGridVerification();
    console.log(printTimestamp(), ' Newly added columns displayed')
});

When("User unchecks all the columns from list", () => {
    patternDashboard.selectedAllColumnsChekboxClick();
    console.log(printTimestamp(), ' User unchecksed all the columns')
});

Then("User should not able to remove all the columns and atleast one column must be present in knowledge dashboard", () => {
    patternDashboard.singleColumnPresentVerification();
    console.log(printTimestamp(), ' User removed all the columns except one')
});

When("User selects all the columns from list", () => {
    patternDashboard.columnConfigurationDropdownClick()
    cy.wait(3000)
    patternDashboard.unSelectedAllColumnsChekboxClick();
    console.log(printTimestamp(), ' Selected all the columns')
});

Then("Number of item selected should get updated in dropdown", () => {
    patternDashboard.newlyAddedColumnsInDataGridVerification();
    console.log(printTimestamp(), ' Number of item selected are updated in drop down')
});

When("User adds all unselected columns from list and removes selected columns", () => {
    patternDashboard.unSelectedAllColumnsChekboxClick();
    console.log(printTimestamp(), ' All unselected columns added')
});

And("Repeat all the above steps for My Knowledge Dashboard", () => {
    knowledgeDashboard.myKnowledgeClick();
    knowledgeDashboard.knowledgeDashboardClick()
    knowledgeDashboard.dataGridInKnowledgeDashboardVerification();
    knowledgeDashboard.columnConfiurationDropdownTextVerification();
    patternDashboard.columnConfigurationDropdownClick();
    knowledgeDashboard.selectedColumnsChekboxCountVerification();
    knowledgeDashboard.unSelectedColumnsChekboxCountVerification();
    knowledgeDashboard.selectedColumnsTextCountVerification();
    knowledgeDashboard.unSelectedColumnsTextCountVerification();
    patternDashboard.pageNavigationClick();
    cy.reload()
    cy.wait(2000)
    patternDashboard.unSelectedAllColumnsChekboxClick();
    patternDashboard.pageNavigationClick();
    cy.reload()
    cy.wait(2000)
    patternDashboard.selectedAllColumnsChekboxClick();
    patternDashboard.pageNavigationClick();
    patternDashboard.unSelectedAllColumnsChekboxClick();
    cy.reload()
    cy.wait(2000)
    patternDashboard.unSelectedAllColumnsChekboxClick();
    patternDashboard.pageNavigationClick();
    console.log(printTimestamp(), ' Repeated all steps in my knowledge dashboard')
});