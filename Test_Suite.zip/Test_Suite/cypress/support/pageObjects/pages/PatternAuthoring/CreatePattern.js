import "../../../index"
import AssertionConstants from "../../../../support/pageObjects/pages/AssertionConstants"
const assertionConstants = new AssertionConstants();
import CreatePatternPageLocators from "../../../../support/pageObjects/PageComponents/createpattern"
const createPatternPageLocators = new CreatePatternPageLocators();
const filePath = 'cypress/fixtures/patternNameCreation.json'
import { userID_Alpha_Numeric } from '../../../../support/commands';

const [patternNameArrey, patternNameUpdatedArrey, arr5, arr4, arr6, arr7] = [[], [], [], [], [], []]
const [patternNames, detailsArrey, PatternName, patternNameInMyPattern] = [[], [], [], []]
const [logicalExpressionArrey, logicalExpressionBeforeAndAfterGrouping, logicalExpressionUnderEvents] = [[], [], []]
const [secondArreyOfLoogicalExpression, patternAndDataModelDetailsArrey, expressionArrey, expressionArreyRulePattern] = [[], [], [], []]
const [arr, patternDetailsArrey, textArrey, arr1, arr2] = [[], [], [], [], []]
let tagValuesList = []
const [addedExpressionInC1OfE1Arrey, addedExpressionInC1OfE2Arrey] = [[], []]
const arreyOfexpressionForAddedCondition = []
let PatternNameValue = ''

//constants
const popupText = 'Are you sure you want to delete the following 1 data model(s)? All its dependent events (if any) will also be deleted.'
const authoringWorkFlowCreatedCreatedMessage = "Workflow Created Successfully"
const createPatternPage = ' Create Pattern '
const defaultCurrrentPageOfTotalPageText = ' Showing 1 of 772 '
const defaultCurrentPageOfTotalPageTextInPatternDashBoard = ' Showing 1 of 75 '
const renamedAuthoringWorkFlowName = 'RenamedWorkFlow'
const renamedExistingAuthoringWorkFlowName = 'RenamedAgain'
const relevanceNoResultsFoundMessageText = ' No results found '
const addActionValue = 'Insert Alert'
const eventNameUnderEvent = ' EventLog4 '
const conditionTextUnderEvent = 'C1 = '
const conditionTwoTextUnderEvent = 'C2 = '
const dataModelText = 'EventLog'
const addCondition = 'Add Action '
const addedCondition = '[   EventLog1  ]'
const modality = 'CT, DCP, DXR'
const patternType = 'Diagnostics'
const firstEventName = ' EventLog1 '
const secondEventName = ' EventLog2 '
const eventThreeName = ' EventLog3 '
const eventFourName = ' EventLog4 '
const eventSixName = ' EventLog6 '
const eventSevenName = ' EventLog7 '
const eventEightName = ' EventLog8 '
const eventNineName = ' EventLog9 '
const ConditionFourText = 'C4 = '
const ConditionTwoText = 'C2 = '
const ConditionThreeText = 'C3 = '
const knowledgeDescription = 'Description '
const knowledgeSymptom = 'Symptoms'
const knowledgeCauseAndSolution = 'Causes and Solutions'
const knowledgeTags = 'Tags'
const recordsFoundText = 'records found'
const adConditionTab = 'Add Condition '
const addActionTab = "Add Action "
const discriptioAttribute = 'Description'
const processIdAttribute = 'ProcessID'
const relatedEventIndexAttribute = 'RelatedEventIndex'
const systemUIDAttribute = 'SystemUID'
const componentAttribute = 'Component'
const lineNumberAttribute = 'LineNumber'
const operatorsUnderAttributeDropdown = '[class="dropdown-option-ellipses pt-option ng-star-inserted"]'
const myPatternThreeDots = '[id="Layer_1"]'
const createPattern = '[id="Create Pattern"]'
const workflowSuccessText = "Workflow Created Successfully"
const importDataModelDropdownCommon = "Common"
const importDataModeldropdownmr = "MR"
const fromdataModel = " From Data Model "
const fromrulePattern = "From Rule/Pattern"
const fromVariable = " From Variable "
const raiseAlert = "Raise Alert"
const insertAlert = "Insert Alert"
const suppressAlert = "Suppress Alert"
const draftSavedText = 'Workflow Saved Successfully'
const withoutKeywordSection = "Without Keyword"
const withKeywordSection = "With Keyword"
const doneButton = "Done"
const noVariablesTextVerification = " No Variables added "
const noteInImportDataModelVisible = 'Select the data models you want to import'
const tagsValuesWithCommaVerification = "PB==Velara, FV==X-ray generation"
const addKnowledgeButton = "Add Knowledge"
const extendsTab = "Extends "
const deleteWorkFlowMessage = " Workflow Deleted Successfully"
const noDataModelImportedText = " No Data Models imported "
const keywordType = 'Testing{enter}'
const importConditionHeading = "Import Conditions";
const cancelButton = "Cancel"
const commonOptionUnderImportDataModel = 'Common'
const text = ' No Data Models imported '
const eventLogDataModel = 'EventLog'
const operatorWaterMark = 'Operator'
const textInEventone = 'Save as rule'
const logicalOperatorForSecondCondition = ' AND '
const formRulePatternOption = 'From Rule/Pattern'
const asACloneOption = 'As a Clone'
const asIsOption = 'As is'
const andOperator = ' AND '
const entriesPerPageText = ' Entries per page: '
const causeAndSolutionText = 'Causes and Solutions '
const selectedAttribute = 'AdditionalInfo'
const indexAttributesOptions = 'Index'
const cloneOptionInPatternDetail = 'Clone'
const knowledgeDetailslable = '"Knowledge Details"';
const lineNumberOperatorInEventLogThree = ' LineNumber '
const indexOperatorInEventThreeAttrTwo = ' ProcessID '
const addedAdditionalKnowledge = ' Ask the customer to complete '
const firstSelectedKnowledgeText = "  Check the motor voltage";
const orderOfExecutionErrorMessage = "Should be between the range (-32768 and 32768). "
const renamedPopUptext = "Workflow Renamed Successfully"
const attributeWaterMark = 'Attribute'
const eventIdAttribute = 'EventID'
const equipmentNumberAttribute = 'EquipmentNumber'
const additionalInfoAttribute = 'AdditionalInfo'
const orderOfExecutionNegativeValue = '-32768'
const orderOfExecutionNegativeWrongValue = '-32769'
const orderOfExecutionPositiveValue = '32767'
const selectedRaiseAlertoptionText = 'Raise Alert'
const insertAlertText = 'Insert Alert'
const selectedsupressAlertOptionText = 'Suppress Alert'
const severityTextAFterSecondTimeUpdation = '3-System Restricted'

const patternNameIndicatorText = 'Pattern name is already in use. Please choose a different name.'

class CreatePattern {
  // Constants
  clickedFromRulePatternAndAddCondition = 'clicked on From Rule-Pattern from + Add Condition'

  buttonsVisibleAsDisabled() {
    cy.get(createPatternPageLocators.withdrawButton).should(assertionConstants.haveClassAssertion,'disable-click-withTooltip')
    cy.get(createPatternPageLocators.deletePatternButtonInDashboard).should(assertionConstants.haveClassAssertion,'disable-click-withTooltip')
  }
  patternNameInsidePatternTextCapture() {
    cy.get(createPatternPageLocators.patternNameInsidePattern).invoke('text').then((valueText)=>{
      arr.length=0;
      cy.wait(3000)
      arr.push(valueText)
    })
  }
  patternNameTypeInFilter() {
    cy.get(createPatternPageLocators.patternNameFilterTextField).type(arr[0]).type('{enter}')
  }
  selectButtonInsidePatternClick() {
    cy.get(createPatternPageLocators.selectButtonInsidePattern).last().click()
  }
  cancelButtonInsidePatternClick() {
    cy.get(createPatternPageLocators.cancelButtonInsidePattern).click()
  }
  rightsideAccordiansVerification() {
    cy.get(createPatternPageLocators.rightsideAccordians).first().click()
    cy.get(createPatternPageLocators.rightsideAccordians).first().click()
  }
  selectAllCheckboxClick() {
    cy.get(createPatternPageLocators.selectAllCheckboxClick).last().click({force: true})
  }
  tagsFieldClick() {
    cy.xpath(createPatternPageLocators.tagsField).scrollIntoView().click();
  }
  removeButtonClick() {
    cy.get(createPatternPageLocators.removeButton).click()
  }
  addButtonClick() {
    cy.get(createPatternPageLocators.addButton).click()
  }
  previousButtonInsidePatternVisible() {
    return cy.get(createPatternPageLocators.previousButtonInsidePattern).should(assertionConstants.beVisibleAssertion)
  }
  saveAsDraftButtonInsidePatternVisible() {
    return cy.get(createPatternPageLocators.saveAsDraftButtonInsidePattern).should(assertionConstants.beVisibleAssertion)
  }
  saveAsDraftButtonInsidePatternClick() {
    return cy.get(createPatternPageLocators.saveAsDraftButtonInsidePattern).click()
  }
  closeButtonInsidePatternVisible() {
    return cy.get(createPatternPageLocators.closeButtonInsidePattern).should(assertionConstants.beVisibleAssertion)
  }
  closeButtonInsidePatternClick() {
    return cy.get(createPatternPageLocators.closeButtonInsidePattern).click()
  }
  versionColumnVisible() {
    return cy.get(createPatternPageLocators.versionColumn).should(assertionConstants.beVisibleAssertion)
  }
  patternNameColumnVisible() {
  return cy.get(createPatternPageLocators.patternNameColumn).should(assertionConstants.beVisibleAssertion)
  }
  metadataSeverityVisible(){
    cy.get(createPatternPageLocators.metadataSeverity).first().invoke('text').should('include','2-System Down')
  }
  collapseScreenIconClick(){
    cy.get(createPatternPageLocators.collapseScreenIcon).click()
  }
  fullScreenIconClick(){
    cy.get(createPatternPageLocators.fullScreenIcon).first().click()
  }
  patternInfoInsidePatternClick(){
    cy.get(createPatternPageLocators.patternInfoInsidePattern).click()
  }
  patternInfoInsidePatternVisible(){
    cy.get(createPatternPageLocators.patternInfoInsidePattern).should(assertionConstants.beVisibleAssertion)
  }
  backAccordianVisible(){
    cy.get(createPatternPageLocators.backAccordian).should(assertionConstants.beVisibleAssertion)
  }
  patternNameInsidePatternVisible(){
    cy.get(createPatternPageLocators.newlyCreatedPatternText).should(assertionConstants.beVisibleAssertion)
  }
  bulkPublishButtonClick() {
    cy.get(createPatternPageLocators.bulkPublishButton).click()
  }
  tagSelectionDropdownSecondValueClick() {
    cy.get(createPatternPageLocators.tagSelectionDropdown).click()
    cy.get(createPatternPageLocators.patternTypeDropdown).eq(1).click()
  }
  tagSelectionDropdownFirstValueClick() {
    cy.get(createPatternPageLocators.tagSelectionDropdown).click()
    cy.get(createPatternPageLocators.patternTypeDropdown).eq(0).click()
  }
  updateButtonInPopUpVisible() {
    cy.get(createPatternPageLocators.doneButtonInPopUp).should(assertionConstants.beVisibleAssertion)
  }
  updateButtonInPopUpClick() {
    cy.get(createPatternPageLocators.doneButtonInPopUp).click()
  }
  cancelButtononInPopUpVisible() {
    return cy.get(createPatternPageLocators.cancelButtonPopUp).eq(1).should(assertionConstants.beVisibleAssertion)
  }
  selectTagHeadingVisible() {
    cy.get(createPatternPageLocators.selectTagHeading).should(assertionConstants.beVisibleAssertion)
  }
  selectAllRecords() {
    cy.get(createPatternPageLocators.selectAllCheckBox).first().click()
  }
  updateButtonVisible() {
    cy.get(createPatternPageLocators.updateButton).should(assertionConstants.beVisibleAssertion)
  }
  updateButtonClick() {
    cy.get(createPatternPageLocators.updateButton).click()
  }
  removeButtonVisible() {
    cy.get(createPatternPageLocators.removeButton).should(assertionConstants.beVisibleAssertion)
  }
  addButtonVisible() {
    cy.get(createPatternPageLocators.addButton).should(assertionConstants.beVisibleAssertion)
  }
  bulkStepNextClick() {
    cy.get(createPatternPageLocators.bulkStepNext).click();
  }
  criticalNeedFieldClick() {
    cy.xpath(createPatternPageLocators.criticalNeedField).click();
  }
  severityFieldClick() {
    cy.xpath(createPatternPageLocators.severityField).scrollIntoView().click();
  }
  setHundredEntriesPerPage() {
    cy.get(createPatternPageLocators.patternTypeDropdownInApplyMetadataPage).click()
    cy.get(createPatternPageLocators.patternTypeDropdown).eq(4).click();
  }
  seditTagAssociationsClick() {
    cy.get(createPatternPageLocators.editTagAssociations).click()
  }
  editTagAssociationsVisible() {
    cy.get(createPatternPageLocators.editTagAssociations).should(assertionConstants.beVisibleAssertion)
  }
  symptomsDataVisible() {
    cy.get(createPatternPageLocators.previewedSection).eq(0).should(assertionConstants.beVisibleAssertion)
  }
  causeAndSolutionsDataVisible() {
    cy.get(createPatternPageLocators.previewedSection).eq(2).should(assertionConstants.beVisibleAssertion)
  }
  publishedPatternStatusSelectionFromList() {
    cy.get(createPatternPageLocators.patternStatusColumn).eq(0).scrollIntoView()
    cy.get(createPatternPageLocators.patternStatusColumn).eq(0).click()
    cy.get(createPatternPageLocators.patternStatusOptions).eq(1).click()
    cy.get(createPatternPageLocators.patternStatusApplyButton).click()
  }
  knowledgeSectionClick() {
    cy.get(createPatternPageLocators.knowledgeClick).click()
  }
  patternSectionCollapseClick() {
    return cy.get(createPatternPageLocators.patternSectionCollapse).click()
  }
  applyMetadataHeadingClick() {
    return cy.get(createPatternPageLocators.applyMetadataHeading).click()
  }
  dateRangeSelectionInIncludeKnowledgeSection() {
    cy.get(createPatternPageLocators.valueTextBox).click()
    cy.get(createPatternPageLocators.monthBackNavigationIcon).eq(0).click()
    cy.get(createPatternPageLocators.calenderDateSelection).eq(8).click()
    cy.get(createPatternPageLocators.calenderDateSelection).eq(20).click()
    cy.get(createPatternPageLocators.limitSelection).clear().type('1')
    cy.get(createPatternPageLocators.applyMetadataHeading).click()
    cy.get(createPatternPageLocators.relevanceCheckbox).click({ force: true })
    cy.get(createPatternPageLocators.nextButton).click({ force: true })
    cy.wait(4000)
    cy.get(createPatternPageLocators.nextButton).click({ force: true })
    cy.get(createPatternPageLocators.validateButton).click()
    cy.get(createPatternPageLocators.saveAsDraft).click()
  }
  systemIdSelection() {
    cy.get(createPatternPageLocators.systemIdSelection).click()
    cy.get(createPatternPageLocators.systemIdOptions).eq(0).click()
    cy.get(createPatternPageLocators.systemIdOptions).eq(1).click()
    cy.get(createPatternPageLocators.systemIdApplyButton).click()
  }
  withdrawButtonVisibleAsEnabled() {
    cy.get(createPatternPageLocators.notificationClass,{timeout: 90000}).should(assertionConstants.beVisibleAssertion).then(()=>{
      cy.wait(3000)
      cy.get(createPatternPageLocators.checkboxInDashboard).eq(0).scrollIntoView()
      cy.get(createPatternPageLocators.checkboxInDashboard).eq(0).scrollIntoView().click({ force: true })
    })
  }
  withdrawButtonVisibleAsDisabled() {
    return cy.get(createPatternPageLocators.withdrawButton).should(assertionConstants.beVisibleAssertion)
  }
  withdrawButtonVisibleEnabled() {
      cy.get(createPatternPageLocators.withdrawButton).should(assertionConstants.beVisibleAssertion)
  }
  withdrawButtonClickAndWithdraw() {
    cy.get(createPatternPageLocators.withdrawButton).click()
    cy.get(createPatternPageLocators.okButtonClick).click()
  }
  publishButtonClick() {
    cy.get(createPatternPageLocators.publishButton).click()
    cy.get(createPatternPageLocators.okButtonClick).click()
  }
  selectAllRecordClickInDashboard() {
    cy.get(createPatternPageLocators.checkboxInDashboard).eq(0).scrollIntoView()
    cy.get(createPatternPageLocators.checkboxInDashboard).eq(0).scrollIntoView().click({ force: true })
  }
  patternNameTypeInSearchFilter() {
    cy.get(createPatternPageLocators.patternNameFilterTextField).type('Authoring_WF_Test{enter}')
  }
  modalityColumnClickAndCT_DCPSelection() {
    cy.get(createPatternPageLocators.modalityColumn).scrollIntoView().click()
    cy.get(createPatternPageLocators.patternStatusOptions).eq(0).click()
    cy.get(createPatternPageLocators.patternStatusOptions).eq(1).click()
    cy.get(createPatternPageLocators.modalityApplyButton).click()
  }
  modalityColumnClickAndCTSelection() {
    cy.get(createPatternPageLocators.modalityColumn).scrollIntoView()
    cy.get(createPatternPageLocators.modalityColumn).scrollIntoView().click()
    // cy.get(selectedModality).eq(0).click()
    cy.get(createPatternPageLocators.CTModality).click()
    cy.get(createPatternPageLocators.modalityApplyButton).click()
  }
  modalityColumnClickAndIGTSelection() {
    cy.get(createPatternPageLocators.modalityColumn).scrollIntoView().click()
    cy.get(createPatternPageLocators.selectedModality).first().click()
    cy.get(createPatternPageLocators.IGTModality).click()
    cy.get(createPatternPageLocators.modalityApplyButton).click()
  }
  servicecontextColumnClickAndFSESelection() {
    cy.get(createPatternPageLocators.servicecontextColumn).scrollIntoView().click()
    cy.get(createPatternPageLocators.patternStatusOptions).eq(0).click()
    cy.get(createPatternPageLocators.servicecontextApplyButton).click()
  }
  deletePatternButtonClickFromInsideOFPattern() {
    return cy.get(createPatternPageLocators.deleteButtonInsidePattern).click()
  }
  firstRecordsNaviagationLinkClick() {
    cy.get(createPatternPageLocators.recordsNaviagationLink).eq(0).click()
  }
  firstRecordsClickInDashboard() {
    cy.get(createPatternPageLocators.importDataModelDropdown).eq(1).click()
  }
  threeDotsGridButtonClickAndDelete() {
    cy.get(createPatternPageLocators.threeDotsGridButton).first().scrollIntoView()
    cy.wait(2000)
    cy.get(createPatternPageLocators.threeDotsGridButton).first().click({ force: true })
    cy.get(createPatternPageLocators.deleteOption).click()
  }
  filtersClearedVerification() {
    cy.xpath(createPatternPageLocators.modalityFilter).should(assertionConstants.notExistsAssertion)
  }
  withdrawButtonClick() {
    cy.get(createPatternPageLocators.withdrawButton).click()
  }
  clearAllFiltersButtonClick() {
    return cy.get(createPatternPageLocators.clearAllFiltersButton).click()
  }
  patternsDeletedNotVisible() {
    cy.readFile(filePath).then(function (result) {
      let PatternNames = result.name;
      cy.contains(PatternNames).should(assertionConstants.notExistsAssertion)
    });
  }
  deletePopUpVisible() {
    return cy.get(createPatternPageLocators.deletePopUp).should(assertionConstants.beVisibleAssertion)
  }
  deletePatternButtonInDashboardClick() {
    return cy.get(createPatternPageLocators.deletePatternButtonInDashboard).click()
  }
  firstFiveRecordClickInDashboard() {
    cy.get(createPatternPageLocators.checkboxInDashboard).eq(1).scrollIntoView()
    cy.get(createPatternPageLocators.checkboxInDashboard).eq(1).scrollIntoView().click({ force: true })
    cy.get(createPatternPageLocators.checkboxInDashboard).eq(2).click()
    cy.get(createPatternPageLocators.checkboxInDashboard).eq(3).click()
    cy.get(createPatternPageLocators.checkboxInDashboard).eq(4).click()
    cy.get(createPatternPageLocators.checkboxInDashboard).eq(5).click()
  }
  firstFiveRecordsClickInDashboard() {
    cy.get(createPatternPageLocators.checkboxInDashboard).eq(1).scrollIntoView().click({ force: true })
    cy.get(createPatternPageLocators.checkboxInDashboard).eq(1).scrollIntoView().click({ force: true })
    cy.get(createPatternPageLocators.checkboxInDashboard).eq(2).click()
    cy.get(createPatternPageLocators.checkboxInDashboard).eq(3).click()
    cy.get(createPatternPageLocators.checkboxInDashboard).eq(4).click()
    cy.get(createPatternPageLocators.checkboxInDashboard).eq(5).click()
    cy.get(createPatternPageLocators.checkboxInDashboard).eq(1).scrollIntoView().click({ force: true })
  }
  firstThreeRecordsClickAndPublish() {
    cy.get(createPatternPageLocators.checkboxInDashboard).eq(1).scrollIntoView().click({ force: true })
    cy.get(createPatternPageLocators.checkboxInDashboard).eq(2).click()
    cy.get(createPatternPageLocators.checkboxInDashboard).eq(3).click()
    cy.get(createPatternPageLocators.checkboxInDashboard).eq(1).scrollIntoView().click({ force: true })
    cy.get(createPatternPageLocators.publishButton).click()

  }
  nextFiveRecordsClickInDashboard() {
    cy.get(createPatternPageLocators.checkboxInDashboard).eq(0).scrollIntoView()
    cy.get(createPatternPageLocators.checkboxInDashboard).eq(6).scrollIntoView().click()
    cy.get(createPatternPageLocators.checkboxInDashboard).eq(7).click()
    cy.get(createPatternPageLocators.checkboxInDashboard).eq(8).click()
    cy.get(createPatternPageLocators.checkboxInDashboard).eq(9).click()
    cy.get(createPatternPageLocators.checkboxInDashboard).eq(10).click()
    cy.get(createPatternPageLocators.checkboxInDashboard).eq(11).click()
  }
  publishedAndWithdrawnPatternStatusSelection() {
    cy.get(createPatternPageLocators.patternStatusColumn).eq(0).scrollIntoView().click()
    // cy.get(patternStatusColumn).eq(0).click()
    cy.get(createPatternPageLocators.patternStatusOptions).eq(1).click()
    cy.get(createPatternPageLocators.patternStatusOptions).eq(2).click()
    cy.get(createPatternPageLocators.patternStatusApplyButton).click()
  }
  draftPatternStatusSelection() {
    cy.get(createPatternPageLocators.patternStatusColumn).eq(0).click()
    cy.get(createPatternPageLocators.patternStatusOptions).eq(0).click()
    cy.get(createPatternPageLocators.patternStatusApplyButton).click()
  }
  withdrawnPatternStatusSelection() {
    cy.get(createPatternPageLocators.patternStatusColumn).eq(0).click()
    cy.get(createPatternPageLocators.patternStatusOptions).eq(2).click()
    cy.get(createPatternPageLocators.patternStatusApplyButton).click()
  }
  publishedPatternStatusSelection() {
    cy.get(createPatternPageLocators.patternStatusColumn).eq(0).click()
    cy.get(createPatternPageLocators.patternStatusOptions).eq(1).click()
    cy.get(createPatternPageLocators.patternStatusApplyButton).click()
  }
  changeEntriesPerPageCountSizeInPatternDashboard() {
    cy.get(createPatternPageLocators.changeEntriesPerPageCount).first().click()
    cy.get(createPatternPageLocators.dropDownOptions).eq(3).click()
  }
  recordsAvailableInDashboardVerification() {
    return cy.get(createPatternPageLocators.recordsAvailableInDashboard).should(assertionConstants.havelengthAssertion, 50)
  }
  fiveRecordsSelectedVerification() {
    return cy.get(createPatternPageLocators.advanceFilterAppliedOnRecords).invoke('text').should('include', '5')
  }
  fiveRecordsSelectedVisible() {
    return cy.get(createPatternPageLocators.advanceFilterAppliedOnRecords).should(assertionConstants.beVisibleAssertion)
  }
  tenRecordsSelectedVerification() {
    return cy.get(createPatternPageLocators.advanceFilterAppliedOnRecords).invoke('text').should('include', '11')
  }
  draftPatternCountVerification() {
    cy.get(createPatternPageLocators.patternNameColumn).scrollIntoView()
    return cy.contains('Draft ').should(assertionConstants.haveLengthGreaterThanAssertion, 2)
  }
  publishedPatternCountVerification() {
    cy.get(createPatternPageLocators.patternNameColumn).scrollIntoView()
    return cy.contains('Published ').should(assertionConstants.beVisibleAssertion)
  }
  publishedPatternNotExistVerification() {
    cy.get(createPatternPageLocators.patternNameColumn).scrollIntoView()
    return cy.contains('Published ').should(assertionConstants.notExistsAssertion)
  }
  withdrawnPatternCountVerification() {
    cy.get(createPatternPageLocators.patternNameColumn).scrollIntoView()
    return cy.contains('Withdrawn ').should(assertionConstants.beVisibleAssertion)
  }
  includeKnowledgeHeadingClick() {
    return cy.get(createPatternPageLocators.includeKnowledgeHeading).click()
  }
  newlyCreatedPatternNavigation() {
    cy.readFile(filePath).then(function (result) {
      let PatternNames = result.name;
      cy.get('#' + PatternNames).click();
    });
  }
  recordSelectionInIncludeKnowledge() {
    cy.get(createPatternPageLocators.selectAllCheckBox).eq(2).click()
  }
  myPatternThreeDotsVisible() {
    return cy.get(createPatternPageLocators.myPatternThreeDots).first().scrollIntoView().should(assertionConstants.beVisibleAssertion)
  }
  myPatternsSectionCollapseIconClick() {
    cy.get(createPatternPageLocators.myPatternsSectionCollapseIcon).click()
  }
  knowledgeNameType() {
    cy.get(createPatternPageLocators.knowledgeNameSearch).click().type(arr[0]).type('{enter}')
  }
  knowledgeNameClear() {
    cy.get(createPatternPageLocators.knowledgeNameSearch).clear().type('{enter}')
  }
  clinedPatternNameVisibleInNewCreatedPattern() {
    cy.readFile(filePath).then(function (result) {
      let PatternNames = result.name;
      cy.contains(PatternNames).should(assertionConstants.beVisibleAssertion)
    });
  }
  patternNameSearch() {
    cy.readFile(filePath).then(function (result) {
      let PatternNames = result.name;
      cy.get(createPatternPageLocators.patternFilterOption).type(PatternNames);
    });
  }
  invalidRegexEnteredVerification() {
    cy.get(createPatternPageLocators.valueTextBox).find('input').should(assertionConstants.haveClassAssertion, 'value-input-field pt-input ng-dirty ng-touched ng-invalid')
  }
  ValidRegexEnteredVerification() {
    cy.get(createPatternPageLocators.valueTextBox).find('input').should(assertionConstants.haveClassAssertion, 'value-input-field pt-input ng-touched ng-valid ng-pristine')
  }
  valueTextBoxClickAndInvalidRegexType() {
    cy.get(createPatternPageLocators.valueTextBox).clear().type('[0-1')
    cy.get(createPatternPageLocators.expandedAddConditionSectionVerification).click()
  }
  valueTextBoxClickAndValidRegexType() {
    cy.get(createPatternPageLocators.valueTextBox).clear().type('Flexi.*')
    cy.get(createPatternPageLocators.expandedAddConditionSectionVerification).click()
  }
  operatorsDropdownClickAndMatchesOperatorSelection() {
    cy.get(createPatternPageLocators.operatorsDropdown).click()
    cy.contains('matches ').click()
  }
  selectedTagsVisible() {
    return cy.xpath(createPatternPageLocators.tagsColumnRecord).scrollIntoView().should(assertionConstants.beVisibleAssertion);
  }
  tagsColumnFirstValueSelectedNotVisible() {
    cy.get(createPatternPageLocators.tagColumnFirstRecord).eq(6).invoke('text').should('not.include', 'Collimeter')
  }
  tagsColumnFirstValueSelectedVerification() {
    cy.get(createPatternPageLocators.tagColumnFirstRecord).eq(6).invoke('text').should('include', 'AWS')
  }
  tagsColumnMultipleValueSelectedVerification() {
    cy.get(createPatternPageLocators.tagColumnFirstRecord).eq(6).invoke('text').should('include', 'AWS, Collimeter, DAP/Collimator')
  }
  searchByKeywordType() {
    cy.get(createPatternPageLocators.searchByKeywordOption).type('detector{enter}')
  }
  datamodelsColumnValueFilteredVerification() {
    return cy.get(createPatternPageLocators.datamodelsColumnSelectedValue).first().invoke('text').should('not.include', 'All').should('include', 'EventLog')
  }
  datamodelsColumnValueNotFilteredVerification() {
    return cy.get(createPatternPageLocators.datamodelsColumnSelectedValue).first().invoke('text').should('include', 'All')
  }
  dataModelsColumnClickAndValueSelection() {
    cy.get(createPatternPageLocators.multiselectFiltersInImportConditionSection).first().click()
    cy.get(createPatternPageLocators.firstValueInDataModelsDropdownInImportCondition).click()
    cy.get(createPatternPageLocators.datamodelsApplyButton).click()
  }

  threeDotsGridButtonClickAndClone() {
    cy.get(createPatternPageLocators.threeDotsGridButton).first().scrollIntoView().click({force: true})
    cy.get(createPatternPageLocators.threeDotsGridButton).first().scrollIntoView().click({force: true})
    cy.get(createPatternPageLocators.cloneButtonFromGrid).click()

  }

  createPatternHeadingClick() {
    return cy.get(createPatternPageLocators.createPatternHeading).click()
  }

  workflowStepsListVisible() {
    return cy.get(createPatternPageLocators.workflowStepsList).each(($el) => {
      cy.wrap($el).should(assertionConstants.beVisibleAssertion)
    })
  }

  saveAsDraftButtonAsDisabled() {
    cy.get(createPatternPageLocators.popUpOkButton).should(assertionConstants.haveAttributeAssertion, 'class', createPatternPageLocators.disabledClass)
  }

  removeActionForceClick() {
    return cy.get(createPatternPageLocators.removeAction).last().click({ force: true })
  }

  patternInformationNotVisible() {
    return cy.get(createPatternPageLocators.patternInformation).should(assertionConstants.notExistsAssertion)
  }

  breadcumbLastValueAsDashboardVisible() {
    return cy.get(createPatternPageLocators.breadcumbLastValue).invoke('text').should('include', 'Dashboard')
  }

  buttonsVerificationAfterCorrectPatternDetails() {
    cy.get(createPatternPageLocators.closeButton).should(assertionConstants.notHaveClassAssertion, createPatternPageLocators.disabledClass)
    cy.get(createPatternPageLocators.popUpOkButton).should(assertionConstants.notHaveClassAssertion, 'class', createPatternPageLocators.disabledClass)
    cy.get(createPatternPageLocators.nextButtton).should(assertionConstants.haveAttributeAssertion, 'class', createPatternPageLocators.disabledClass)
  }

  patternNameDetailsCleartext() {
    cy.get(createPatternPageLocators.patternNameTextBox).clear()
    cy.wait(2000)
  }

  invalidPatternNameEnteredValidationMessageVerification() {
    cy.get(createPatternPageLocators.invalidPatternNameEnteredValidationMessage).invoke('text').should('include', 'Pattern name is already in use. Please choose a different name.')
  }

  patternNameTextBoxInvalidNameType() {
    cy.get(createPatternPageLocators.existingPatternNameCapture).eq(5).invoke('text').then((value) => {
      cy.writeFile(filePath, { name: value })
      cy.wait(2000)
    })
    cy.readFile(filePath).then(function (result) {
      let PatternNames = result.name;
      cy.get(createPatternPageLocators.patternNameTextBox).type(PatternNames);
    });
  }

  logicalExpressionAtEventLevelAfterGroupingForRulePattern() {
    cy.get(createPatternPageLocators.logicalExpressionAtEventLevelForEvents).children().invoke('text').then((updatedexpression) => {
      expect(updatedexpression).to.exist
    })
  }

  logicalExpressionAtEventLevelAfterUngroupingGroupedAndUngroupedEvent() {
    cy.get(createPatternPageLocators.logicalExpressionAtEventLevelForEvents).children().invoke('text').then((updateexpression) => {
      expect(updateexpression).to.exist
    })
  }
  logicalExpressionAtEventLevelAfterGroupingGroupedAndUngroupedEvent() {
    cy.get(createPatternPageLocators.logicalExpressionAtEventLevelForEvents).children().invoke('text').then((updateexpression) => {
      arr6.push(updateexpression)
      cy.log(arr)
      expect(updateexpression).to.exist
    })
  }

  logicalExpressionAtEventLevelAfterGrouping() {
    cy.get(createPatternPageLocators.logicalExpressionAtEventLevelForEvents).children().invoke('text').then((updatedexpression) => {
      arr6.push(updatedexpression)
      expect(updatedexpression).to.exist
    })
  }
  updatedlogicalExpressionUnderEventVisible() {
    cy.get(createPatternPageLocators.logicalExpressionUnderEvent).eq(0).invoke('text').then((updatedexpression) => {
      arr5.push(updatedexpression)
      expect(updatedexpression).to.exist
      expect(updatedexpression).to.not.equal(arr4[0])
    })
  }
  operatorDropdownAtEventAndConditionBetweenEventFourAndFiveClick(){
    cy.get(createPatternPageLocators.operatorDropdownAtEventAndCondition).eq(8).click()
  }

  getPatternName() {
    cy.get(createPatternPageLocators.patternDashboardBreadCrum).find('[class="pt-layout-container"]').find('ul').children('li').last().find('a').find('span').invoke('text').then((Name) => {
      patternNames.push(Name)
      cy.wait(3000)
      cy.log(patternNames)
    })
  }

  checkBoxAtEventOneClick() {
    cy.get(createPatternPageLocators.checkBox).eq(0).click()
  }

  eventOneNotExist() {
    cy.get(createPatternPageLocators.createdEvent).first().should(assertionConstants.notContainAssertion, ' EventLog1 ')
  }

  eventOneVisible() {
    cy.get(createPatternPageLocators.createdEvent).first().should(assertionConstants.containAssertion, ' EventLog1 ').and(assertionConstants.beVisibleAssertion)
  }

  patternNameTypeInPatternInformationSection() {
    let x = 'Authoring_WF_Test' + Math.floor((Math.random() * 1000) + 1);
    cy.wait(2000)
    cy.readFile(filePath).then(function (result) {
      cy.wait(3000)
      let PatternNameTypehh = result.name;
      cy.get(patternName).type(result.name);
    });
  }

  SaveAsDraftClick() {
    return cy.get(createPatternPageLocators.saveAsDraft).click()
  }
  deleteButtonInDeleteWFPopupVisible() {
    cy.get(createPatternPageLocators.okButtonClick).should(assertionConstants.beVisibleAssertion)
  }
  cancelButtonInDeleteWFPopupVisible() {
    cy.get(createPatternPageLocators.cancelButtonInDeleteWFPopup).should(assertionConstants.beVisibleAssertion)
  }
  cancelButtonInDeleteWFPopupClick() {
    cy.get(createPatternPageLocators.cancelButtonInDeleteWFPopup).click()
  }
  deleteWFBodyTextVisible() {
    cy.get(createPatternPageLocators.deleteWFBodyText).should(assertionConstants.beVisibleAssertion)
  }
  deleteWFTextVisible() {
    cy.get(createPatternPageLocators.deleteWFText).should(assertionConstants.beVisibleAssertion)
  }
  deleteOptionClick() {
    return cy.get(createPatternPageLocators.deleteOption).click({ force: true })
  }
  renamedPopUptextVisible() {
    cy.contains(renamedPopUptext).should(assertionConstants.beVisibleAssertion)
  }
  renameInvalidValueType() {
    cy.get(createPatternPageLocators.renameInputBox).first().then(() => {
      cy.readFile(filePath).then(function (result) {
        PatternNameValue = result.PatternNameWithInvalidLength;
        cy.get(renameInputBox).first().clear().type(PatternNameValue).type('{enter}')
      });
    })
  }
  renameTextBoxType() {
    cy.get(createPatternPageLocators.renameInputBox).first().clear().type('RenamedWF{enter}')
  }
  NewPatternCreatedThreeDotsClickAndItsAvailableButtonsVerification() {
    cy.get(createPatternPageLocators.renameOption).should(assertionConstants.beVisibleAssertion);
    cy.get(createPatternPageLocators.deleteOption).should(assertionConstants.beVisibleAssertion);
  }
  NewPatternCreatedNotVisible() {
    cy.get(createPatternPageLocators.breadcumbLastValue).last().invoke("text")
      .then((text1) => {
        cy.get(
          "#" + text1 + " > #nav-dropdown-btn > .ng-star-inserted > #Layer_1"
        ).last().scrollIntoView().should(assertionConstants.notExistsAssertion)
      })
  }
  orderOfExecutionTextBoxAlfabetInvalidValueTypeAndVerification() {
    cy.get(createPatternPageLocators.orderOfExecutionTextbox).type('ABC')
    cy.get(createPatternPageLocators.orderOfExecutionTextbox).should(assertionConstants.haveAttributeAssertion, 'placeholder', '0 (Default)')
  }
  orderOfExecutionTextBoxValidValueVerification() {
    cy.get(createPatternPageLocators.orderOfExecutionTextbox).clear().type(orderOfExecutionNegativeValue)
    cy.contains(orderOfExecutionErrorMessage).should(assertionConstants.notExistsAssertion)
    cy.get(createPatternPageLocators.orderOfExecutionTextbox).clear().type(orderOfExecutionPositiveValue)
    cy.contains(orderOfExecutionErrorMessage).should(assertionConstants.notExistsAssertion)
  }
  orderOfExecutionTextBoxInValidValueVerification() {
    cy.get(createPatternPageLocators.orderOfExecutionTextbox).clear().type(orderOfExecutionNegativeWrongValue)
    cy.contains(orderOfExecutionErrorMessage).should(assertionConstants.beVisibleAssertion)
  }
  orderOfExecutionTextBoxInValidWithNegativeValuTextVerification() {
    cy.get(createPatternPageLocators.orderOfExecutionTextbox).clear().type('3-3-3-3')
    cy.get(createPatternPageLocators.orderOfExecutionTextbox).should(assertionConstants.haveClassAssertion, 'pt-input ng-dirty ng-touched ng-invalid')
  }
  nextButtonInPatternVisibleAsEnabled() {
    cy.get(createPatternPageLocators.nextButtonInPattern).should(assertionConstants.haveClassAssertion, 'pt-primary pt-button ng-star-inserted')
  }
  orderOfExecutionTextBoxValueClear() {
    cy.get(createPatternPageLocators.orderOfExecutionTextbox).clear()
  }
  orderOfExecutionTextBoxValueType() {
    cy.get(createPatternPageLocators.orderOfExecutionTextbox).type('123')
  }
  orderOfExecutionTextBoxDefaultValueVerification() {
    cy.get(createPatternPageLocators.orderOfExecutionTextbox).should(assertionConstants.haveAttributeAssertion, 'placeholder', '0 (Default)')
  }
  orderOfExecutionTextBoxVisible() {
    cy.get(createPatternPageLocators.orderOfExecutionTextbox).should(assertionConstants.beVisibleAssertion)
  }
  descriptionVisible() {
    cy.get(createPatternPageLocators.descriptionSection).should(assertionConstants.beVisibleAssertion)
  }
  deleteWorkFlowMessageVisible() {
    return cy.contains(deleteWorkFlowMessage).should(assertionConstants.beVisibleAssertion);
  }
  renameOptionVisible() {
    return cy.get(createPatternPageLocators.renameOption).should(assertionConstants.beVisibleAssertion);
  }
  deleteOptionVisible() {
    return cy.get(createPatternPageLocators.deleteOption).should(assertionConstants.beVisibleAssertion);
  }
  workflowSuccessTextVisible() {
    return cy.contains(workflowSuccessText).should(assertionConstants.beVisibleAssertion);
  }
  breadcumbClassFind() {
    return cy.get(createPatternPageLocators.patternDashboardBreadCrum).find(createPatternPageLocators.ptLayoutContainerClass)
  }
  noResultsFoundInRelevanceMessageVisible() {
    cy.contains(createPatternPageLocators.noResultsFoundInRelevanceMessage).scrollIntoView().should(assertionConstants.beVisibleAssertion);
  }
  ThreeDotsClick(value) {
    cy.get("section[id='" + value + "'] > #nav-dropdown-btn > .ng-star-inserted > #Layer_1")
  }
  breadcumbLastValueCapture() {
    cy.get(createPatternPageLocators.breadcumbLastValue).last()
      .invoke("text")
      .then((textValue) => {
        arr.length = 0;
        cy.wait(2000)
        arr.push(textValue);
        cy.log(arr)
      });
  }
  NewPatternCreatedThreeDotsClick() {
    cy.wait(2000)
    cy.get("#" + arr[0] + " > #nav-dropdown-btn > .ng-star-inserted > #Layer_1").last().click()
  }
  patternNameLength() {
    cy.get(createPatternPageLocators.breadcumbLastValue).last()
      .invoke("text")
      .then((textValue) => {
        arr.length = 0;
        cy.wait(2000)
        arr.push(textValue);
        cy.log(arr)
        cy.wait(2000)
      });
    expect(arr[0]).to.have.lengthOf(250)
  }
  NewPatternThreeDotsClick() {
    cy.wait(2000)
    cy.get(createPatternPageLocators.breadcumbLastValue).last().invoke("text")
      .then((text1) => {
        cy.get(
          "#" + text1 + " > #nav-dropdown-btn > .ng-star-inserted > #Layer_1"
        ).first().scrollIntoView().click()
      })
  }
  NewPatternCreatedVisible() {
    cy.get(createPatternPageLocators.breadcumbLastValue).last().invoke("text")
      .then((text1) => {
        cy.get(
          "#" + text1 + " > #nav-dropdown-btn > .ng-star-inserted > #Layer_1"
        ).last().scrollIntoView().should(assertionConstants.beVisibleAssertion);
      })
  }
  newlyCreatedWFAndItsThreeDotsVisible() {
    cy.get("#" + arr[0]).eq(0).scrollIntoView().should(assertionConstants.beVisibleAssertion);
    cy.get("#" + arr[0] + " > #nav-dropdown-btn > .ng-star-inserted > #Layer_1").scrollIntoView().should(assertionConstants.beVisibleAssertion);
  }
  addTagPlusIconClick() {
    return cy.get(createPatternPageLocators.addTagPlusIcon).click()
  }
  myPatternPageNavigation() {
    cy.get(createPatternPageLocators.breadcrumbValues).eq(2).click()
  }
  NewPatternCreatedVerification() {
    cy.wait(2000)
    cy.get(createPatternPageLocators.breadcrumbValues).last().should(assertionConstants.beVisibleAssertion);
    cy.get(createPatternPageLocators.breadcrumbValues).last().invoke('text').then((value) => {
      patternDetailsArrey.length = 0
      patternDetailsArrey.push(value)
    })
  }
  NewPatternCreatedThreeDotsClickAndVerification() {
    cy.wait(2000)
    cy.get(
      "#" + patternDetailsArrey + " > #nav-dropdown-btn > .ng-star-inserted > #Layer_1"
    ).last().click({ force: true })
    cy.get(createPatternPageLocators.renameOption).should(assertionConstants.beVisibleAssertion);
    cy.get(createPatternPageLocators.deleteOption).should(assertionConstants.beVisibleAssertion);
  }
  NewPatternCreatedThreeDotsClickAndDeletion() {
    cy.get(
      "#" + patternDetailsArrey + " > #nav-dropdown-btn > .ng-star-inserted > #Layer_1"
    ).last().click({ force: true })
    cy.get(createPatternPageLocators.deleteOption).click({ force: true });
    cy.get(createPatternPageLocators.okButtonClick).click()
  }
  patternVisibleInDashboard() {
    cy.log(patternDetailsArrey)
    cy.wait(3000)
    cy.get('#' + patternDetailsArrey).scrollIntoView().should('exist');
  }
  newlyCreatedPatternVisit() {
    cy.get('#' + patternDetailsArrey).click()
  }
  createPatternHeadingActiveVerification() {
    return cy.get(createPatternPageLocators.createPatternHeading).should(assertionConstants.haveAttributeAssertion, 'class', createPatternPageLocators.activeClass);
  }
  workflowsVisible() {
    return cy.get(createPatternPageLocators.workflow).eq(5).should(assertionConstants.beVisibleAssertion);
  }
  MyPatternDashboardVisible() {
    return cy.get(createPatternPageLocators.dashboard).eq(1).should(assertionConstants.beVisibleAssertion);
  }
  breadcrumbValuesVisible() {
    cy.get(createPatternPageLocators.breadcrumbValues).each(($el) => {
      cy.wrap($el).should(assertionConstants.beVisibleAssertion)
    });
  }
  patternInformationTabVisible() {
    return cy.contains(createPatternPageLocators.patternInformationTab).should(assertionConstants.beVisibleAssertion);
  }
  validDataValidationTestingAtDaySpanInApplyMetadataPage() {
    cy.get(createPatternPageLocators.daySpan).click().type('24')
  }
  invalidDataValidationTestingAtDaySpanInApplyMetadataPage() {
    cy.get(createPatternPageLocators.daySpan).click().clear().then(() => {
      cy.get(createPatternPageLocators.daySpan).should(assertionConstants.haveAttributeAssertion, 'class', 'ng-untouched pt-input ng-dirty ng-invalid')
    })
  }
  validationFailureVisible() {
    cy.get(createPatternPageLocators.daySpan).should(assertionConstants.haveAttributeAssertion, 'class', 'ng-untouched pt-input ng-dirty ng-invalid')
  }
  nextButtonVisibleAsDisabled() {
    cy.get(createPatternPageLocators.nextButtton).should(assertionConstants.haveAttributeAssertion, 'class', createPatternPageLocators.disabledClass);
  }
  patternTypeDropdownInApplyMetadataPageSelection() {
    cy.get(createPatternPageLocators.patternTypeDropdownInApplyMetadataPage).eq(1).click();
    cy.get(createPatternPageLocators.patternTypeDropdown).eq(0).click();
  }
  createPatternPageInformationSubmission() {
    this.patternName().click();
    let x = 'Authoring_WF_Test' + Math.floor((Math.random() * 1000) + 1);
    cy.writeFile(filePath, { name: x })
    cy.wait(2000)
    cy.readFile(filePath).then(function (result) {
      let PatternNames = result.name;
      cy.get(createPatternPageLocators.patternName).type(PatternNames);
    });
    cy.get(createPatternPageLocators.description).click();
    cy.get(createPatternPageLocators.description).type(Cypress.env("PatternDescription"));
    this.importdatamodelTab().click();
    cy.get(createPatternPageLocators.importdatamodelDropdownArrow).click();
    cy.wait(2000)
    cy.contains(importDataModelDropdownCommon).last().click();
    cy.get(createPatternPageLocators.clickoutsidetoGetResult).click({ force: true });
    cy.contains(adConditionTab).click();
    cy.get(createPatternPageLocators.addConditionPlusIcon).click({ force: true });
    cy.contains(" From Data Model ").click();
    this.option1Click();
    cy.contains("AdditionalInfo").click({ force: true });
    this.operatorsDropdownClick()
    cy.contains("==").click({ force: true });
    this.valueInputField()
    this.addActionTab().click();
    cy.get(createPatternPageLocators.addActionPlusIcon).should(assertionConstants.beVisibleAssertion);
    cy.get(createPatternPageLocators.addActionPlusIcon).click({ force: true });
    cy.contains(raiseAlert).click({ force: true });
  }
  addActionTabExpandedVisible() {
    return cy.get(createPatternPageLocators.addActionPlusIcon).should(assertionConstants.beVisibleAssertion);
  }
  addActionTabClick() {
    return cy.contains(addActionTab).click();
  }
  mandatoryFieldsWithAsteriskInCreatePatternPageVisible() {
    cy.get(createPatternPageLocators.mandatoryFieldsWithAsterisk).each(($el) => {
      cy.wrap($el).should(assertionConstants.beVisibleAssertion)
    });
  }
  mandatoryFieldsInCreatePatternPageVisible() {
    cy.get(createPatternPageLocators.mandatoryFields).each(($el) => {
      cy.wrap($el).should(assertionConstants.beVisibleAssertion)
    });
  }
  gridVerificationInPattern() {
    cy.get(createPatternPageLocators.gridVerification).each(($el) => {
      cy.wrap($el).should(assertionConstants.beVisibleAssertion)
    });
  }
  recordsTextInvokeFunction1(record, textValue) {
    cy.xpath(record).invoke('text').then((value) => {
      cy.wait(2000)
      patternDetailsArrey.length = 0
      patternDetailsArrey.push(value.slice(0, textValue))
    });
  }
  recordsTextInvokeFunction2(record, textValue) {
    cy.xpath(record).invoke('text').then((value) => {
      cy.wait(2000)
      textArrey.length = 0
      textArrey.push(value.slice(0, textValue))
    });
  }
  importConditionHeadingNotVisible() {
    return cy.contains(importConditionHeading).should(assertionConstants.notExistsAssertion)
  }
  cancelButtonClick() {
    return cy.contains(cancelButton).click()
  }
  descriptionColumnClickAndSortingOfDataVerification() {
    cy.get(createPatternPageLocators.discriptionColumn).click();
    this.recordsTextInvokeFunction1(createPatternPageLocators.descriptionInAddConditionRecord1, 3)
    this.recordsTextInvokeFunction2(createPatternPageLocators.descriptionInAddConditionRecord2, 3)
    cy.log(patternDetailsArrey)
    cy.log(textArrey)
    if (patternDetailsArrey >= textArrey) {
      cy.log("Data is sorted as ascending");
    }
    else {
      cy.log("Data is sorted as descending");
    }
    cy.get(createPatternPageLocators.discriptionColumn).click();
    cy.wait(2000)
    this.recordsTextInvokeFunction1(createPatternPageLocators.descriptionInAddConditionRecord1, 3)
    this.recordsTextInvokeFunction2(createPatternPageLocators.descriptionInAddConditionRecord2, 3)
    cy.log(patternDetailsArrey)
    cy.log(textArrey)
    if (patternDetailsArrey >= textArrey) {
      cy.log("Data is sorted as descending");
    }
    else {
      cy.log("Data is sorted as ascending");
    }
  }
  descriptionIconInAddConditionIconVerification() {
    return cy.get(createPatternPageLocators.patternNameSorted).eq(2).should(assertionConstants.haveAttributeAssertion, 'class', 'p-sortable-column-icon pi pi-fw pi-sort-alt')
  }
  PatternNameColumnClickAndSortingOfDataVerification() {
    cy.get(createPatternPageLocators.nameColumn).click();
    this.recordsTextInvokeFunction1(createPatternPageLocators.nameInAddConditionRecord1, 3)
    this.recordsTextInvokeFunction2(createPatternPageLocators.nameInAddConditionRecord2, 3)
    cy.log(patternDetailsArrey)
    cy.log(textArrey)
    if (patternDetailsArrey >= textArrey) {
      cy.log("Data is sorted as ascending");
    }
    else {
      cy.log("Data is sorted as descending");
    }
    cy.get(createPatternPageLocators.nameColumn).click();
    cy.wait(2000)
    this.recordsTextInvokeFunction1(createPatternPageLocators.nameInAddConditionRecord1, 3)
    this.recordsTextInvokeFunction2(createPatternPageLocators.nameInAddConditionRecord2, 3)
    cy.log(patternDetailsArrey)
    cy.log(textArrey)
    if (patternDetailsArrey >= textArrey) {
      cy.log("Data is sorted as descending");
    }
    else {
      cy.log("Data is sorted as ascending");
    }
  }
  patternNameIconInAddConditionDescVerification() {
    return cy.get(createPatternPageLocators.patternNameSorted).eq(1).should(assertionConstants.haveAttributeAssertion, 'class', 'p-sortable-column-icon pi pi-fw pi-sort-amount-down')
  }
  nameColumnClick() {
    cy.get(createPatternPageLocators.nameColumn).click()
  }
  patternNameIconInAddConditionAscVerification() {
    return cy.get(createPatternPageLocators.patternNameSorted).eq(0).should(assertionConstants.haveAttributeAssertion, 'class', 'p-sortable-column-icon pi pi-fw pi-sort-amount-up-alt')
  }
  patternNameInAddConditionAscSortedVerification() {
    return cy.get(createPatternPageLocators.patternNameInAddCondition).should(assertionConstants.haveAttributeAssertion, 'aria-sort', 'ascending')
  }
  fromrulePatternClick() {
    return cy.contains(fromrulePattern).click();
  }
  modalityDropdownInApplyMetadataOptionSelection() {
    cy.get(createPatternPageLocators.addTagFromList).eq(0).click()
    return cy.get(createPatternPageLocators.addTagFromList).eq(1).click()

  }

  modalityDropdownInApplyMetadata() {
    return cy.get(createPatternPageLocators.modalityDropdownInApplyMetadata)
  }
  validateHeadingPendingVerification() {
    return cy.get(createPatternPageLocators.validateHeading).should(assertionConstants.haveAttributeAssertion, 'class', createPatternPageLocators.ngStarInsertedClass)
  }
  validateHeadingActiveVerification() {
    return cy.get(createPatternPageLocators.validateHeading).should(assertionConstants.haveAttributeAssertion, 'class', createPatternPageLocators.ngStarInsertedActiveClass)
  }
  requestReviewHeadingPendingVerification() {
    return cy.get(createPatternPageLocators.requestReviewHeading).should(assertionConstants.haveAttributeAssertion, 'class', createPatternPageLocators.ngStarInsertedClass)
  }
  createPatternHeadingCompletedVerification() {
    return cy.get(createPatternPageLocators.createPatternHeading).should(assertionConstants.haveAttributeAssertion, 'class', 'completed ng-star-inserted')
  }
  applyMetadataHeadingCompletedVerification() {
    return cy.get(createPatternPageLocators.applyMetadataHeading).should(assertionConstants.haveAttributeAssertion, 'class', 'ng-star-inserted completed')
  }
  applyMetadataHeadingActiveVerification() {
    return cy.get(createPatternPageLocators.applyMetadataHeading).should(assertionConstants.haveAttributeAssertion, 'class', ngStarInsertedActiveClass)
  }
  applyMetadataHeadingInProgressVerification() {
    return cy.get(createPatternPageLocators.applyMetadataHeading).should(assertionConstants.haveAttributeAssertion, 'class', ngStarInProgresStateClass)
  }
  applyMetadataHeadingInprogressVerification() {
    return cy.get(createPatternPageLocators.applyMetadataHeading).should(assertionConstants.haveAttributeAssertion, 'class', 'in-progress ng-star-inserted')
  }
  includeKnowledgeHeadingActiveVerification() {
    return cy.get(createPatternPageLocators.includeKnowledgeHeading).should(assertionConstants.haveAttributeAssertion, 'class', 'active ng-star-inserted')
  }
  includeKnowledgeHeadingPendingVerification() {
    return cy.get(createPatternPageLocators.includeKnowledgeHeading).should(assertionConstants.haveAttributeAssertion, 'class', ngStarInsertedClass)
  }
  buttonsVerification() {
    cy.get(createPatternPageLocators.closeButton).should(assertionConstants.notHaveClassAssertion, createPatternPageLocators.disabledClass)
    cy.get(createPatternPageLocators.popUpOkButton).should(assertionConstants.haveAttributeAssertion, 'class', createPatternPageLocators.disabledClass)
    cy.get(createPatternPageLocators.nextButtton).should(assertionConstants.haveAttributeAssertion, 'class', createPatternPageLocators.disabledClass)
  }
  patternInformationTabClick() {
    return cy.contains(createPatternPageLocators.patternInformationTab).click()
  }
  orderOfExecutionTextBoxVisible() {
    cy.get(createPatternPageLocators.orderOfExecutionTextBox).should(assertionConstants.beVisibleAssertion)
  }
  patternInfo() {
    return cy.get(createPatternPageLocators.patternInfo)
  }
  patternInformationVisible() {
    return cy.get(createPatternPageLocators.patternInformation).eq(0).should(assertionConstants.beVisibleAssertion)
  }
  dropdownValueClick() {
    return cy.get(createPatternPageLocators.dropdownValue).eq(1).click({ force: true })
  }
  breadcumbLastValue() {
    return cy.get(createPatternPageLocators.breadcumbLastValue)
  }
  option1Click() {
    return cy.get(createPatternPageLocators.option1).click()
  }
  operatorsDropdownClick() {
    return cy.get(createPatternPageLocators.operatorsDropdown).click()
  }
  valueInputField() {
    return cy.get(createPatternPageLocators.valueInputField).type("Testing")
  }
  relevanceCheckboxClick() {
    return cy.get(createPatternPageLocators.relevanceCheckbox).click({ force: true })
  }
  removeAddedTags() {
    return cy.get(createPatternPageLocators.removeMarkVerification).each(($el) => {
      cy.wrap($el).click()
    })
  }
  expandedDetails() {
    return cy.get(createPatternPageLocators.expandedDetails).eq(0)
  }
  withoutKeywordClick() {
    return cy.contains(withoutKeywordSection).click()
  }
  addedTagVisible() {
    return cy.get(createPatternPageLocators.addTagsList).should(assertionConstants.beVisibleAssertion)
  }
  doneButtonClick() {
    return cy.get(createPatternPageLocators.addTagOkButton).click({ force: true })
  }
  doneButtonClickInPopUpClick() {
    cy.contains(doneButton).click()
  }
  keywordDropdownClick() {
    cy.get(createPatternPageLocators.keywordDropdownVisibleInTagSection).click()
    cy.get(createPatternPageLocators.dropdownValuesVerification).eq(0).click()
  }
  operatorDropdownClick() {
    cy.get(createPatternPageLocators.operatorDropdownVisibleInTagSection).click()
    cy.get(createPatternPageLocators.dropdownValuesVerification).eq(0).click()
  }
  valueDropdownClick() {
    cy.get(createPatternPageLocators.valueDropdownVisibleInTagSection).click()
    cy.get(createPatternPageLocators.dropdownValuesVerification).eq(0).invoke('text').then((value) => {
      tagValuesList.push(value)
    })
    cy.get(createPatternPageLocators.dropdownValuesVerification).eq(0).click()
  }
  addedTagNotAvailableInWithoutKeywordDropdownVerification() {
    cy.get(createPatternPageLocators.keywordDropdownVisibleInTagSection).click()
    cy.get(createPatternPageLocators.dropdownValuesVerification).eq(0).click()
    cy.get(createPatternPageLocators.operatorDropdownVisibleInTagSection).click()
    cy.get(createPatternPageLocators.dropdownValuesVerification).eq(0).click()
    cy.get(createPatternPageLocators.valueDropdownVisibleInTagSection).click()
    cy.wait(1000)
    cy.log(createPatternPageLocators.createPatternPageLocators.tagValuesList)
    cy.get(createPatternPageLocators.dropdownValuesVerification).each(($el) => {
      cy.wrap($el).should(assertionConstants.notIncludeTextAssertion, tagValuesList[0])
    })
    cy.get(createPatternPageLocators.valueDropdownVisibleInTagSection).click()
  }
  keywordDropdownVisibleInTagSection() {
    return cy.get(createPatternPageLocators.keywordDropdownVisibleInTagSection).should(assertionConstants.beVisibleAssertion)
  }
  operatorDropdownVisibleInTagSection() {
    return cy.get(createPatternPageLocators.operatorDropdownVisibleInTagSection).should(assertionConstants.beVisibleAssertion)
  }
  valueDropdownVisibleInTagSection() {
    return cy.get(createPatternPageLocators.valueDropdownVisibleInTagSection).should(assertionConstants.beVisibleAssertion)
  }
  withKeywordClick() {
    return cy.contains(withKeywordSection).click()
  }
  addedTagNotAvailableInDropdownVerification() {
    cy.get(createPatternPageLocators.searchTextBox).click()
    cy.get(createPatternPageLocators.addTagFromList).eq(0).invoke('text').then((value) => {
      arr.push(value)
    })
    cy.get(createPatternPageLocators.addTagFromList).eq(0).click()
    cy.get(createPatternPageLocators.addTagOkButton).click()
    cy.get(createPatternPageLocators.searchTextBox).click()
    cy.get(createPatternPageLocators.addTagFromList).each(($el) => {
      cy.wrap($el).should('not.match', arr[0])
    })
    cy.get(createPatternPageLocators.searchTextBox).click()
  }
  removeMarkVerification() {
    return cy.get(createPatternPageLocators.removeMarkVerification).should(assertionConstants.beVisibleAssertion)
  }
  removeMarkVerificationInKnowledge() {
    return cy.get(createPatternPageLocators.removeMarkVerificationInKnowledge).should(assertionConstants.beVisibleAssertion)
  }
  doneButtonEnabledVerification() {
    return cy.get(createPatternPageLocators.doneButtonDisabledVerification).should(assertionConstants.haveNotAttributeAssertion, 'disabled')
  }
  addTagInWithoutKeywordSection() {
    cy.get(createPatternPageLocators.searchTextBox).click()
    cy.get(createPatternPageLocators.addTagFromList).eq(0).click()
    cy.get(createPatternPageLocators.addTagOkButton).click()
  }
  searchTextBoxVisibleWithWatermark() {
    cy.get(createPatternPageLocators.searchTextBox).should(assertionConstants.beVisibleAssertion)
    return cy.get(createPatternPageLocators.searchTextBox).should(assertionConstants.haveAttributeAssertion, 'placeholder', 'Select Tags')
  }
  cancelButtononPopUpEnabledVerification() {
    return cy.get(createPatternPageLocators.cancelButtonPopUp).should(assertionConstants.haveNotAttributeAssertion, 'disabled')
  }
  doneButtonDisabledVerification() {
    return cy.get(createPatternPageLocators.doneButtonDisabledVerification).should(assertionConstants.haveAttributeAssertion, 'disabled')
  }
  withKeywordSectionVisible() {
    cy.contains(withKeywordSection).should(assertionConstants.beVisibleAssertion)
  }
  withoutKeywordSectionVisible() {
    cy.contains(withoutKeywordSection).should(assertionConstants.beVisibleAssertion)
  }
  addTagHeadingVisible() {
    cy.get(createPatternPageLocators.addTagHeading).first().should(assertionConstants.beVisibleAssertion)
    cy.get(createPatternPageLocators.addTagHeading).first().should(assertionConstants.haveAttributeAssertion, 'class', 'pt-title')
  }
  addTagButtonClick() {
    return cy.get(createPatternPageLocators.addTagButton).click()
  }
  addAction() {
    cy.contains(addActionTab).click()
    cy.get(createPatternPageLocators.addActionPlusIcon).should(assertionConstants.beVisibleAssertion)
    cy.get(createPatternPageLocators.addActionPlusIcon).click({ force: true })
    cy.contains(raiseAlert).click({ force: true })
  }
  importDataModelAction() {
    cy.get(createPatternPageLocators.importdatamodelTab).click()
    cy.get(createPatternPageLocators.importdatamodelDropdownArrow).click()
    cy.contains(importDataModelDropdownCommon).last().click()
    cy.get(createPatternPageLocators.clickoutsidetoGetResult).click({ force: true })
  }
  nextButtonVisible() {
    return cy.get(createPatternPageLocators.nextButtonVisible).should(assertionConstants.beVisibleAssertion)
  }
  saveAsDraftButtonVisible() {
    return cy.get(createPatternPageLocators.saveAsDraft).should(assertionConstants.beVisibleAssertion)
  }
  closeButtonVisible() {
    return cy.get(createPatternPageLocators.closeButton).should(assertionConstants.beVisibleAssertion)
  }
  patternNameNotVisible() {
    return cy.get(createPatternPageLocators.patternName).should(assertionConstants.beVisibleAssertion)
  }
  patternDescriptionVisible() {
    return cy.get(createPatternPageLocators.patternDescription).should(assertionConstants.beVisibleAssertion)
  }
  patternNameVisible() {
    return cy.get(createPatternPageLocators.patternName).should(assertionConstants.beVisibleAssertion)
  }
  addActionTabVisible() {
    return cy.contains(addActionTab).should(assertionConstants.beVisibleAssertion)
  }
  addConditionTabVisible() {
    return cy.contains(adConditionTab).should(assertionConstants.beVisibleAssertion)
  }
  extendsTabVisible() {
    return cy.contains(extendsTab).should(assertionConstants.beVisibleAssertion)
  }
  importDataModelTabVisible() {
    return cy.get(createPatternPageLocators.importdatamodelTab).should(assertionConstants.beVisibleAssertion)
  }
  createPatternGridAsSelected() {
    cy.get(createPatternPageLocators.patternName).should(assertionConstants.beVisibleAssertion)
    cy.get(createPatternPageLocators.description).should(assertionConstants.beVisibleAssertion)
    return cy.get(createPatternPageLocators.createPatternGridAsSelected).should(assertionConstants.haveAttributeAssertion, 'class', activeClass)
  }
  gridVerification() {
    return cy.get(createPatternPageLocators.gridVerification)
  }
  okButtonClick() {
    return cy.get(createPatternPageLocators.okButtonClick).click({ force: true })
  }
  saveAsDraftButtonClick() {
    return cy.get(createPatternPageLocators.saveAsDraft).click()
  }
  saveAsDraftButtonForceClick() {
    return cy.get(createPatternPageLocators.saveAsDraft).click({ force: true })
  }
  applyMetadataActiveVerification() {
    cy.wait(2000)
    return cy.get(createPatternPageLocators.applyMetadataActiveVerification).should(assertionConstants.haveAttributeAssertion, 'class', 'active ng-star-inserted')
  }
  removeAction() {
    return cy.get(createPatternPageLocators.removeAction).last().click()
  }
  previousButtonClick() {
    return cy.get(createPatternPageLocators.previousButtonClick).click()
  }
  nextButtonEnabledVerification() {
    return cy.get(createPatternPageLocators.nextButtonDisabledVerification).should(assertionConstants.haveAttributeAssertion, 'class', 'pt-primary pt-button ng-star-inserted')
  }
  addConditionInPattern() {
    cy.contains(adConditionTab).click()
    cy.get(createPatternPageLocators.addConditionPlusIcon).click({ force: true })
    cy.contains(" From Data Model ").click()
    cy.get(createPatternPageLocators.option1).click()
    cy.contains("AdditionalInfo").click({ force: true })
    cy.get(createPatternPageLocators.operatorsDropdown).click()
    cy.contains("==").click({ force: true })
    cy.get(createPatternPageLocators.valueInputField).type("Testing")
  }
  nextButtonDisabledVerification() {
    return cy.get(createPatternPageLocators.nextButtonDisabledVerification).should(assertionConstants.haveAttributeAssertion, 'class', createPatternPageLocators.disabledClass)
  }
  knowledgeClick() {
    cy.get(createPatternPageLocators.knowledgeClick).click()
    return cy.get(createPatternPageLocators.addKnowledgePlusIcon).click()
  }

  symptomNameColumnType() {
    return cy.get(createPatternPageLocators.symtomNameTextField).type(keywordType)
  }

  selectSymptomsButtonClick() {
    return cy.get(createPatternPageLocators.selectSymptomsButton).click({ force: true })
  }

  symptomsClick() {
    return cy.contains(knowledgeSymptom).click()
  }

  searchedDataFoundVerificationForCause() {
    cy.get(createPatternPageLocators.attributeForCause).eq(0).click()
    cy.get(createPatternPageLocators.dropdownValuesVerification).eq(1).click()
    cy.get(createPatternPageLocators.searchBoxTestVisible).type(keywordType)
    cy.get(createPatternPageLocators.tableDataValue).eq(0).click()
    cy.get(createPatternPageLocators.previewedSection).eq(0).invoke('text').should('include', 'testing')
  }
  selectClauseHeadingVisible() {
    return cy.get(createPatternPageLocators.selectClauseHeading).should(assertionConstants.beVisibleAssertion)
  }
  causeButtonVisible() {
    return cy.get(createPatternPageLocators.causeButton).should(assertionConstants.beVisibleAssertion)
  }
  causeButtonClick() {
    return cy.get(createPatternPageLocators.causeButton).click()
  }
  causesAndSolutionsClick() {
    return cy.contains(causeAndSolutionText).click()
  }

  addKnowledgeButtonClick() {
    return cy.contains(addKnowledgeButton).click({ force: true })
  }
  relevanceFieldClick() {
    return cy.get(createPatternPageLocators.relevanceFild).eq(0).click()
  }
  nextButtonClick() {
    cy.get(createPatternPageLocators.nextButton).click({ force: true })
  }
  nextButtonForceClick() {
    cy.get(createPatternPageLocators.nextButton).click({ force: true })
  }
  tableNotPresentVerification() {
    cy.get(createPatternPageLocators.tableData).should('not.exist')
  }
  checkBoxNotCheckedVerification() {
    cy.get(createPatternPageLocators.checkboxInImportDataModel).should('not.be.checked')
  }
  importdatamodelDrpdownValueTextVerification() {
    cy.get(createPatternPageLocators.importDataModelDropDownList).each(($el) => {
      cy.wrap($el).should(assertionConstants.beVisibleAssertion)
    })
  }
  tagsFilterType() {
    cy.get(createPatternPageLocators.tagsFilterValue).eq(1).click()
    cy.get(createPatternPageLocators.tagsMultiselectFilterValue).first().click()
    cy.get(createPatternPageLocators.applyButtonOfTagslFilter).click()
  }
  dataModelsFilterType() {
    cy.get(createPatternPageLocators.colcounLevelDataModelFilter).click()
    cy.get(createPatternPageLocators.tagsMultiselectFilterValue).first().click()
    cy.get(createPatternPageLocators.applyButtonOfDataModelFilter).click()
  }
  descriptionFilterType() {
    cy.get(createPatternPageLocators.descriptionFilterTextField).type(keywordType)
  }
  patternFilterType() {
    cy.get(createPatternPageLocators.patternNameFilterTextField).type(keywordType)
  }
  tagsFilter() {
    cy.get(createPatternPageLocators.tagsColumn).should(assertionConstants.haveAttributeAssertion, 'aria-sort', 'none')
    cy.get(createPatternPageLocators.tagsColumn).click()
    cy.get(createPatternPageLocators.tagsColumn).should(assertionConstants.haveAttributeAssertion, 'aria-sort', 'ascending')
    cy.get(createPatternPageLocators.tagsColumn).click()
    cy.get(createPatternPageLocators.tagsColumn).should(assertionConstants.haveAttributeAssertion, 'aria-sort', 'descending')
  }
  dataModelFilter() {
    cy.get(createPatternPageLocators.dataModelColumn).should(assertionConstants.haveAttributeAssertion, 'aria-sort', 'none')
    cy.get(createPatternPageLocators.dataModelColumn).click()
    cy.get(createPatternPageLocators.dataModelColumn).should(assertionConstants.haveAttributeAssertion, 'aria-sort', 'ascending')
    cy.get(createPatternPageLocators.dataModelColumn).click()
    cy.get(createPatternPageLocators.dataModelColumn).should(assertionConstants.haveAttributeAssertion, 'aria-sort', 'descending')
  }
  descriptionFilter() {
    cy.get(createPatternPageLocators.discriptionColumn).should(assertionConstants.haveAttributeAssertion, 'aria-sort', 'none')
    cy.get(createPatternPageLocators.discriptionColumn).click()
    cy.get(createPatternPageLocators.discriptionColumn).should(assertionConstants.haveAttributeAssertion, 'aria-sort', 'ascending')
    cy.get(createPatternPageLocators.discriptionColumn).click()
    cy.get(createPatternPageLocators.discriptionColumn).should(assertionConstants.haveAttributeAssertion, 'aria-sort', 'descending')
  }
  nameColumnFilter() {
    cy.get(createPatternPageLocators.nameColumn).should(assertionConstants.haveAttributeAssertion, 'aria-sort', 'none')
    cy.get(createPatternPageLocators.nameColumn).click()
    cy.get(createPatternPageLocators.nameColumn).should(assertionConstants.haveAttributeAssertion, 'aria-sort', 'ascending')
    cy.get(createPatternPageLocators.nameColumn).click()
    cy.get(createPatternPageLocators.nameColumn).should(assertionConstants.haveAttributeAssertion, 'aria-sort', 'descending')
  }
  showAllResultVerification() {
    cy.get(createPatternPageLocators.showAllResult).should(assertionConstants.havelengthAssertion, 10)
  }

  attributeClick() {
    cy.get(createPatternPageLocators.attributeForCause).eq(0).click()
    cy.get(createPatternPageLocators.dropdownValuesVerification).eq(6).click()
  }
  crossMarkClick() {
    return cy.get(createPatternPageLocators.crossMark).eq(0).click()
  }
  clearSearchBoxType() {
    return cy.get(createPatternPageLocators.searchBoxTestVisible).clear() 
  }
  searchedDataFoundVerification() {
    cy.get(createPatternPageLocators.expandedDetails).first().invoke('text').should('include', 'testing')
  }
  noDataFoundVerification() {
    return cy.get(createPatternPageLocators.noDataFoundVerification).should(assertionConstants.beVisibleAssertion)
  }
  searchBoxType() {
    return cy.get(createPatternPageLocators.searchBoxTestVisible).type(keywordType)
  }
  searchBoxTypewithInvalidTextSearch() {
    return cy.get(createPatternPageLocators.searchBoxTestVisible).type('ABCDEFG{enter}')
  }
  searchBoxVisible() {
    return cy.get(createPatternPageLocators.searchBoxTestVisible).should(assertionConstants.beVisibleAssertion)
  }
  dropdownValuesVerification() {
    cy.get(createPatternPageLocators.attributeForCause).eq(0).click()
    cy.get(createPatternPageLocators.dropdownValuesVerification).each(($el) => {
      cy.wrap($el).should(assertionConstants.beVisibleAssertion)
    })
  }
  byDefaultAllisVisibleatSearch() {
    return cy.get(createPatternPageLocators.dropdownatSearchVisible).eq(0).invoke('text').should('eq', 'All')
  }
  dropdownatSearchVisible() {
    return cy.get(createPatternPageLocators.dropdownatSearchVisible).eq(0).should(assertionConstants.beVisibleAssertion)
  }
  tagsValuesWithCommaVerification() {
    return cy.contains(tagsValuesWithCommaVerification).scrollIntoView().should(assertionConstants.beVisibleAssertion)
  }
  tagsColumnVisible() {
    return cy.get(createPatternPageLocators.tagsColumn).should(assertionConstants.beVisibleAssertion)
  }
  dataModelColumnVisible() {
    return cy.get(createPatternPageLocators.dataModelColumn).should(assertionConstants.beVisibleAssertion)
  }
  discriptionColumnVisible() {
    return cy.get(createPatternPageLocators.discriptionColumn).should(assertionConstants.beVisibleAssertion)
  }
  nameColumnVisible() {
    return cy.get(createPatternPageLocators.nameColumn).should(assertionConstants.beVisibleAssertion)
  }
  importButtonEnabledVerification() {
    return cy.get(createPatternPageLocators.ButtonVisible).eq(1).should(assertionConstants.haveNotAttributeAssertion, 'disabled')
  }
  horizontalPanelVerification() {
    return cy.get(createPatternPageLocators.horizontalPanelVerification).should(assertionConstants.beVisibleAssertion)
  }
  navigationIconsClick() {
    cy.get(createPatternPageLocators.navigationIcons).should(assertionConstants.beVisibleAssertion)
    return cy.get(createPatternPageLocators.navigationIcons).click()
  }
  sizeAndPatternDetailsVerificationAfterCollapse() {
    cy.get(createPatternPageLocators.sizeAndPatternDetails).eq(1).should('not.exist')
    return cy.get(createPatternPageLocators.importCondLogicalExpression).should('not.exist')
  }
  sizeAndPatternDetailsVerification() {
    cy.get(createPatternPageLocators.sizeAndPatternDetails).eq(1).should(assertionConstants.beVisibleAssertion)
    return cy.get(createPatternPageLocators.importCondLogicalExpression).should(assertionConstants.beVisibleAssertion)
  }
  firstPatternOpenClick() {
    return cy.get(createPatternPageLocators.expandedDetails).eq(0).click()
  }
  importButtonDisabledVerification() {
    return cy.get(createPatternPageLocators.ButtonVisible).eq(1).should(assertionConstants.haveAttributeAssertion, 'disabled')
  }
  popUpCloseVerification() {
    return cy.get(createPatternPageLocators.importConditionsHeadingVisible).should('not.exist')
  }

  nextPageNavigationClickandVerification() {
    cy.get(createPatternPageLocators.nextPageNavigation).eq(1).click()
    return cy.get(createPatternPageLocators.totalCountOfPage).invoke('text').should('include', ' Showing 2')
  }
  previousPageNavigationClickandVerification() {
    cy.get(createPatternPageLocators.nextPageNavigation).eq(0).click()
    return cy.get(createPatternPageLocators.totalCountOfPage).invoke('text').should('include', ' Showing 1')
  }
  totalrecordsPerPageVerificationforTen() {
    return cy.xpath(createPatternPageLocators.totalRecordFoundCount).should(assertionConstants.havelengthAssertion, 10)
  }
  totalrecordsPerPageVerificationforTwenty() {
    return cy.xpath(createPatternPageLocators.totalRecordFoundCount).should(assertionConstants.havelengthAssertion, 20)
  }
  changeEntriesPerPageCount() {
    cy.get(createPatternPageLocators.changeEntriesPerPageCount).eq(2).click()
    cy.get(createPatternPageLocators.dropDownOptions).eq(2).click()
  }
  changeEntriesPerPageCountSize() {
    cy.get(createPatternPageLocators.changeEntriesPerPageCount).eq(1).click()
    cy.get(createPatternPageLocators.dropDownOptions).eq(2).click()
  }
  patternNameASCOrderSortedVisible() {
    return cy.get(createPatternPageLocators.patternNameSorted).eq(0).should(assertionConstants.haveAttributeAssertion, 'class', 'p-sortable-column-icon pi pi-fw pi-sort-amount-up-alt')
  }
  searchBoxTestVisible() {
    return cy.get(createPatternPageLocators.searchBoxTestVisible).should(assertionConstants.haveAttributeAssertion, 'placeholder', 'Search by Keyword')
  }
  totalCountOfPageVisible() {
    return cy.get(createPatternPageLocators.totalCountOfPage).should(assertionConstants.beVisibleAssertion)
  }
  entriesPerPageVisible() {
    return cy.contains(createPatternPageLocators.entriesPerPage).should(assertionConstants.beVisibleAssertion)
  }
  importButtonVisible() {
    return cy.get(createPatternPageLocators.ButtonVisible).eq(1).should(assertionConstants.beVisibleAssertion)
  }
  CancelButtonVisible() {
    return cy.get(createPatternPageLocators.ButtonVisible).eq(0).should(assertionConstants.beVisibleAssertion)
  }

  recordsFoundTextVerification() {
    cy.get(createPatternPageLocators.recordsFoundTextVerification).should(assertionConstants.beVisibleAssertion)
    return cy.get(createPatternPageLocators.recordsFoundTextVerification).invoke('text').should('include', recordsFoundText)
  }
  keywordDropDownWithAllSelected() {
    cy.get(createPatternPageLocators.keywordDropDownWithAllSelected).should(assertionConstants.beVisibleAssertion)
    return cy.get(createPatternPageLocators.keywordDropDownWithAllSelected).eq(1).invoke('text').should('eq', 'All')
  }
  showAllCheckboxVisible() {
    return cy.get(createPatternPageLocators.showAllCheckboxVisible).should(assertionConstants.beVisibleAssertion)
  }
  searchByShowAllTextVisible() {
    return cy.get(createPatternPageLocators.searchByShowAllText).invoke('text').should('eq', 'Search for a pattern or click on "Show All" to view all available patterns')
  }
  noDataVisibleInTable() {
    return cy.get(createPatternPageLocators.noDataVisibleInTable).should('not.exist')
  }
  patternSelected() {
    cy.get(createPatternPageLocators.patternSelected).should(assertionConstants.haveAttributeAssertion, ariaSelectedAttribute)
    return cy.get(createPatternPageLocators.patternSelected).should(assertionConstants.beVisibleAssertion)
  }
  ruleDisabled() {
    cy.get(createPatternPageLocators.ruleDisabled).should(assertionConstants.haveNotAttributeAssertion, ariaSelectedAttribute)
    return cy.get(createPatternPageLocators.ruleDisabled).should(assertionConstants.beVisibleAssertion);
  }
  importConditionsHeadingVisible() {
    cy.get(createPatternPageLocators.importConditionsHeadingVisible).invoke('text').should('eq', 'Import Conditions')
    return cy.get(createPatternPageLocators.importConditionsHeadingVisible).should(assertionConstants.beVisibleAssertion)
  }
  fromRulePatternClick() {
    return cy.contains(fromrulePattern).click()
  }
  checkboxUnClick() {
    cy.get(createPatternPageLocators.checkboxVisible).eq(0).click()
    cy.get(createPatternPageLocators.checkboxVisible).eq(0).click()
    cy.get(createPatternPageLocators.okButtonClick).click({ force: true })
  }
  checkboxClick() {
    return cy.get(createPatternPageLocators.checkboxVisible).eq(1)
  }
  importdatamodelDrpdownMRSelection() {
    return cy.contains("Common").should(assertionConstants.beVisibleAssertion)
  }
  attributesVisible() {
    return cy.get(createPatternPageLocators.attributesVisible).should(assertionConstants.beVisibleAssertion)
  }
  dataModelsHoverVisible() {
    return cy.contains(importDataModelDropdownCommon).trigger('mouseover')
  }
  importdatamodelDrpdownValueVerification() {
    return cy.get(createPatternPageLocators.importDataModelDropDownList)
  }
  importdatamodelDrpdownValueCapture() {
    return cy.contains(importDataModelDropdownCommon);
  }
  importdatamodelDrpdownValueCapturedVisible() {
    return cy.get(createPatternPageLocators.importDataModelCapturedValue).should(assertionConstants.beVisibleAssertion)
  }
  importdatamodelDrpdownValueCapturedRemoveMarkVisible() {
    return cy.get(createPatternPageLocators.importDataModelCapturedValueRemove).should(assertionConstants.beVisibleAssertion)
  }
  importdatamodelDrpdownValueCapturedRemoveMarkClick() {
    return cy.get(createPatternPageLocators.importDataModelCapturedValueRemove).click()
  }
  removedOptionNotVisible() {
    cy.contains('Delete').click()
    return cy.contains('SystemParameters').should('not.exist')
  }
  importdatamodelDrpdownVisible() {
    return cy.get(createPatternPageLocators.importdatamodelDropdownArrow).should(assertionConstants.beVisibleAssertion);
  }
  noteInImportDataModelVisible() {
    return cy.contains(noteInImportDataModelVisible).should(assertionConstants.beVisibleAssertion)
  }
  dashboardButtonVisible() {
    return cy.get(createPatternPageLocators.dashboardButtonVisible).should(assertionConstants.beVisibleAssertion)
  }
  atATimeOneExpandedVerification() {
    cy.contains(adConditionTab).click();
    cy.get(createPatternPageLocators.importdatamodelDropdownArrow).should(assertionConstants.notVisibleAssertion);
    cy.wait(2000)
    cy.get(createPatternPageLocators.importdatamodelTab).click()
    return cy.get(createPatternPageLocators.addConditionPlusIcon).should(assertionConstants.notVisibleAssertion)
  }
  addConditionExpandedVisible() {
    return cy.get(createPatternPageLocators.addConditionPlusIcon).should(assertionConstants.beVisibleAssertion)
  }
  addConditionCollapsedVisible() {
    return cy.get(createPatternPageLocators.addConditionPlusIcon).should(assertionConstants.notVisibleAssertion)
  }
  fromdataModelOptionSelection() {
    cy.get(createPatternPageLocators.option1).click()
    cy.contains(eventIdAttribute).click()
    cy.get(createPatternPageLocators.addConditionPlusIcon).click({ force: true })
    return cy.contains(fromdataModel).click()
  }
  fromdataModelClick() {
    return cy.contains(fromdataModel).click()
  }
  noVariablesTextVerification() {
    return cy.contains(noVariablesTextVerification).should(assertionConstants.beVisibleAssertion)
  }
  fromVariableClick() {
    return cy.contains(fromVariable).click()
  }
  fromdataModelHoverValidationAfterSelection() {
    cy.contains(fromdataModel).click()
    return cy.get(createPatternPageLocators.option1).should(assertionConstants.beVisibleAssertion)
  }
  importdatamodelDrpdownCommonSelection() {
    return cy.get(createPatternPageLocators.importDataModlCommonSelection).eq(0).click({ force: true })
  }
  importdatamodelDrpdownClick() {
    return cy.get(createPatternPageLocators.importdatamodelDropdownArrow).click({ force: true });
  }
  importdatamodelTabClick() {
    return cy.get(createPatternPageLocators.importdatamodelTab).click()
  }
  fromdataModelHoverValidationBeforeSelection() {
    cy.contains(fromdataModel).click()
    return cy.contains(noDataModelImportedText).should(assertionConstants.beVisibleAssertion)
  }
  fromdataModelVisible() {
    return cy.contains(fromdataModel).should(assertionConstants.beVisibleAssertion)
  }
  fromrulePatternVisible() {
    return cy.contains(fromrulePattern).should(assertionConstants.beVisibleAssertion)
  }
  fromVariableVisible() {
    return cy.contains(fromVariable).should(assertionConstants.beVisibleAssertion)
  }
  addConditionPlusIconVisible() {
    return cy.get(createPatternPageLocators.addConditionPlusIcon).should(assertionConstants.beVisibleAssertion)
  }
  expandedAddConditionSectionVerification() {
    return cy.get(createPatternPageLocators.expandedAddConditionSectionVerification).should(assertionConstants.beVisibleAssertion)
  }
  addConditionTabClick() {
    return cy.contains(adConditionTab).click()
  }
  addCondtionAsteriskVisible() {
    cy.get(createPatternPageLocators.addCondtionAsterisk).should(assertionConstants.beVisibleAssertion)
    return cy.get(createPatternPageLocators.addCondtionAsterisk).should('have.class', 'mandatory')
  }
  myPatternThreeDotsClick() {
    return cy.get(createPatternPageLocators.myPatternThreeDots).eq(1).scrollIntoView().click()
  }
  createPatternClick() {
    return cy.get(createPatternPageLocators.createPattern).click()
  }
  createPatternVisible() {
    return cy.get(createPatternPageLocators.createPattern).should(assertionConstants.beVisibleAssertion)
  }
  myPatternThreeDots() {
    return cy.get(createPatternPageLocators.myPatternThreeDots)
  }
  createPattern() {
    return cy.get(createPatternPageLocators.createPattern)
  }
  workflowSuccessText() {
    return cy.contains(workflowSuccessText)
  }
  createPatternHeading() {
    return cy.get(createPatternPageLocators.createPatternHeading)
  }
  applyMetadataHeading() {
    return cy.get(createPatternPageLocators.applyMetadataHeading)
  }
  includeKnowledgeHeading() {
    return cy.get(createPatternPageLocators.includeKnowledgeHeading)
  }
  validateHeading() {
    return cy.get(createPatternPageLocators.validateHeading)
  }
  requestReviewHeading() {
    return cy.get(createPatternPageLocators.requestReviewHeading)
  }
  patternInformationTab() {
    return cy.contains(createPatternPageLocators.patternInformationTab)
  }
  importdatamodelTab() {
    return cy.get(createPatternPageLocators.importdatamodelTab)
  }
  adConditionTab() {
    return cy.contains(adConditionTab)
  }
  addActionTab() {
    return cy.contains(addActionTab)
  }
  patternName() {
    return cy.get(createPatternPageLocators.patternName)
  }
  description() {
    return cy.get(createPatternPageLocators.description)
  }
  orderOfExecution() {
    return cy.get(createPatternPageLocators.orderOfExecution)
  }
  importdatamodelDrpdownArrow() {
    return cy.get(createPatternPageLocators.importdatamodelDropdownArrow);
  }
  importDataModelDrpdown() {
    return cy.get(createPatternPageLocators.importDataModelDropdown);
  }
  importDataModelDrpdownCommon() {
    return cy.contains(importDataModelDropdownCommon);
  }
  importDataModeldrpdownmr() {
    return cy.contains(importDataModeldropdownmr).last();
  }
  clickoutsidetoGetResult() {
    return cy.get(createPatternPageLocators.clickoutsidetoGetResult)
  }
  addConditionPlusIcon() {
    return cy.get(createPatternPageLocators.addConditionPlusIcon)
  }
  fromdataModel() {
    return cy.contains(fromdataModel)
  }
  fromrulePattern() {
    return cy.contains(fromrulePattern)
  }
  fromVariable() {
    return cy.contains(fromVariable)
  }
  addactionPlusIcon() {
    return cy.get(createPatternPageLocators.addActionPlusIcon);
  }
  raiseAlert() {
    return cy.contains(raiseAlert)
  }
  insertAlert() {
    return cy.contains(insertAlert)
  }
  suppressAlert() {
    return cy.contains(suppressAlert);
  }
  saveAsDraft() {
    return cy.get(createPatternPageLocators.saveAsDraft)
  }
  draftSavedText() {
    return cy.contains(draftSavedText)
  }

  authoringWorkFlowCreatedCreatedMessage() {
    return cy.contains(authoringWorkFlowCreatedCreatedMessage)
  }
  threeDotsOfAuthoringWorkflow() {
    return cy.get(createPatternPageLocators.threeDotsOfAuthoringWorkFlow)
  }
  renameOption() {
    return cy.get(createPatternPageLocators.renameOption)
  }
  deleteOption() {
    return cy.get(createPatternPageLocators.deleteOption)
  }
  deleteWorkFlowMessage() {
    return cy.contains(deleteWorkFlowMessage)
  }
  relaunchApplication() {
    return cy.reload()
  }
  CloseTheApplication() {
    cy.log("Application is closed")
  }
  modalityDropdownfield() {
    return cy.get(createPatternPageLocators.modalityDropdownfield)
  }
  modalityDropdown() {
    return cy.get(modalityDropdown)
  }
  patternType() {
    return cy.get(createPatternPageLocators.modalityDropdownfield).eq(2)
  }
  patternTypeDropdown() {
    return cy.get(createPatternPageLocators.patternTypeDropdown)
  }
  relevanceField() {
    return cy.contains(createPatternPageLocators.relevanceField)
  }
  relevanceText() {
    return cy.contains(createPatternPageLocators.relevanceText)
  }
  serviceContextFields() {
    return cy.get(createPatternPageLocators.serviceContextFields)
  }
  severityFields() {
    return cy.get(createPatternPageLocators.severityFields)
  }
  commentBox() {
    return cy.get(createPatternPageLocators.commentBox)
  }
  addTagButton() {
    return cy.get(createPatternPageLocators.addTagButton)
  }
  cancelButton() {
    return cy.contains(cancelButton);
  }
  withKeywordSection() {
    return cy.contains(withKeywordSection)
  }
  withoutKeywordSection() {
    return cy.contains(withoutKeywordSection)
  }

  selectTag() {
    return cy.get(createPatternPageLocators.selectTag)
  }
  addTagFromList() {
    return cy.get(createPatternPageLocators.addTagFromList)
  }
  addTagOkButton() {
    return cy.get(createPatternPageLocators.addTagOkButton)
  }
  doneButton() {
    return cy.contains(doneButton)
  }
  clickOnPopUpOkButton() {
    return cy.get(createPatternPageLocators.popUpOkButton)
  }
  clicksOnPopUpOkButton() {
    return cy.get(createPatternPageLocators.popUpOkButton).click()
  }
  tagId() {
    return cy.get(createPatternPageLocators.tagId);
  }
  addConditionPlusIconClick() {
    return cy.get(createPatternPageLocators.plusIconInAddCondition).scrollIntoView().click({ force: true })
  }
  addConditionIconClick() {
    cy.get(createPatternPageLocators.plusIconInAddCondition).scrollIntoView().then(() => {
      cy.wait(2000)
      cy.get(createPatternPageLocators.plusIconInAddCondition).click({ force: true })
    })
  }
  addEvents() {
    cy.get(createPatternPageLocators.plusIconInAddCondition).click({ force: true })
    cy.wait(2000)
    cy.get(createPatternPageLocators.formDataModel).eq(0).click({ force: true })
    cy.wait(1000)
    cy.get(createPatternPageLocators.dataModel).find('span').click()
    cy.get(createPatternPageLocators.confirmationPopUp).last().find(attributeOneEventOneOperators).first().click()

  }

  myPatternDropArrowClick() {
    return cy.get(createPatternPageLocators.myPatternDropArrow).eq(1).click()
  }
  dataModelDropArrowClick() {
    return cy.get(createPatternPageLocators.dataModelDropdownArrow).click({ force: true })
  }
  dataModelCommonOptionDropArrowClick() {
    return cy.get(createPatternPageLocators.dataModelCommonOptionDropArrow).click()
  }

  ValueForTestOneType() {
    return cy.get(createPatternPageLocators.ValueForTestOne).first().type(1)
  }

  addCondtionOptionForTestOneClick() {
    return cy.get(createPatternPageLocators.addCondtionOptionForTestOne).eq(0).click()
  }

  addConditionPopUpVisible() {
    return cy.get(createPatternPageLocators.addConditionPopUp).should(assertionConstants.beVisibleAssertion)
  }

  operatorOneDropdownFortetsOneClick() {
    return cy.get(createPatternPageLocators.operatorOneDropdownFortetsOne).click()
  }

  absOperatorforTestOneClick() {
    return cy.get(createPatternPageLocators.Operator).first().click()
  }

  lelAttributeOfTestOneClick() {
    return cy.get(createPatternPageLocators.attribute).first().click()
  }

  operatorTwoFortetsOneClick() {
    return cy.get(createPatternPageLocators.operatorTwoFortetsOne).last().click()
  }

  starOperatorforTestOneClick() {
    return cy.get(createPatternPageLocators.Operator).first().click()
  }

  attributetwoArrowForTestOneClick() {
    return cy.get(createPatternPageLocators.attributetwoArrowForTestOne).click()
  }

  eventLog1OptionUnderAttributeTwoclick() {
    return cy.get(createPatternPageLocators.dataModel).click()
  }

  uwlattributeOfAttributeTwoOfTestoneClick() {
    return cy.get(createPatternPageLocators.attribute).eq(1).click()
  }


  addedExpressionForEventOneVisible() {
    return cy.contains(createPatternPageLocators.addedExpressionForEventOne).should(assertionConstants.beVisibleAssertion)
  }

  popupTextVisible() {
    cy.contains(popupText).should(assertionConstants.beVisibleAssertion)
    return cy.get(tagId)
  }
  popuptextVisible() {
    cy.contains(popupText).should(assertionConstants.beVisibleAssertion)
  }

  createPatternButtonClick() {
    return cy.get(createPatternPageLocators.createPattern).click()
  }

  importDataModelClick() {
    return cy.get(createPatternPageLocators.impoprtDataModel).click()
  }
  formDataModelClick() {
    return cy.get(createPatternPageLocators.formDataModel).eq(0).click({ force: true })
  }
  importedEventLogModelClick() {
    return cy.get(createPatternPageLocators.dataModel).find('span').click()
  }

  dataModelAttributeListVisible() {
    return cy.get(createPatternPageLocators.confirmationPopUp).last().find(attributeOneEventOneOperators).should(assertionConstants.beVisibleAssertion)
  }
  addConditionButtonForeventOneClick() {
    return cy.get(createPatternPageLocators.addConditionButton).eq(0).click()
  }
  attributeOneDropDownArrowForTestOneClick() {
    return cy.get(createPatternPageLocators.attributeOneDropDownArrowForTestOne).click()
  }

  eventLog1OptionUnderattriubuteOneClick() {
    return cy.get(createPatternPageLocators.dataModel).click()
  }

  attributeOptionUnderTestTwoOfEventTwoClick() {
    return cy.get(createPatternPageLocators.addedCondtionAttributeDropdown).last().click()
  }

  addExpressionOptionForTestTwoUnderEventTwoClick() {
    return cy.get(createPatternPageLocators.addCondtionOptionForTestOne).click()
  }

  operatorOneOfAddExpressionFortetsTwoClick() {
    return cy.get(createPatternPageLocators.operatorOneOfAddExpressionFortetsTwo).click()
  }

  absOperatorOfAddExpressionFortetsTwoClick() {
    return cy.get(createPatternPageLocators.Operator).first().click()
  }

  attributeOneGropDownArrowForTestTwoClick() {
    return cy.get(createPatternPageLocators.attributeOneDropDownArrowForTestOne).click()
  }

  eventLog1OptionUnderattributeOneOfTestTwoClick() {
    return cy.get(createPatternPageLocators.dataModel).click()
  }

  uwlDropdownOptionUnderattributeOneOfTestTwoClick() {
    return cy.get(createPatternPageLocators.attribute).last().click()
  }

  attributeTwoDropdownArrowUnderTestTwoClick() {
    return cy.get(createPatternPageLocators.attributeTwoDropdownArrowUnderTestTwo).click()
  }

  popupWithTestModelNameVisible() {
    return cy.get(createPatternPageLocators.confirmationPopUp).should(assertionConstants.containAssertion, 'EventLog').and(assertionConstants.beVisibleAssertion)
  }

  deleteButtonVisible() {
    return cy.get(createPatternPageLocators.okButtonOnPopUp).should(assertionConstants.beVisibleAssertion)
  }

  cancelButtonVisible() {
    return cy.contains(cancelButton).should(assertionConstants.beVisibleAssertion)
  }

  showAllCheckboxClick() {
    cy.get(createPatternPageLocators.checkBox).click()
  }

  ShowCheckboxClick() {
    cy.get(createPatternPageLocators.checkBox).last().click()
  }

  attributeDropDownClick() {
    cy.get(createPatternPageLocators.attributeDropDown).first().click()
  }

  systemParameterDataModelClick() {
    cy.contains(createPatternPageLocators.testTwoOptionUnderAttributeTwoDropdownOfTestTwo).click()
  }

  eventLogDataModelClick() {
    cy.contains(eventLogDataModel).click()
  }

  dataModelAdditionalInfoAttributeClick() {
    return cy.get(createPatternPageLocators.confirmationPopUp).last().find(attributeOneEventOneOperators).first().click()
  }
  operatorForEventOneClick() {
    return cy.get(createPatternPageLocators.operatorForEventOne).last().click()
  }
  operatorForEventLastClick() {
    return cy.get(createPatternPageLocators.operatorForEventOne).last().click()
  }

  equaltoOperatorClick() {
    return cy.get(createPatternPageLocators.Operator).first().click()
  }

  mainOperatorDropdownArrowUnderTesttwoClick() {
    return cy.get(createPatternPageLocators.mainOperatorDropdownArrowUnderTesttwo).eq(3).click()
  }

  andOperatorUnderTesttwoClick() {
    return cy.get(createPatternPageLocators.Operator).first().click()
  }

  operatorOneFortetsTwoClick() {
    return cy.get(createPatternPageLocators.operatorForEventOne).last().click()
  }

  equalToOperatorUnderOperatorOneDropdownListOfTestTwoClick() {
    return cy.get(createPatternPageLocators.Operator).first().click()
  }

  ValueOptionForTestTwoType() {
    return cy.get(createPatternPageLocators.ValueForTestOne).last().type(1)
  }

  operatorTwoOptionFortestTwoClick() {
    return cy.get(createPatternPageLocators.operatorTwoOptionFortestTwo).last().click()
  }

  starOperatorUnderOperatorTwoDropdownListFortestTwoClick() {
    return cy.get(createPatternPageLocators.Operator).first().click()
  }

  eventLog2OptionUnderAttributeTwoDropdownOfTestTwoClick() {
    return cy.get(createPatternPageLocators.testTwoOptionUnderAttributeTwoDropdownOfTestTwo).click()
  }

  uwlDropdownOptionUnderAttributeTwoDropdownOfTestTwoClick() {
    return cy.get(createPatternPageLocators.attribute).last().click()
  }

  eventOneRemoveOptionClick() {
    return cy.get(createPatternPageLocators.eventOneRemoveOption).first().click()
  }

  deleteButtonClick() {
    cy.contains('Delete').click()
  }

  crossMarkOfImportedDataModelClick() {
    return cy.get(createPatternPageLocators.crossMarkOfImportedDataModel).click()
  }

  popupVisible() {
    return cy.get(createPatternPageLocators.confirmationPopUp).should(assertionConstants.beVisibleAssertion)
  }

  seletedTestDataModelVisible() {
    return cy.get(createPatternPageLocators.seletedTestDataModel).first().should(assertionConstants.beVisibleAssertion)
  }

  dependentEventVisible() {
    return cy.get(createPatternPageLocators.dependentEvent).last().should(assertionConstants.beVisibleAssertion)
  }

  commonOptionUnderImportDataModelClick() {
    return cy.contains(commonOptionUnderImportDataModel).click()
  }

  popupOfRemovingMultipleDataModelsVisible() {
    return cy.get(createPatternPageLocators.confirmationPopUp).should(assertionConstants.beVisibleAssertion).and(assertionConstants.containAssertion, popupText)
  }

  seletedTestDataModelNotExists() {
    return cy.get(createPatternPageLocators.seletedTestDataModel).should(assertionConstants.notExistsAssertion)
  }

  dependentEventNotExists() {
    return cy.get(createPatternPageLocators.dependentEvent).should(assertionConstants.notExistsAssertion)
  }

  crosssMarkOfdataModelClick() {
    return cy.get(createPatternPageLocators.crosssMarkOfdataModel).click()
  }

  addedExpressionForEventTwoInRed() {
    return cy.get(createPatternPageLocators.addedExpressionForEvent).last().should(assertionConstants.haveAttributeAssertion, 'class', 'pt-dropdown ng-touched ng-dirty ng-invalid')
  }



  noDataModelImortedTextVisible() {
    cy.contains(text).should(assertionConstants.beVisibleAssertion)
  }

  autoGeneratedFirstEventVisible() {
    cy.get(createPatternPageLocators.autoGeneratedFirstEvent).should(assertionConstants.beVisibleAssertion)
  }

  AutoGeneratedFirstConditionVisible() {
    cy.get(createPatternPageLocators.AutoGeneratedFirstCondition).should(assertionConstants.beVisibleAssertion)
  }

  AttributeForFirstEventVisible() {
    cy.get(createPatternPageLocators.addedExpressionForEvent).find(ptLayoutContainerClass).find('span').first().should(assertionConstants.haveTextAssertion, 'AdditionalInfo').and(assertionConstants.beVisibleAssertion)
  }

  autoGeneratedFirstEventNameVisible() {
    cy.get(createPatternPageLocators.autoGeneratedEventName).should(assertionConstants.haveTextAssertion, ' EventLog1 ').and(assertionConstants.beVisibleAssertion)
  }

  checkBoxForFirstEventNameVisible() {
    cy.get(createPatternPageLocators.checkBox).first().should(assertionConstants.beExistAssertion)
  }

  checkBoxForFirstConditionVisible() {
    cy.get(createPatternPageLocators.checkBox).last().should(assertionConstants.beExistAssertion)
  }

  attributeDropDownVisible() {
    cy.get(createPatternPageLocators.attributeDropDown).should(assertionConstants.beVisibleAssertion)
  }

  operatorDropDownVisible() {
    cy.get(createPatternPageLocators.mainOperatorDropdownArrowUnderTesttwo).should(assertionConstants.beVisibleAssertion)
  }

  valueTextBoxVisible() {
    cy.get(createPatternPageLocators.valueTextBox).should(assertionConstants.beVisibleAssertion)
  }

  crossMarkAtConditionLevelVisible() {
    cy.get(createPatternPageLocators.crossMarkAtConditionLevel).should(assertionConstants.beVisibleAssertion)
  }

  plusIconAtConditionLevelVisible() {
    cy.get(createPatternPageLocators.addConditionButton).should(assertionConstants.beVisibleAssertion)
  }

  crossMarkAtGroupLevelVisible() {
    cy.get(createPatternPageLocators.eventOneRemoveOption).should(assertionConstants.beVisibleAssertion)
  }

  expandCollapseIconAtgroupLevelVisible() {
    cy.get(createPatternPageLocators.expandCollapseIconAtgroupLevel).eq(5).should(assertionConstants.beVisibleAssertion)
  }

  showAllButtonClick() {
    cy.get(createPatternPageLocators.checkBox).last().click()
  }

  plusIconToAddConditionVisible() {
    cy.get(createPatternPageLocators.plusIconInAddCondition).should(assertionConstants.beVisibleAssertion)
  }

  operatorWaterMarkVisible() {
    cy.contains(operatorWaterMark).should(assertionConstants.beVisibleAssertion)
  }

  valueWaterMarkVisible() {
    cy.get(createPatternPageLocators.valueWaterMark).should(assertionConstants.beVisibleAssertion)
  }

  attributeForSecondConditionInFirstEventClick() {
    cy.get(createPatternPageLocators.addedExpressionForEvent).eq(1).click()
  }

  attributeForSecondConditionClick() {
    cy.get(createPatternPageLocators.attributeForSecondCondition).eq(1).click({ force: true })
  }

  operatorDropDownForSecondConditionClick() {
    cy.get(createPatternPageLocators.operatorForEventOne).eq(1).click({ force: true })
  }

  equalToOperatorForSecondConditonClick() {
    cy.get(createPatternPageLocators.Operator).first().click()
  }

  equalToOperatorForSecondConditonClickAndSelect() {
    cy.get(createPatternPageLocators.operatorsDropdown).eq(0).click()
    cy.get(createPatternPageLocators.patternTypeDropdown).eq(0).click()
  }

  valueOptionForSecondConditionType() {
    cy.get(createPatternPageLocators.valueOptionForSecondCondition).last().type('2')
  }

  logicalOperatorDropdownForSecondConditionClick() {
    cy.get(createPatternPageLocators.mainOperatorDropdownArrowUnderTesttwo).last().click()
  }

  logicalOperatorForSecondConditionClick() {
    cy.contains(logicalOperatorForSecondCondition).click()
  }

  logicalExpressionAtConditionLevelVisible() {
    cy.get(createPatternPageLocators.AutoGeneratedFirstCondition).should(assertionConstants.containAssertion, '  C1  AND C2 ').and(assertionConstants.beVisibleAssertion)
  }

  secondEventVisible() {
    cy.get(createPatternPageLocators.autoGeneratedFirstEvent).last().find(autoGeneratedEventName).should(assertionConstants.haveTextAssertion, ' EventLog2 ').and(assertionConstants.beVisibleAssertion)
  }

  operatorDropDownForSecondEventFirstConditionClick() {
    cy.get(createPatternPageLocators.operatorForEventOne).last().click({ force: true })
  }

  addConditionButtonForEventTwoClick() {
    cy.get(createPatternPageLocators.addConditionButton).last().click()
  }

  valueForConditionTwoInEvenmtwoType() {
    cy.get(createPatternPageLocators.ValueForTestOne).last().type('2')
  }

  attributeOptionForSecondConditionInSecondEventClick() {
    cy.get(createPatternPageLocators.addedExpressionForEvent).last().click()
  }

  operatorForSecondConditionInSecondEventClick() {
    cy.get(createPatternPageLocators.operatorForEventOne).last().click({ force: true })
  }

  valueOptionForSecondConditionInSecondEventClick() {
    cy.get(createPatternPageLocators.valueOptionForSecondCondition).last().click()
  }

  valueForSecondConditionInSecondEventClick() {
    cy.get(createPatternPageLocators.valueForSecondConditionInSecondEvent).first().click()
  }

  operatorBetweenTwoEventsClick() {
    cy.get(createPatternPageLocators.mainOperatorDropdownArrowUnderTesttwo).eq(3).click()
  }

  AndOperatorBetweenTwoEventsClick() {
    cy.get(createPatternPageLocators.Operator).first().click()
  }

  logicalExpressionAtEventLevelVisible() {
    cy.get(createPatternPageLocators.logicalExpressionAtEventLevel).invoke('text').then((Expression) => {
      expect(Expression).to.be.exist
    })
  }

  opeartorDropDownForEvent3ConditionOneClick() {
    cy.get(createPatternPageLocators.operatorForEventOne).last().click({ force: true })
  }

  valueForFirstConditionInThridEventType() {
    cy.get(createPatternPageLocators.valueWaterMark).last().type('2')
  }

  addConditionButtonForEventThreeClick() {
    cy.get(createPatternPageLocators.addConditionButton).last().click()
  }

  attributeDropDownOptionForConditionTwoEvent3Click() {
    cy.get(createPatternPageLocators.addedExpressionForEvent).last().click()
  }

  operatorDropDownForCondition2Event3Click() {
    cy.get(createPatternPageLocators.operatorForEventOne).last().click()
  }

  valueForCondition2Event3Click() {
    cy.get(createPatternPageLocators.valueOptionForSecondCondition).last().type(1)
  }

  conditionLevelOperatorForCondition2Event2Click() {
    cy.get(createPatternPageLocators.mainOperatorDropdownArrowUnderTesttwo).eq(5).click()
  }

  andNOtOperatorForCondition2Event2() {
    cy.get(createPatternPageLocators.Operator).eq(1).click()
  }

  operatorDropdownBetweenEvent2And3Click() {
    cy.get(createPatternPageLocators.mainOperatorDropdownArrowUnderTesttwo).eq(6).click()
  }

  andNotOperatorAtEventLevelForEvent2And3Click() {
    cy.get(createPatternPageLocators.Operator).first().click()
  }

  ConditionLevelOperatorForCondition3Event3Click() {
    cy.get(createPatternPageLocators.mainOperatorDropdownArrowUnderTesttwo).last().click()
  }

  andOperatorForCondition2InEvent3Click() {
    cy.get(createPatternPageLocators.Operator).first().click()
  }

  textInEventoneNotVisible() {
    cy.contains(textInEventone).should(assertionConstants.notVisibleAssertion)
  }

  logicalExpressionAtAddConditionLevelExist() {
    cy.get(createPatternPageLocators.logicalExpressionAtAddConditionLevel).eq(2).find('span').invoke('text').then((expression) => {
      expect(expression).to.exist
    })
  }

  saveAsDraftBButtonClick() {
    cy.get(createPatternPageLocators.saveAsDraft).click()
  }

  messageVisible() {
    cy.contains(draftSavedText).should(assertionConstants.beVisibleAssertion)
  }

  systemParameterDataModelInListClick() {
    cy.get(createPatternPageLocators.testTwoOptionUnderAttributeTwoDropdownOfTestTwo).click()
  }

  groupAttributeOfSystemParameterDataModelClick() {
    cy.get(createPatternPageLocators.attribute).eq(1).click({ force: true })
  }

  addConditionPulsIconClick() {
    cy.get(createPatternPageLocators.plusIconInAddCondition).click({ force: true })
  }

  eventLevelOperatorForEventFour() {
    cy.get(createPatternPageLocators.mainOperatorDropdownArrowUnderTesttwo).eq(9).click()
  }

  andNotOperatorForEventFourClick() {
    cy.get(createPatternPageLocators.Operator).eq(1).click()
  }

  logicalExpressionWithSystemParameterEventVisible() {
    cy.get(createPatternPageLocators.logicalExpressionAtEventLevel).invoke('text').then((expression) => {
      expect(expression).to.include('AND NOT SystemParameters1')
    })
  }

  systemConfigurationDataModelClick() {
    cy.get(createPatternPageLocators.DataModel).eq(0).click({ force: true })
  }

  systemConfigurationDataModelInListClick() {
    cy.get(createPatternPageLocators.systemConfigurationDataModelInList).click({ force: true })
  }

  countAttributeUnderSystemConfigurationClick() {
    cy.get(createPatternPageLocators.attribute).eq(2).click({ force: true })
  }

  eventLevelOperatorForEventFiveClick() {
    cy.get(createPatternPageLocators.mainOperatorDropdownArrowUnderTesttwo).eq(11).click()
  }

  andOperatorForEventFiveClick() {
    cy.get(createPatternPageLocators.operators).first().click()
  }

  logicalExpressionWithSystemConfigurationEventVisible() {
    cy.get(createPatternPageLocators.logicalExpressionAtEventLevel).invoke('text').then((expression) => {
      expect(expression).to.include('AND SystemConfiguration1 ')
    })
  }

  evenetLogDataModelInListClick() {
    cy.get(createPatternPageLocators.eventLogDataModelInList).click({ force: true })
  }

  additionInfoAttributeUnderEventLogClick() {
    cy.get(createPatternPageLocators.attribute).eq(3).click({ force: true })
  }

  eventLevelDropDownForEventSixClick() {
    cy.get(createPatternPageLocators.mainOperatorDropdownArrowUnderTesttwo).eq(13).click()
  }

  andNotOperatorForEventSixClick() {
    cy.get(createPatternPageLocators.Operator).eq(1).click()
  }

  logicalExpressionWithEventLogEventVisible() {
    cy.get(createPatternPageLocators.logicalExpressionAtEventLevel).invoke('text').then((expression) => {
      expect(expression).to.include('AND NOT EventLog1')
    })
  }



  formRulePatternOptionClick() {
    cy.contains(formRulePatternOption).click()
  }
  patternClick() {
    cy.get(createPatternPageLocators.availablePatternsList).last().find('tr').eq(1).find('td').first().find('span').first().click({ force: true })
  }

  patternClickForWFCreation() {
    cy.get(createPatternPageLocators.availablePatternsList).last().find('tr').eq(2).find('td').first().find('span').first().click({ force: true })
  }

  importButtonClick() {
    cy.get(createPatternPageLocators.importButton).click()
  }

  patternUnderAddConditionVisible() {
    cy.get(createPatternPageLocators.patternUnderAddCondition).find(autoGeneratedFirstEvent).should(assertionConstants.beVisibleAssertion)
  }

  addExpressionPopUpCloseButtonClick() {
    cy.get(createPatternPageLocators.addExpressionPopUpCloseButton).click()
  }

  selectedTestDataModelClick() {
    cy.get(createPatternPageLocators.selectedDataModel).eq(0).click()
  }

  selectedEventLOgDataModelClick() {
    cy.get(createPatternPageLocators.selectedDataModel).eq(0).click()
  }

  importedSystemDataModelVisible() {
    cy.get(createPatternPageLocators.dataModel).children('span').should(assertionConstants.haveTextAssertion, 'SystemParameters').and(assertionConstants.beVisibleAssertion)
  }

  importedSystemDataModelClick() {
    cy.get(createPatternPageLocators.dataModel).click()
  }

  groupAttributesOfSystemParameterImportedDataModelClick() {
    cy.get(createPatternPageLocators.attribute).eq(0).click()
  }

  selectedSystemParameterDataModelClick() {
    cy.get(createPatternPageLocators.selectedDataModel).eq(0).click()
  }

  importedSystemConfigurationDataModelVisible() {
    cy.get(createPatternPageLocators.dataModel).children('span').should(assertionConstants.haveTextAssertion, 'SystemConfiguration').and(assertionConstants.beVisibleAssertion)
  }

  importedSystemConfigurationDataModelClick() {
    cy.get(createPatternPageLocators.dataModel).click()
  }

  countAttributesOfSystemConfigurationImportedDataModelClick() {
    cy.get(createPatternPageLocators.attribute).eq(0).click()
  }

  selectedSystemConfigurationDataModelClick() {
    cy.get(createPatternPageLocators.selectedDataModel).eq(0).click()
  }
  importedEventLogDataModelVisible() {
    cy.get(createPatternPageLocators.dataModel).children('span').should(assertionConstants.haveTextAssertion, 'EventLog').and(assertionConstants.beVisibleAssertion)
  }

  importedEventLogDataModelClick() {
    cy.get(createPatternPageLocators.dataModel).click()
  }

  additionalInfoAttributesOfEventLogImportedDataModelClick() {
    cy.contains(additionalInfoAttribute).click({ force: true })
  }

  eventLogAttributeClick() {
    return cy.get(createPatternPageLocators.dataModel).find('span').click()
  }

  additionalInfoAttributeClick() {
    cy.get(createPatternPageLocators.attribute).first().click()
  }

  operatorOneDropdownForEventOneClick() {
    cy.get(createPatternPageLocators.mainOperatorDropdownArrowUnderTesttwo).first().click()
  }

  notOperatorForEventClick() {
    cy.get(createPatternPageLocators.operators).click()
  }

  operatorOneDropdownForEventTwoClick() {
    cy.get(createPatternPageLocators.mainOperatorDropdownArrowUnderTesttwo).eq(2).click()
  }

  andOperatorForEventClick() {
    cy.get(createPatternPageLocators.operators).first().click()
  }

  addedCondtionAttributeDropdownClick() {
    cy.get(createPatternPageLocators.addedCondtionAttributeDropdown).last().click()
  }

  addedCondtionAttributeDropdownInFirstEventClick() {
    cy.get(createPatternPageLocators.addedCondtionAttributeDropdown).eq(0).click()
  }
  addExpressionsTitleVisible() {
    cy.get(createPatternPageLocators.addExpressionsTitle).should(assertionConstants.haveTextAssertion, 'Add Expression').and(assertionConstants.beVisibleAssertion)
  }

  operatorInAddExpressinPopUp() {
    cy.get(createPatternPageLocators.mainOperatorDropdownArrowUnderTesttwo).last().should(assertionConstants.beVisibleAssertion)
  }

  attributeOneInAddExpressinPopUpVisible() {
    cy.get(createPatternPageLocators.attributeOneInAddExpressinPopUp).should(assertionConstants.beVisibleAssertion)
  }

  operatorTwoInAddExpressionPopUpVisible() {
    cy.get(createPatternPageLocators.operatorForEventOne).last().should(assertionConstants.beVisibleAssertion)
  }

  attributeTwoInAddExpressionPopUpVisible() {
    cy.get(createPatternPageLocators.attributeTwoInAddExpressionPopUp).should(assertionConstants.beVisibleAssertion)
  }

  doneButtonInPopUpVisible() {
    cy.get(createPatternPageLocators.doneButtonInPopUp).should(assertionConstants.notBeEnabledAssertion).and(assertionConstants.beVisibleAssertion)
  }

  closeButtonInPopUpVisible() {
    cy.get(createPatternPageLocators.closeButtonInPopUp).should(assertionConstants.beVisibleAssertion)
  }

  eventLogOneUnderAttributeVisible() {
    cy.get(createPatternPageLocators.dataModel).find('span').should(assertionConstants.haveTextAssertion, 'EventLog1').and(assertionConstants.beVisibleAssertion)
  }

  eventLogTwoUnderAttributeVisible() {
    cy.get(createPatternPageLocators.testTwoOptionUnderAttributeTwoDropdownOfTestTwo).find('span').should(assertionConstants.haveTextAssertion, 'EventLog2').and(assertionConstants.beVisibleAssertion)
  }

  eventLogOneUnderAttributeclick() {
    cy.get(createPatternPageLocators.dataModel).click()
  }

  OperatorForeventLog1UnderAtribute1Click() {
    cy.get(createPatternPageLocators.attribute).eq(1).click()
  }

  OperatorForeventLog1UnderAtribute2Click() {
    cy.get(createPatternPageLocators.attribute).eq(2).click()
  }

  OperatorForeventLog1UnderAttribute2Click() {
    cy.get(createPatternPageLocators.attribute).eq(0).click()
  }

  closeButtonInPopUpClick() {
    cy.get(createPatternPageLocators.closeButtonInPopUp).click({ force: true })
  }

  addConditionPopUpNotExist() {
    cy.get(createPatternPageLocators.addConditionPopUp).should(assertionConstants.notExistsAssertion)
  }

  operatorTextBoxTextWithOutAddedExpression() {
    cy.get(createPatternPageLocators.addedExpressionForEvent).last().find(ptLayoutContainerClass).first().find('span').should('have.text', 'Attribute')
  }

  doneButtonEnabled() {
    cy.contains(doneButton).should(assertionConstants.notBeDisabledAssertion)
  }

  operatorTextBoxTextWithAddedExpression() {
    cy.get(createPatternPageLocators.addedExpressionForEvent).last().find(createPatternPageLocators.ptLayoutContainerClass).first().find('span').should('have.text', addedExpressionForEventOne).and(assertionConstants.beVisibleAssertion)
  }

  patternNameType() {
    cy.get(createPatternPageLocators.patternName).type(userID_Alpha_Numeric())
  }

  descriptionType() {
    cy.get(createPatternPageLocators.description).type('PatternDescription')
  }

  orderOfExecutionType() {
    cy.get(createPatternPageLocators.orderOfExecution).clear().type('1')
  }

  ValueForEventOneType() {
    cy.get(createPatternPageLocators.ValueForTestOne).last().type('1')
  }

  msUnitClick() {
    cy.get(createPatternPageLocators.msUnit).find('dls-option-list').first().children().first().click()
  }

  addActionClick() {
    cy.get(createPatternPageLocators.addAction).last().click()
  }

  addActionPlusIconClick() {
    cy.get(createPatternPageLocators.addActionPlusIcon).click()
  }

  raiseAlertOptionClick() {
    cy.get(createPatternPageLocators.attribute).first().click()
  }

  savedDetailsVisible() {
    cy.get(createPatternPageLocators.logicalExpressionAtAddConditionLevel).should(assertionConstants.beVisibleAssertion)
  }

  rulePatternClick() {
    return cy.get(createPatternPageLocators.formDataModel).eq(1).click()
  }

  firstKnowledgeClick() {
    cy.get(createPatternPageLocators.firstKnowledge).first().find('td').first().click()
  }
  attributeOneUnderEventOneClick() {
    cy.get(createPatternPageLocators.addedExpressionForEvent).first().click()
  }

  operatorTextBoxTextForRulePaternWithAddedExpressionVisible() {
    cy.get(createPatternPageLocators.addedExpressionForEvent).first().find(createPatternPageLocators.ptLayoutContainerClass).first().find('span').should('have.text', addedExpressionForEventOne).and(assertionConstants.beVisibleAssertion)
  }

  unitDropdownClick() {
    cy.get(createPatternPageLocators.UnitDropDown).eq(1).click()
  }

  msUnitForRulePatternClick() {
    cy.get(createPatternPageLocators.Operator).first().click()
  }

  addedCondtionAttributeDropdownForLog2Click() {
    cy.get(createPatternPageLocators.addedCondtionAttributeDropdown).last().click()
  }

  addExpressionOptionForEventTwoClick() {
    cy.get(createPatternPageLocators.addCondtionOptionForTestOne).click()
  }

  operatorForEventTwoClick() {
    cy.get(createPatternPageLocators.operatorForEventOne).last().click()
  }

  ValueForEventTwoType() {
    cy.get(createPatternPageLocators.ValueForTestOne).last().type('2')
  }

  unitDropdownForEventTwoClick() {
    cy.get(createPatternPageLocators.UnitDropDown).last().click()
  }

  removeEventButtonClick() {
    cy.get(createPatternPageLocators.eventOneRemoveOption).first().click()
  }

  eventsAndConditionInredColor() {
    cy.get(createPatternPageLocators.addedExpressionForEvent).should(assertionConstants.haveAttributeAssertion, 'class', 'pt-dropdown ng-touched ng-pristine ng-invalid').and(assertionConstants.beVisibleAssertion)
  }

  eventLogOneUnderAttributeOneNotVisible() {
    cy.get(createPatternPageLocators.dataModel).find('span').should(assertionConstants.notHaveTextAssertion, 'EventLog1')
  }

  eventLogOneUnderAttributeTwoNotVisible() {
    cy.get(createPatternPageLocators.dataModel).find('span').should(assertionConstants.notHaveTextAssertion, 'EventLog1')
  }

  addedCondtionAttributeDropdownForEventTwoInRulepatternClick() {
    cy.get(createPatternPageLocators.addedCondtionAttributeDropdown).last().click()
  }

  operatorTextBoxTextWithOutAddedExpressionForRulePattern() {
    cy.get(createPatternPageLocators.addedExpressionForEvent).last().find(createPatternPageLocators.ptLayoutContainerClass).first().find('span').should('have.text', 'Attribute')
  }

  operatorTextBoxTextWithAddedExpressionForRulePattern() {
    cy.get(createPatternPageLocators.addedExpressionForEvent).last().find(ptLayoutContainerClass).first().find('span').should('have.text', addedExpressionForEventOne)
  }

  operatorForEventTwoInRulePatternClick() {
    cy.get(createPatternPageLocators.operatorForEventOne).last().click()
  }

  ValueForEventTwoInRulePatternType() {
    cy.get(createPatternPageLocators.ValueForTestOne).last().type('2')
  }

  unitDropdownForEventTwoInRulePatternClick() {
    cy.get(createPatternPageLocators.UnitDropDown).eq(1).click()
  }



  fromVariableOptionEnabled() {
    cy.contains(fromVariable).should(assertionConstants.notBeDisabledAssertion)
  }

  fromVariableOptionClick() {
    cy.contains(fromVariable).click()
  }

  valueForSecondConditionFirstEventType() {
    cy.get(createPatternPageLocators.valueWaterMark).eq(1).type('2')
  }

  valueForSecondConditionSecondEventType() {
    cy.get(createPatternPageLocators.valueWaterMark).last().type('1')
  }

  eventOneUnderFromvariableVisible() {
    cy.get(createPatternPageLocators.dataModel).should(assertionConstants.beVisibleAssertion)
  }

  eventTwoUnderFromvariableVisible() {
    cy.get(createPatternPageLocators.testTwoOptionUnderAttributeTwoDropdownOfTestTwo).should(assertionConstants.beVisibleAssertion)
  }

  eventOneUnderFromvariableClick() {
    cy.get(createPatternPageLocators.dataModel).click()
  }

  eventTwoUnderFromvariableClick() {
    cy.get(createPatternPageLocators.testTwoOptionUnderAttributeTwoDropdownOfTestTwo).click()
  }

  asACloneOptionVisible() {
    cy.contains(asACloneOption).should(assertionConstants.beVisibleAssertion)
  }

  asIsOptionClick() {
    cy.contains(asIsOption).click()
  }

  asIsOptionVisible() {
    cy.contains(asIsOption).should(assertionConstants.beVisibleAssertion)
  }

  crossIconEnabledAndVisible() {
    cy.get(createPatternPageLocators.eventOneRemoveOption).last().should(assertionConstants.notBeDisabledAssertion).and(assertionConstants.beVisibleAssertion)
  }

  copiedEventNameVisible() {
    cy.get(createPatternPageLocators.autoGeneratedEventName).last().should(assertionConstants.haveTextAssertion, ' EventLog1 ').and(assertionConstants.beVisibleAssertion)
  }

  operatorBetweenEvent() {
    cy.get(createPatternPageLocators.operator).last().should(assertionConstants.beVisibleAssertion)
  }

  eventNameHover() {
    cy.get(createPatternPageLocators.autoGeneratedEventName).last().trigger('mouseover')
  }

  andOperatorClick() {
    cy.contains(andOperator).click()
  }

  updatedLogicalExpresssionUnderAddConditionVisible() {
    cy.get(createPatternPageLocators.logicalExpressionAtEventLevel).invoke('text').then((expression) => {
      expressionArrey.push(expression)
      cy.log(expressionArrey)
      expect(expression).to.be.exist
    })
  }

  operatorAtConditionTwoEventOneClick() {
    cy.get(createPatternPageLocators.operator).eq(2).click()
  }

  andOperatorAtConditionTwoEventOne() {
    cy.get(createPatternPageLocators.valueForSecondConditionInSecondEvent).eq(0).click()
  }

  conditonOneInEventOneCheckBox() {
    cy.get(createPatternPageLocators.checkBox).eq(1).click()
  }

  conditonTwoInEventOneCheckBox() {
    cy.get(createPatternPageLocators.checkBox).eq(2).click()
  }

  groupButtonAtConditonClick() {
    cy.get(createPatternPageLocators.groupButton).first().click()
  }

  ungroupOptionForConditionsVisible() {
    cy.get(createPatternPageLocators.ungroupOption).last().should(assertionConstants.beVisibleAssertion)
  }

  EventTwoCheckBoxClick() {
    cy.get(createPatternPageLocators.checkBox).eq(2).click()
  }

  copiedEventCheckBoxClick() {
    cy.get(createPatternPageLocators.checkBox).last().click()
  }

  groupButtonAtEventEnabled() {
    cy.get(createPatternPageLocators.groupButonAtEvent).should(assertionConstants.notBeDisabledAssertion)
  }

  groupButtonAtEventClick() {
    cy.get(createPatternPageLocators.groupButonAtEvent).scrollIntoView().click()
  }

  updatedLogicalExpresssionUnderAddConditionAfterAddingGroup() {
    cy.get(createPatternPageLocators.logicalExpressionAtEventLevel).invoke('text').then((updatedExpression) => {
      expect(updatedExpression).not.equal(expressionArrey[0])
      expect(updatedExpression).contain('(   EventLog2  AND EventLog1  )')
    })
  }

  updatedLogicalExpresssionUnderAddConditionAfterUngrouping() {
    cy.get(createPatternPageLocators.logicalExpressionAtEventLevel).invoke('text').then((updatedExpression) => {
      expect(updatedExpression).not.contain('(   EventLog2  AND EventLog1  )')
    })
  }

  ungroupOptionForEventEnabled() {
    cy.get(createPatternPageLocators.ungroupOptionForEvent).should(assertionConstants.notBeDisabledAssertion)
  }

  ungroupOptionForEventClick() {
    cy.get(createPatternPageLocators.ungroupOptionForEvent).click()
  }

  groupButtonforEventTwo() {
    cy.get(createPatternPageLocators.groupButtonforEventOne).first().scrollIntoView().should(assertionConstants.haveTextAssertion, ' Group ').and(assertionConstants.beVisibleAssertion)
  }

  groupButtonforEvent() {
    cy.get(createPatternPageLocators.groupButtonforEventOne).eq(0).should(assertionConstants.notBeEnabledAssertion)
  }

  crossIconAtEventlevelClick() {
    cy.get(createPatternPageLocators.eventOneRemoveOption).eq(0).click()
  }

  confirmationPopUpVisible() {
    cy.get(createPatternPageLocators.confirmationPopUp).should(assertionConstants.beVisibleAssertion)
  }

  eventVisible() {
    cy.contains(firstEventName).should(assertionConstants.beVisibleAssertion)
  }


  eventNotVisible() {
    cy.contains(firstEventName).should(assertionConstants.notExistsAssertion)
  }

  crossIconAtEventAddedFromAsIsOptionClick() {
    cy.get(createPatternPageLocators.eventOneRemoveOption).last().click()
  }

  confirmationPopUpNotExist() {
    cy.get(createPatternPageLocators.confirmationPopUp).should(assertionConstants.notExistsAssertion)
  }

  eventAddedFromAsIsOptionNotExist() {
    cy.get(createPatternPageLocators.eventAddedFromAsIsOption).should(assertionConstants.notExistsAssertion)
  }

  eventThreeEventLevelCheckboxClick() {
    cy.get(createPatternPageLocators.checkBox).eq(2).click()
  }

  eventFourEventLevelCheckboxClick() {
    cy.get(createPatternPageLocators.checkBox).eq(4).click()
  }

  crossIconAtGroupedEventLevelClick() {
    cy.get(createPatternPageLocators.crossIconAtGroupedEventLevel).click()
  }

  groupedEventsVisible() {
    cy.get(createPatternPageLocators.groupEvent).should(assertionConstants.containAssertion, ' EventLog3 ', ' EventLog4 ')
  }

  groupedEventsNotExist() {
    cy.get(createPatternPageLocators.groupedEvents).should(assertionConstants.notExistsAssertion)
  }

  savedEventVisible() {
    cy.get(createPatternPageLocators.savedEvent).eq(1).should(assertionConstants.beVisibleAssertion)
  }

  eventTwoUnderFromVariableForRulePatternVisible() {
    cy.get(createPatternPageLocators.dataModel).should(assertionConstants.beVisibleAssertion)
  }

  eventThreeUnderFromVariableForRulePatternVisible() {
    cy.get(createPatternPageLocators.testTwoOptionUnderAttributeTwoDropdownOfTestTwo).should(assertionConstants.beVisibleAssertion)
  }

  eventFourUnderFromVariableForRulePatternVisible() {
    cy.get(createPatternPageLocators.systemConfigurationDataModelInList).should(assertionConstants.beVisibleAssertion)
  }

  eventTwoUnderFromVariableForRulePatternClick() {
    cy.get(createPatternPageLocators.dataModel).click()
  }

  eventThreeUnderFromVariableForRulePatternClick() {
    cy.get(createPatternPageLocators.testTwoOptionUnderAttributeTwoDropdownOfTestTwo).click()
  }

  eventFourUnderFromVariableForRulePatternClick() {
    cy.get(createPatternPageLocators.systemConfigurationDataModelInList).click()
  }

  copiedEventFromRulePattenNameVisible() {
    cy.get(createPatternPageLocators.autoGeneratedEventName).last().should(assertionConstants.haveTextAssertion, ' EventLog3 ').and(assertionConstants.beVisibleAssertion)
  }


  operatorDropDownForCopiedEventVisible() {
    cy.get(createPatternPageLocators.mainOperatorDropdownArrowUnderTesttwo).last().should(assertionConstants.beVisibleAssertion)
  }

  operatorDropDownForCopiedEventClick() {
    cy.get(createPatternPageLocators.mainOperatorDropdownArrowUnderTesttwo).last().click()
  }

  crossIconForCopiedEventFromRulePatternEnabledAndVisible() {
    cy.get(createPatternPageLocators.eventOneRemoveOption).last().should(assertionConstants.notBeDisabledAssertion).and(assertionConstants.beVisibleAssertion)
  }

  andOperatorForCopiedEventClick() {
    cy.get(createPatternPageLocators.valueForSecondConditionInSecondEvent).eq(0).click()
  }

  updatedLogicalExpresssionUnderAddConditionForRulePatternVisible() {
    cy.get(createPatternPageLocators.logicalExpressionAtEventLevel).invoke('text').then((expression) => {
      expressionArreyRulePattern.push(expression)
      cy.log(expressionArrey)
      expect(expression).to.be.exist
    })
  }

  attributeDropDownForEventTwoConditionFourClick() {
    cy.get(createPatternPageLocators.addedExpressionForEvent).eq(4).click()
  }

  componentAttributeOptionsForEventTwoConditionFourClick() {
    cy.contains(componentAttribute).click()
  }
  componentAttributeAdditionalInfoOptionsForEventTwoConditionFourClick() {
    cy.contains('AdditionalInfo').click()
  }

  evenetIdAttributeClick() {
    cy.contains(eventIdAttribute).click()
  }

  operatorDropDownBetweenAttrAndValueForEventTwoConditonfourClick() {
    cy.get(createPatternPageLocators.operatorForEventOne).eq(4).click()
  }

  equalToOperatorsOptionsForEventTwoConditionFourClick() {
    cy.get(createPatternPageLocators.valueForSecondConditionInSecondEvent).eq(1).click()
  }

  valueOptionForEventTwoConditionFourType() {
    cy.get(createPatternPageLocators.valueOptionForEventTwoConditionFour).type('2')
  }

  operatorDropDownForEventTwoConditionFourClick() {
    cy.get(createPatternPageLocators.mainOperatorDropdownArrowUnderTesttwo).eq(6).click()
  }

  andOperatorsOptionsForEventTwoConditionFourClick() {
    cy.get(createPatternPageLocators.valueForSecondConditionInSecondEvent).eq(0).click()
  }

  checkBoxForConditionOneEventwoClick() {
    cy.get(createPatternPageLocators.checkBox).eq(3).click()
  }

  checkBoxForConditionTwoEventwoClick() {
    cy.get(createPatternPageLocators.checkBox).eq(4).click()
  }

  checkBoxForConditionThreeEventwoClick() {
    cy.get(createPatternPageLocators.checkBox).eq(5).click()
  }

  checkBoxForConditionFoutEventwoClick() {
    cy.get(createPatternPageLocators.checkBox).eq(6).click()
  }

  groupButtonForEventTwoConditionsClick() {
    cy.get(createPatternPageLocators.groupButton).first().click({ force: true })
  }

  ungroupOptionForGroupedConditionsVisible() {
    cy.get(createPatternPageLocators.ungroupOption).should(assertionConstants.containAssertion, 'Group')
  }

  checkBoxForCopiedEventClick() {
    cy.get(createPatternPageLocators.checkBox).last().click()
  }

  checkBoxForEventThreeClick() {
    cy.get(createPatternPageLocators.checkBox).eq(4).click()
  }

  updatedLogicalExpresssionUnderAddConditionAfterAddingGroupForRulePattern() {
    cy.get(createPatternPageLocators.logicalExpressionAtEventLevel).invoke('text').then((updatedExpression) => {
      expect(updatedExpression).not.equal(expressionArreyRulePattern[0])
      expect(updatedExpression).contain('(   EventLog4  AND EventLog3  )')
    })
  }

  ungroupOptionForGroupedConditionsEnabled() {
    cy.get(createPatternPageLocators.ungroupOption).last().should(assertionConstants.containAssertion, 'Group')
  }

  ungroupOptionForGroupedConditionsClick() {
    cy.get(createPatternPageLocators.ungroupOption).last().click()
  }

  crossIconAtEventTwoClick() {
    cy.get(createPatternPageLocators.eventOneRemoveOption).eq(1).click()
  }

  createdEventVisible() {
    cy.get(createPatternPageLocators.autoGeneratedFirstEvent).eq(1).should(assertionConstants.containAssertion, ' EventLog3 ').and(assertionConstants.beVisibleAssertion)
  }

  createdEventNotExist() {
    cy.get(createPatternPageLocators.autoGeneratedFirstEvent).eq(1).should(assertionConstants.notContainAssertion, ' EventLog3 ')
  }

  eventFourOptionUnderFormVariableOptionClick() {
    cy.get(createPatternPageLocators.testTwoOptionUnderAttributeTwoDropdownOfTestTwo).click()
  }

  eventAddedFromAsIsOptionInRulepatternNotExist() {
    cy.get(createPatternPageLocators.eventAddedFromAsIsOptionInRulepattern).should(assertionConstants.notExistsAssertion)
  }

  eventFiveCheckBoxClick() {
    cy.get(createPatternPageLocators.checkBox).eq(7).click()
  }

  eventTwoCheckBoxClick() {
    cy.get(createPatternPageLocators.checkBox).eq(2).click()
  }

  groupedEventsInRulePaternVisible() {
    cy.get(createPatternPageLocators.groupedEvents).should(assertionConstants.containAssertion, ' EventLog4 ', ' EventLog6 ').and(assertionConstants.beVisibleAssertion)
  }

  groupedEventsInRulePaternNotExist() {
    cy.get(createPatternPageLocators.groupedEvents).should(assertionConstants.notExistsAssertion)
  }

  operatorDropDownBetweenAddedEventsClick() {
    cy.get(createPatternPageLocators.mainOperatorDropdownArrowUnderTesttwo).eq(6).click()
  }

  operatorDropDownBetweenAddedEventsFromRulePaternClick() {
    cy.get(createPatternPageLocators.mainOperatorDropdownArrowUnderTesttwo).eq(10).click()
  }

  operatorOptionsBetweenFifthAndSixthEventClick() {
    cy.get(createPatternPageLocators.valueForSecondConditionInSecondEvent).eq(0).click()
  }

  rulePatternOptionClick() {
    cy.get(createPatternPageLocators.rulePatternOption).eq(1).click()
  }

  importConditionPopUpVisible() {
    cy.get(createPatternPageLocators.importConditionPopUp).should(assertionConstants.beVisibleAssertion)
  }

  commonSearchBoxType() {
    cy.get(createPatternPageLocators.commonSearchBox).clear().type('detector')
  }

  searchButtonClick() {
    cy.get(createPatternPageLocators.searchButton).first().click()
  }

  coloumLevelNameFilterVisible() {
    cy.get(createPatternPageLocators.coloumLevelNameFilter).should(assertionConstants.beVisibleAssertion)
  }

  coloumLevelDecriptionFilterVisible() {
    cy.get(createPatternPageLocators.coloumLevelDecriptionFilter).should(assertionConstants.beVisibleAssertion)
  }

  coloumLevelDataModelFilterVisible() {
    cy.get(createPatternPageLocators.colcounLevelDataModelFilter).should(assertionConstants.beVisibleAssertion)
  }

  coloumLevelTagsFilterVisible() {
    cy.get(createPatternPageLocators.coloumLevelTagsFilter).should(assertionConstants.beVisibleAssertion)
  }

  coloumLevelTagsFilterClick() {
    cy.get(createPatternPageLocators.coloumLevelTagsFilter).click()
  }

  coloumLevelDataModelfilterClick() {
    cy.get(createPatternPageLocators.colcounLevelDataModelfilter).first().scrollIntoView().click()
  }

  coloumLevelDataModelfilterVisible() {
    cy.get(createPatternPageLocators.colcounLevelDataModelfilter).first().scrollIntoView().should(assertionConstants.beVisibleAssertion)
  }

  coloumLevelDataModelFilterClick() {
    cy.get(createPatternPageLocators.colcounLevelDataModelFilter).click()
  }

  selectAllCheckBoxVisible() {
    cy.get(createPatternPageLocators.selectAllCheckBox).should(assertionConstants.beVisibleAssertion)
  }

  filterOptionVisible() {
    cy.get(createPatternPageLocators.filterOption).should(assertionConstants.beVisibleAssertion)
  }

  checkBoxAtEachValueLevelVisible() {
    cy.get(createPatternPageLocators.checkBoxAtEachValueLevel).should(assertionConstants.beVisibleAssertion)
  }

  clearButtonVisible() {
    cy.get(createPatternPageLocators.clearButton).should(assertionConstants.beVisibleAssertion)
  }

  applyButtonVisible() {
    cy.get(createPatternPageLocators.applyButton).should(assertionConstants.beVisibleAssertion)
  }

  applyButtonClick() {
    cy.get(createPatternPageLocators.applyButton).click({ force: true })
  }

  filteredDataVisible() {
    cy.get(createPatternPageLocators.availablePatternsList).last().find('tr').find('td').find('span').should(assertionConstants.beVisibleAssertion)
  }

  dataModelDropDownNotExist() {
    cy.get(createPatternPageLocators.dataModelDropDown).should(assertionConstants.notExistsAssertion)
  }

  valueOnDropDownVisible() {
    cy.get(createPatternPageLocators.valueOnDropDown).first().should(assertionConstants.containAssertion, 'EventLog').and(assertionConstants.beVisibleAssertion)
  }

  valueOnToolTipVisible() {
    cy.get(createPatternPageLocators.valueOnDropDown).first().trigger('mouseover')
  }

  clearButtonClick() {
    cy.get(createPatternPageLocators.clearButton).click()
  }


  valueOnDropDownNotVisible() {
    cy.get(createPatternPageLocators.valueOnDropDown).first().should(assertionConstants.notContainAssertion, 'EventLog')
  }

  testDataModelClick() {
    cy.get(createPatternPageLocators.testDataModel).click()
  }

  noRecordsTextVisible() {
    cy.contains(noRecordsText).should(assertionConstants.beVisibleAssertion)
  }

  valueOnDropDownWithMultiSelectVisible() {
    cy.get(createPatternPageLocators.valueOnDropDown).first().should(assertionConstants.containAssertion, 'Test, SystemParameters, EventLog').and(assertionConstants.beVisibleAssertion)
  }

  filterOptionInDropDownType() {
    cy.get(createPatternPageLocators.filterOptionInDropDown).type('EventLog')
  }

  eventLogDataModelInDropDownVisible() {
    cy.contains(eventLogDataModel).should(assertionConstants.beVisibleAssertion)
  }

  nameFilterSearchIconDisabled() {
    cy.get(createPatternPageLocators.searchButton).eq(1).should(assertionConstants.notBeEnabledAssertion)
  }

  descriptionFilterSearchIconDisabled() {
    cy.get(createPatternPageLocators.searchButton).eq(2).should(assertionConstants.notBeEnabledAssertion)
  }

  nameFilterTextBoxType() {
    cy.get(createPatternPageLocators.coloumLevelNameFilter).type('motor')
  }

  descriptionFilterTextBoxType() {
    cy.get(createPatternPageLocators.coloumLevelDecriptionFilter).type('detector')
  }

  descriptionFilterSearchIconClick() {
    cy.get(createPatternPageLocators.searchButton).eq(2).click()
  }

  nameFilterSearchIconEnabled() {
    cy.get(createPatternPageLocators.searchButton).eq(1).should(assertionConstants.notBeDisabledAssertion)
  }

  descriptionFilterSearchIconEnabled() {
    cy.get(createPatternPageLocators.searchButton).eq(2).should(assertionConstants.notBeDisabledAssertion)
  }

  commonSearchTextBoxClick() {
    cy.get(createPatternPageLocators.commonSearchTextBox).last().click({ force: true })
  }

  nameOptionUnderCommonSearchClick() {
    cy.get(createPatternPageLocators.Operator).eq(5).click()
  }

  allOptionUnderCommonSearchClick() {
    cy.get(patternTypeDropdown).eq(0).click()
  }

  commonSearchTextBoxNameSelectedClick() {
    cy.get(createPatternPageLocators.commonSearchTextBoxNameSelected).eq(5).click()
  }

  commonSearchBoxdetectorType() {
    cy.get(createPatternPageLocators.commonSearchBox).clear().type('detector')
  }

  entriesPerPageTextVisible() {
    cy.contains(entriesPerPageText).should(assertionConstants.beVisibleAssertion)
  }

  pageCountVisible() {
    cy.get(createPatternPageLocators.pageCount).should(assertionConstants.containAssertion, 'Showing 1 of ').and(assertionConstants.beVisibleAssertion)
  }

  recordCountVisible() {
    cy.get(createPatternPageLocators.recordCount).should(assertionConstants.containAssertion, recordsFoundText).and(assertionConstants.beVisibleAssertion)
  }

  nameFilterSearchIconClick() {
    cy.get(createPatternPageLocators.searchButton).eq(1).click()
  }

  crossMarkAtKnowledgeNameClick() {
    cy.get(createPatternPageLocators.crosssIcon).eq(5).click()
  }

  nameFilterTextBoxWithoutText() {
    cy.get(createPatternPageLocators.coloumLevelNameFilter).should(assertionConstants.notContainAssertion, 'motor')
  }

  crossMarkAtKnowledgeNamenotExist() {
    cy.get(createPatternPageLocators.crosssIcon).eq(3).should(assertionConstants.notBeDisabledAssertion)
  }

  crosssIconAtNameFilterVisible() {
    cy.get(createPatternPageLocators.crosssIcon).eq(5).should(assertionConstants.beVisibleAssertion)
  }

  crosssIconAtDescriptionFilterVisible() {
    cy.get(createPatternPageLocators.crosssIcon).eq(6).should(assertionConstants.beVisibleAssertion)
  }

  attributeDropDownOptionsInCommonSearchClick() {
    cy.get(createPatternPageLocators.valueForSecondConditionInSecondEvent).eq(1).click()
  }

  conditionDropDownOptionsInCommonSearchClick() {
    cy.get(createPatternPageLocators.valueForSecondConditionInSecondEvent).eq(2).click()
  }

  commonSearchBoxMotorType() {
    cy.get(createPatternPageLocators.commonSearchBox).clear().type('motor')
  }

  dataModelDropDownOptionsInCommonSearchClick() {
    cy.get(createPatternPageLocators.valueForSecondConditionInSecondEvent).eq(3).click()
  }

  commonSearchBoxEventLogType() {
    cy.get(createPatternPageLocators.commonSearchBox).clear().type('EventLog')
  }

  descriptionDropDownOptionsInCommonSearchClick() {
    cy.get(createPatternPageLocators.valueForSecondConditionInSecondEvent).eq(4).click()
  }

  tagsDropDownOptionsInCommonSearchClick() {
    cy.get(createPatternPageLocators.valueForSecondConditionInSecondEvent).eq(6).click()
  }

  commonSearchBoxDicomType() {
    cy.get(createPatternPageLocators.commonSearchBox).clear().type('dicom')
  }

  tagsDropdownClick() {
    cy.get(createPatternPageLocators.tagsDropdown).last().click()
  }

  collimeterOptionClick() {
    cy.get(createPatternPageLocators.collimeterOption).click()
  }

  applyButtonInTagsDropdownClick() {
    cy.get(createPatternPageLocators.applyButtonInTagsDropdown).click()
  }

  commonSearchBoxErrorType() {
    cy.get(createPatternPageLocators.commonSearchBox).clear().type('1')
  }

  doseMeasurementOptionClick() {
    cy.get(createPatternPageLocators.doseMeasurementOption).click()
  }

  eventLogDataModelInColumnLevelFilterClick() {
    cy.get(createPatternPageLocators.eventLogDataModelInColumnLevelFilter).scrollIntoView().click()
  }

  dropDownOptionUnderAddConditionClick() {
    return cy.get(createPatternPageLocators.dropDownOptionUnderAddCondition).click({ force: true })
  }


  message() {
    return cy.contains(draftSavedText).should(assertionConstants.beVisibleAssertion)
  }

  showAllCheckBoxUnchecked() {
    return cy.get(createPatternPageLocators.checkBox).should(assertionConstants.notBeCheckedAssertion)
  }

  descriptionOptionUnderCommonSearchClick() {
    return cy.get(createPatternPageLocators.dropDownOptions).eq(4).click()
  }

  tenEntriesPerPageDropDownText() {
    cy.get(createPatternPageLocators.entriesPerPageDropDown).find('span').should(assertionConstants.haveTextAssertion, '10').and(assertionConstants.beVisibleAssertion)
  }

  cloneOptionInPatternDetailClick() {
    cy.contains(cloneOptionInPatternDetail).click()
  }

  firstPatternClick() {
    cy.get(createPatternPageLocators.firstPatternClick).eq(0).find('td').eq(1).find('span').first().invoke('text').then((el) => {
      cy.contains(el).dblclick()
    })
  }

  entriesPerPageDropDownClick() {
    cy.get(createPatternPageLocators.entriesPerPageDropDown).click({ force: true })
  }

  patternTwoClick() {
    cy.get(createPatternPageLocators.availablePatternsList).last().find('tr').eq(1).find('td').first().click()
  }

  firstOperatorInAttributeOneEventOneOperatorsClick() {
    cy.get(createPatternPageLocators.attributeOneEventOneOperators).eq(9).click()
  }

  firstOperatorInAttributeTwoEventOneOperatorsClick() {
    cy.get(createPatternPageLocators.attributeOneEventOneOperators).eq(10).scrollIntoView().click()
  }

  firstOperatorInAttributeTwoEventOneOperatorsInEventTwoClick() {
    cy.get(createPatternPageLocators.attributeOneEventOneOperators).eq(8).click()
  }

  patternNameDetailsOfUserOne() {
    cy.get(createPatternPageLocators.importDataModelDetailInCreatePatternPage).eq(0).invoke('text').then((patternNameValue) => {
      patternAndDataModelDetailsArrey.push(patternNameValue)
      cy.log(patternAndDataModelDetailsArrey)
    })
  }

  importedDataModelDetailsOfUserOne() {
    cy.get(createPatternPageLocators.importDataModelDetailInCreatePatternPage).eq(1).invoke('text').then((dataModelValue) => {
      patternAndDataModelDetailsArrey.push(dataModelValue)
      cy.log(patternAndDataModelDetailsArrey)
    })
  }

  addedConditionDetailsOfUserOne() {
    cy.get(createPatternPageLocators.importDataModelDetailInCreatePatternPage).eq(2).invoke('text').then((addedConditionValue) => {
      patternAndDataModelDetailsArrey.push(addedConditionValue)
      cy.log(patternAndDataModelDetailsArrey)
    })
  }

  deletePattern() {
    cy.get("section[id='" + patternNames[0] + "'] > #nav-dropdown-btn > .ng-star-inserted > #Layer_1")
      .click({ force: true })
  }

  deleteSecondPattern() {
    cy.get("section[id='" + patternNames[1] + "'] > #nav-dropdown-btn > .ng-star-inserted > #Layer_1")
      .click({ force: true })
  }

  operatorDropdownAtEventAndConditionForConditionFourClick() {
    cy.get(createPatternPageLocators.operatorDropdownAtEventAndCondition).eq(4).click()
  }

  groupedAllEventsNotExist() {
    cy.get(createPatternPageLocators.groupedEvents).should(assertionConstants.notExistsAssertion)
  }

  patternThreeClick() {
    cy.get(createPatternPageLocators.availablePatternsList).last().find('tr').eq(2).find('td').first().click()
  }

  operatorDropdownAtEventAndConditionBetweenEventTwoAndThreeForRulePattenClick() {
    cy.get(createPatternPageLocators.operatorDropdownAtEventAndCondition).eq(8).click()
  }

  eventNameUnderEventVisible() {
    cy.contains(eventNameUnderEvent).should(assertionConstants.beVisibleAssertion)
  }

  operatorOptionAboveCopiedEventForEventTwoForRulePatternClick() {
    cy.get(createPatternPageLocators.operatorDropdownAtEventAndCondition).eq(8).click()
  }
  patternStateDropdownClick() {
    cy.get(createPatternPageLocators.valueOnDropDown).eq(0).click()
  }

  publishedOptionClick() {
    cy.get(createPatternPageLocators.publishedOption).click()
  }

  tenRecordsPerPgae() {
    cy.get(createPatternPageLocators.firstKnowledge).should(assertionConstants.havelengthAssertion, '10')
  }


  entriesPerPageOptionsVerification() {
    cy.get(createPatternPageLocators.valueForSecondConditionInSecondEvent).eq(0).should(assertionConstants.containAssertion, '5').and(assertionConstants.beVisibleAssertion)
    cy.get(createPatternPageLocators.valueForSecondConditionInSecondEvent).eq(1).should(assertionConstants.containAssertion, '10').and(assertionConstants.beVisibleAssertion)
    cy.get(createPatternPageLocators.valueForSecondConditionInSecondEvent).eq(2).should(assertionConstants.containAssertion, '20').and(assertionConstants.beVisibleAssertion)
    cy.get(createPatternPageLocators.valueForSecondConditionInSecondEvent).eq(3).should(assertionConstants.containAssertion, '50').and(assertionConstants.beVisibleAssertion)
    cy.get(createPatternPageLocators.valueForSecondConditionInSecondEvent).eq(4).should(assertionConstants.containAssertion, '100').and(assertionConstants.beVisibleAssertion)

  }

  fiveEntriesPerPageOptionClick() {
    cy.get(createPatternPageLocators.valueForSecondConditionInSecondEvent).eq(0).click()
  }

  fiveRecordsPerPgae() {
    cy.get(createPatternPageLocators.firstKnowledge).should(assertionConstants.havelengthAssertion, '5')
  }

  currentPageOfTotalPageText() {
    cy.get(createPatternPageLocators.pageCount).should(assertionConstants.notHaveTextAssertion, defaultCurrrentPageOfTotalPageText)
  }

  searchByKeywordOptionType() {
    cy.get(createPatternPageLocators.searchByKeywordOption).type('detector')
  }

  searchIconClicked() {
    cy.get(createPatternPageLocators.searchIcon).first().click()
  }

  nameFilterType() {
    cy.get(createPatternPageLocators.coloumLevelNameFilter).type('motor')
  }

  searchIconOfNameFilterClick() {
    cy.get(createPatternPageLocators.searchIcon).eq(1).click()
  }

  arrowToNevigateToNextpageClick() {
    cy.get(createPatternPageLocators.arrowToNevigateToNextpage).click({ force: true })
  }

  importConditionPopUpNotExist() {
    cy.get(createPatternPageLocators.importConditionPopUp).should(assertionConstants.notExistsAssertion)
  }

  currentPageOfTotalPageTextVisible() {
    cy.get(createPatternPageLocators.pageCount).invoke('text').then((Text) => {
      expect(Text).to.include(' Showing 1 of')
    })
  }

  fifteenEntriesPerPageDropDownText() {
    cy.get(createPatternPageLocators.entriesPerPageDropDown).find('span').should(assertionConstants.haveTextAssertion, '15').and(assertionConstants.beVisibleAssertion)
  }

  fifteenRecordsInPatternDashBoard() {
    cy.get(createPatternPageLocators.recordsInPatternDashBoard).should(assertionConstants.havelengthAssertion, '15')
  }


  entriesPerPageOptionsVerificationInMyPatternDashboard() {
    cy.get(createPatternPageLocators.valueForSecondConditionInSecondEvent).eq(0).should(assertionConstants.containAssertion, '10').and(assertionConstants.beVisibleAssertion)
    cy.get(createPatternPageLocators.valueForSecondConditionInSecondEvent).eq(1).should(assertionConstants.containAssertion, '15').and(assertionConstants.beVisibleAssertion)
    cy.get(createPatternPageLocators.valueForSecondConditionInSecondEvent).eq(2).should(assertionConstants.containAssertion, '20').and(assertionConstants.beVisibleAssertion)
    cy.get(createPatternPageLocators.valueForSecondConditionInSecondEvent).eq(3).should(assertionConstants.containAssertion, '50').and(assertionConstants.beVisibleAssertion)
    cy.get(createPatternPageLocators.valueForSecondConditionInSecondEvent).eq(4).should(assertionConstants.containAssertion, '100').and(assertionConstants.beVisibleAssertion)
    cy.get(createPatternPageLocators.valueForSecondConditionInSecondEvent).eq(5).should(assertionConstants.containAssertion, '500').and(assertionConstants.beVisibleAssertion)
  }

  tenEntriesPerPageOptionInDashBoardClick() {
    cy.get(createPatternPageLocators.valueForSecondConditionInSecondEvent).eq(0).click()
  }

  tenRecordsInPatternDashBoard() {
    cy.get(createPatternPageLocators.recordsInPatternDashBoard).should(assertionConstants.havelengthAssertion, '10')
  }

  currentPageOfTotalPageTextInDashBoard() {
    cy.get(createPatternPageLocators.pageCount).should(assertionConstants.notHaveTextAssertion, defaultCurrentPageOfTotalPageTextInPatternDashBoard)
  }

  patternNameSearchOptionInDashBoardType() {
    cy.get(createPatternPageLocators.coloumLevelNameFilter).type('motor')
  }



  screwsRemovedFromAddPartPopUp() {
    cy.get(createPatternPageLocators.confirmationPopUp).should(assertionConstants.notContainAssertion, 'screws')
  }

  descriptionFiledTextBoxType() {
    cy.get(createPatternPageLocators.descriptionFiledTextBox).type('KnowledgeWithCause')
  }


  PartsIconVisible() {
    cy.get(createPatternPageLocators.PartsIcon).should(assertionConstants.beVisibleAssertion)
  }


  secondRowDescriptionTextBoxVisible() {
    cy.get(createPatternPageLocators.descriptionTextBox).last().should(assertionConstants.haveAttributeAssertion, 'placeholder', "Part Description").and(assertionConstants.beVisibleAssertion)
  }

  secondTwelveNCTextBoxType() {
    cy.get(createPatternPageLocators.twelveNCTextBox).last().type('spanner')
  }

  secondDescriptionTextBoxClick() {
    cy.get(createPatternPageLocators.descriptionTextBox).last().click()
  }

  secondTwelveNCTextBoxInRedColor() {
    cy.get(createPatternPageLocators.twelveNCTextBox).last().should(assertionConstants.haveAttributeAssertion, 'class', "pt-input ng-dirty ng-touched ng-invalid")
  }

  redColorInfoIconWithValidationMessageVisible() {
    cy.get(createPatternPageLocators.redColorInfoIcon).first().should(assertionConstants.beVisibleAssertion)
  }

  ValidationMessageForDuplicateNameVisible() {
    cy.contains(createPatternPageLocators.ValidationMessageForDuplicateName).should(assertionConstants.beVisibleAssertion)
  }

  secondTwelveNCTextBoxCleared() {
    cy.get(createPatternPageLocators.twelveNCTextBox).last().clear()
  }

  addPlusIconToAddRoClick() {
    cy.get(createPatternPageLocators.addConditionButton).last().click()
  }

  removeXIconEnabled() {
    cy.get(createPatternPageLocators.crossMarkAtConditionLevel).should(assertionConstants.notBeDisabledAssertion)
  }

  secondRowtwelveNCTextBoxForType() {
    cy.get(createPatternPageLocators.twelveNCTextBox).eq(1).type('Motor')
  }

  thirdRowTwelveNCTextBoxForType() {
    cy.get(createPatternPageLocators.twelveNCTextBox).eq(2).type('screws')
  }

  fourthRowTwelveNCTextBoxForType() {
    cy.get(createPatternPageLocators.twelveNCTextBox).eq(3).type('bolts')
  }

  secondRowDescriptionTextBoxType() {
    cy.get(createPatternPageLocators.descriptionTextBox).eq(2).type('Switches')
  }

  thirdRowDescriptionTextBoxType() {
    cy.get(createPatternPageLocators.descriptionTextBox).eq(3).type('PowerSupply')
  }

  fourthRowDescriptionTextBoxType() {
    cy.get(createPatternPageLocators.descriptionTextBox).eq(4).type('CanNode')
  }


  eventWithConditionVisible() {
    cy.get(createPatternPageLocators.autoGeneratedFirstEvent).should(assertionConstants.beVisibleAssertion)
  }

  selectedAttributeVisible() {
    cy.contains(selectedAttribute).should(assertionConstants.beVisibleAssertion)
  }

  EventOneEventLevelOperatorDropDownClick() {
    cy.get(createPatternPageLocators.mainOperatorDropdownArrowUnderTesttwo).eq(0).click()
  }

  noneOperatorVisible() {
    cy.get(createPatternPageLocators.valueForSecondConditionInSecondEvent).eq(0).should(assertionConstants.containAssertion, '- None -').and(assertionConstants.beVisibleAssertion)
  }

  notOperatorVisible() {
    cy.get(createPatternPageLocators.valueForSecondConditionInSecondEvent).eq(1).should(assertionConstants.containAssertion, 'NOT').and(assertionConstants.beVisibleAssertion)
  }

  EventOneConditionOneOperatorDropDownClick() {
    cy.get(createPatternPageLocators.mainOperatorDropdownArrowUnderTesttwo).eq(1).click()
  }
  operatorDropDownBetweenAttrAndValueForEventOneClick() {
    cy.get(createPatternPageLocators.operatorForEventOne).first().click()
  }

  equalToOperatorsInOperatorDropDownVisible() {
    cy.get(createPatternPageLocators.Operator).eq(0).should(assertionConstants.beVisibleAssertion)
  }

  notEqualToOperatorsInOperatorDropDownVisible() {
    cy.get(createPatternPageLocators.Operator).eq(1).should(assertionConstants.beVisibleAssertion)
  }

  lengthOperatorsInOperatorDropDownVisible() {
    cy.get(createPatternPageLocators.Operator).eq(3).should(assertionConstants.beVisibleAssertion)
  }

  matchesOperatorsInOperatorDropDownVisible() {
    cy.get(createPatternPageLocators.Operator).eq(4).should(assertionConstants.beVisibleAssertion)
  }

  notMatchesOperatorsInOperatorDropDownVisible() {
    cy.get(createPatternPageLocators.Operator).eq(5).should(assertionConstants.beVisibleAssertion)
  }

  soundsLikeOperatorsInOperatorDropDownVisible() {
    cy.get(createPatternPageLocators.Operator).eq(6).should(assertionConstants.beVisibleAssertion)
  }

  endsWithOperatorsInOperatorDropDownVisible() {
    cy.get(createPatternPageLocators.Operator).last().should(assertionConstants.beVisibleAssertion)
  }

  eventOneConditionTwoOperatorDropDownClick() {
    cy.get(createPatternPageLocators.mainOperatorDropdownArrowUnderTesttwo).eq(2).click()
  }

  andAndNotOrOrNotOperatosUnderDropdownVisible() {
    cy.get(createPatternPageLocators.valueForSecondConditionInSecondEvent).eq(0).should(assertionConstants.beVisibleAssertion)
    cy.get(createPatternPageLocators.valueForSecondConditionInSecondEvent).eq(1).should(assertionConstants.beVisibleAssertion)
    cy.get(createPatternPageLocators.valueForSecondConditionInSecondEvent).eq(2).should(assertionConstants.beVisibleAssertion)
    cy.get(createPatternPageLocators.valueForSecondConditionInSecondEvent).eq(3).should(assertionConstants.beVisibleAssertion)
  }
  secondEventWithConditionVisible() {
    cy.get(createPatternPageLocators.autoGeneratedFirstEvent).last().should(assertionConstants.beVisibleAssertion)
  }

  operatorDropDownBetweenTwoEventsClick() {
    cy.get(createPatternPageLocators.mainOperatorDropdownArrowUnderTesttwo).last().click()
  }

  indexAttributesOptionsClick() {
    cy.contains(indexAttributesOptions).click()
  }

  operatorDropDownBetweenAttrAndValueForEventThreeClick() {
    cy.get(createPatternPageLocators.operatorForEventOne).eq(3).click()
  }

  greaterThanOperatorsInOperatorDropDownVisible() {
    cy.get(createPatternPageLocators.Operator).eq(2).should(assertionConstants.beVisibleAssertion)
  }

  lessThanOperatorsInOperatorDropDownVisible() {
    cy.get(createPatternPageLocators.Operator).eq(3).should(assertionConstants.beVisibleAssertion)
  }

  EventThreeConditionOneOperatorDropDownClick() {
    cy.get(createPatternPageLocators.mainOperatorDropdownArrowUnderTesttwo).eq(6).click()
  }

  EventThreeConditionTwoOperatorDropDownClick() {
    cy.get(createPatternPageLocators.mainOperatorDropdownArrowUnderTesttwo).eq(7).click({ force: true })
  }

  EventThreeConditionThreeOperatorDropDownClick() {
    cy.get(createPatternPageLocators.mainOperatorDropdownArrowUnderTesttwo).last().click({ force: true })
  }

  operatorDropDownBetweenEventTWoAndThreeClick() {
    cy.get(createPatternPageLocators.mainOperatorDropdownArrowUnderTesttwo).eq(5).click()
  }

  attributeDropDownForSecondImportedPatternClick() {
    cy.get(createPatternPageLocators.addedExpressionForEvent).last().click()
  }

  eventFiveConditionOneOperatorDropDownClick() {
    cy.get(createPatternPageLocators.mainOperatorDropdownArrowUnderTesttwo).last().click()
  }

  eventFiveConditionTwoOperatorDropDownClick() {
    cy.get(createPatternPageLocators.mainOperatorDropdownArrowUnderTesttwo).last().click({ force: true })
  }

  eventFiveConditionThreeOperatorDropDownClick() {
    cy.get(createPatternPageLocators.mainOperatorDropdownArrowUnderTesttwo).eq(17).click({ force: true })
  }

  operatorDropDownBetweenEventFourAndFiveClick() {
    cy.get(createPatternPageLocators.mainOperatorDropdownArrowUnderTesttwo).eq(14).scrollTo('bottom').click({ force: true })
  }

  componentAttributeClick() {
    cy.get(createPatternPageLocators.attributeForSecondCondition).eq(1).click()
  }

  addExpressionPopUpFirstOperatorDropDownClick() {
    cy.get(createPatternPageLocators.addExpressionPopUpFirstOperatorDropDown).click()
  }

  absOperatorsInOperatorDropDownVisible() {
    cy.get(createPatternPageLocators.Operator).eq(0).should(assertionConstants.beVisibleAssertion)
  }

  avgOperatorsInOperatorDropDownVisible() {
    cy.get(createPatternPageLocators.Operator).eq(1).should(assertionConstants.beVisibleAssertion)
  }

  maxOperatorsInOperatorDropDownVisible() {
    cy.get(createPatternPageLocators.Operator).eq(2).should(assertionConstants.beVisibleAssertion)
  }

  minOperatorsInOperatorDropDownVisible() {
    cy.get(createPatternPageLocators.Operator).eq(3).should(assertionConstants.beVisibleAssertion)
  }

  modOperatorsInOperatorDropDownVisible() {
    cy.get(createPatternPageLocators.Operator).eq(4).should(assertionConstants.beVisibleAssertion)
  }

  addExpressionPopUpSecondOperatorDropDownClick() {
    cy.get(createPatternPageLocators.operatorForEventOne).last().click()
  }

  starOperatorsInOperatorDropDownVisible() {
    cy.get(createPatternPageLocators.Operator).eq(0).should(assertionConstants.beVisibleAssertion)
  }

  slashOperatorsInOperatorDropDownVisible() {
    cy.get(createPatternPageLocators.Operator).eq(1).should(assertionConstants.beVisibleAssertion)
  }

  percentageOperatorsInOperatorDropDownVisible() {
    cy.get(createPatternPageLocators.Operator).eq(2).should(assertionConstants.beVisibleAssertion)
  }

  plusOperatorsInOperatorDropDownVisible() {
    cy.get(createPatternPageLocators.Operator).eq(3).should(assertionConstants.beVisibleAssertion)
  }

  minusOperatorsInOperatorDropDownVisible() {
    cy.get(createPatternPageLocators.Operator).eq(4).should(assertionConstants.beVisibleAssertion)
  }

  absOperatorsInOperatorDropDownClick() {
    cy.get(createPatternPageLocators.Operator).eq(0).click()
  }

  starOperatorsInOperatorDropDownClick() {
    cy.get(createPatternPageLocators.Operator).eq(0).click()
  }

  greaterThanToOperatorsInOperatorDropDownVisible() {
    cy.get(createPatternPageLocators.Operator).eq(2).should(assertionConstants.beVisibleAssertion)
  }

  lessThanToOperatorsInOperatorDropDownVisible() {
    cy.get(createPatternPageLocators.Operator).eq(3).should(assertionConstants.beVisibleAssertion)
  }

  greaterThanEqualToOperatorsInOperatorDropDownVisible() {
    cy.get(createPatternPageLocators.Operator).eq(4).should(assertionConstants.beVisibleAssertion)
  }

  lessThanEqualToOperatorsInOperatorDropDownVisible() {
    cy.get(createPatternPageLocators.Operator).eq(5).should(assertionConstants.beVisibleAssertion)
  }

  attributeDropDownForFirstImportedPatternClick() {
    cy.get(createPatternPageLocators.addedExpressionForEvent).last().click()
  }

  eventLogThreeOptionUnderAttrOneClick() {
    cy.get(createPatternPageLocators.systemConfigurationDataModelInList).click()
  }

  lineNumberOperatorInEventLogThreeClick() {
    cy.contains(lineNumberOperatorInEventLogThree).click()
  }

  indexOperatorInEventThreeAttrTwoClick() {
    cy.contains(indexOperatorInEventThreeAttrTwo).click({ force: true })
  }

  patternNameDetailsOfUserOneNotExist() {
    cy.get(createPatternPageLocators.patternNameTextBox).should(assertionConstants.notContainAssertion, arr[0])
  }

  importedDataModelDetailsOfUserOneNotExist() {
    cy.get(createPatternPageLocators.importedDataModelSection).should(assertionConstants.notContainAssertion, arr[1])
  }

  addedConditionDetailsOfUserOneNotExist() {
    cy.get(createPatternPageLocators.addConditionSection).should(assertionConstants.notContainAssertion, arr[2])
  }

  nextButtonOnCreatePageEnabled() {
    cy.get(createPatternPageLocators.nextButtonOnCreatePage).should(assertionConstants.notBeDisabledAssertion)
  }

  viewStageVisibleAndHighlighted() {
    cy.get(createPatternPageLocators.viewStage).should(assertionConstants.containAssertion, ' View ').and(assertionConstants.beVisibleAssertion).and(assertionConstants.haveAttributeAssertion, 'class', ngStarInsertedActiveClass)
  }

  createStageWithTickMark() {
    cy.get(createPatternPageLocators.createStage).should(assertionConstants.containAssertion, ' Create ').and(assertionConstants.beVisibleAssertion).and(assertionConstants.haveAttributeAssertion, 'class', 'ng-star-inserted completed')
  }

  symptomOneTextInViewStepVisible() {
    cy.contains(knowledgeSymptomDetails).should(assertionConstants.beVisibleAssertion)
  }

  causeOneTextInViewStepVisible() {
    cy.contains(knowledgeCauseDetails).should(assertionConstants.beVisibleAssertion)
  }

  solutionOnetextInViewStepVisible() {
    cy.contains(knowledgeSolutionnDetails).should(assertionConstants.beVisibleAssertion)
  }

  fullScreenViewButtonClick() {
    cy.get(createPatternPageLocators.fullScreenViewButton).click()
  }

  knowledgeDetailsInFulllScreen() {
    cy.get(createPatternPageLocators.knowledgeDetailsInFulllScreen).should(assertionConstants.haveAttributeAssertion, 'class', 'enable-fullscreen')
  }

  userOnCreateSection() {
    cy.get(createPatternPageLocators.createStage).should(assertionConstants.containAssertion, ' Create ').and(assertionConstants.beVisibleAssertion).and(assertionConstants.haveAttributeAssertion, 'class', ngStarInsertedActiveClass)
  }

  knowledgeDescriptionDetailsExpanded() {
    cy.contains(knowledgeDescriptionDetails).should(assertionConstants.beVisibleAssertion)
  }

  knowledgeSymptomDetailsExpanded() {
    cy.contains(knowledgeSymptomDetails).should(assertionConstants.beVisibleAssertion)
  }

  knowledgeCausesAndSolutionsknowledgeCauseDetailsExpanded() {
    cy.contains(knowledgeCauseDetails).should(assertionConstants.beVisibleAssertion)
  }

  knowledgeTagsDetailsExpanded() {
    cy.contains(knowledgeTagsDetails).should(assertionConstants.beVisibleAssertion)
  }

  KnowledgeDescriptionDetailsCollapseAndExpandButtonClick() {
    cy.get(createPatternPageLocators.expandCollapseIconAtgroupLevel).first().click()
  }

  versionIndraftStageVisible() {
    cy.get(createPatternPageLocators.versionIndraftStage).should(assertionConstants.haveTextAssertion, 'Draft').and(assertionConstants.beVisibleAssertion)
  }

  versionIndraftStageNotExist() {
    cy.get(createPatternPageLocators.versionIndraftStage).should(assertionConstants.notExistsAssertion)
  }


  addActionWithAsteriskVisible() {
    cy.get(createPatternPageLocators.addAction).eq(5).children().last().should(assertionConstants.haveTextAssertion, '*').and(assertionConstants.beVisibleAssertion)
  }

  plusIconUnderAddActionVisible() {
    cy.get(createPatternPageLocators.plusIconUnderAddAction).should(assertionConstants.beVisibleAssertion)
  }

  plusIconUnderAddActionClick() {
    cy.get(createPatternPageLocators.plusIconUnderAddAction).click()
  }

  raiseAlertoptionVisible() {
    cy.get(createPatternPageLocators.attribute).children().eq(0).should(assertionConstants.containAssertion, 'Raise Alert').should(assertionConstants.beVisibleAssertion)
  }

  insertAlertOptionVisible() {
    cy.get(createPatternPageLocators.testTwoOptionUnderAttributeTwoDropdownOfTestTwo).should(assertionConstants.containAssertion, addActionValue).should(assertionConstants.beVisibleAssertion)
  }

  suppressAlertOptionVisible() {
    cy.get(createPatternPageLocators.systemConfigurationDataModelInList).should(assertionConstants.containAssertion, 'Suppress Alert').should(assertionConstants.beVisibleAssertion)
  }

  raiseAlertSelectedOptionAsATagVisible() {
    cy.get(createPatternPageLocators.savedEvent).last().should(assertionConstants.containAssertion, 'Raise Alert').and(assertionConstants.beVisibleAssertion)
  }

  insertAlertOptionClick() {
    cy.get(createPatternPageLocators.testTwoOptionUnderAttributeTwoDropdownOfTestTwo).click()
  }

  insertAlertSelectedOptionAsATagVisible() {
    cy.get(createPatternPageLocators.savedEvent).last().should(assertionConstants.containAssertion, addActionValue).and(assertionConstants.beVisibleAssertion)
  }

  crossMarkOfTagClick() {
    cy.get(createPatternPageLocators.crosssMarkOfdataModel).last().click()
  }

  addActionValueNotExist() {
    cy.get(addActionValue).should(assertionConstants.notExistsAssertion)
  }


  groupConditionOptionVisibleAndDisabled() {
    cy.get(createPatternPageLocators.groupUngroupConditionOption).first().should(assertionConstants.haveTextAssertion, ' Group ').and(assertionConstants.beVisibleAssertion).and(assertionConstants.notBeEnabledAssertion)
  }

  crossMarkAtEventOnelevelEnabled() {
    cy.get(createPatternPageLocators.crossMark).first().should(assertionConstants.notBeDisabledAssertion)
  }

  addConditionButtonAtConditionTwoClick() {
    cy.get(createPatternPageLocators.addConditionButton).eq(1).click()
  }

  attributeDropdownAtConditionThreeClick() {
    cy.get(createPatternPageLocators.addedExpressionForEvent).eq(2).click()
  }

  operatorDropdownBetweenAttrAndValueConditionThreeClick() {
    cy.get(createPatternPageLocators.operatorForEventOne).eq(2).click({ force: true })
  }

  valueInputBoxForConditionThreeType() {
    cy.get(createPatternPageLocators.valueWaterMark).eq(2).type(3)
  }

  addConditionButtonAtConditionThreeClick() {
    cy.get(createPatternPageLocators.addConditionButton).eq(2).click()
  }

  attributeDropdownAtConditionFourClick() {
    cy.get(createPatternPageLocators.addedExpressionForEvent).eq(3).click()
  }

  operatorDropdownBetweenAttrAndValueConditionFourClick() {
    cy.get(createPatternPageLocators.operatorForEventOne).eq(3).click()
  }

  valueInputBoxForConditionFourType() {
    cy.get(createPatternPageLocators.valueWaterMark).eq(3).type(4)
  }

  addConditionButtonAtConditionFourClick() {
    cy.get(createPatternPageLocators.addConditionButton).eq(3).click()
  }

  attributeDropdownAtConditionFiveClick() {
    cy.get(createPatternPageLocators.addedExpressionForEvent).eq(4).click()
  }

  operatorDropdownBetweenAttrAndValueConditionFiveClick() {
    cy.get(createPatternPageLocators.operatorForEventOne).eq(4).click()
  }

  valueInputBoxForConditionFiveType() {
    cy.get(createPatternPageLocators.valueWaterMark).eq(4).type(5)
  }

  operatorSelectionForConditions() {
    cy.get(createPatternPageLocators.operatorDropdownAtEventAndCondition).eq(2).click()
    cy.get(createPatternPageLocators.Operator).eq(2).click()
    cy.get(createPatternPageLocators.operatorDropdownAtEventAndCondition).eq(3).click()
    cy.get(createPatternPageLocators.Operator).eq(0).click()
    cy.get(createPatternPageLocators.operatorDropdownAtEventAndCondition).eq(4).click()
    cy.get(createPatternPageLocators.Operator).eq(0).click()
  }

  operatorDropdownAtEventAndConditionForConditionTwoClick() {
    cy.get(createPatternPageLocators.operatorDropdownAtEventAndCondition).eq(2).click()
  }

  operatorDropdownAtEventAndConditionForConditionThreeClick() {
    cy.get(createPatternPageLocators.operatorDropdownAtEventAndCondition).eq(3).click()
  }

  orOperatorOptionsUnderDropdownForConditionTwoClick() {
    cy.get(createPatternPageLocators.Operator).eq(2).click()
  }

  andOperatorOptionsUnderDropdownForConditionThreeClick() {
    cy.get(createPatternPageLocators.Operator).eq(0).click()
  }


  andOperatorOptionsUnderDropdownForConditionFourClick() {
    cy.get(createPatternPageLocators.Operator).eq(0).click()
  }

  logicalExpressionUnderEventVisible() {
    cy.get(createPatternPageLocators.AutoGeneratedFirstCondition).eq(0).invoke('text').then((expression) => {
      logicalExpressionUnderEvents.push(expression)
      cy.log(logicalExpressionUnderEvents)
      expect(expression).to.exist
    })
  }

  checkBoxAtSecondConditionClick() {
    cy.get(createPatternPageLocators.checkBox).eq(2).click()
  }

  groupConditionOptionDisabled() {
    cy.get(createPatternPageLocators.groupUngroupConditionOption).first().should(assertionConstants.notBeEnabledAssertion)
  }

  checkBoxAtFirstConditionInEventTwoClick() {
    cy.get(createPatternPageLocators.checkBox).last().click()
  }

  checkBoxAtThirdConditionClick() {
    cy.get(createPatternPageLocators.checkBox).eq(3).click()
  }

  groupConditionOptionEnabled() {
    cy.get(createPatternPageLocators.groupUngroupConditionOption).first().should(assertionConstants.notBeDisabledAssertion)
  }

  groupConditionOptionClick() {
    cy.get(createPatternPageLocators.groupUngroupConditionOption).first().click()
  }


  groupedConditionsVisible() {
    cy.get(createPatternPageLocators.groupedConditions).should(assertionConstants.beVisibleAssertion)
  }

  ungroupConditionOptionVisibleAndEnabled() {
    cy.get(createPatternPageLocators.groupUngroupConditionOption).eq(1).should(assertionConstants.haveTextAssertion, 'Ungroup').and(assertionConstants.beVisibleAssertion).and(assertionConstants.notBeDisabledAssertion)
  }

  crossMarkAtGroupedConditionlevelEnabled() {
    cy.get(createPatternPageLocators.crossMarkAtConditionLevel).eq(1).should(assertionConstants.notBeDisabledAssertion)
  }

  operatorDropdownAtEventAndConditionForGroupedConditionClick() {
    cy.get(createPatternPageLocators.operatorDropdownAtEventAndCondition).eq(3).click()
  }

  ungroupConditionOptionClick() {
    cy.get(createPatternPageLocators.groupUngroupConditionOption).eq(1).click()
  }

  updatedlogicalExpressionUnderEventAfterUngroupingVisible() {
    cy.get(createPatternPageLocators.AutoGeneratedFirstCondition).eq(0).invoke('text').then((updatedexpression) => {
      expect(updatedexpression).to.exist
      expect(updatedexpression).to.not.equal(secondArreyOfLoogicalExpression[0])
    })
  }

  conditionsWithCheckBoxVisible() {
    cy.get(createPatternPageLocators.conditionsWithCheckBox).should(assertionConstants.beVisibleAssertion)
  }

  removeConditionButtonForConditionFourClick() {
    cy.get(createPatternPageLocators.crossMarkAtConditionLevel).eq(3).click()
  }

  conditionFourNotExist() {
    cy.get(createPatternPageLocators.autoGeneratedFirstEvent).first().should(assertionConstants.notContainAssertion, ConditionFourText)
  }

  updatedLogicalExpressionUnderEventAfterRemovingFourthCondition() {
    cy.get(createPatternPageLocators.AutoGeneratedFirstCondition).first().should(assertionConstants.notContainAssertion, 'C4')
  }

  crossMarkAtGroupedConditionlevelClick() {
    cy.get(createPatternPageLocators.eventOneRemoveOption).eq(1).click()
  }

  conditionTwoNotExist() {
    cy.get(createPatternPageLocators.autoGeneratedFirstEvent).first().should(assertionConstants.notContainAssertion, ConditionTwoText)
  }

  conditionThreeNotExist() {
    cy.get(createPatternPageLocators.autoGeneratedFirstEvent).first().should(assertionConstants.notContainAssertion, ConditionThreeText)
  }

  updatedLogicalExpressionUnderEventAfterRemovingGroupedCondition() {
    cy.get(createPatternPageLocators.AutoGeneratedFirstCondition).first().should(assertionConstants.notContainAssertion, 'C2', 'C3')
  }

  patternInformationOptionClick() {
    cy.contains(createPatternPageLocators.patternInformationOption).click()
  }

  operatorDropdownBetweenAttrAndValueForEventFiveClick() {
    cy.get(createPatternPageLocators.operatorForEventOne).eq(5).click()
  }

  valueInputBoxForEventFiveType() {
    cy.get(createPatternPageLocators.valueWaterMark).eq(5).type(5)
  }

  groupOptionAtEventDisabled() {
    cy.get(createPatternPageLocators.groupOptionAtEvent).should(assertionConstants.notBeEnabledAssertion)
  }

  saveAsRuleOptionDisabled() {
    cy.get(createPatternPageLocators.saveAsRuleOption).should(assertionConstants.notBeEnabledAssertion)
  }

  groupUngroupConditionOptionDisabled() {
    cy.get(createPatternPageLocators.groupUngroupConditionOption).eq(0).should(assertionConstants.notBeEnabledAssertion)
  }

  crossMarkAtConditionLevelEnabled() {
    cy.get(createPatternPageLocators.crossMark).eq(0).should(assertionConstants.notBeDisabledAssertion)
  }


  checkBoxAtConditionOneClick() {
    cy.get(createPatternPageLocators.checkBox).eq(1).click()
  }

  checkBoxAtEventTwoClick() {
    cy.get(createPatternPageLocators.checkBox).eq(3).click()
  }

  groupOptionAtEventEnabled() {
    cy.get(createPatternPageLocators.groupOptionAtEvent).should(assertionConstants.notBeDisabledAssertion)
  }

  groupOptionAtEventClick() {
    cy.get(createPatternPageLocators.groupOptionAtEvent).click({ force: true })
  }

  operatorDropdownAtEventAndConditionBetweenEventOneAndTwoClick() {
    cy.get(createPatternPageLocators.operatorDropdownAtEventAndCondition).eq(3).click()
  }

  orOperatorOptionsUnderDropdownClick() {
    cy.get(createPatternPageLocators.Operator).eq(2).click()
  }

  logicalExpressionAtEventLevelBeforeGrouping() {
    cy.get(createPatternPageLocators.logicalExpressionAtEventLevelForEvents).children().invoke('text').then((expression) => {
      logicalExpressionArrey.push(expression)
      cy.log(logicalExpressionArrey)

    })
  }


  operatorDropdownAtEventAndConditionBetweenEventTwoAndThreeClick() {
    cy.get(createPatternPageLocators.operatorDropdownAtEventAndCondition).eq(6).click()
  }


  operatorDropdownAtEventAndConditionBetweenEventThreeAndFourClick() {
    cy.get(createPatternPageLocators.operatorDropdownAtEventAndCondition).eq(8).click()
  }

  checkBoxAtEventThreeClick() {
    cy.get(createPatternPageLocators.checkBox).eq(4).click()
  }

  checkBoxAtEventFourClick() {
    cy.get(createPatternPageLocators.checkBox).eq(5).click()
  }

  orOperatorOptionsUnderDropdownBetweenEventsClick() {
    cy.get(createPatternPageLocators.Operator).eq(0).click()
  }


  operatorDropdownAtEventAndConditionAtWholeEventClick() {
    cy.get(createPatternPageLocators.operatorDropdownAtEventAndCondition).eq(0).click()
  }

  operatorDropdownAtEventAndConditionAtFirstEventGroupClick() {
    cy.get(createPatternPageLocators.operatorDropdownAtEventAndCondition).eq(1).click()
  }

  operatorDropdownAtEventAndConditionAtSecondEventGroupClick() {
    cy.get(createPatternPageLocators.operatorDropdownAtEventAndCondition).eq(7).click()
  }

  groupedEventsOfEventOneAndTwoVisible() {
    cy.get(createPatternPageLocators.groupedEvents).eq(0).should(assertionConstants.beVisibleAssertion)
  }

  groupedEventsOfEventThreeAndFourVisible() {
    cy.get(createPatternPageLocators.groupedEvents).eq(0).should(assertionConstants.beVisibleAssertion)
  }

  ungroupOptionForGroupedEventsEnebled() {
    cy.get(createPatternPageLocators.ungroupOptionForGroupedEvents).first().should(assertionConstants.notBeDisabledAssertion)
  }

  crossMarkAtGroupedEventsEnabled() {
    cy.get(createPatternPageLocators.crossMarkAtGroupedEvents).should(assertionConstants.notBeDisabledAssertion)
  }

  groupOptionAtGroupedEventDisabled() {
    cy.get(createPatternPageLocators.groupOptionAtEvent).should(assertionConstants.notBeEnabledAssertion)
  }


  checkBoxForConditionsAnEventExist() {
    cy.get(createPatternPageLocators.checkBox).should(assertionConstants.beExistAssertion)
  }

  attributeDropdownsVisible() {
    cy.get(createPatternPageLocators.addedCondtionAttributeDropdown).should(assertionConstants.beVisibleAssertion)
  }

  operatorDropdownAtEventAndConditionVisible() {
    cy.get(createPatternPageLocators.operatorDropdownAtEventAndCondition).should(assertionConstants.beVisibleAssertion)
  }

  operatorsBetweenAttributeAndValueVisible() {
    cy.get(createPatternPageLocators.operatorForEventOne).should(assertionConstants.beVisibleAssertion)
  }

  valueOptionVisible() {
    cy.get(createPatternPageLocators.valueWaterMark).should(assertionConstants.beVisibleAssertion)
  }

  checkBoxForThirdAndFourthGroupedEventClick() {
    cy.get(createPatternPageLocators.checkBox).eq(4).click()
  }

  checkBoxForFifthEventClick() {
    cy.get(createPatternPageLocators.checkBox).eq(7).click()
  }

  ungroupOptionForGroupedEventsClick() {
    cy.get(createPatternPageLocators.ungroupOptionForGroupedEvents).first().click()
  }

  crossMarkOfEventFiveClick() {
    cy.get(createPatternPageLocators.eventOneRemoveOption).last().click()
  }

  popUpTitleVisible() {
    cy.get(createPatternPageLocators.popUpTitle).invoke('text').then((text1) => {
      cy.contains(text1).should(assertionConstants.beVisibleAssertion)
    })
  }

  popUpDialogueVisible() {
    cy.get(createPatternPageLocators.popUpDialogue).invoke('text').then((text1) => {
      cy.contains(text1).should(assertionConstants.beVisibleAssertion)
    })
  }

  lastEventVisible() {
    cy.get(createPatternPageLocators.autoGeneratedEventName).last().should(assertionConstants.haveTextAssertion, ' EventLog5 ').should(assertionConstants.beVisibleAssertion)
  }

  lastEventNotExist() {
    cy.get(createPatternPageLocators.autoGeneratedEventName).last().should(assertionConstants.notHaveTextAssertion, ' EventLog5 ')
  }

  lastEventInRulePatternVisible() {
    cy.get(createPatternPageLocators.autoGeneratedEventName).last().should(assertionConstants.containAssertion, ' EventLog ')
  }

  lastEventInRulePatternNotExist() {
    cy.get(createPatternPageLocators.autoGeneratedEventName).last().should(assertionConstants.haveTextAssertion, ' EventLog5 ').should(assertionConstants.beVisibleAssertion)
  }

  checkBoxAtFirstGroupOfEventsClick() {
    cy.get(createPatternPageLocators.checkBox).first().click()
  }

  checkBoxAtSecondGroupOfEventsClick() {
    cy.get(createPatternPageLocators.checkBox).eq(3).click()
  }

  crossMarkAtGroupedEventsClick() {
    cy.get(createPatternPageLocators.crossMarkAtGroupedEvents).first().click()
  }

  popUpTitleForDeletingAllGroupedEventsVisible() {
    cy.get(createPatternPageLocators.popUpTitle).invoke('text').then((text3) => {
      cy.contains(text3).should(assertionConstants.beVisibleAssertion)
    })
  }

  popUpDialogueForDeletingAllGroupedEventsVisible() {
    cy.get(createPatternPageLocators.popUpDialogue).invoke('text').then((text2) => {
      cy.contains(text2).should(assertionConstants.beVisibleAssertion)
    })
  }

  groupedAllEventsVisible() {
    cy.get(createPatternPageLocators.groupedEvents).should(assertionConstants.beVisibleAssertion)
  }

  groupedAllEventsNotExist() {
    cy.get(createPatternPageLocators.groupedEvents).should(assertionConstants.notExistsAssertion)
  }

  andOperatorOptionsUnderDropdownClick() {
    cy.get(createPatternPageLocators.Operator).eq(0).click()
  }

  operatorDropdownAtEventAndConditionBetweenEventFourAndFiveForRulePattenClick() {
    cy.get(createPatternPageLocators.operatorDropdownAtEventAndCondition).last().click()
  }

  logicalExpressionAtEventLevelBeforeGroupingForRulePattern() {
    cy.get(createPatternPageLocators.logicalExpressionAtEventLevelForEvents).children().invoke('text').then((expression) => {
      logicalExpressionBeforeAndAfterGrouping.push(expression)
      cy.log(logicalExpressionBeforeAndAfterGrouping)

    })
  }


  checkBoxAtEventTwoForRulePatternClick() {
    cy.get(createPatternPageLocators.checkBox).eq(4).click()
  }

  checkBoxAtEventThreeForRulePatternClick() {
    cy.get(createPatternPageLocators.checkBox).eq(8).click()
  }

  checkBoxAtEventFourForRulePatternClick() {
    cy.get(createPatternPageLocators.checkBox).last().click()
  }

  operatorDropdownAtEventAndConditionForSecondGroupEventOneClick() {
    cy.get(createPatternPageLocators.operatorDropdownAtEventAndCondition).eq(11).click()
  }

  checkBoxForThirdAndFourthGroupedEventForRulePatternClick() {
    cy.get(createPatternPageLocators.checkBox).eq(8).click()
  }

  checkBoxAtEventFiveForRulePatternClick() {
    cy.get(createPatternPageLocators.checkBox).last().click()
  }

  logicalExpressionAtEventLevelAfterGroupingGroupedAndUngroupedEventForRulePattern() {
    cy.get(createPatternPageLocators.logicalExpressionAtEventLevelForEvents).children().invoke('text').then((updateexpression) => {
      logicalExpressionBeforeAndAfterGrouping.push(updateexpression)
      cy.log(arr)
      expect(updateexpression).to.exist
    })
  }

  logicalExpressionAtEventLevelAfterUngroupingGroupedAndUngroupedEventForRulePattern() {
    cy.get(createPatternPageLocators.logicalExpressionAtEventLevelForEvents).children().invoke('text').then((updateexpression) => {
      expect(updateexpression).to.exist
      expect(updateexpression).to.not.equal(logicalExpressionBeforeAndAfterGrouping[2])
    })
  }

  conditionRemoveButtonVisibleAndDisabled() {
    cy.get(createPatternPageLocators.crossMarkAtConditionLevel).should(assertionConstants.beVisibleAssertion).and(assertionConstants.notBeEnabledAssertion)
  }

  crossMarkAtEventOneVisible() {
    cy.get(createPatternPageLocators.eventOneRemoveOption).should(assertionConstants.beVisibleAssertion)
  }

  addConditionPlusIconAtC1Click() {
    cy.get(createPatternPageLocators.addConditionButton).first().click()
  }

  secondConditionInFirstEventVisible() {
    cy.wait(2000)
    cy.get(createPatternPageLocators.conditionsName).eq(1).should(assertionConstants.containAssertion, 'C2').and(assertionConstants.beVisibleAssertion)
  }

  sequenceOfConditionAfterClickPplusIconAtC1() {
    cy.get(createPatternPageLocators.conditionsName).eq(0).invoke('text').then((text1) => {
      cy.contains(text1).should(assertionConstants.containAssertion, 'C1')
    })

    cy.get(createPatternPageLocators.conditionsName).eq(1).invoke('text').then((text1) => {
      cy.contains(text1).should(assertionConstants.containAssertion, 'C3')
    })

    cy.get(createPatternPageLocators.conditionsName).eq(2).invoke('text').then((text1) => {
      cy.contains(text1).should(assertionConstants.containAssertion, 'C2')
    })

  }

  addConditionPlusIconAtC2Click() {
    cy.get(createPatternPageLocators.addConditionButton).eq(2).click()
  }

  sequenceOfConditionAfterClickPplusIconAtC2() {
    cy.get(createPatternPageLocators.conditionsName).eq(0).invoke('text').then((text1) => {
      cy.contains(text1).should(assertionConstants.containAssertion, 'C1')
    })

    cy.get(createPatternPageLocators.conditionsName).eq(1).invoke('text').then((text1) => {
      cy.contains(text1).should(assertionConstants.containAssertion, 'C3')
    })

    cy.get(createPatternPageLocators.conditionsName).eq(1).invoke('text').then((text1) => {
      cy.contains(text1).should(assertionConstants.containAssertion, 'C3')
    })

    cy.get(createPatternPageLocators.conditionsName).eq(3).invoke('text').then((text1) => {
      cy.contains(text1).should(assertionConstants.containAssertion, 'C4')
    })

  }

  conditionRemoveButtonAtConditionThreeClick() {
    cy.get(createPatternPageLocators.crossMarkAtConditionLevel).eq(2).click()
  }

  eventContainerWithOutConditionTwo() {
    cy.get(createPatternPageLocators.autoGeneratedFirstEvent).should(assertionConstants.notContainAssertion, 'C2')
  }

  addConditionPlusIconAtC4Click() {
    cy.get(createPatternPageLocators.addConditionButton).eq(2).click()
  }

  sequenceOfConditionAfterClickPplusIconAtC4() {
    cy.get(createPatternPageLocators.conditionsName).eq(0).invoke('text').then((text1) => {
      cy.contains(text1).should(assertionConstants.containAssertion, 'C1')
    })

    cy.get(createPatternPageLocators.conditionsName).eq(1).invoke('text').then((text1) => {
      cy.contains(text1).should(assertionConstants.containAssertion, 'C3')
    })

    cy.get(createPatternPageLocators.conditionsName).eq(2).invoke('text').then((text1) => {
      cy.contains(text1).should(assertionConstants.containAssertion, 'C4')
    })

    cy.get(createPatternPageLocators.conditionsName).eq(3).invoke('text').then((text1) => {
      cy.contains(text1).should(assertionConstants.containAssertion, 'C5')
    })

  }

  logicalExpressionForConditionVisible() {
    cy.get(createPatternPageLocators.AutoGeneratedFirstCondition).children().first().invoke('text').then((logicalexpression) => {
      expect(logicalexpression).to.exist
    })
  }

  crossMarkAtEventOneClick() {
    cy.get(createPatternPageLocators.eventOneRemoveOption).eq(0).click()
  }

  operatorDropdownBetweenAttrAndValueForEventFourClick() {
    cy.get(createPatternPageLocators.operatorForEventOne).eq(3).click()
  }

  valueInputBoxForEventFourType() {
    cy.get(createPatternPageLocators.valueWaterMark).eq(3).type(4)
  }


  checkBoxAtEventTwoToGroupEventClick() {
    cy.get(createPatternPageLocators.checkBox).eq(2).click()
  }

  expandAndCollapseIconAtEventVisible() {
    cy.get(createPatternPageLocators.expandCollapseIconAtgroupLevel).eq(4).should(assertionConstants.beVisibleAssertion)
  }

  expandAndCollapseIconAtEventClick() {
    cy.get(createPatternPageLocators.expandCollapseIconAtgroupLevel).eq(4).click({ force: true })
  }


  conditionTextUnderEventNotVisible() {
    cy.contains(conditionTextUnderEvent).should(assertionConstants.notVisibleAssertion)
  }

  conditionTextUnderEventVisible() {
    cy.contains(conditionTextUnderEvent).should(assertionConstants.beVisibleAssertion)
  }

  operatorOptionAboveCopiedEventForEventOneClick() {
    cy.get(createPatternPageLocators.operatorDropdownAtEventAndCondition).eq(11).click()
  }

  copiedEventFromEventOneExist() {
    cy.get(createPatternPageLocators.copiedEventFromEvents).should(assertionConstants.beExistAssertion)
  }

  copiedEventFromEventOneNotExist() {
    cy.get(createPatternPageLocators.copiedEventFromEvents).should(assertionConstants.notExistsAssertion)
  }

  eventTwoUnderFormVariableClick() {
    cy.get(createPatternPageLocators.dataModel).click()
  }

  operatorOptionAboveCopiedEventForEventTwoClick() {
    cy.get(createPatternPageLocators.operatorDropdownAtEventAndCondition).eq(7).click()
  }

  copiedEventFromEventTwoExist() {
    cy.get(createPatternPageLocators.copiedEventFromEvents).should(assertionConstants.beExistAssertion)
  }

  copiedEventFromEventTwoNotExist() {
    cy.get(createPatternPageLocators.copiedEventFromEvents).should(assertionConstants.notExistsAssertion)
  }

  operatorOptionsClick() {
    cy.get(createPatternPageLocators.Operator).eq(1).click()
  }

  operatorOptionAboveCopiedEventForEventFourClick() {
    cy.get(createPatternPageLocators.operator).eq(2).click()
  }

  copiedEventFormEVentFourWithoutCollapseAndExpandIcon() {
    cy.get(createPatternPageLocators.copiedEventFormEVentFour).should(assertionConstants.haveNotAttributeAssertion, 'viewBox')
  }

  operatorOptionAboveCopiedEventForEventOneForRulePatternClick() {
    cy.get(createPatternPageLocators.operatorDropdownAtEventAndCondition).eq(12).click()
  }


  operatorDropdownAtEventAndConditionBetweenEventThreeAndFourForRulePattenClick() {
    cy.get(createPatternPageLocators.operatorDropdownAtEventAndCondition).last().click()
  }

  conditionRemoveButtonVisibleForFormRulePattern() {
    cy.get(createPatternPageLocators.crossMarkAtConditionLevel).should(assertionConstants.beVisibleAssertion)
  }

  scrollElement() {
    cy.get(createPatternPageLocators.addAction).last().scrollIntoView()
  }

  addConditionPlusIconAtC3Click() {
    cy.get(createPatternPageLocators.addConditionButton).eq(2).click()
  }

  fourthConditionInFirstEventVisible() {
    cy.get(createPatternPageLocators.conditionsName).eq(3).should(assertionConstants.containAssertion, 'C4').and(assertionConstants.beVisibleAssertion)
  }

  c3ConditionsNameForFirstConditionInRulePattern() {
    cy.get(createPatternPageLocators.conditionsName).eq(2).invoke('text').then((text1) => {
      cy.contains(text1).should(assertionConstants.containAssertion, 'C3')
    })
  }

  c5ConditionsNameForSecondConditionInRulePattern() {
    cy.get(createPatternPageLocators.conditionsName).eq(3).invoke('text').then((text1) => {
      cy.contains(text1).should(assertionConstants.containAssertion, 'C5')
    })
  }

  c4ConditionsNameForThirdConditionInRulePattern() {
    cy.get(createPatternPageLocators.conditionsName).eq(4).invoke('text').then((text1) => {
      cy.contains(text1).should(assertionConstants.containAssertion, 'C4')
    })
  }

  addConditionPlusIconAtC4InRulePatternClick() {
    cy.get(createPatternPageLocators.addConditionButton).eq(4).click()
  }

  c6ConditionsNameForSixthConditionInRulePattern() {
    cy.get(createPatternPageLocators.conditionsName).eq(5).invoke('text').then((text1) => {
      cy.contains(text1).should(assertionConstants.containAssertion, 'C6')
    })
  }

  conditionRemoveButtonAtConditionC4Click() {
    cy.get(createPatternPageLocators.crossMarkAtConditionLevel).eq(4).click()
  }

  eventContainerWithOutConditionFour() {
    cy.get(createPatternPageLocators.autoGeneratedFirstEvent).eq(0).should(assertionConstants.notContainAssertion, 'C4')
  }

  addConditionPlusIconAtC6Click() {
    cy.get(createPatternPageLocators.addConditionButton).eq(4).click()
  }

  c6ConditionsNameForSixthConditionInRulePatternAfterRemovingC4() {
    cy.get(createPatternPageLocators.conditionsName).eq(4).invoke('text').then((text1) => {
      cy.contains(text1).should(assertionConstants.containAssertion, 'C6')
    })
  }

  c7ConditionsNameForSeventhConditionInRulePattern() {
    cy.get(createPatternPageLocators.conditionsName).eq(5).invoke('text').then((text1) => {
      cy.contains(text1).should(assertionConstants.containAssertion, 'C7')
    })
  }

  operatorDropdownAtEventAndConditionForConditionFiveClick() {
    cy.get(createPatternPageLocators.operator).eq(5).click()
  }

  operatorDropdownAtEventAndConditionForConditionSixClick() {
    cy.get(createPatternPageLocators.operator).eq(6).click()
  }

  checkBoxAtEventTwoInRulePatternClick() {
    cy.get(createPatternPageLocators.checkBox).eq(4).click()
  }


  patterndescriptionDetails() {
    cy.get(createPatternPageLocators.patterndescriptionDetails).last().invoke('text').then((description1) => {
      detailsArrey.push(description1.trim())
      cy.log(detailsArrey)
    })
  }

  patternDataModelDetails() {
    cy.get(createPatternPageLocators.patternDataModelDetails).invoke('text').then((dataModel1) => {
      detailsArrey.push(dataModel1.trim())
      cy.log(detailsArrey)
    })
  }

  patternExpression() {
    cy.get(createPatternPageLocators.patternExpression).invoke('text').then((expression) => {
      detailsArrey.push(expression.trim())
      cy.log(detailsArrey)
    })
  }

  modelityDetails() {
    cy.get(createPatternPageLocators.modelityType).first().children().last().invoke('text').then((modelity) => {
      detailsArrey.push(modelity.trim())
      cy.log(detailsArrey)
    })
  }

  patternTypeDetails() {
    cy.get(createPatternPageLocators.patternTypee).first().children().last().invoke('text').then((patternType1) => {
      detailsArrey.push(patternType1.trim())
      cy.log(detailsArrey)
    })
  }

  daySpanDetails() {
    cy.get(createPatternPageLocators.daySpanDetails).first().children().last().invoke('text').then((dayspan) => {
      detailsArrey.push(dayspan.trim())
      cy.log(detailsArrey)
    })

  }

  knowledgeNameDetails() {
    cy.get(createPatternPageLocators.knowledgeName).invoke('text').then((knowledgeName1) => {
      detailsArrey.push(knowledgeName1.trim())
      cy.log(detailsArrey)
    })
  }

  createPatternPageVisible() {
    cy.contains(createPatternPage).should(assertionConstants.beVisibleAssertion)
  }

  patternNameIndicatorTextVisible() {
    cy.contains(patternNameIndicatorText).should(assertionConstants.beVisibleAssertion)
  }

  importDataModelDetailInCreatePatternPage() {
    cy.get(createPatternPageLocators.importDataModelDetailInCreatePatternPage).first().should(assertionConstants.haveTextAssertion, detailsArrey[1])
  }

  patternNameTextBoxType() {
    cy.get(createPatternPageLocators.patternNameTextBox).type(userID_Alpha_Numeric())
  }

  patternNameBoxType() {
    cy.get(createPatternPageLocators.patternNameTextBox).click({ force: true }).type(userID_Alpha_Numeric())
  }

  plusIconClick() {
    cy.get(createPatternPageLocators.plusIcon).click()
  }

  modalityInApplyMetadataPage() {
    cy.get(createPatternPageLocators.detailsInApplyMetadataPage).first().children().first().find('span').should('have.text', detailsArrey[3])
  }

  patternNameInApplyMetadataPage() {
    cy.get(createPatternPageLocators.detailsInApplyMetadataPage).eq(1).find(ptLayoutContainerClass).first().find('span').should('have.text', detailsArrey[4])
  }

  daySpanInApplyMetadataPage() {
    cy.get(createPatternPageLocators.daySapnInApplyMedadataPage).should('have.attr', 'placeholder', "24 (Default)")
  }

  serviceContextDropDownInApplyMetadataPageClick() {
    cy.get(createPatternPageLocators.modalityDropdownInApplyMetadata).eq(1).click()
  }
  modalityDropDownInApplyMetadataPageClick() {
    cy.get(createPatternPageLocators.modalityDropdownInApplyMetadata).eq(0).click()
  }

  fseOptionClick() {
    cy.get(createPatternPageLocators.fseOption).first().click()
  }

  newlyCreatedWorkFlowText() {
    cy.get(createPatternPageLocators.newlyCreatedPatternText).invoke('text').then((Name) => {
      PatternName.push(Name.trim())
      cy.log(PatternName)
    })
  }

  patternDashboardClick() {
    cy.get(createPatternPageLocators.Dashboard).first().click()
  }

  patternInPatternDashboardVisible() {
    cy.get(createPatternPageLocators.availablePatternsList).last().then((page) => {
      expect(page).to.contain(PatternName[0])
    })
  }

  myPatternDashboardClick() {
    cy.get(createPatternPageLocators.Dashboard).eq(2).click()
  }

  PatternInMyPatternDashboardPage() {
    cy.get(createPatternPageLocators.myPatternDashboardPage).eq(1).then((MyPatternDashboard) => {
      expect(MyPatternDashboard).to.contain(PatternName[0])
    })
  }

  firstPatternInMyPatternClick() {
    cy.get(createPatternPageLocators.firstPatternClick).find('td').eq(1).find('span').first().click()
  }


  newlyCreatedWorkFlowInMyPatternText() {
    cy.get(createPatternPageLocators.newlyCreatedPatternText).invoke('text').then((NameOne) => {
      patternNameInMyPattern.push(NameOne.trim())
      cy.log(patternNameInMyPattern)
    })
  }

  patternInMyPatternDashboard() {
    cy.get(createPatternPageLocators.availablePatternsList).last().then((NewPatternName) => {
      expect(NewPatternName).to.contain(patternNameInMyPattern[1])
    })
  }

  searchBarType() {
    cy.get(createPatternPageLocators.searchBar).then((elOne) => {
      cy.wrap(elOne).type(patternNameInMyPattern[0])
    })
  }

  searchIconClick() {
    cy.get(createPatternPageLocators.searchIcon).click({ force: true })
  }

  myPatternImportDataModelDetailInCreatePatternPage() {
    cy.get(createPatternPageLocators.importDataModelDetailInCreatePatternPage).first().should(assertionConstants.haveTextAssertion, dataModelText)
  }

  myPatternAddConditionDetailInCreatePatternPage() {
    cy.get(createPatternPageLocators.importDataModelDetailInCreatePatternPage).eq(0).should(assertionConstants.containAssertion, 'EventLog')
  }

  myPatternModalityInApplyMetadataPage() {
    cy.get(createPatternPageLocators.modalityDropdownInApplyMetadata).first().find(createPatternPageLocators.ptLayoutContainerClass).first().find('span').should('have.text', modality)
  }

  myPatternPatternNameInApplyMetadataPage() {
    cy.get(createPatternPageLocators.patternTypeDropdownInApplyMetadataPage).eq(1).find(createPatternPageLocators.ptLayoutContainerClass).first().find('span').should('have.text', patternType)
  }

  commentAreaType() {
    cy.get(createPatternPageLocators.commentArea).type('one')
  }

  patternNameSearchOptionType() {
    cy.get(createPatternPageLocators.coloumLevelNameFilter).then((NewPatternName) => {
      cy.wrap(NewPatternName).type(patternNameInMyPattern[1])
    })
  }

  searchIconInMyPatternDashboardClick() {
    cy.get(createPatternPageLocators.searchIcon).click()
  }

  addtagPlusButtonClick() {
    cy.get(createPatternPageLocators.addTagPlusButton).click()
  }


  launchApp() {
    return cy.visit(Cypress.env("URL"));
  }

  patternTabThreeDotsClick() {
    return cy.get(createPatternPageLocators.patternTabThreeDots).first().click()
  }

  addConditionOptionClick() {
    return cy.get(addConditionOption).eq(3).click({ force: true })
  }

  fromRulePatternOpotionClick() {
    return cy.contains(fromrulePattern).click({ force: true })
  }

  commonSearchDropdownClick() {
    return cy.get(createPatternPageLocators.commonSearchTextBox).last().click()
  }

  tagsOptionUnderCommonSearchClick() {
    return cy.get(createPatternPageLocators.dropDownOptions).last().click()

  }

  searchByKeyWordDicomOptionType() {
    return cy.get(createPatternPageLocators.searchByKeyWordOption).type('DICOM')
  }

  searchButtonOfSearchByKeyWordClick() {
    return cy.get(createPatternPageLocators.searchButtonOfSearchByKeyWord).first().click()
  }

  searchedPatternDetailsForDicomVisible() {
    return cy.get(createPatternPageLocators.searchedPatternDetails).eq(3).should(assertionConstants.containAssertion, 'DICOM')
  }

  nameFilterDnsType() {
    return cy.get(createPatternPageLocators.coloumLevelNameFilter).type('DNS')
  }

  searchButtonOfNameFilterClick() {
    return cy.get(createPatternPageLocators.searchButton).eq(1).click()
  }

  filteredDataOfNameFilterDnsVisible() {
    return cy.get(createPatternPageLocators.searchedPatternDetails).first().should(assertionConstants.containAssertion, 'DNS').and(assertionConstants.beVisibleAssertion)
  }

  removeFilterButtonOfNameFilterClick() {
    return cy.get(createPatternPageLocators.crosssIcon).eq(4).click()
  }

  discriptionFilterMotorType() {
    return cy.get(createPatternPageLocators.coloumLevelDecriptionFilter).type('motor')
  }

  searchButtonOfDescriptionFilterClick() {
    return cy.get(createPatternPageLocators.searchButton).eq(2).click(({ force: true }))
  }

  filteredDataOfDescriptionFilterMotorVisible() {
    return cy.get(createPatternPageLocators.searchedPatternDetails).first().find('span').first().should(assertionConstants.containAssertion, 'motor').and(assertionConstants.beVisibleAssertion)
  }

  removeFilterButtonOfDescriptionFilterClick() {
    return cy.get(createPatternPageLocators.crosssIcon).last().click()
  }

  dataModelsFilterClick() {
    return cy.get(createPatternPageLocators.valueOnDropDown).first().click()
  }

  dataModeldropDownEventLogOptionClick() {
    return cy.get(createPatternPageLocators.dataModeldropDownEventLogOption).click()

  }

  applyButtonOfDataModelFilterClick() {
    return cy.get(createPatternPageLocators.applyButtonOfDataModelFilter).click()
  }

  filteredDataOfDataMOdelFilterVisible() {
    return cy.get(createPatternPageLocators.searchedPatternDetails).eq(2).should(assertionConstants.containAssertion, 'EventLog ')

  }

  clearDataModeFilterOptionClick() {
    return cy.get(createPatternPageLocators.valueOnDropDown)
  }

  tagsFilterOptionClick() {
    return cy.get(createPatternPageLocators.valueOnDropDown).last().click()
  }

  tagsFilterDICOMandInteroperabilityOptionClick() {
    return cy.get(createPatternPageLocators.tagsFilterDICOMandInteroperabilityOption).click()
  }

  applyButtonOfTagsFilterClick() {
    return cy.get(createPatternPageLocators.applyButtonOfTagslFilter).click({ force: true })
  }

  filteredDataOfTagsFilter() {
    return cy.get(createPatternPageLocators.searchedPatternDetails).should(assertionConstants.beVisibleAssertion)

  }

  showAllCheckBoxClicked() {
    return cy.get(createPatternPageLocators.checkBox).click().should(assertionConstants.notBeCheckedAssertion)
  }

  showAllCheckBoxchecked() {
    return cy.get(createPatternPageLocators.checkBox).click()
  }

  allFilteredRecordsVisible() {
    return cy.get(createPatternPageLocators.availablePatternsList).find('tr>td').should(assertionConstants.beVisibleAssertion)

  }
  allOnCommonSearchVisible() {
    return cy.get(createPatternPageLocators.allText).eq(1).should(assertionConstants.haveTextAssertion, 'All').and(assertionConstants.beVisibleAssertion)
  }

  searchByKeyWordErrorOptionType() {
    return cy.get(createPatternPageLocators.searchByKeyWordOption).type('error')
  }

  searchedPatternDetailsForErrorVisible() {
    return cy.get(createPatternPageLocators.searchedPatternDetails).eq(2).should(assertionConstants.containAssertion, 'Error')
  }

  nameFilterDetectorType() {
    return cy.get(createPatternPageLocators.coloumLevelNameFilter).type('detector')
  }

  descriptionFilterErrorType() {
    return cy.get(createPatternPageLocators.coloumLevelDecriptionFilter).type('error')
  }

  filteredDataOfNameFilterDetectorVisible() {
    return cy.get(createPatternPageLocators.searchedPatternDetails).should(assertionConstants.containAssertion, 'Detector').and(assertionConstants.beVisibleAssertion)
  }

  filteredDataOfDescriptionFilterErrorVisible() {
    return cy.get(createPatternPageLocators.searchedPatternDetails).should(assertionConstants.containAssertion, 'error').and(assertionConstants.beVisibleAssertion)
  }

  nameFilterCleared() {
    return cy.get(createPatternPageLocators.coloumLevelNameFilter).should(assertionConstants.notHaveTextAssertion, 'Dns')
  }

  descriptionFilterCleared() {
    return cy.get(createPatternPageLocators.coloumLevelDecriptionFilter).should(assertionConstants.notHaveTextAssertion, 'rejected')
  }

  dataModelFilterCleared() {
    return cy.get(createPatternPageLocators.valueOnDropDown).should(assertionConstants.notHaveTextAssertion, 'EventLog')
  }

  tagsFilterCleared() {
    return cy.get(createPatternPageLocators.valueOnDropDown).should(assertionConstants.notHaveTextAssertion, 'FV==DICOM and Interoperability')
  }

  nameFilterWithDetectorCleared() {
    return cy.get(createPatternPageLocators.coloumLevelNameFilter).should(assertionConstants.notHaveTextAssertion, 'detector')
  }

  descriptionFilterWitherrorCleared() {
    return cy.get(createPatternPageLocators.coloumLevelDecriptionFilter).should(assertionConstants.notHaveTextAssertion, 'error')
  }

  nameFilterRejectedType() {
    return cy.get(createPatternPageLocators.coloumLevelNameFilter).type('rejected')
  }

  filteredDataOfNameFilterRejectedVisible() {
    return cy.get(createPatternPageLocators.searchedPatternDetails).should(assertionConstants.containAssertion, 'rejected').and(assertionConstants.beVisibleAssertion)
  }

  DescriptionFilterxrayType() {
    return cy.get(createPatternPageLocators.coloumLevelDecriptionFilter).type('Xray')
  }

  filteredDataOfDescriptionFilterXrayVisible() {
    return cy.get(createPatternPageLocators.searchedPatternDetails).should(assertionConstants.containAssertion, 'Xray').and(assertionConstants.beVisibleAssertion)
  }

  allFilteredRecordsNotExists() {
    return cy.get(createPatternPageLocators.availablePatternsList).should(assertionConstants.notExistsAssertion)
  }

  nameFilterDnsCleared() {
    return cy.get(createPatternPageLocators.coloumLevelNameFilter).should(assertionConstants.notHaveTextAssertion, 'Dns')
  }

  discriptionFilterRejectedCleared() {
    return cy.get(createPatternPageLocators.coloumLevelDecriptionFilter).should(assertionConstants.notHaveTextAssertion, 'Rejected')
  }

  patternDashboardTitleVisible() {
    cy.get(createPatternPageLocators.patternDashboardTitle).should(assertionConstants.haveTextAssertion, 'Patterns').and(assertionConstants.beVisibleAssertion)
  }

  patternDashboardBreadCrumVisible() {
    cy.get(createPatternPageLocators.patternDashboardBreadCrum).find('li').should(assertionConstants.havelengthAssertion, '5')
  }

  fullscreenViewButtonvisible() {
    cy.get(createPatternPageLocators.fullScreenViewButton).should(assertionConstants.beVisibleAssertion)
  }

  fullscreenViewButtonClick() {
    cy.get(createPatternPageLocators.fullScreenViewButton).click({ force: true })
  }

  fullScreenVisible() {
    cy.get(createPatternPageLocators.fullScreen).should(assertionConstants.beVisibleAssertion)
  }

  patternHeaderWithPatternDetailsVisible() {
    cy.get(createPatternPageLocators.addAction).find('span').first().should(assertionConstants.haveTextAssertion, 'Pattern Details ').and(assertionConstants.beVisibleAssertion)
  }

  buttonsAtBottomVisible() {
    cy.get(createPatternPageLocators.buttonsAtBottom).find('button').should(assertionConstants.beVisibleAssertion)
  }

  backArrowClick() {
    cy.get(createPatternPageLocators.backArrow).click()
  }

  fullScreenNotExist() {
    cy.get(createPatternPageLocators.fullScreen).should(assertionConstants.notExistsAssertion)
  }

  readOnlyModeExist() {
    cy.get(createPatternPageLocators.readOnlyMode).should(assertionConstants.beExistAssertion)
  }

  dashboardWithPattrensVisible() {
    cy.get(createPatternPageLocators.availablePatternsList).find('td').should(assertionConstants.beVisibleAssertion)
  }

  myPatternArrowClick() {
    cy.get(createPatternPageLocators.myPatternArrow).eq(1).click()
  }

  toggleIconVisible() {
    cy.get(createPatternPageLocators.toggleIcon).should(assertionConstants.beVisibleAssertion)
  }

  leftPaneDashboardBoxVisible() {
    cy.get(createPatternPageLocators.leftPaneDashboardBox).should(assertionConstants.beVisibleAssertion)
  }

  myPattrenDashboardClick() {
    cy.get(createPatternPageLocators.myPattrenDashboard).last().click()
  }

  mypatternDashboardBreadCrumVisible() {
    cy.get(createPatternPageLocators.patternDashboardBreadCrum).find('li').should(assertionConstants.havelengthAssertion, '7')
  }


  includeKnowledgePageVisible() {
    cy.get(createPatternPageLocators.includeKnowledgePage).find('li').eq(2).should(assertionConstants.haveClassAssertion, "ng-star-inserted active")
  }
  previousButtonEnabled() {
    cy.get(createPatternPageLocators.previousButtonClick).should(assertionConstants.notBeDisabledAssertion)
  }

  closeButtonEnabled() {
    cy.get(createPatternPageLocators.closeButton).should(assertionConstants.notBeDisabledAssertion)
  }

  saveAsDraftEnabled() {
    cy.get(createPatternPageLocators.saveAsDraftButton).should(assertionConstants.notBeDisabledAssertion)
  }

  nextButtonDisabled() {
    cy.get(createPatternPageLocators.nextButton).last().should(assertionConstants.notBeEnabledAssertion)
  }
  dataInGridVisible() {
    cy.get(createPatternPageLocators.availablePatternsList).find('td').should(assertionConstants.beVisibleAssertion)
  }

  firstKnowledgwSelect() {
    cy.get(createPatternPageLocators.KnowledgwSelectcheckBox).eq(1).click()
  }

  nextButtonEnabled() {
    cy.get(createPatternPageLocators.nextButton).should(assertionConstants.notBeDisabledAssertion)
  }

  nextClick() {
    cy.get(createPatternPageLocators.next).click()
  }

  reviewTabClick() {
    cy.get(createPatternPageLocators.Tab).last().click()
  }

  createPatternWithRightMarkVisible() {
    cy.get(createPatternPageLocators.TitleWithRightMark).find('li').first().should(assertionConstants.haveAttributeAssertion, 'class').and(assertionConstants.containAssertion, 'completed')
  }

  applyMetadataWithRightMarkVisible() {
    cy.get(createPatternPageLocators.TitleWithRightMark).find('li').eq(1).should(assertionConstants.haveAttributeAssertion, 'class').and(assertionConstants.containAssertion, 'completed')
  }

  includeKnowledgeWithRightMarkVisible() {
    cy.get(createPatternPageLocators.TitleWithRightMark).find('li').eq(2).should(assertionConstants.haveAttributeAssertion, 'class').and(assertionConstants.containAssertion, 'completed')
  }

  saveAsDraftClick() {
    cy.get(createPatternPageLocators.saveAsDraft).click()
  }

  saveAsDraftDisabled() {
    cy.get(createPatternPageLocators.saveAsAfterClick).should(assertionConstants.haveClassAssertion, createPatternPageLocators.disabledClass)
  }

  closeButtonClick() {
    cy.get(createPatternPageLocators.closeButton).click()
  }

  confirmationPopUpHeaderVisible() {
    cy.get(createPatternPageLocators.popUpTitle).should(assertionConstants.containAssertion, 'WARNING: You have unsaved changes.').and(assertionConstants.beVisibleAssertion)
  }

  confirmationPopUpDialogVisible() {
    cy.get(createPatternPageLocators.popUpDialogue).should(assertionConstants.containAssertion, ' Press OK to continue or Cancel to stay on this page. ').and(assertionConstants.beVisibleAssertion)
  }

  okButtonOnPopUpVisible() {
    cy.get(createPatternPageLocators.okButtonOnPopUp).should(assertionConstants.beVisibleAssertion)
  }

  okButtonOnPopUpClick() {
    cy.get(okButtonOnPopUp).click()
  }

  breadCrumbForMyPatternDashboard() {
    cy.get(createPatternPageLocators.breadCrumbForMyPatternDashboard).find('li').should(assertionConstants.havelengthAssertion, '7')
  }

  myPatternDashboardSelected() {
    cy.get(createPatternPageLocators.myPatternDashboard).should(assertionConstants.haveAttributeAssertion, ariaSelectedAttribute, "true")
  }

  firstKnowledgwClick() {
    cy.get(createPatternPageLocators.KnowledgwSelectcheckBox).eq(1).click()
  }

  removeKnowledgeIconClick() {
    cy.get(createPatternPageLocators.removeKnowledgeIcon).first().click()
  }

  removeKnowledgesIconsClick() {
    cy.get(createPatternPageLocators.removeKnowledgeIcon).click({ multiple: true })
  }

  secondKnowledgwSelect() {
    cy.get(createPatternPageLocators.KnowledgwSelectcheckBox).eq(3).click()
  }

  thirdKnowledgwSelect() {
    cy.get(createPatternPageLocators.KnowledgwSelectcheckBox).eq(5).click()
  }

  existingWFClick() {
    cy.get(createPatternPageLocators.existingWF).eq(1).find('p').find('.p-treenode.p-treenode-leaf.ng-star-inserted').last().click()
  }

  additionalKnowledgeNotVisible() {
    cy.contains(addedAdditionalKnowledge).should(assertionConstants.notExistsAssertion)
  }

  lastSelectedKnowledgeText() {
    cy.get(createPatternPageLocators.firstKnowledge).eq(1).find('td').eq(1).find('span').first().invoke('text').should(assertionConstants.beVisibleAssertion)

  }

  selectedKnowledgeTextInRightSection() {
    cy.get(createPatternPageLocators.KnowledgeTextInRightSection).first().should(assertionConstants.haveTextAssertion, firstSelectedKnowledgeText);

  }

  iconToCollaspeRightSideSectionVisible() {
    cy.get(createPatternPageLocators.iconToCollaspeRightSideSection).first().should(assertionConstants.beVisibleAssertion);
  }

  iconToCollaspeRightSideSectionClick() {
    cy.get(createPatternPageLocators.iconToCollaspeRightSideSection).first().click();
  }

  KnowledgeDetailsTextWhenRightSideCollapse() {
    cy.get(createPatternPageLocators.KnowledgeDetailsTextWhenRightSideCollapse).last().should(assertionConstants.beVisibleAssertion);

  }

  iconToExpandRightSideSectionVisible() {
    cy.get(createPatternPageLocators.iconToExpandRightSideSection).first().should(assertionConstants.beVisibleAssertion);
  }

  KnowledgeDetailsLableVisible() {
    return cy.get(createPatternPageLocators.KnowledgeDetailsTextWhenRightSideCollapse).then((el) => {
      const before = window.getComputedStyle(el[1], "before");
      const contentValue = before.getPropertyValue("content");
      expect(contentValue).to.equal(knowledgeDetailslable);
    });
  }

  iconToExpandRightSideSectionClick() {
    cy.get(createPatternPageLocators.iconToExpandRightSideSection).first().click();
  }

  showAllNameCheckBoxClick() {
    cy.get(createPatternPageLocators.checkBoxAtEachValueLevel).first().click();
  }

  causeAndSolutionInDefaultScreenVisible() {
    cy.get(createPatternPageLocators.causeAndSolutionInDefaultScreen).should(assertionConstants.haveNotAttributeAssertion, 'class', 'enable-fullscreen')
  }
  detaInReviewTabGridVisible() {
    cy.get(createPatternPageLocators.knowledges).first().find("li").should(assertionConstants.beVisibleAssertion);
  }

  firstKnowledgwSelectInReviewTab() {
    cy.get(createPatternPageLocators.firstKnowledgwSelectInReviewTab).click();
  }

  iconToCollaspeRightSideSectionInReviewTabVisible() {
    cy.get(createPatternPageLocators.iconToCollaspeRightSideSection).last().should(assertionConstants.beVisibleAssertion);
  }

  iconToCollaspeRightSideSectionInReviewTabClick() {
    cy.get(createPatternPageLocators.iconToCollaspeRightSideSection).last().click();
  }

  iconToExpandRightSideSectionInReviewTabVisible() {
    cy.get(createPatternPageLocators.iconToExpandRightSideSection).last().should(assertionConstants.beVisibleAssertion);
  }

  iconToExpandRightSideSectionInReviewTabClick() {
    cy.get(createPatternPageLocators.iconToExpandRightSideSection).last().click();
  }

  secondKnowledgeInReviewTabClick() {
    cy.get(createPatternPageLocators.secondKnowledgeInReviewTab).click();
  }

  KnowledgeDetailsTextWhenRightSideCollapseInReviewTabVisible() {
    cy.get(createPatternPageLocators.KnowledgeDetailsTextWhenRightSideCollapseInReviewTab).should(assertionConstants.beVisibleAssertion);

  }

  knowledgeDetailsInReviewTabVisible() {
    cy.get(createPatternPageLocators.knowledgeDetailsReviewTab).should(assertionConstants.beVisibleAssertion);
  }

  knowledgeInRightSection() {
    cy.get(createPatternPageLocators.firstKnowledge).eq(12).find("span").first().invoke("text").then((value) => {
      patternDetailsArrey.push(value.trim());
      cy.log(arr);
    });
  }

  compareText() {
    cy.get(createPatternPageLocators.lastSelectedKnowledgeTextInRightSection).first().invoke("text").then((el) => {
      newArr.push(el.trim());
      cy.log(newArr);
      expect(arr[0]).to.eq(newArr[0])
    });
  }


  knowledgeDescriptionVisible() {
    cy.contains(knowledgeDescription).should(assertionConstants.beVisibleAssertion)
  }

  knowledgeSymptomVisible() {
    cy.contains(knowledgeSymptom).should(assertionConstants.beVisibleAssertion)
  }

  knowledgeCauseAndSolutionVisible() {
    cy.contains(knowledgeCauseAndSolution).should(assertionConstants.beVisibleAssertion)
  }

  knowledgeTagsVisible() {
    cy.contains(knowledgeTags).should(assertionConstants.beVisibleAssertion)
  }

  knowledgeNameInIncludeTabRightSectionVisible() {
    cy.get(createPatternPageLocators.knowledgeName).first().should(assertionConstants.beVisibleAssertion)
  }

  collapsableAndExpandableIconOfDescriptionInIncludeTabClick() {
    cy.get(createPatternPageLocators.expandCollapseIconAtgroupLevel).first().click()
  }

  descriptionAccordionsExpanded() {
    cy.get(createPatternPageLocators.descriptionAccordions).first().should(assertionConstants.haveClassAssertion, descriptionAccordiansClass)
  }

  symptomsAccordionsExpanded() {
    cy.get(createPatternPageLocators.Accordions).first().children(createPatternPageLocators.dlsExpanderChildrenClass).eq(1).should(assertionConstants.haveClassAssertion, ptExpanderClass)
  }

  causeAndSoultionAccordionsExpanded() {
    cy.get(createPatternPageLocators.Accordions).first().children(createPatternPageLocators.dlsExpanderChildrenClass).eq(2).should(assertionConstants.haveClassAssertion, ptExpanderClass)
  }


  tagsAccordionsExpanded() {
    cy.get(createPatternPageLocators.Accordions).first().children(createPatternPageLocators.dlsExpanderChildrenClass).eq(3).should(assertionConstants.haveClassAssertion, ptExpanderClass)
  }


  descriptionAccordionsCollapsed() {
    cy.get(createPatternPageLocators.descriptionAccordions).first().should(assertionConstants.notHaveClassAssertion, descriptionAccordiansClass)

  }

  descriptionDetailsVisible() {
    cy.get(createPatternPageLocators.descriptionDetails).should(assertionConstants.containAssertion, '   Check the motor voltage ').and(assertionConstants.beVisibleAssertion)

  }

  collapsableAndExpandableIconOfCauseAndSolutionInIncludeTabClick() {
    cy.get(createPatternPageLocators.expandCollapseIconAtgroupLevel).eq(2).click()
  }

  reviewTabWithKnowledgeCountVisible() {
    cy.get(createPatternPageLocators.reviewTabWithKnowledgeCount).last().should(assertionConstants.beVisibleAssertion)
  }

  knowledgeNameHeaderVisible() {
    cy.get(createPatternPageLocators.knowledgeNameHeader).should(assertionConstants.haveTextAssertion, 'Knowledge Name').and(assertionConstants.beVisibleAssertion)
  }

  selectedFirstKnowledge() {
    cy.get(createPatternPageLocators.knowledges).find('li').first().should(assertionConstants.haveAttributeAssertion, 'class', "pt-separator pt-selected ng-star-inserted")
  }

  selectedKnowledgeDetailsVisible() {
    cy.get(createPatternPageLocators.selectedKnowledgeDetails).last().children(dlsExpanderChildrenClass).should(assertionConstants.beVisibleAssertion)
  }

  KnowledgeText() {
    cy.get(createPatternPageLocators.firstKnowledge).children().invoke('text').then((textone) => {
      knowledgeAndSymptomTextArrey.push(textone)
    })

    cy.get(createPatternPageLocators.seconndKnowledge).children().invoke('text').then((texttwo) => {
      knowledgeAndSymptomTextArrey.push(texttwo)
    })

    cy.get(createPatternPageLocators.thirdKnowledge).children().invoke('text').then((textthree) => {
      knowledgeAndSymptomTextArrey.push(textthree)
    })
    cy.log(knowledgeAndSymptomTextArrey)

  }

  orderOfKnowledges() {
    cy.get(createPatternPageLocators.knowledges).find('li').first().invoke('text').then((textone) => {
      expect(textone).to.equal(knowledgeAndSymptomTextArrey[0])
    })
    cy.get(createPatternPageLocators.knowledges).find('li').eq(1).invoke('text').then((texttwo) => {
      expect(texttwo).to.equal(knowledgeAndSymptomTextArrey[1])
    })
    cy.get(createPatternPageLocators.knowledges).find('li').eq(2).invoke('text').then((textthree) => {
      expect(textthree).to.equal(knowledgeAndSymptomTextArrey[2])
    })
  }

  knowledgeNameInReviewTabRightSectionVisible() {
    cy.get(createPatternPageLocators.knowledgeName).last().should(assertionConstants.beVisibleAssertion)
  }

  descriptionAccordionsInReviewtabExpanded() {
    cy.get(createPatternPageLocators.descriptionAccordions).last().should(assertionConstants.haveClassAssertion, createPatternPageLocators.descriptionAccordiansClass)

  }

  symptomsAccordionsInReviewtabExpanded() {
    cy.get(Accordions).last().children(dlsExpanderChildrenClass).eq(1).should(assertionConstants.haveClassAssertion, createPatternPageLocators.ptExpanderClass)
  }

  causeAndSoultionAccordionsInReviewtabExpanded() {
    cy.get(createPatternPageLocators.Accordions).last().children(createPatternPageLocators.dlsExpanderChildrenClass).eq(2).should(assertionConstants.haveClassAssertion, ptExpanderClass)
  }

  tagsAccordionsInReviewtabExpanded() {
    cy.get(createPatternPageLocators.Accordions).last().children(createPatternPageLocators.dlsExpanderChildrenClass).eq(3).should(assertionConstants.haveClassAssertion, ptExpanderClass)
  }

  collapsableAndExpandableIconInReviewTabClick() {
    cy.get(createPatternPageLocators.expandCollapseIconAtgroupLevel).eq(4).click()
  }

  crossMarkOfFirstKnowaledgeClick() {
    cy.get(createPatternPageLocators.crossMarkOfFirstKnowaledge).first().click()
  }

  knowledgeDescriptionInrewviewTabVisible() {
    cy.get(createPatternPageLocators.knowledgeDescriptionInrewviewTab).last().find('span').should(assertionConstants.haveTextAssertion, 'Description ').and(assertionConstants.beVisibleAssertion)
  }

  includeTabClick() {
    cy.get(createPatternPageLocators.includeTab).find('li').first().click()
  }

  reviewTabWithUpdatedKnowledgeCountVisible() {
    cy.get(createPatternPageLocators.reviewTabWithKnowledgeCount).last().should(assertionConstants.haveTextAssertion, 'Review (2)')
  }

  removedKnowledgeUnselected() {
    cy.get(createPatternPageLocators.removedKnowledge).first().should(assertionConstants.notBeCheckedAssertion)
  }

  fullScreenButtonInIncludeTabClick() {
    cy.get(createPatternPageLocators.fullScreenButtonInIncludeTab).first().click()
  }

  rightSectionInFullScreenView() {
    cy.get(createPatternPageLocators.rightSectionInFullScreenView).children('div').eq(1).should(assertionConstants.haveAttributeAssertion, 'class', "col-md-6 rightView ng-star-inserted col-md-12 details-full-view")
  }

  leftPaneVisible() {
    cy.get(createPatternPageLocators.leftPane).should(assertionConstants.beVisibleAssertion)
  }

  includeTabVisible() {
    cy.get(createPatternPageLocators.includeTab).find('li').first().should(assertionConstants.beVisibleAssertion)
  }

  fullScreenViewButtonAtPatternLevelClick() {
    cy.get(createPatternPageLocators.fullScreenViewButton).click()
  }


  includeTabNotExist() {
    cy.get(createPatternPageLocators.includeTab).find('li').first().should(assertionConstants.notExistsAssertion)
  }

  reviewTabWithKnowledgeCountNotExist() {
    cy.get(createPatternPageLocators.reviewTabWithKnowledgeCount).last().should(assertionConstants.notExistsAssertion)
  }

  previousButtonVisible() {
    cy.xpath(createPatternPageLocators.previousButtonClick).should(assertionConstants.beVisibleAssertion)
  }

  allButtonsVisible() {
    cy.get(createPatternPageLocators.allButtons).find('button').should(assertionConstants.beVisibleAssertion)
  }

  searchButtonVisible() {
    cy.get(createPatternPageLocators.searchButton).should(assertionConstants.beVisibleAssertion)
  }


  knowledgeCauseAndSolutionDetailsvisible() {
    cy.get(createPatternPageLocators.knowlwdgeCauseAndSolution).eq(1).should(assertionConstants.beVisibleAssertion)
  }

  detailsOfCauseAndSolutionInIncludeTabVisible() {
    cy.get(createPatternPageLocators.detailsOfCauseAndSolutionInIncludeTab).first().should(assertionConstants.beVisibleAssertion)
  }

  entriesPerpageDropdownClick() {
    cy.get(createPatternPageLocators.entriesPerpageDropdown).last().click()
  }

  allSymptomsOfNextPageSelected() {
    cy.get(createPatternPageLocators.checkBoxAtEachValueLevel).should(assertionConstants.beVisibleAssertion)
  }

  symptomAndCauseDescriptionVisible() {
    cy.get(createPatternPageLocators.symptomDescription).should(assertionConstants.beVisibleAssertion)
  }
  symptomTagsVisible() {
    cy.get(createPatternPageLocators.symptomTag).should(assertionConstants.beVisibleAssertion)
  }

  symtomsOrCausesOnCurrentPageSelected() {
    cy.get(createPatternPageLocators.symptomsOnCurrentPage).last().find('tr').should(assertionConstants.haveAttributeAssertion, 'class', 'p-selectable-row ng-star-inserted row-hightlight-with-border p-highlight')
  }
  symptomsOrCauseWithoutEditOption() {
    cy.get(createPatternPageLocators.symptomsOrCauseWithoutEditOption).each((el, index) => {
      if (index !== 3) {
        cy.wrap(el).children('button').should(assertionConstants.havelengthAssertion, 1)
      }
    })
  }

  selectedCauseWithEditOptionVisible() {
    cy.get(createPatternPageLocators.addedCauseWithEditOption).eq(3).find('[dlstooltip="Edit"]').and(assertionConstants.beVisibleAssertion)
  }

  AddAuthoringWokFlowButtonClick() {
    return cy.get(createPatternPageLocators.AddAuthoringWokFlowButton).click()
  }

  workFlowMessageVisible() {
    return cy.contains(draftSavedText).should(assertionConstants.beVisibleAssertion)
  }

  workFlowMessageNotVisible() {
    return cy.contains(draftSavedText).should(assertionConstants.notVisibleAssertion)
  }

  fetchPatternName() {
    cy.get(createPatternPageLocators.patternDashboardBreadCrum).find(ptLayoutContainerClass).find('ul').children('li').last().find('a').find('span').invoke('text').then((Name) => {
      patternNameArrey.push(Name.trim())
      cy.wait(3000)
      cy.log(patternNameArrey)
    })
  }

  authoringWFName() {
    cy.get(createPatternPageLocators.savedPatternName).last().children().last().find('li').children().find(workFlowNameClass).invoke('text').then((patternName1) => {
      expect(patternName1.trim()).to.equal(patternNameArrey[0])
    })
  }

  threeDotsBesideWfnameClick() {
    cy.get(createPatternPageLocators.threeDotsBesideWfname).last().click()
  }

  renameOptionClick() {
    return cy.get(createPatternPageLocators.renameOption).click()
  }

  renameInputBoxType() {
    cy.get(createPatternPageLocators.renameInputBox).first().clear().type(renamedAuthoringWorkFlowName)
  }

  changedPatternNameType() {
    cy.get(createPatternPageLocators.patternName).type(userID_Alpha_Numeric())
  }

  workFlowNameAfterUpdatingPatternName() {
    cy.get(createPatternPageLocators.savedPatternName).last().children().last().find('li').children().find(workFlowNameClass).invoke('text').then((patternName1) => {
      expect(patternName1.trim()).to.equal(renamedAuthoringWorkFlowName)
    })
  }

  patternNameAfterUpdation() {
    cy.get(createPatternPageLocators.patternDashboardBreadCrum).find(ptLayoutContainerClass).find('ul').children('li').last().find('a').find('span').invoke('text').then((Name) => {
      patternNameUpdatedArrey.push(Name.trim())
      cy.wait(3000)
      cy.log(patternNameUpdatedArrey)
    })

  }

  updatedWorkFlowNameAfterUpdatingPatternName() {
    cy.get(createPatternPageLocators.savedPatternName).last().children().last().find('li').children().find(workFlowNameClass).invoke('text').then((worlflowName) => {
      expect(worlflowName.trim()).to.equal(patternNameUpdatedArrey[0])
    })
  }

  existingWorkFlowClick() {
    cy.contains(renamedAuthoringWorkFlowName).click()
  }

  threeDotsOfExistingWfClick() {
    cy.get(createPatternPageLocators.threeDotsOfExistingWf).children('span').click()
  }

  renameInputBoxForExistingWFType() {
    cy.get(createPatternPageLocators.renameInputBox).first().type(renamedExistingAuthoringWorkFlowName)
  }

  existingWfNameNotMatchedWithPatternName() {
    cy.get(createPatternPageLocators.existingWfName).find('[class="node-item pt-menu-example-row ng-star-inserted"]').find('a').invoke('text').then((text1) => {
      expect(text1.trim()).to.not.include(patternNameArrey[0])
    })
  }

  addedCondtionAttributeDropdownForFirstEvent() {
    return cy.get(createPatternPageLocators.addedCondtionAttributeDropdown).first().click()
  }

  OperatorForeventLog1UnderAtribute2InExpressionPopUpClick() {
    cy.get(createPatternPageLocators.attribute).eq(0).click()
  }

  addedCondtionAttributeDropdownForConditionTwoEventOneClick() {
    cy.get(createPatternPageLocators.addedCondtionAttributeDropdown).eq(1).click()
  }

  addedExpressionForEventOneInConditionOne() {
    return cy.get(createPatternPageLocators.addedExpressionForEvent).children().children().invoke('text').then((addedExpression) => {
      addedExpressionInC1OfE1Arrey.push(addedExpression.trim())
      cy.log(addedExpressionInC1OfE1Arrey)
    })
  }

  expressionAddedInC1VisibleInC2OfEventVerification() {
    cy.get(createPatternPageLocators.attributeForSecondCondition).last().invoke('text').then((text1) => {
      expect(text1).to.exist
    })
  }

  expressionAddedInC1NotVisibleInE2Verification() {
    cy.get(createPatternPageLocators.attributeList).should(assertionConstants.notContainAssertion, addedExpressionInC1OfE1Arrey[0])

  }

  addedCondtionAttributeDropdownForConditionTwoEventTwoClick() {
    cy.get(createPatternPageLocators.addedCondtionAttributeDropdown).eq(3).click()
  }

  conditionRemoveIconOfConditionOneInEventTwoClick() {
    cy.get(createPatternPageLocators.crossMarkAtConditionLevel).eq(2).click()
  }

  slashOperatorforTestOneClick() {
    return cy.get(createPatternPageLocators.Operator).eq(1).click()
  }

  firstAddedExpressionInC1OfE2() {
    cy.get(createPatternPageLocators.attributeForSecondCondition).last().invoke('text').then((firstExpression) => {
      addedExpressionInC1OfE2Arrey.push(firstExpression.trim())
      cy.log(addedExpressionInC1OfE2Arrey)
    })
  }

  addedCondtionAttributeDropdownForConditionOneEventTwoClick() {
    cy.get(createPatternPageLocators.addedCondtionAttributeDropdown).eq(2).click()
  }

  firstExpressionAddedInC1VisibleInC2OfEventVerification() {
    cy.get(createPatternPageLocators.attributeForSecondCondition).last().invoke('text').then((text1) => {
      expect(text1).to.exist
    })
  }

  operatorForFirstEventConditionOneClick() {
    return cy.get(createPatternPageLocators.operatorForEventOne).eq(0).click()
  }

  addedExpressionInDropdownOfC1InE1Exist() {
    cy.get(createPatternPageLocators.addedExpressionsInConditions).first().invoke('text').then((expression) => {
      expect(expression).to.exist
    })
  }

  secondEventWithConditions() {
    cy.get(createPatternPageLocators.autoGeneratedFirstEvent).last().find('[id="cond-name"]').should(assertionConstants.beExistAssertion)
  }

  operatorBetweenEventsClick() {
    cy.get(createPatternPageLocators.mainOperatorDropdownArrowUnderTesttwo).eq(4).click()
  }

  addConditionButtonAtConditionThreeInEventTwoClick() {
    cy.get(createPatternPageLocators.addConditionButton).eq(5).click()
  }

  addConditionButtonAtConditionFourInEventTwoClick() {
    cy.get(createPatternPageLocators.addConditionButton).eq(6).click()
  }

  operatorSelectionForConditionsInEventTwo() {
    cy.get(createPatternPageLocators.operatorDropdownAtEventAndCondition).eq(8).click()
    cy.get(createPatternPageLocators.operators).eq(2).click()
    cy.get(createPatternPageLocators.operatorDropdownAtEventAndCondition).eq(9).click()
    cy.get(createPatternPageLocators.operators).eq(0).click()
  }

  attributeDropDownForConditionFourEventTwoClick() {
    cy.get(createPatternPageLocators.addedExpressionForEvent).eq(6).click()
  }

  attributeDropDownForConditionFiveEventTwoClick() {
    cy.get(createPatternPageLocators.addedExpressionForEvent).eq(7).click()
    cy.wait(2000)
  }

  operatorSelectionForConditionFourAndFiveInEventTwo() {
    cy.get(createPatternPageLocators.operator).eq(6).click()
    cy.get(createPatternPageLocators.Operator).first().click()
    cy.get(createPatternPageLocators.operator).eq(7).click()
    cy.get(createPatternPageLocators.Operator).first().click()
  }

  valueForConditionFourAndFiveInenetTwoType() {
    cy.get(createPatternPageLocators.ValueForTestOne).eq(6).type('3')
    cy.get(createPatternPageLocators.ValueForTestOne).eq(7).type('4')
  }

  orOperatorAtEventLevelForEvent2Click() {
    cy.get(createPatternPageLocators.Operator).eq(1).click()
  }

  equipmentNumberAttributeClick() {
    cy.contains(equipmentNumberAttribute).click({ force: true })
  }

  notEqualToOperatorsInOperatorDropDownClick() {
    cy.get(createPatternPageLocators.Operator).eq(1).click()
  }

  valueInputBoxChangedForConditionThreeType() {
    cy.get(createPatternPageLocators.valueWaterMark).eq(2).clear().type(2)
  }

  addConditionSectionWithOutPatternDetails() {
    cy.get(createPatternPageLocators.addConditionSection).should(assertionConstants.notContainAssertion, autoGeneratedFirstEvent)
  }

  importedDataModelSectionWithOutDataModel() {
    cy.get(createPatternPageLocators.importedDataModelSection).should(assertionConstants.notContainAssertion, '[class="pt-token-only ng-star-inserted"]')
  }

  importedDataModelSectionWithDataModel() {
    cy.get(createPatternPageLocators.importedDataModelSection).should(assertionConstants.containAssertion, 'EventLog')
  }

  attributeWaterMarkVisible() {
    cy.contains(attributeWaterMark).should(assertionConstants.beVisibleAssertion)
  }

  operatorDropdownAtEventAndConditionForConditionFiveInEventOneClick() {
    cy.get(createPatternPageLocators.operatorDropdownAtEventAndCondition).eq(5).click()
  }

  logicalExpressionForAddedConditionExist() {
    cy.get(createPatternPageLocators.logicalExpressionAtAddConditionLevel).eq(2).find('span').invoke('text').then((expression) => {
      expect(expression).to.exist
      arreyOfexpressionForAddedCondition.push(expression)
      cy.log(arreyOfexpressionForAddedCondition)

    })
  }

  updatesLogicalExpressionForAddedConditionExist() {
    cy.get(createPatternPageLocators.logicalExpressionAtEventLevel).invoke('text').then((updatedexpression) => {
      expect(updatedexpression).to.exist
      expect(updatedexpression).not.equal(arreyOfexpressionForAddedCondition[0])

    })
  }

  autoGeneratedEventNameNotSameToImportedConditionFromPatternEventNameVerification() {
    cy.get(createPatternPageLocators.autoGeneratedEventName).invoke('text').then((DataModelName) => {
      expect(createPatternPageLocators.DataModelName).not.to.equal(eventLogDataModel)
    })
  }

  sameEventNamesNotExistUnderAddConditionVerification() {
    cy.contains(firstEventName).should(assertionConstants.havelengthAssertion, '1')
  }

  secondEventNameIncremented() {
    cy.get(createPatternPageLocators.autoGeneratedEventName).last().invoke('text').then((secondEventname) => {
      expect(createPatternPageLocators.secondEventname).to.equal(secondEventName)
    })
  }

  asACloneOptionClick() {
    cy.contains(asACloneOption).click()
  }

  eventNamesIncremented() {
    cy.get(createPatternPageLocators.autoGeneratedEventName).eq(2).should(assertionConstants.haveTextAssertion, eventThreeName)
    cy.get(createPatternPageLocators.autoGeneratedEventName).eq(3).should(assertionConstants.haveTextAssertion, eventFourName)
  }

  sameEventNamesNotExistAfterAdddingmultipleConditionsVerification() {
    cy.contains(secondEventName).should(assertionConstants.havelengthAssertion, '1')
    cy.contains(eventThreeName).should(assertionConstants.havelengthAssertion, '1')
    cy.contains(eventFourName).should(assertionConstants.havelengthAssertion, '1')
  }


  eventWithOperatorsAttributesAndConditionVisible() {
    cy.get(createPatternPageLocators.autoGeneratedFirstEvent).last().should(assertionConstants.containAssertion, 'Operator')
    cy.get(createPatternPageLocators.autoGeneratedFirstEvent).last().should(assertionConstants.containAssertion, 'AdditionalInfo')
    cy.get(createPatternPageLocators.autoGeneratedFirstEvent).last().should(assertionConstants.containAssertion, conditionTextUnderEvent)

  }

  incrementedNameOfEvent() {
    cy.get(createPatternPageLocators.autoGeneratedEventName).last().should(assertionConstants.haveTextAssertion, ' EventLog3 ')
  }

  groupButtonDisabled() {
    cy.get(createPatternPageLocators.groupButton).last().should(assertionConstants.notBeEnabledAssertion)
  }

  eventOneRemoveOptionEnabled() {
    cy.get(createPatternPageLocators.eventOneRemoveOption).last().should(assertionConstants.notBeDisabledAssertion)
  }

  logicalExpressionInCopiedVisible() {
    cy.get(createPatternPageLocators.AutoGeneratedFirstCondition).last().should(assertionConstants.beVisibleAssertion)
  }

  attributeDropDownOptionForConditionOneEvent3Click() {
    cy.get(createPatternPageLocators.addedExpressionForEvent).eq(2).click()
  }

  equipmentNumberAttributeOptionsForEventTwoConditionFourClick() {
    cy.get(createPatternPageLocators.attributeForSecondCondition).eq(2).click()
  }

  operatorDropDownForConditionOneEvent3Click() {
    cy.get(createPatternPageLocators.operatorForEventOne).eq(2).click()
  }

  attributeDropDownOfFirstConditionOfFirstEventWithAdditionalInfoText() {
    cy.get(createPatternPageLocators.attributeDropDown).first().find('span').first().should(assertionConstants.notHaveTextAssertion, 'EquipmentNumber')
  }

  attributeDropDownOfConditionOneInEventOneClick() {
    cy.get(createPatternPageLocators.attributeDropDown).first().click()
  }

  indexAttributeOptionsForEventTwoConditionFourClick() {
    cy.get(createPatternPageLocators.attributeForSecondCondition).eq(7).click()
  }

  clonedEventWithSameConditiondAndUpdates() {
    cy.get(createPatternPageLocators.autoGeneratedFirstEvent).last().should('contain', ConditionTwoText)
    cy.get(createPatternPageLocators.attributeDropDown).eq(5).should(assertionConstants.containAssertion, 'EquipmentNumber')

  }

  operatorDropdownAboveCopiedEventClick() {
    cy.get(operatorDropdownAtEventAndCondition).eq(8).click()
  }

  logicalExpressionAfterGroupingActualANdCopiedEvent() {
    cy.get(createPatternPageLocators.logicalExpressionAtEventLevel).invoke('text').then((expression) => {
      expect(expression).to.include('[     (   EventLog1  )  AND EventLog4  ]')
    })
  }

  logicalExpressionAsPerUpdatedUngroupedEventsEvent() {
    cy.get(createPatternPageLocators.logicalExpressionAtEventLevel).invoke('text').then((expression) => {
      expect(expression).to.not.include('(   EventLog1  AND EventLog4  )')
    })
  }

  groupOptionDisabledForUngroupedEvents() {
    cy.get(createPatternPageLocators.groupButton).first().should(assertionConstants.notBeEnabledAssertion)
    cy.get(createPatternPageLocators.groupButton).eq(1).should(assertionConstants.notBeEnabledAssertion)
  }

  checkBoxAtEventClick() {
    cy.get(createPatternPageLocators.checkBox).eq(5).click()
  }

  popUpDeleteOption() {
    return cy.get(createPatternPageLocators.popUpDeleteOption).click()
  }

  popUpDeleteOptionVisible() {
    return cy.get(createPatternPageLocators.popUpDeleteOption).should(assertionConstants.beVisibleAssertion)
  }

  crossMarkAtSecondGroupedEventsClick() {
    cy.get(createPatternPageLocators.crossMarkAtGroupedEvents).click()
  }

  groupedEventsDeletedVerification() {
    cy.contains(secondEventName).should(assertionConstants.notExistsAssertion)
    cy.contains(firstEventName).should(assertionConstants.notExistsAssertion)
  }

  savedEventFourUnderFromVariableVisible() {
    cy.get(createPatternPageLocators.dataModel).find('span').should(assertionConstants.haveTextAssertion, 'EventLog3').and(assertionConstants.beVisibleAssertion)
  }

  eventsAddedFromRulePatternUnderFromVariableVisible() {
    cy.get(createPatternPageLocators.eventFiveUnderFromVariable).children('span').should(assertionConstants.haveTextAssertion, 'EventLog4').and(assertionConstants.beVisibleAssertion)
    cy.get(createPatternPageLocators.eventSixUnderFromVariable).children('span').should(assertionConstants.haveTextAssertion, 'EventLog5').and(assertionConstants.beVisibleAssertion)
    cy.get(createPatternPageLocators.eventSevenUnderFromVariable).children('span').should(assertionConstants.haveTextAssertion, 'EventLog6').and(assertionConstants.beVisibleAssertion)
    cy.get(createPatternPageLocators.createPatternPageLocators.eventEightUnderFromVariable).children('span').should(assertionConstants.haveTextAssertion, 'EventLog7').and(assertionConstants.beVisibleAssertion)
  }

  eventFiveUnderFromVariableClick() {
    cy.get(createPatternPageLocators.eventFiveUnderFromVariable).click()
  }

  eventSixUnderFromVariableClick() {
    cy.get(createPatternPageLocators.eventSixUnderFromVariable).click()
  }


  eventSevenUnderFromVariableClick() {
    cy.get(createPatternPageLocators.eventSevenUnderFromVariable).click()
  }

  eventEightUnderFromVariableClick() {
    cy.get(createPatternPageLocators.eventEightUnderFromVariable).click()
  }

  eventWithOperatorsAttributesAndConditionAddedFromRulePatternVisible() {
    cy.get(createPatternPageLocators.autoGeneratedFirstEvent).last().should(assertionConstants.containAssertion, 'Operator')
    cy.get(createPatternPageLocators.autoGeneratedFirstEvent).last().should(assertionConstants.containAssertion, 'Description')
    cy.get(createPatternPageLocators.autoGeneratedFirstEvent).last().should(assertionConstants.containAssertion, conditionTextUnderEvent)

  }

  incrementedNameOfEventAddedFromRulePattern() {
    cy.get(createPatternPageLocators.autoGeneratedEventName).last().should(assertionConstants.haveTextAssertion, ' EventLog8 ')
  }

  addConditionButtonForEventNineClick() {
    cy.get(createPatternPageLocators.addConditionButton).last().click()
  }

  attributeDropDownOptionForConditionTwoEventNineClick() {
    cy.get(createPatternPageLocators.addedExpressionForEvent).last().click()
  }

  operatorDropDownForCondition2EventNineClick() {
    cy.get(createPatternPageLocators.operatorForEventOne).last().click()
  }

  valueForCondition2EventNineType() {
    cy.get(createPatternPageLocators.valueOptionForSecondCondition).last().type(1)
  }

  operatorDropdownAtEventAndConditionForEventNineClick() {
    cy.get(createPatternPageLocators.operatorDropdownAtEventAndCondition).last().click()
  }

  logicalExpressionInCopiedEventInRulePatternVisible() {
    cy.get(createPatternPageLocators.AutoGeneratedFirstCondition).last().should(assertionConstants.beVisibleAssertion)
  }

  attributeDropdownForConditionOneInEventNineClick() {
    cy.get(createPatternPageLocators.attributeDropDown).eq(10).click()
  }

  lineNumberAttributeClick() {
    cy.contains(lineNumberAttribute).click()
  }

  attributeDropDownOfFirstConditionOfFifthEventWithDescriptionText() {
    cy.get(createPatternPageLocators.attributeDropDown).eq(2).find('span').first().should(assertionConstants.notHaveTextAssertion, 'LineNumber')
  }

  attributeDropdownAtConditionThreeInEventFiveClick() {
    cy.get(createPatternPageLocators.addedExpressionForEvent).eq(5).click()
  }

  operatorSelectionForConditionFourInEventFiveClick() {
    cy.get(createPatternPageLocators.operatorsUnderAttributeDropdown).eq(1).click()
  }

  operatorDropdownForConditionFourInEvenetFiveClick() {
    cy.get(createPatternPageLocators.operator).eq(5).click()
  }

  valueOptionForFourthConditionInEventFiveType() {
    cy.get(createPatternPageLocators.valueOptionForSecondCondition).eq(5).type(4)
  }

  clonedEventWithSameConditiondAndUpdatesInRulePattern() {
    cy.get(createPatternPageLocators.autoGeneratedFirstEvent).last().should('contain', ConditionFourText)
    cy.get(createPatternPageLocators.attributeDropDown).eq(15).should(assertionConstants.containAssertion, 'Component')

  }

  operatorDropdownAboveCopiedEventFromRulePatternClick() {
    cy.get(createPatternPageLocators.operatorDropdownAtEventAndCondition).eq(21).click()
  }

  checkBoxAtEventFiveForRulePatternClick() {
    cy.get(createPatternPageLocators.checkBox).eq(3).click()
  }

  checkBoxAtEventTenForRulePatternClick() {
    cy.get(createPatternPageLocators.checkBox).eq(21).click()
  }


  logicalExpressionAfterGroupingActualAndCopiedEventForRulePattern() {
    cy.get(createPatternPageLocators.logicalExpressionAtEventLevel).invoke('text').then((expression) => {
      expect(expression).to.include('(   EventLog4  AND EventLog9  )')
    })
  }

  logicalExpressionAsPerUpdatedUngroupedEventsForRulePatternEvent() {
    cy.get(createPatternPageLocators.logicalExpressionAtEventLevel).invoke('text').then((expression) => {
      expect(expression).to.not.include('(   EventLog5  AND EventLog10  )')
    })
  }

  groupOptionDisabledForUngroupedEventsForRulePattern() {
    cy.get(createPatternPageLocators.groupButton).eq(1).should(assertionConstants.notBeEnabledAssertion)
    cy.get(createPatternPageLocators.groupButton).eq(2).should(assertionConstants.notBeEnabledAssertion)
  }

  eventFiveRemoveOptionClick() {
    return cy.get(createPatternPageLocators.eventOneRemoveOption).eq(1).click()
  }

  eventFiveVisible() {
    cy.get(createPatternPageLocators.autoGeneratedFirstEvent).eq(1).should(assertionConstants.containAssertion, ' EventLog5 ').and(assertionConstants.beVisibleAssertion)
  }

  eventFiveNotExist() {
    cy.get(createPatternPageLocators.autoGeneratedFirstEvent).should(assertionConstants.notContainAssertion, ' EventLog5 ')
  }

  operatorDropdownBetweenEventEightAndNineFromRulePatternClick() {
    cy.get(createPatternPageLocators.operatorDropdownAtEventAndCondition).eq(16).click()
  }

  checkBoxAtEventSixForRulePatternClick() {
    cy.get(createPatternPageLocators.checkBox).eq(8).click()
  }

  checkBoxAtEventSevenForRulePatternClick() {
    cy.get(createPatternPageLocators.checkBox).eq(10).click()
  }

  checkBoxAtEventEightForRulePatternClick() {
    cy.get(createPatternPageLocators.checkBox).eq(13).click()
  }

  checkBoxAtEventNineForRulePatternClick() {
    cy.get(createPatternPageLocators.checkBox).eq(16).click()
  }

  groupedEventsAddedFromRulePatternDeletedVerification() {
    cy.contains(eventSixName).should(assertionConstants.notExistsAssertion)
    cy.contains(eventSevenName).should(assertionConstants.notExistsAssertion)
    cy.contains(eventEightName).should(assertionConstants.notExistsAssertion)
  }

  savedEventTenUnderFromVariableForRulePatternVisible() {
    cy.get(createPatternPageLocators.eventFiveUnderFromVariable).find('span').should(assertionConstants.haveTextAssertion, 'EventLog9').and(assertionConstants.beVisibleAssertion)
  }

  eventsAndConditionsInSequence() {
    cy.get(createPatternPageLocators.autoGeneratedFirstEvent).eq(0).should('contain', firstEventName)
    cy.get(createPatternPageLocators.autoGeneratedFirstEvent).eq(1).should('contain', secondEventName)
    cy.get(createPatternPageLocators.autoGeneratedFirstEvent).eq(0).find('[id="exp-cont_0"]').first().should('contain', conditionTextUnderEvent)
    cy.get(createPatternPageLocators.autoGeneratedFirstEvent).eq(0).find('[id="exp-cont_1"]').first().should('contain', conditionTwoTextUnderEvent)
    cy.get(createPatternPageLocators.autoGeneratedFirstEvent).eq(1).find('[id="exp-cont_0"]').last().should('contain', conditionTextUnderEvent)
    cy.get(createPatternPageLocators.autoGeneratedFirstEvent).eq(1).find('[id="exp-cont_1"]').last().should('contain', conditionTwoTextUnderEvent)

  }

  discriptioAttributeClick() {
    cy.contains(discriptioAttribute).click()
  }

  processIdAttributeClick() {
    cy.contains(processIdAttribute).click()
  }

  relatedEventIndexAttributeClick() {
    cy.contains(relatedEventIndexAttribute).click()
  }

  valueInputBoxForConditionSevenType() {
    cy.get(createPatternPageLocators.valueWaterMark).eq(6).type(5)
  }

  operatorDropdownBetweenAttrAndValueForconditionSevenClick() {
    cy.get(createPatternPageLocators.operatorForEventOne).eq(6).click()
  }

  systemUIDAttributeClick() {
    cy.contains(systemUIDAttribute).click()
  }

  operatorDropdownBetweenAttrAndValueForconditionEightClick() {
    cy.get(createPatternPageLocators.operatorForEventOne).eq(8).click()
  }

  valueInputBoxForConditionEightType() {
    cy.get(createPatternPageLocators.valueWaterMark).eq(8).type(2)
  }

  attributeDropDownForConditionEightClick() {
    cy.get(createPatternPageLocators.addedExpressionForEvent).eq(8).click()
  }

  addedExpressionForEventTwoInRedColor() {
    return cy.get(createPatternPageLocators.addedExpressionForEvent).first().should(assertionConstants.haveAttributeAssertion, 'class', 'pt-dropdown ng-untouched ng-pristine ng-valid')
  }

  logicalExpressionWithDeletedFirstEvent() {
    cy.get(createPatternPageLocators.logicalExpressionAtEventLevel).should(assertionConstants.notContainAssertion, firstEventName)
  }

  incrementedNameOfEventAfterEventThree() {
    cy.get(createPatternPageLocators.autoGeneratedEventName).last().should(assertionConstants.haveTextAssertion, ' EventLog4 ')
  }

  crossMarkOfEventFourClick() {
    cy.get(createPatternPageLocators.eventOneRemoveOption).last().click()
  }

  crossMarkAtConditionTwoInEventOneClick() {
    cy.get(createPatternPageLocators.crossMarkAtConditionLevel).eq(1).click()
  }

  updatedLogicalExpressionUnderEventAfterRemovingConditionTwo() {
    cy.get(createPatternPageLocators.AutoGeneratedFirstCondition).first().should(assertionConstants.notContainAssertion, 'C2')
  }

  operatorDropdownBetweenEventTwoAndThreeWithOutOperator() {
    cy.get(createPatternPageLocators.mainOperatorDropdownArrowUnderTesttwo).eq(4).find('[class="pt-placeholder ng-star-inserted"]').first().should(assertionConstants.haveTextAssertion, 'Operator')
  }

  relevanceNoResultsFoundMessageTextVisible() {
    cy.contains(relevanceNoResultsFoundMessageText).should(assertionConstants.beVisibleAssertion)
  }

  patternNameIndicatorTextNotExist() {
    cy.contains(createPatternPageLocators.patternNameIndicatorText).should(assertionConstants.notExistsAssertion)
  }

  saveAsDraftOnCreatePatternEnabled() {
    cy.get(createPatternPageLocators.saveAsDraft).should(assertionConstants.notBeDisabledAssertion)
  }

  saveAsDraftOnCreatePatternDisabled() {
    cy.get(createPatternPageLocators.saveAsDraft).should(assertionConstants.notBeEnabledAssertion)
  }

  selectedRaiseAlertoptionTextVisible() {
    cy.contains(selectedRaiseAlertoptionText).should(assertionConstants.beVisibleAssertion)
  }

  userOnCreatePatternPageVerification() {
    return cy.get(createPatternPageLocators.createPatternGridAsSelected).should(assertionConstants.haveAttributeAssertion, 'class', 'ng-star-inserted active')
  }

  insertAlertTextInUIVisible() {
    cy.contains(insertAlertText).should(assertionConstants.beVisibleAssertion)
  }

  suppressAlertOptionSelect() {
    cy.get(createPatternPageLocators.supressAlertOption).click()
  }

  supressAlertOptionTextVisible() {
    cy.contains(selectedsupressAlertOptionText).should(assertionConstants.beVisibleAssertion)
  }

  modalityDropdownfieldInApplyMatadataPageClick() {
    cy.get(createPatternPageLocators.modalityDropdownfield).last().click({ force: true })
  }

  severityFieldsSecondOptionInapplyMetadataPageClick() {
    cy.get(createPatternPageLocators.severityFields).eq(1).click()
  }

  severityTextAfterUpdationVisible() {
    cy.contains(createPatternPageLocators.severityTextAfterUpdation).should(assertionConstants.beVisibleAssertion)
  }

  severityFieldsThirdOptionInapplyMetadataPageClick() {
    cy.get(createPatternPageLocators.severityFields).eq(2).click({ force: true })
  }

  severityTextAFterSecondTimeUpdationVisible() {
    cy.contains(severityTextAFterSecondTimeUpdation).should(assertionConstants.beVisibleAssertion)
  }

  getPatternName() {
    cy.get(createPatternPageLocators.patternDashboardBreadCrum).find(createPatternPageLocators.ptLayoutContainerClass).find('ul').children('li').last().find('a').find('span').invoke('text').then((Name) => {
      patternNames.push(Name)
      cy.wait(3000)
      cy.log(patternNames)
    })
  }

  eventOneVisible() {
    cy.get(createPatternPageLocators.autoGeneratedFirstEvent).first().should(assertionConstants.containAssertion, ' EventLog1 ').and(assertionConstants.beVisibleAssertion)
  }

  includeKnowledgeHeadingPendingVerification() {
    return cy.get(createPatternPageLocators.includeKnowledgeHeading).should(assertionConstants.haveAttributeAssertion, 'class', createPatternPageLocators.AddAuthoringWokFlowButtonClickngStarInsertedClass)
  }

  applyMetadataHeadingActiveVerification() {
    return cy.get(createPatternPageLocators.applyMetadataHeading).should(assertionConstants.haveAttributeAssertion, 'class', createPatternPageLocators.ngStarInsertedActiveClass)
  }

  createdPatternClick() {
    cy.get(createPatternPageLocators.createdPattern).eq(1).children().last().click()
  }

 
  PatternNameSearchInSearchOption() {
    return cy.get(createPatternPageLocators.patternFilterOption).then((PatternName)=>{
        cy.wrap(PatternName).type(patternNames[0])
    })
}

  patternNameOnDetailsPageClick() {
    cy.get(createPatternPageLocators.patternNameOnDetailsPage).invoke('text').then((patternName) => {
      cy.contains(patternName).click()
      cy.wait(2000)
    })
  } 

  filterForKeywordTypeKnowledgeName() {
    cy.get(createPatternPageLocators.filterForKeyword).type(patternName[0])
  }

  secondPatternNameSearchInSearchOption() {
    return cy.get(createPatternPageLocators.patternFilterOption).then((PatternName)=>{
        cy.wrap(PatternName).type(patternNames[1])
    })
  }

  searchByKeyWordPublishedPatternNameType() {
    return cy.get(createPatternPageLocators.searchByKeyWordOption).type(patternNames[0])
  }

  publishedPatternRecordInRulePatternVisible(){
    cy.get(createPatternPageLocators.publishedPatternRecordInRulePattern).should(assertionConstants.beVisibleAssertion)
  }

  cancelButtononPopUpClick() {
    return cy.get(createPatternPageLocators.cancelButtonPopUp).last().click()
  }

  deletedPatternNameSearchInSearchOption() {
    return cy.get(createPatternPageLocators.patternFilterOption).clear().type(patternNames[0])
 }

 PatternNameSearchInSearchOptionForPublishingPatternFromThreeDots() {
  return cy.get(createPatternPageLocators.patternFilterOption).then((PatternName)=>{
      cy.wrap(PatternName).type(patternNames[1])
  })
}

modalityDropdownInApplyMetadataOptionWithIGTSelection() {
  cy.get(createPatternPageLocators.addTagFromList).eq(0).click()
  return cy.get(createPatternPageLocators.addTagFromList).eq(1).click()

}

publishedPatternVisible() {
  cy.get(availablePatternsList).should(assertionConstants.beVisibleAssertion)
}

secondPatternNameSearchInSearchOption() {
  return cy.get(patternFilterOption).then((PatternName)=>{
      cy.wrap(PatternName).type(patternNames[1])
  })
} 
}

export default CreatePattern;

