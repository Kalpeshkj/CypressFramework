import "../../../index";

// Contants
const patternNameThreeDots = " > #nav-dropdown-btn > .ng-star-inserted > #Layer_1";
const clickOnAnyPattern = 'User Click on any pattern'
const patternDetailsInReadOnlyMode = 'Pattern details should be available in read only mode'


class Constants {
  existingPublishedKnowledgesDisplayedText = 'All existing published knowledges Symptom displayed'
  selectedSymptomDisplayedInReadMode = 'Selected Symptom displayed in read only mode'
  applicationLaunched = ' Application launched'
  testCaseExecuted = ' Test Case Executed Successfully'

  
  patternNameThreeDots() {
    return patternNameThreeDots;
  }

  clickOnAnyPattern(){
    return clickOnAnyPattern;
  }

  patternDetailsInReadOnlyMode(){
    return patternDetailsInReadOnlyMode; 
  }

  
}
export default Constants;
