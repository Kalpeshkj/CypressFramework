class ApplyMetadataPageLocators{
dayspanDayTextbox = '#dayspan>dls-layout-container.pt-layout-container>input'
applymetadataDropdownContainers = 'div>dls-dropdown>dls-layout-container.pt-layout-container'
fullScreenButton = 'img[alt="Expand"]'
collapsedNavigationPanelBlock = '.sidebar_block'
addTagFromList = 'dls-multiselect-option[role="option"]'
modalityDropdownInApplyMetadata = 'dls-multiselect[role="listbox"]';
productFamilyRelevanceInCollapsed = 'div[aria-posinset="2"]>button'
modalityDropdownInRelevance = 'div[aria-posinset="1"]>button'
modalityDropdownInApplyMetadataSection = "dls-layout-container>span"
relevanceInExpanded = 'li>div[aria-posinset="1"]'
applyMetadataActiveVerification = "#step-1" 
ngStarInsertedActiveClass = 'ng-star-inserted active'
applyMetadataHeading = "#step-1"
newlyCreatedPatternText = '#pat-name'
previousButtonClick = "//span[contains(text(),'Previous')]"
closeButton = "div>button#pat-close>dls-layout-container"
saveAsDraftButton = '[id="pat-draft"]'
nextButtonDisabledVerification = "button[id='pat-step-next']"
optionOnApplyMetadataPage = '.field-name.mb-0'
daySpanTextBoxWithDefaultWatermark = '[formcontrolname="dayspan"]'
daySpanUnitTextBox =  '#dayspan-unit'
daySpanUnits = '.pt-option-list'
rangePlaceholder = '.range-indicator'
commentFieldCharacterText = '.char-count.width-100'
fullScreenViewButton = 'button[class="pt-quiet-default icon-fullscreen pl-0 pt-button"]'
version = '.version-info.pt-label'
commentBox = "#comment"
WaterMarks = '[class="width-100 pt-dropdown ng-untouched ng-pristine ng-invalid ng-star-inserted"]'
serviceContextWaterMark = '[class="width-100 pt-multiselect ng-untouched ng-invalid ng-star-inserted ng-dirty"]>dls-layout-container>span'
serviceContextFields = ".pt-option-list > :nth-child(1)"
modalityDropdownfield = ".ng-star-inserted >.pt-layout-container > .ng-star-inserted"
fieldsWithRedBorder = '[class="width-100 pt-multiselect ng-star-inserted ng-dirty ng-touched ng-invalid"]'
severityWithText = '[class="width-100 pt-dropdown ng-star-inserted ng-touched ng-dirty ng-valid"]'
severityFields = ".pt-option-list >.pt-option"
addTagOption = '[id="add-tag-btn"]'
addTagPopUp = '[id="undefined"]'
withOutKeywordOption = '[id="without-keyword"]'
withkeywordOption = '[id="with-keyword"]'
withOutKeywordSerchOption = '[name="withoutKeyword"]'
tagValuesUnderDropdown = '[class="pt-multiselect-option ng-star-inserted"]'
addTagPlusIcon = '[id="add-select-tag"]'
addedTagsSection = '[class="col-12"]'
keywordField = '[name="keyword"]'
operatorField = '[name="operator"]'
valueField = '[id="select-value"]'
dropdownOptions = '[class="pt-option ng-star-inserted"]'
doneButton = '[id="done-btn-popup"]'
tagValueUnderAddtagSection = '[class="pt-token-only float-left ng-star-inserted"]'
selectiongAllUnderRelevnce = '[class="p-checkbox-box"]'
}

export default ApplyMetadataPageLocators;