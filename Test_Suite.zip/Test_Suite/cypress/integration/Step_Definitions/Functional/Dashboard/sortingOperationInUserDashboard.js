/// <reference types="Cypress" />
/// <reference types='cypress-tags' />

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import TagDashboard from "../../../../support/pageObjects/pages/Dashboard/TagDashboard";
import UserDashboard from "../../../../support/pageObjects/pages/Dashboard/UserDashboard";
const userDashboard = new UserDashboard();
const tagDashboard = new TagDashboard();



When("User clicks on the username on top right corner of the page", () => {
    userDashboard.settingsDropdownClick()
    console.log(printTimestamp(), ' Clicked on the username')
});

Then("Settings option should be available there", () => {
    userDashboard.settinsOptionVisible()
    console.log(printTimestamp(), ' Settings option displayed')
});

And("Verifies Test box should be present for User Email,Name and Added By columns for filtering", () => {
    userDashboard.FilterTextboxVisible();
    console.log(printTimestamp(), ' Verifies Test box should be present for User Email,Name and Added By columns for filtering')
});

When("User Insert any text on the text box available in each of the columns", () => {
    userDashboard.userEmailColumnFilterValidation();
    userDashboard.userNameColumnFilterValidation();
    console.log(printTimestamp(), ' Inserted text on the text box')
});

Then('Data should get filtered based on the search data given in text box', () => {
    userDashboard.filteredDataVerification();
    console.log(printTimestamp(), ' Data filtered based on the search data')
});

And("Verifies clear all filters button present on right top", () => {
    userDashboard.clearAllFilterButtonVisible();
    console.log(printTimestamp(), ' Clear all filters button present')
});

When("User Clicks on Clear All filters", () => {
    userDashboard.clearAllFilterButtonClick();
    console.log(printTimestamp(), ' Clicked on Clear All filter')
});

Then("All the filters should be removed and entire data should be displayed", () => {
    userDashboard.ClearedFilterValidation();
    console.log(printTimestamp(), ' All the filters removed')
});

When("User Insert any text which doesnt have result on the text box available in each of the columns", () => {
    userDashboard.invalidUserNameColumnFilterValidation();
    console.log(printTimestamp(), ' Inserted any text which doesnt have result')
});

Then("No Records found should be displayed in the dashboard", () => {
    userDashboard.noRecordsFoundTextVisible();
    console.log(printTimestamp(), ' No Records found displayed')
});

And("Verifies Group Name column has a drop down to perform multi select", () => {
    userDashboard.groupNameColumnDropDownCheckboxVisible();
    console.log(printTimestamp(), ' Verified Group Name column has a drop down')
});

When("User Click on the drop down option available for Group Name column", () => {
    userDashboard.groupNameColumnFilterClick()
    cy.log('Group Name Column is already open, No need to re open')
    console.log(printTimestamp(), ' Clicked on the drop down option available for Group Name column')
});

Then("There must be a search box to search values and All the values in the drop down should be sorted in ascending order", () => {
    userDashboard.searchBoxInGroupNameColumnVisible();
    console.log(printTimestamp(), ' search box to search values present')
});

When("User Click on the dropdown option available for Group Name column and select multiple options", () => {
    userDashboard.groupNameDropdownOptionClick()
    userDashboard.groupNameColumnDropDownCheckboxClick();
    console.log(printTimestamp(), ' Clicked on the dropdown option available for Group Name column')
});

Then("The data should be filtered based on the options selected", () => {
    userDashboard.groupNameColumnFilteredDataVerification();
    console.log(printTimestamp(), ' Data should be filtered')
});

And("Verifies the Group Name column having more than one Group Value", () => {
    userDashboard.groupNameFilteredRecordsVisible();
    console.log(printTimestamp(), ' Verified the Group Name column having more than one Group Value')
});

And("Verifies date picker is available for Added On column to filter based on date", () => {
    userDashboard.datePickerVisibleConfirmationAtAddedOnColumn();
    console.log(printTimestamp(), ' Verified date picker is available for Added On column')

});

When("User Click on date picker icon in Added On column and choose the current or previous date", () => {
    userDashboard.todaysDateSelectionAtAddedOnColumn();
    console.log(printTimestamp(), ' Clicked on date picker icon in Added On column and choose the current or previous date')
});

Then("Data should be filtered based on the chose date", () => {
    cy.log('Data is not present for current month, so wont be able to validate this step')
    console.log(printTimestamp(), ' Data filtered based on the chose date')

});

When("User Clicks on each column and verifies sorting", () => {
    userDashboard.userEmailColumnClickAndSortingOfDataVerification();
    console.log(printTimestamp(), ' Clicks on each column and verified sorting')
});

When("User Choose 10,15,20,50,100 and 500 entries per page one by one", () => {
    userDashboard.entriesPerPageValuesVerification();
    console.log(printTimestamp(), ' User Choose 10,15,20,50,100 and 500 entries per page one by one')
 
});

When("The data grid should show the results as per the entries selected per page", () => {
    userDashboard.entriesPerPageValuesChangedToTwentyVerification();
    console.log(printTimestamp(), ' Data grid shown the results as per the entries selected per page')
});

And("Verifies the page navigation buttons by clicking on Next and previous pages", () => {
    userDashboard.pageNavigationValidation();
    console.log(printTimestamp(), ' Verified the page navigation buttons by clicking on Next and previous pages')
});
