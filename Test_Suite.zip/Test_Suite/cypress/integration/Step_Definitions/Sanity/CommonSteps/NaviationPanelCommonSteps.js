import "../../../../support/index";
import { Then, When} from "cypress-cucumber-preprocessor/steps";
import NavigationPanel from "../../../../support/pageObjects/pages/Dashboard/NavigationPanel";
const navigationPanel = new NavigationPanel();
import {printTimestamp} from '../../../../support/commands';


Then("Dashboard should be in selected state", () => {
    navigationPanel.selectedDashboard()
    console.log(printTimestamp(), 'Verified Dashboard in selected state')
});

Then("Three Vertical dots should be present", () => {
    navigationPanel.threeverticalDotsVisible()
    console.log(printTimestamp(), ' Verified Three vertival dots present')
});

Then("My ReviewDashboard, Rules, Models, Plots should be in disabled state", () => {
    navigationPanel.myReviewDashboard()
    navigationPanel.rules()
    navigationPanel.models()
    navigationPanel.plots()
    console.log(printTimestamp(), ' Verified My ReviewDashboard, Rules, Models, Plots should be in disabled ')
});

Then("Home,Patterns,Dashboard breadcrum should be present", () => {
    navigationPanel.breadcrumbVisible()
    console.log(printTimestamp(), ' Verified Home,Patterns,Dashboard breadcrum should be present')
});

Then("Home should not be in the disabled State", () => {
    navigationPanel.homeDisabled()
    console.log(printTimestamp(), 'Verified Home should not be in the disabled State')
});

When("User Clicks on collapsable caret on the pattern tab", () => {
    navigationPanel.collasableCaretOfPatternsClick()
    console.log(printTimestamp(), ' Clicked on collapsable caret')
});

Then("Patterns, Knowledge, Rules, Models, Plots should be displayed", () => {
    navigationPanel.patternsVisible()
    navigationPanel.knowledgeVisible()
    navigationPanel.rulesVisible()
    navigationPanel.modelsVisible()
    navigationPanel.plotsVisible()
    console.log(printTimestamp(), 'Patterns, Knowledge, Rules, Models, Plots are displayed')
});

Then("Only patterns is collapsable Then Expandable", () => {
    navigationPanel.patternCollapsableandExpandable()
    console.log(printTimestamp(), 'Only patterns is collapsable Then Expandable')
});

When("All options are in collapsable State", () => {
    navigationPanel.allOptions()
    console.log(printTimestamp(), ' Verified All options are in collapsable State')
});

Then("Home,Patterns,Dashboard breadcrum should be present", () => {
    navigationPanel.breadcrumbVisible()
    console.log(printTimestamp(), ' Verified Home,Patterns,Dashboard breadcrum should be present')
});

Then("Home should not be in the disabled State", () => {
    navigationPanel.homeDisabled()
    console.log(printTimestamp(), 'Verified Home should not be in the disabled State')
});

When("User clicks on pattern tab and then My Pattern is Expanded", () => {
    navigationPanel.PatternTabClick()
    navigationPanel.MyPatternClick()
    console.log(printTimestamp(), ' clicked on pattern tab and then My Pattern is Expanded')
});

Then("Dashboard, Authoring Workflow should be displayed", () => {
    navigationPanel.dashboardUnderMyPatternVisible()
    navigationPanel.authoringWorkFlowUnderMyPatternvisible()
    console.log(printTimestamp(), 'Dashboard, Authoring Workflow are displayed')
});

When("User clicks on three vertical dots of My Pattern", () => {
    navigationPanel.threeverticalDotsClick()
    cy.wait(1000)
    console.log(printTimestamp(), ' clicked on three vertical dots of My Pattern')
});

Then("Create pattern button should be present", () => {
    navigationPanel.createPatternButtonVisible()
    console.log(printTimestamp(), ' Verified Create pattern button are present')
});

When("User clicks on arrow mark available in bottom panel", () => {
    navigationPanel.ArrowMarkClick()
    console.log(printTimestamp(), ' clicked on arrow mark available in bottom panel')
});

Then("Left pane should collapse", () => {
    navigationPanel.leftPanelNotVisible()
    console.log(printTimestamp(), ' Verified Left pane should collapse')
});

Then("Horizontal Label Navigation Panel should be present", () => {
    navigationPanel.navigationPanelLable()
    console.log(printTimestamp(), ' Verified Horizontal Label Navigation Panel is present')
});

When("User relaunches application", () => {
    navigationPanel.relaunchApplication();
    console.log(printTimestamp(), 'User relaunched application')
});

Then("Pattern Should be in Expanded State", () => {
    navigationPanel.patternExpanded()
    console.log(printTimestamp(), ' Verified Pattern Should be in Expanded State')
});

When("User clicks on arrow mark available in bottom panel", () => {
    navigationPanel.ArrowMark()
    console.log(printTimestamp(), ' clicked on arrow mark available in bottom panel')
});

Then("Left pane should collapse", () => {
    navigationPanel.leftPane()
    console.log(printTimestamp(), ' Verified Left pane should collapse')
});

Then("Close the Application", () => {
    cy.log('Test case executed successfully')
    console.log(printTimestamp(), 'Test case executed successfully')
});
