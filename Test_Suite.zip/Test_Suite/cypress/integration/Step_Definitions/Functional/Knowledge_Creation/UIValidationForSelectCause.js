/// <reference types="Cypress" />
/// <reference types = 'cypress-tags' />  

import "../../../../support/index"
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';
import CreateKnowledge from "../../../../support/pageObjects/pages/KnowledgeAuthoring/CreateKnowledge";
const createKnowledge = new CreateKnowledge();

When("User should be able to navigate to existing knowledge workflow or create new knowledge workflow", () => {
    createKnowledge.knowledgeClick()
    createKnowledge.addKnowledgeWorkflowButtonClick()
    cy.wait(3000)
    console.log(printTimestamp(), 'User able to navigate to existing knowledge workflow or create new knowledge workflow')
});

And("User should be able to add details in Knowledge Information section", () => {
    createKnowledge.knowledgeNameTextBoxType()
    createKnowledge.descriptionFiledTextBoxType()
    console.log(printTimestamp(), 'User able to add details in Knowledge Information section')
});

And("expand Causes and Solutions section", () => {
    createKnowledge.causeAndSolutionSectionClick()
    console.log(printTimestamp(), 'expanded Causes and Solutions section')
});

When("user click on Select cause button", () => {
    createKnowledge.selectCauseButtonClick()
    cy.wait(2000)
    console.log(printTimestamp(), 'clicked on Select cause button')
});

Then("Select Cause pop up should get displayed", () => {
    createKnowledge.selectCausePopupVisible()
    console.log(printTimestamp(), 'Select Cause pop up gets displayed')
});

And("None of cause details should be displayed", () => {
    createKnowledge.causeDetailsNotVisible()
    console.log(printTimestamp(), 'None of cause details displayed')
})
And("Select Cause as title,'Search for a cause or click on  Show All to view all available causes' should be displayed", () => {
    createKnowledge.selectCauseTitleVisible()
    createKnowledge.messageBelowSelectCauseTitleVisible()
    console.log(printTimestamp(), 'Select Cause as title,"Search for a cause or click on  Show All to view all available causes" displayed')
});

And("Drop down for keyword where All is by default selected,Search textbox with 'Search by Keyword' watermark,"
    + "Show All check box should be displayed", () => {
        createKnowledge.dropdownWithAllSelectedVisible()
        createKnowledge.searchByKeywordtextBoxWithText()
        console.log(printTimestamp(), "Drop down for keyword where All is by default selected,Search textbox with 'Search by Keyword' watermark,"
            + "Show All check box displayed")
    });

When("User Click on Show All check box", () => {
    createKnowledge.showAllCheckboxClick()
    console.log(printTimestamp(), 'Clicked on Show All check box')
});

Then("Select option at each row for single multi select  -Column level filter,Displayed records of Total records found", () => {
    createKnowledge.selectAllCkeckBoxVisible()
    createKnowledge.recordsCountVisible()
    console.log(printTimestamp(), 'Select option at each row for single multi select  -Column level filter,Displayed records of Total records found')
});

And("Cancel and Select buttons at right bottom ,Entries per page  : drop down by default 10 displayed", () => {
    createKnowledge.cancelButtonVisible()
    createKnowledge.selectButtonVisible()
    createKnowledge.entriesPerPageDropdownVisible()
    createKnowledge.entriesPerPageDropdownTextVisible()
    console.log(printTimestamp(), 'Cancel and Select buttons at right bottom ,Entries per page  : drop down by default 10 displayed')
});

And("Showing current page of total page <>", () => {
    createKnowledge.currentPageNoText()
    console.log(printTimestamp(), 'Showing current page of total page <>')
});

When("User Change entries per page from drop down  option", () => {
    createKnowledge.entriesPerPageDropdownClick()
    createKnowledge.fiveEntriesPerpageOptionClick()
    cy.wait(2000)
    console.log(printTimestamp(), 'User Change entries per page from drop down  option')
});

Then("Based on selected value from drop down number of records should be display", () => {
    createKnowledge.selectedEntriesOfRecordsVisible()
    console.log(printTimestamp(), 'Based on selected value from drop down number of records display')
});

When("User click on > and nevigate to next page", () => {
    createKnowledge.arrowSymbolTonavigateToNextPageClick()
    createKnowledge.nextPage()
    console.log(printTimestamp(), 'clicked on > and nevigate to next page')
});

Then("Based on that,current page number and pattern details should be displayed", () => {
    createKnowledge.nextPageNoVisible()
    createKnowledge.nextPagePatternDetailsVisible()
    console.log(printTimestamp(), 'Based on that,current page number and pattern details displayed')
});

When("User click on < nevigate to previous page", () => {
    createKnowledge.arrowSymbolTonavigateToPreviousPageClick()
    createKnowledge.PreviousPage()
    console.log(printTimestamp(), 'clicked on < nevigate to previous page')
});

Then("Based on that,current page number and pattern detail should be displayed", () => {
    createKnowledge.PreviousPageNoVisible()
    createKnowledge.PreviousPagePatternDetailsVisible()
    console.log(printTimestamp(), 'Based on that,current page number and pattern detail displayed')
});

And("For first page < should be in disabled state", () => {
    createKnowledge.arrowSymbolTonavigateToPreviousPageDisabled()
    console.log(printTimestamp(), 'For first page < in disabled state')
});

When("User Change number of entries per page and navigate to next page", () => {
    createKnowledge.afterClickOnPreviousArrowEnriesPerPageClick()
    createKnowledge.TenEntriesPerpageOptionClick()
    createKnowledge.arrowSymbolTonavigateToNextPageClick()
    console.log(printTimestamp(), 'Changed number of entries per page and navigate to next page')
});

And("Click on  Cancel", () => {
    createKnowledge.cancelButtonClick()
    console.log(printTimestamp(), 'Clicked on  Cancel')
});

Then("pop up should get closed", () => {
    createKnowledge.selectCausePopupNotExist()
    console.log(printTimestamp(), 'pop up gets closed')
});

When("User open select cause pop up", () => {
    createKnowledge.selectCauseButtonClick()
    createKnowledge.showAllCheckboxClick()
    cy.wait(2000)
    console.log(printTimestamp(), 'open select cause pop up')
});

Then("Entries per page should be 10 Enteries  per page : by default 10 , other values in dropdown : 5 , 10 , 20 , 50 , 100", () => {
    createKnowledge.entriesPerPageDropdownTextVisible()
    createKnowledge.entriesPerPageDropdownClick()
    createKnowledge.entriesPerPageOptionsVerification()
    console.log(printTimestamp(), 'Entries per page 10 Enteries  per page : by default 10 , other values in dropdown : 5 , 10 , 20 , 50 , 100')
});

And("Showing first page of total page <> should be available", () => {
    createKnowledge.currentPageNoText()
    console.log(printTimestamp(), 'Showing first page of total page <> available')
});

And("Select  button should be disabled when none of cause is selected", () => {
    createKnowledge.selectButtonDisabled()
    console.log(printTimestamp(), 'Select  button disabled when none of cause is selected')
});

When("User selects any cause from grid", () => {
    createKnowledge.causeSearchOptionType()
    createKnowledge.causeSearchButtonClick()
    cy.wait(2000)
    createKnowledge.selectSearchedKnowledgeClick()
    console.log(printTimestamp(), 'selects any cause from grid')
});

Then("Grid should be resized", () => {
    createKnowledge.resizedGrid()
    console.log(printTimestamp(), 'Grid resized')
});

And("cause details should be displayed in right side,At a time only one cause should be selected", () => {
    createKnowledge.selectedCauseDetailsVisible()
    console.log(printTimestamp(), 'cause details displayed in right side,At a time only one cause selected')
});

And("Select button should be enabled when any cause is selected", () => {
    createKnowledge.selectButtonEnabled()
    console.log(printTimestamp(), 'Select button enabled when any cause is selected')
});

// When("User Hover on cause details grid", () => {


console.log(printTimestamp(), 'Hovered on cause details grid')
// });

// Then("Data should be available in tooltip", () => {

console.log(printTimestamp(), 'Data available in tooltip')
// });

And(">Collapse Details should be available", () => {
    createKnowledge.collapseDetailsIconVisible()
    console.log(printTimestamp(), '>Collapse Details available')
});

And("Cause Name,Description of Cause,Solution Name with priority,Description of Solution,Parts Data for Solution should be displayed", () => {
    createKnowledge.causeNameVisible()
    createKnowledge.descriptionOfCauseVisible()
    createKnowledge.solutionNameVisible()
    createKnowledge.priorityTextVisible()
    createKnowledge.descriptionOfSolutionVisible()
    createKnowledge.partsDataForSolutionVisibel()
    console.log(printTimestamp(), 'Cause Name,Description of Cause,Solution Name with priority,Description of Solution,Parts Data for Solution displayed')
});

And("Tags Data for Solution,Tags Data for Cause,Associations Knowledge name which are associated with cause should be displayed", () => {
    createKnowledge.tagsDataForSolutionVisible()
    createKnowledge.tagsDataForCauseVisible()
    console.log(printTimestamp(), 'Tags Data for Solution,Tags Data for Cause,Associations Knowledge name which are associated with cause displayed')
});

And("Tags and Associations values should be displayed in token should be displayed", () => {
    createKnowledge.tagsDataForSolutionWithTokenVisible()
    createKnowledge.tagsDataForCauseWithTokenVisible()
    console.log(printTimestamp(), 'Tags and Associations values displayed in token')
});

When("User selects multiple row for causes", () => {
    createKnowledge.clearAllFilterButtonClick()
    cy.wait(2000)
    createKnowledge.secondCauseSelected()
    createKnowledge.thirdCauseSelected()
    createKnowledge.firstCauseSelected()
    cy.wait(2000)
    createKnowledge.lastestSelectedCasueText()
    console.log(printTimestamp(), 'selects multiple row for causes')
});

Then("latest selected cause details should be displayed at right side section", () => {
    createKnowledge.lastestSelectedKnowledgeInRightSection()
    console.log(printTimestamp(), 'latest selected cause details displayed at right side section')
});

When("User selects all row available in current page", () => {
    createKnowledge.selectAllCkeckBoxClick()
    console.log(printTimestamp(), 'selects all row available in current page')
});

Then("first cause displayed in current page should get displayed in right side section", () => {
    createKnowledge.FirstSelectedKnowledgeInRightSection()
    console.log(printTimestamp(), 'first cause displayed in current page displayed in right side section')
});

When("User click on cancel button", () => {
    createKnowledge.cancelButtonClick()
    console.log(printTimestamp(), 'clicked on cancel button')
});

Then("Select Cause pop up should be closed", () => {
    createKnowledge.selectCausePopupNotExist()
    console.log(printTimestamp(), 'Select Cause pop up closed')
});

When("User Click on Select Cause", () => {
    createKnowledge.selectCauseButtonClick()
    console.log(printTimestamp(), 'UClicked on Select Cause')
});

Then("Select All should be available in unchecked state", () => {
    createKnowledge.showAllCheckBoxUnchecked()
    console.log(printTimestamp(), 'Select All available in unchecked state')
});

And("None of data should be available in grid", () => {
    createKnowledge.causeDetailsNotVisible()
    createKnowledge.cancelButtonClick()
    console.log(printTimestamp(), 'None of data available in grid')
});

And("Close DAW application", () => {
    cy.DeleteWorkflow()
    cy.log('Test case executed successfully')
    console.log(printTimestamp(), 'Test case executed successfully')
});