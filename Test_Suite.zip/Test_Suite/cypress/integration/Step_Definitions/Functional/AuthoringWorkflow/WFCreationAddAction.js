/// <reference types="Cypress" /> 
/// <reference types = 'cypress-tags' />

import "../../../../support/index"
import { When, Then, And } from "cypress-cucumber-preprocessor/steps"
import { printTimestamp } from '../../../../support/commands';

import NavigationPanel from "../../../../support/pageObjects/pages/Dashboard/NavigationPanel";
const navigationPanel = new NavigationPanel();
import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();

When("User Clicks on three dots of my pattern", () => {
    createPattern.myPatternThreeDotsClick()
    console.log(printTimestamp(), 'Clicked on three dots of my pattern')
});

Then("Create Pattern option is displayed", () => {
    navigationPanel.createPatternButtonVisible()
    console.log(printTimestamp(), 'Create Pattern option displayed')
});

And("User enter Pattern Information", () => {
    createPattern.createPatternButtonClick()
    cy.wait(3000)
    createPattern.patternNameType()
    createPattern.descriptionType()
    createPattern.orderOfExecutionType()
    console.log(printTimestamp(), 'entered Pattern Information')
});

And("User Click on Import Data Model and Select any Data Model from drop down option", () => {
    createPattern.importDataModelClick()
    createPattern.dataModelDropArrowClick()
    createPattern.dataModelCommonOptionDropArrowClick()
    createPattern.eventLogDataModelClick()
    createPattern.dataModelDropArrowClick()
    console.log(printTimestamp(), 'Clicked on Import Data Model and Selected Data Model from drop down option')
});

And("User Click on Add Condition and Add condition From Data Model or Rule or Pattern", () => {
    createPattern.addConditionTabClick()
    createPattern.addConditionPlusIconClick()
    cy.wait(2000)
    createPattern.formDataModelClick()
    cy.wait(1000)
    createPattern.eventLogAttributeClick()
    createPattern.additionalInfoAttributeClick()
    createPattern.operatorForEventOneClick()
    createPattern.equaltoOperatorClick()
    createPattern.ValueForTestOneType()
    console.log(printTimestamp(), 'Clicked on Add Condition and Add condition From Data Model or Rule or Pattern')
});

Then("Verify that asterisk available for Add Action to display as mandatory field", () => {
    createPattern.addActionWithAsteriskVisible()
    console.log(printTimestamp(), 'Verified that asterisk available for Add Action to display as mandatory field')
});

When("Click on Add Action", () => {
    createPattern.addActionClick()
    console.log(printTimestamp(), 'Clicked on Add Action')
});

Then("Add Action should be expanded", () => {
    createPattern.plusIconUnderAddActionVisible()
    console.log(printTimestamp(), 'Add Action should expanded')
});

And("+ Drop down should be available under Add Action", () => {
    createPattern.plusIconUnderAddActionVisible()
    console.log(printTimestamp(), '+ Drop down available under Add Action')
});

When("User Click  on + drop down", () => {
    createPattern.plusIconUnderAddActionClick()
    cy.wait(1000)
    console.log(printTimestamp(), 'Clicked on + drop down')
});

Then("Raise Alert,Insert Alert,Suppress Alert options should be displayed", () => {
    createPattern.raiseAlertoptionVisible()
    createPattern.insertAlertOptionVisible()
    createPattern.suppressAlertOptionVisible()
    console.log(printTimestamp(), 'Raise Alert,Insert Alert,Suppress Alert options displayed')
});

When("User Select option from drop down option", () => {
    createPattern.raiseAlertOptionClick()
    console.log(printTimestamp(), 'Selects option from drop down option')
});

Then("The selected option should be available as a tag", () => {
    createPattern.raiseAlertSelectedOptionAsATagVisible()
    console.log(printTimestamp(), 'The selected option available as a tag')
});

When("User Select other option from drop down and verify tag", () => {
    createPattern.plusIconUnderAddActionClick()
    cy.wait(1000)
    createPattern.insertAlertOptionClick()
    console.log(printTimestamp(), 'Selects other option from drop down and verify tag')
});

Then("The selected option should be available  as a tag", () => {
    createPattern.insertAlertSelectedOptionAsATagVisible()
    console.log(printTimestamp(), 'The selected option available as a tag')
});

When("User Click on X mark of tag", () => {
    createPattern.crossMarkOfTagClick()
    console.log(printTimestamp(), 'Clicked on X mark of tag')
});

Then("Value for Add Action should get removed", () => {
    createPattern.addActionValueNotExist()
    console.log(printTimestamp(), 'Value for Add Action gets removed')
});

And("Data should be matched between db and UI for Add Action Table Name - Public.action", () => {

    console.log(printTimestamp(), 'Data matched between db and UI for Add Action Table Name - Public.action')
});


