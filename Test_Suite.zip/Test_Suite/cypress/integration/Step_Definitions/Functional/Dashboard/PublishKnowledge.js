/// <reference types="Cypress" />
/// <reference types = 'cypress-tags' />

import "../../../../support/index";
import { When, Then, And } from "cypress-cucumber-preprocessor/steps";
import { printTimestamp } from '../../../../support/commands';

import CreatePattern from "../../../../support/pageObjects/pages/PatternAuthoring/CreatePattern";
const createPattern = new CreatePattern();
import KnowledgeDashboard from "../../../../support/pageObjects/pages/Knowledge_Dashboard/KnowledgeDashboard";
const knowledgeDashboard = new KnowledgeDashboard();
import IncludeKnowledge from "../../../../support/pageObjects/pages/PatternAuthoring/includeKnowledgepageObj";
const includeKnowledge = new IncludeKnowledge();

When("User Navigates to knowledge dashboard", () => {
    knowledgeDashboard.knowledgeClick()
    knowledgeDashboard.knowledgeDashboardClick()
    console.log(printTimestamp(), ' Navigated to knowledge dashboard')
})

Then("Verifies publish options in knowledge dashboard", () => {
    knowledgeDashboard.publishButtonVisibleAsDisabled()
    knowledgeDashboard.firstKnowledgeRecordThreeDotClick()
    knowledgeDashboard.publishButtonInThreeDotsVisibleAsDisabled()
    knowledgeDashboard.lastRecordClickInDashboard()
    knowledgeDashboard.publishButtonInsideWFVisibleAsDisabled()
    console.log(printTimestamp(), ' Verified publish options in knowledge dashboard')
})

Then("Selects Valid Draft Knowledge and Verify publish button", () => {
    knowledgeDashboard.addKnowledgeClick()
    cy.CreateMyKnowledge()
    knowledgeDashboard.saveAsDraftButtonClick()
    cy.wait(3000)
    createPattern.breadcumbLastValueCapture()
    knowledgeDashboard.knowledgeDashboardClick()
    knowledgeDashboard.modalitySelection()
    cy.wait(4000)
    knowledgeDashboard.firstRecordClickInDashboard()
    knowledgeDashboard.publishButtonInsideWFVisibleAsEnabled()
    console.log(printTimestamp(), ' Selected Valid Draft Knowledge and Verify publish button')
})

Then("Selects Invalid Knowledge or other than Draft state knowledge and Verify publish button", () => {
    knowledgeDashboard.backPageClick()
    knowledgeDashboard.LastCheckboxClickInKnowledgeRecord()
    knowledgeDashboard.publishButtonVisibleAsDisabled()
    knowledgeDashboard.firstKnowledgeRecordThreeDotClick()
    knowledgeDashboard.publishButtonInThreeDotsVisibleAsDisabled()
    console.log(printTimestamp(), ' Selected Invalid Knowledge or other than Draft state knowledge and Verify publish button')
})

And("Selects valid Draft knowledge and verifies pop up", () => {
    createPattern.knowledgeNameType()
    cy.wait(2000)
    knowledgeDashboard.FirstCheckboxClickInKnowledgeRecord()
    knowledgeDashboard.publishButtonVisibleAsEnabled()
    knowledgeDashboard.firstRecordThreeDotsClick()
    knowledgeDashboard.publishButtonInThreeDotsVisibleAsEnabled()
    knowledgeDashboard.publishButtonInThreeDotsClick()
    console.log(printTimestamp(), ' Selected valid Draft knowledge and verifies pop up')
})

Then("Clicks on cancel button from pop up and verify selected knowledge", () => {
    knowledgeDashboard.cancelButtonInPopUpClick()
    knowledgeDashboard.firstRecordThreeDotsClick()
    knowledgeDashboard.publishButtonInThreeDotsVisibleAsEnabled()
    console.log(printTimestamp(), ' Clicked on cancel button from pop up and verify selected knowledge')
})

Then("Clicks on publish button from pop up and verify selected knowledge", () => {
    knowledgeDashboard.publishButtonInThreeDotsClick()
    knowledgeDashboard.popUpOkButtonClick()
    cy.wait(3000)
    console.log(printTimestamp(), ' Clicked on publish button from pop up and verify selected knowledge')
})

When("User Navigates to Include Knowledge step in Patterns and verify published knowledge", () => {
    console.log(printTimestamp(), ' User Navigated to Include Knowledge step in Patterns and verify published knowledge')
})

Then("Navigates to knowledge workflow and verify published knowledge's cause and symptom in Select Cause and Select Symptom pop up", () => {
    knowledgeDashboard.firstRecordClickInDashboard()
    knowledgeDashboard.symptomsDataInPopupVisible()
    knowledgeDashboard.causeDataInPopupVisible()
    knowledgeDashboard.solutionsDataInPopupVisible()
    console.log(printTimestamp(), ' Navigated to knowledge workflow and verify published knowledges cause and symptom')
})       

Then("Selects multiple valid and invalid knowledge and verify publish button", () => {
    knowledgeDashboard.backPageClick()
    createPattern.knowledgeNameClear()
    cy.wait(2000)
    knowledgeDashboard.FirstCheckboxClickInKnowledgeRecord()
    knowledgeDashboard.LastCheckboxClickInKnowledgeRecord()
    knowledgeDashboard.publishButtonVisibleAsDisabled()
    console.log(printTimestamp(), ' Selected multiple valid and invalid knowledge and verify publish button')
})

Then("Selects multiple valid draft knowledge and click on publish button", () => {
    knowledgeDashboard.knowledgeStatusColumnClickAndDraftSelection()
    cy.wait(3000)
    knowledgeDashboard.multipleRecordsClickInKnowledgeRecord()
    knowledgeDashboard.publishButtonClickFromDashboard()
    knowledgeDashboard.cancelButtonInPopUpClick()
    console.log(printTimestamp(), ' Selected multiple valid draft knowledge and click on publish button')
})  

When("User Navigate to my knowledge dashboard and verify publish button", () => {  
    knowledgeDashboard.myKnowledgeDashboardClick()
    knowledgeDashboard.publishButtonInDashboardNotExist()
    console.log(printTimestamp(), ' User Navigated to my knowledge dashboard and verify publish button')
})

Then("Publish multiple valid knowledge with existing association", () => {  
    console.log(printTimestamp(), ' Publish multiple valid knowledge with existing association')
})

And("Validate pattern details", () => {  
    createPattern.knowledgeNameType()
    cy.wait(2000)
    knowledgeDashboard.FirstCheckboxClickInKnowledgeRecord()
    cy.wait(3000)
    knowledgeDashboard.deleteKnowledge()
    console.log(printTimestamp(), ' Validate pattern details')
})